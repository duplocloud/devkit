# @duplocloud-internal/ng-common-lib

Shared **Angular** UI library for DuploCloud apps — components, services, models, pipes, directives, and utilities. Published to **GitHub Packages**.

> Requires Angular **22.1.x**. Other major versions are not supported.

---

## 1. Configure the registry

This package lives on GitHub Packages under the `@duplocloud-internal` scope.

**Project `.npmrc`** (committed — registry mapping only, no token):
```
@duplocloud-internal:registry=https://npm.pkg.github.com
```

**One-time auth, per machine** — put your token in your *global* `~/.npmrc` (not the project). After this, `npm install` just works in any project, with no per-install step:
```bash
# if you use the GitHub CLI:
npm config set //npm.pkg.github.com/:_authToken=$(gh auth token) --location=user

# or paste a Personal Access Token (classic) with read:packages scope:
npm config set //npm.pkg.github.com/:_authToken=ghp_xxxxxxxx --location=user
```

> You must be a member of the `duplocloud-internal` org with package read access. CI needs no setup — `GITHUB_TOKEN` is injected automatically.

## 2. Install

```bash
npm install @duplocloud-internal/ng-common-lib
```

Strict npm resolution — **no `--legacy-peer-deps`**. Install the **peer dependencies** too (most already exist in an Angular 22 app):

`@angular/core`, `@angular/common`, `@angular/forms`, `@angular/router`, `@angular/platform-browser`, `@angular/cdk`, `@angular/material` (all `^22.1.0`), `rxjs@^7.8.0`, `@ng-bootstrap/ng-bootstrap@^21.0.0`, `@ng-select/ng-select@^23.5.1`, `@ngbracket/ngx-layout@^22.0.1`, `@ngx-translate/core@^18.0.0`, `@swimlane/ngx-datatable@^25.0.0`, `ngx-echarts@^22.0.0`, `ngx-markdown@^22.0.0`, `ngx-monaco-editor-v2@^22.0.4`, `ngx-toastr@^20.0.5`, `angularx-flatpickr@^8.1.0`, `echarts@^6.1.0`, `marked@^18.0.7`, `flatpickr@^4.6.9`, `@popperjs/core@^2.11.8`, `monaco-editor@^0.55.1`.

> **ngx-toastr caveat**: there is currently no Angular-22 release of `ngx-toastr` on npm. Mirror the portal's own `package.json` `overrides` block so it resolves against your app's `@angular/core`/`@angular/common`:
> ```json
> "overrides": {
>   "ngx-toastr": {
>     "@angular/common": "$@angular/common",
>     "@angular/core": "$@angular/core"
>   }
> }
> ```

`ng-block-ui` is **not** on this list — it ships bundled inside the package. See [§6](#6-loading-overlays-ng-block-ui).

---

## 3. Set up in your `AppModule`

```typescript
import {
  CommonLibModule,            // runtime config (forRoot)
  CommonLibComponentsModule,  // datatables, modals, viewers, cards, BlockUI…
  CoreCommonModule,           // feather-icon / ripple directives + core pipes
  SharedFormsModule,          // form fields + validators
  BlockUIModule,              // loading overlay (bundled ng-block-ui fork)
} from '@duplocloud-internal/ng-common-lib';
import { environment } from '../environments/environment';

@NgModule({
  imports: [
    CommonLibModule.forRoot({
      apiUrl: environment.apiUrl,         // base URL for DuploApiInterceptor
      mixpanelToken: environment.mixpanelToken,  // optional; empty = analytics off
    }),
    BlockUIModule.forRoot(),
    CommonLibComponentsModule,
    CoreCommonModule,
    SharedFormsModule,
  ],
})
export class AppModule {}
```

`CommonLibModule.forRoot(...)` is called **once** at the app root. All fields are optional — omitted values fall back to defaults (`apiUrl: '/'`, analytics off).

---

## 4. Use it

```typescript
import {
  ConfirmationModalService,
  FilterTableUtils,
  DuploHttpClient,
  EnumUtils,
  YamlUtils,
} from '@duplocloud-internal/ng-common-lib';
```

```html
<searchable-datatable [rows]="rows" [columns]="columns"></searchable-datatable>
<view-with-sidecards> … </view-with-sidecards>
<status-with-style [status]="status"></status-with-style>
```

**Standalone components** (e.g. `SpinnerComponent`, `YamlSnippetEditorComponent`) — import directly into a component's `imports`, no module needed:

```typescript
import { SpinnerComponent } from '@duplocloud-internal/ng-common-lib';

@Component({ standalone: true, imports: [SpinnerComponent], /* … */ })
export class MyComponent {}
```

---

## 5. Host responsibilities (contracts the library can't own)

- **`window.appBrandTitle`** — some components/models read this global. Set it before common-lib renders (e.g. in `index.html` or app bootstrap).
- **App initialization** — the library does **not** ship an `APP_INITIALIZER`. If you need to preload `SystemFeatures` before bootstrap, provide your own factory.

---

## 6. Loading overlays (ng-block-ui)

`ng-block-ui` is a DuploCloud-maintained fork, built as its own Angular library and shipped **inside** the `ng-common-lib` tarball (`bundleDependencies` → a nested `node_modules/ng-block-ui`). You never install it separately — every symbol is re-exported through `@duplocloud-internal/ng-common-lib`.

**Setup** — import `BlockUIModule` once at the app root (already shown in [§3](#3-set-up-in-your-appmodule)):
```typescript
import { BlockUIModule } from '@duplocloud-internal/ng-common-lib';

@NgModule({ imports: [BlockUIModule.forRoot()] })
export class AppModule {}
```

**Template directive** — wrap the region to block with `*blockUI`, naming the instance:
```html
<div *blockUI="'myBlock'">
  … content that gets covered by the spinner …
</div>
```

**Component decorator** — bind a named instance and drive it from code:
```typescript
import { BlockUI, NgBlockUI } from '@duplocloud-internal/ng-common-lib';

@Component({ /* ... */ })
export class MyComponent {
  @BlockUI('myBlock') blockUI: NgBlockUI;

  load() {
    this.blockUI.start('Loading...');
    // ...
    this.blockUI.stop();
  }
}
```
`NgBlockUI` also exposes `.update(message)` (change the message on an active block) and `.reset()` (force-clear regardless of nested start-call count).

**Global blocking** — omit the name to drive the app-wide instance:
```typescript
@BlockUI() blockUI: NgBlockUI;
```

**Service alternative** — inject `BlockUIService` to start/stop one or more named blocks without a decorator, e.g. from a guard or interceptor:
```typescript
import { BlockUIService } from '@duplocloud-internal/ng-common-lib';

constructor(private blockUIService: BlockUIService) {}

this.blockUIService.start('myBlock', 'Loading...');
this.blockUIService.stop('myBlock');
this.blockUIService.update('myBlock', 'Almost done...');
this.blockUIService.reset('myBlock');           // or an array of names
this.blockUIService.resetGlobal();              // resets every instance
```

**In-repo (portal / ai-studio) developers**: the fork's source lives at `common-lib/ng-block-ui/`, not inside `common-lib/` proper. It is built to `dist/ng-block-ui` once per install by a guarded `postinstall` script (`scripts/postinstall-build-block-ui.js`), which no-ops on dependency-only layers (e.g. the Docker builder stage) where `angular.json` isn't present yet. If you edit the fork's source, rebuild it manually with `npm run build:block-ui` before your changes show up. It's shared as a **native-federation singleton** (`ng-block-ui` → `portal/dist/ng-block-ui`), so the portal host and the AI Studio remote share one BlockUI world — a block started from one is visible/controllable from the other.

---

## 7. Kubernetes explorer

`K8sExplorerComponent` (`<app-k8s-explorer>`) is a Lens-style view of one Kubernetes scope: categories on the left, a list per kind (the namespace filter shows only for namespaced kinds), a details panel, and a bottom dock with kubectl, pod shell and logs tabs. It calls the existing AI Studio endpoints itself through the host's `REMOTE_DuploHttpClient`, so a scope id is the only thing a host has to pass. It has no routes and needs a bounded height.

```typescript
import { K8sExplorerComponent } from '@duplocloud-internal/ng-common-lib';

@Component({
  standalone: true,
  imports: [K8sExplorerComponent],
  template: `<app-k8s-explorer [scopeId]="scopeId" style="display:block;height:calc(100vh - 10rem)"></app-k8s-explorer>`,
})
export class MyClusterPage {
  scopeId = '…';
}
```

| Input | Default | Purpose |
|---|---|---|
| `scopeId` | required | The Kubernetes scope to explore. |
| `workspaceId` | session's AI workspace | Workspace for the user endpoints. |
| `mode` | `'user'` | `'admin'` uses the admin endpoints (no restart or delete). |
| `scopeHint` | — | Optional, admin mode: the scope's name, provider and whether it uses a static token. The admin endpoints don't return them; without it the scope shows by its id and is treated as not static-token, so the static-token gating for terminals doesn't apply. |
| `api` | built-in | A `K8sExplorerApi` plain object, e.g. to proxy through an extension's own controller. A missing optional method hides the action it backs. |
| `kinds` | all | Registry ids to show, e.g. `['overview', 'pods', 'events']`. |
| `state` / `(stateChange)` | — | Kind, namespace (`'*'` = all) and open object, for URL sync. |
| `namespaces`, `lockNamespace` | — | Narrow or pin the namespace filter. |
| `readOnly` | `false` | Hides the REST and typed actions that change the cluster (scale, restart, delete, edit and the like). |
| `features` | all on | `terminal`, `logs`, `actions`, `secretReveal`. |
| `refreshIntervalMs` | `10000` | Auto-refresh for the visible list; "All namespaces" across more than 5 namespaces refreshes every 30s. |
| `autoRefresh` | `true` | Starts with auto-refresh on; the user can still toggle it in the toolbar. |
| `fanOutConcurrency` | `4` | Namespace requests run at once for "All namespaces" (each fan-out on its own; the Overview runs two). |
| `showScopeName` | `true` | Turn off when you project your own scope picker into the toolbar. |
| `canSwitchScope` | `false` | Set when your picker offers other scopes, so a scope that can't be opened also suggests picking another one. |
| `fitViewport` | `false` | Sizes the explorer from its top edge to the bottom of the window. |

The explorer spends no row on page chrome. Its top row has the page title over the sidebar, then the toolbar: the scope's name, then auto-refresh, Refresh, kubectl and kubeconfig download. To let users switch scopes, project your own picker with `k8sExplorerScope`: it goes into the toolbar in place of the scope's name, at the width you give it, and stays there when the sidebar is collapsed.

```html
<app-k8s-explorer [scopeId]="scopeId" [showScopeName]="false" [fitViewport]="true">
  <app-list-filter-select k8sExplorerScope width="18.75rem" label="Scope" [options]="scopes" [value]="scopeId" (valueChange)="pick($event)" />
</app-k8s-explorer>
```

Each kind's table, filter pills and extra columns come from its registry entry: `facet` buckets rows for the pills (ReplicaSets open on `Active`, cluster roles on `Custom`), and `enrich` fills columns that need pods from elsewhere (pods and CPU/memory requests per node and namespace, pods using a claim) after the rows are on screen.

The host must provide:

- `REMOTE_DuploHttpClient` and `REMOTE_UserSession` (every AI Studio route and extension already has them).
- A toastr setup, for errors and confirmations.
- `BlockUIModule.forRoot()` at the app root ([§6](#6-loading-overlays-ng-block-ui)): the list and Overview use block-UI overlays while they load.
- ng-bootstrap modals (`NgbModal`, from `NgbModule` or `NgbModalModule`): Restart and Delete pod confirm through `ConfirmationModalService`.
- The xterm stylesheet served at `assets/css/xterm/xterm.css`, which the kubectl and shell tabs load at runtime. In `angular.json`, add an asset `{ "glob": "xterm.css", "input": "./node_modules/@xterm/xterm/css", "output": "assets/css/xterm" }`.

Secret values are masked in the UI; the backend still returns them, so treat Secrets as visible to anyone with access to the scope.

---

## 8. Connections

A connection is a provider, a credential and a scope, created together. The kit lets an agent offer that in three levels. Each level is built from the one below.

The kit may register a provider type when the `typeDefinition` you give is not registered yet. It never updates an existing type. It never changes or deletes existing providers, credentials or scopes. Admin → Providers is untouched.

That check (`ensureType`, which may register the type) runs early, not only on Connect: when a provider picker with a `typeDefinition` renders, when the credential form's "+ New credential" opens, and when level 1's modal opens.

**Host token:** provide `REMOTE_DuploHttpClient`. Without it every call fails with `ConnectionsService: REMOTE_DuploHttpClient is not provided.` (an error on the Observable).

Level 1, level 3, the provider picker and the credential form take an optional `typeDefinition` (a `ConnectionTypeDefinition`). The scope picker does not. Level 1 emits, and level 3 returns, `{ providerId, credentialName, scopeId }`. Level 2 gives three separate values.

```typescript
import { ConnectionTypeDefinition } from '@duplocloud-internal/ng-common-lib';

const clickUpType: ConnectionTypeDefinition = {
  type: 'clickup',
  label: 'ClickUp',
  category: 'other',
  credentialSchema: { fields: [{ key: 'apiToken', label: 'API token', htmlType: 'password', sensitive: true, required: 'always' }] },
};
```

### Level 1. Ready flow

`<duplo-connection-field>` lists existing connections, opens a modal for "+ New" and shows Connected. The `ngModel` value is the scope id. `(connected)` emits a `ConnectionResult` on every pick or create.

```typescript
import { ConnectionFieldComponent } from '@duplocloud-internal/ng-common-lib';
// imports: [FormsModule, ConnectionFieldComponent]
```
```html
<duplo-connection-field
  category="other"
  [typeDefinition]="clickUpType"
  [(ngModel)]="settings.clickUp.scopeId"
  (connected)="onConnected($event)">
</duplo-connection-field>
```

Inputs: `category` (required), `type`, `typeDefinition`, `label`. Without a type or type definition, "+ New" is hidden.

### Level 2. Parts

One component per piece. You arrange them in your own page, wizard or modal. Each is a form control (`ngModel`).

| Component | Value | Inputs |
|---|---|---|
| `<duplo-provider-picker>` | provider id | `category` (required), `type`, `typeDefinition` |
| `<duplo-credential-form>` | credential name | `providerId` (required), `typeDefinition` |
| `<duplo-scope-picker>` | scope id | `providerId` (required), `credentialName` (required) |

```html
<duplo-provider-picker category="other"
  [typeDefinition]="jiraType"
  [(ngModel)]="providerId"></duplo-provider-picker>

<duplo-credential-form [providerId]="providerId"
  [typeDefinition]="jiraType"
  [(ngModel)]="credentialName"></duplo-credential-form>

<duplo-scope-picker [providerId]="providerId"
  [credentialName]="credentialName"
  [(ngModel)]="scopeId"></duplo-scope-picker>
```

Import `ProviderPickerComponent`, `CredentialFormComponent` and `ScopePickerComponent`.

### Validation

No component renders a `required` message. Add `required` to the element, and your own message if you need one.

Error keys your form can see on these controls:

| Key | Control | When |
|---|---|---|
| `connectionNotFound` | `<duplo-connection-field>` | The loaded list lacks the value (for example, the scope was deleted). |
| `providerPending` | `<duplo-provider-picker>` | "+ New provider" is open and not added yet. |
| `providerNotFound` | `<duplo-provider-picker>` | The loaded list lacks the value. |
| `credentialPending` | `<duplo-credential-form>` | "+ New credential" is open and not added yet. |
| `credentialNotFound` | `<duplo-credential-form>` | The loaded list lacks the value. |
| `scopePending` | `<duplo-scope-picker>` | "+ New scope" is open and not added yet. |
| `scopeNotFound` | `<duplo-scope-picker>` | The loaded list lacks the value. |

A not-found value shows as a disabled "… not found" option. The check waits for the list: while it loads, or after it fails, the value is kept and counts as valid. So you can move a saved value between levels without changing it.

### Level 3. Functions

No UI. `ConnectionsService` is `providedIn: 'root'`. Every method returns a cold Observable: each subscription runs the call again. Concurrent `ensureType` calls for the same type share one run.

```typescript
import { ConnectionsService } from '@duplocloud-internal/ng-common-lib';

private connections = inject(ConnectionsService);

// one shot: type + provider + credential + scope
this.connections.connect({
  category: 'other',
  typeDefinition: slackType,
  name: 'acme-slack',
  values: { botToken },
}).subscribe(c => { /* { providerId, credentialName, scopeId } */ });
```

Retry after a failure: keep `err.partial` and pass it as `resume` on the next call.

```typescript
import { ConnectionError, ConnectionResult, ConnectionsService, ConnectRequest } from '@duplocloud-internal/ng-common-lib';

private readonly connections = inject(ConnectionsService);
private botToken = '';
private name = 'acme-slack';
private partial: Partial<ConnectionResult> | undefined;

/** Runs on Connect, and again on Try again after a failure. */
connectSlack(): void {
  const request: ConnectRequest = {
    category: 'other',
    typeDefinition: slackType,
    name: this.name,
    values: { botToken: this.botToken },
    ...(this.partial ? { resume: this.partial } : {}),
  };
  this.connections.connect(request).subscribe({
    next: result => {
      this.partial = undefined;
      this.save(result.scopeId);
    },
    error: (err: unknown) => {
      this.partial = err instanceof ConnectionError ? err.partial : undefined;
    },
  });
}
```

A provider-step failure has an empty `partial`: nothing was created, so change `name` before retrying. A scope-step failure has `partial.providerId`: the retry only creates the scope, and `name` names only the scope, so you can change it if the first one was taken.

Step by step:

```typescript
connections.ensureType(def)
connections.listProviders({ category, type })
connections.createProvider({ category, type, name, credentialName, values, schema })
connections.listCredentials(providerId)
connections.addCredential(providerId, name, values, schema)
connections.listScopes({ providerId, credentialName })
connections.createScope({ providerId, credentialName, name })
connections.listConnections({ category, type })
```

`createProvider`, `addCredential` and `createScope` check the name before any request: the provider rule for providers, the scope rule for credentials and scopes. A bad name fails with a `ConnectionError` whose `step` is `'validation'`.

### Limits

- Scopes are created with an empty resource map and providers with no account id. This suits generic and custom categories. Cloud categories (account id required) and the LLM category are not supported. Use Admin → Providers there.
- `connect()` creates on every subscription. Subscribe once.
- A failed run never deletes what it created. Retry with `resume: error.partial`. `error` is a `ConnectionError`.
- A failed provider step cannot be resumed. Retry with another name.
- Provider and scope names are saved in lowercase. Each must be unique across all providers and all scopes, not just the category. A clash fails with the backend's message, shown inline.
- The connection name must satisfy the scope-name rule, because it names both the provider and the scope.

---

## What's inside

| Area | Highlights |
|---|---|
| **Components** | `SearchableDataTableComponent`, `ServersideDataTableComponent`, `TokenPaginatedDataTableComponent`, `ConfirmationModalComponent` (+service), `ViewJson/ViewYaml`, `ViewWithSidecardsComponent`, `ScrollableNavTabComponent`, `StatusWithStyleComponent`, `MiniCardComponent`, `CodeBlockWithCopyComponent`, xterm blocks, `K8sExplorerComponent` (see [§7](#7-kubernetes-explorer)), connections kit (see [§8](#8-connections)) |
| **Forms** (`SharedFormsModule`) | `GenericFormFieldComponent`, `PasswordFieldComponent`, key-value fields, validation directives (`validation-state`, `validation-errors`, INI/XML/YAML), custom validators (email, URL, IP, CIDR) |
| **Services** | `DuploHttpClient` / `DuploCiHttpClient` (SSE via `loadEventSource`), `CoreConfigService`, `CoreMenuService`, `DuploToastrService`, `ClipboardService`, `SubDestroyService`, `MixpanelService` |
| **Models** | `UserSession`, `SystemFeatures`, `TenantFeatures`, `Infrastructure`, `AdminTenant`, `CloudPlatform`/`K8sPlatform`/`UserRole` enums, `KeyValuePair` |
| **Pipes** (`CoreCommonModule`) | `PrettyJson`, `PrettyYaml`, `TimeAgo`, `Initials`, `Filter`, `OrderBy`, `Safe` |
| **Directives** (`CoreCommonModule`) | `FeatherIconDirective`, `RippleEffectDirective` |
| **Utils** | `FilterTableUtils`, `EnumUtils`, `YamlUtils`, `JSONUtils`, `StringUtils`, `DateUtils`, `extractErrorMessage`, `SharedAlertsService` |
| **BlockUI** (bundled `ng-block-ui` fork — see [§6](#6-loading-overlays-ng-block-ui)) | `BlockUIModule`, `BlockUIService`, `@BlockUI` decorator, `NgBlockUI`, `[blockUI]`/`*blockUI` directive |

All public symbols are exported from the package root (single barrel):

```typescript
import { /* anything public */ } from '@duplocloud-internal/ng-common-lib';
```

---

## Publishing (maintainers)

Releases are tag-triggered: bump `version` in `common-lib/package.json`, then tag and push `ng-common-lib-v<version>` (must match). The **Publish ng-common-lib** workflow builds and publishes to GitHub Packages. Local dry run: `npm run pack:common-lib` (builds `ng-block-ui`, builds the lib, bundles the fork in, and produces a local tarball via `npm pack`). Full details, including the manual-publish fallback and pre-publish checklist: see `common-lib/PUBLISHING.md`.

---

## Compatibility

| | |
|---|---|
| Angular | 22.1.x (peer) |
| Node (build) | `^22.22.3 \|\| ^24.15.0 \|\| >=26.0.0` |
| Module format | FESM2022 + typings (Ivy partial) |
