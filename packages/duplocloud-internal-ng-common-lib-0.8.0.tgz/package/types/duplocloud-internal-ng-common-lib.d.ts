import * as i28 from 'ng-block-ui';
import { NgBlockUI } from 'ng-block-ui';
export * from 'ng-block-ui';
import * as i0 from '@angular/core';
import { InjectionToken, Type, OnDestroy, OnInit, AfterViewInit, OnChanges, EventEmitter, NgZone, ChangeDetectorRef, ElementRef, SimpleChanges, SimpleChange, TemplateRef, ViewContainerRef, QueryList, Renderer2, PipeTransform, AfterContentInit, SecurityContext as SecurityContext$1, ModuleWithProviders, Injector, Signal } from '@angular/core';
import * as rxjs from 'rxjs';
import { Observable, Subject, OperatorFunction, BehaviorSubject, Subscription } from 'rxjs';
import * as i4 from '@swimlane/ngx-datatable';
import { ColumnMode, DataTableColumnDirective, DatatableRowDetailDirective, DatatableComponent, SortPropDir, HeaderCellContext, CellContext, TableColumn } from '@swimlane/ngx-datatable';
import { TranslateService, TranslationObject } from '@ngx-translate/core';
import * as i3$2 from '@ng-bootstrap/ng-bootstrap';
import { NgbAlert, NgbNav, NgbTooltip, NgbActiveModal, Placement, NgbModalRef, NgbModal, NgbTimeAdapter, NgbTimeStruct } from '@ng-bootstrap/ng-bootstrap';
import { Clipboard } from '@angular/cdk/clipboard';
import * as i30 from 'ngx-toastr';
import { ToastrService, IndividualConfig } from 'ngx-toastr';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, ActivatedRoute, NavigationExtras } from '@angular/router';
import * as _duplocloud_internal_ng_common_lib from '@duplocloud-internal/ng-common-lib';
import * as i3 from '@angular/common';
import { Location } from '@angular/common';
import * as i9 from '@angular/material/icon';
import { MatIconRegistry } from '@angular/material/icon';
import * as i1 from 'ngx-monaco-editor-v2';
import * as i2 from 'ngx-markdown';
import * as i2$1 from '@ngbracket/ngx-layout';
import { MediaObserver } from '@ngbracket/ngx-layout';
import * as i3$1 from '@angular/forms';
import { FormGroupDirective, NgForm, NgControl, ValidationErrors, AbstractControl, AsyncValidator, Validator, ValidatorFn, ControlValueAccessor } from '@angular/forms';
import { DomSanitizer, SafeHtml, SafeStyle, SafeScript, SafeUrl, SafeResourceUrl } from '@angular/platform-browser';
import * as i5 from '@ng-select/ng-select';
import { HttpErrorResponse, HttpClient, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpContextToken, HttpBackend } from '@angular/common/http';
import * as i29 from 'angularx-flatpickr';
import { Diff2HtmlConfig } from 'diff2html';
import { HighlightStyle } from '@codemirror/language';
import { Extension } from '@codemirror/state';
import { ITerminalOptions, ITheme } from '@xterm/xterm';
import { ThemeOption } from 'ngx-echarts';
import { StringKeyOf } from 'ts-enum-util/dist/types/types';
import * as marked from 'marked';
import { Token } from 'marked';

/** IAM-role help sentence; each half drops when its link is null, and both null renders nothing. */
declare class IamRoleHelpComponent {
    readonly docsUrl: i0.InputSignal<string>;
    readonly templateUrl: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IamRoleHelpComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IamRoleHelpComponent, "app-iam-role-help", never, { "docsUrl": { "alias": "docsUrl"; "required": false; "isSignal": true; }; "templateUrl": { "alias": "templateUrl"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** ISO 42001 point-of-use AI disclosure. config.json `text.aiDisclosure` overrides `defaultText`. */
declare class AiDisclosureComponent {
    readonly defaultText: i0.InputSignal<string>;
    readonly text: i0.Signal<string>;
    readonly link: string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<AiDisclosureComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AiDisclosureComponent, "app-ai-disclosure", never, { "defaultText": { "alias": "defaultText"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Value injected into a canvas renderer component. Renderers read the doc id and its content stream from
 * here instead of an `@Input()` — `ngComponentOutlet` (Angular 15) cannot bind component inputs, so the
 * host hands the renderer its data through a per-canvas injector carrying this token.
 */
interface CanvasDoc {
    docId: string;
    content$: Observable<string>;
}
declare const CANVAS_DOC: InjectionToken<CanvasDoc>;
/**
 * Describes how to render a canvas document (an agent artifact opened in the canvas panel). An extension
 * registers one of these from its ticket wrapper so its own canvas files render its own component, with no
 * host code change. The match predicate decides which artifacts this renderer claims.
 */
interface CanvasRendererDescriptor {
    /** Unique id, e.g. 'tf:extracted-environments'. Re-registering the same id replaces the prior descriptor. */
    id: string;
    /** Canvas tab title. */
    title: string;
    /** Whether the canvas shows the Edit/Save controls. Defaults to false. */
    isEditable?: boolean;
    /** Higher wins on overlapping matches. Defaults to 0; extensions use a positive value (e.g. 10). */
    priority?: number;
    /** Returns true for artifacts this renderer should claim (matched against `artifact.id`). */
    match: (artifact: {
        id?: string;
    }) => boolean;
    /** Component to instantiate for the canvas. */
    component: Type<unknown>;
    /** Optional module that declares/provides `component` — required for components from a Module-Federation
     *  remote so the host can build them with their own module providers. */
    ngModule?: Type<unknown>;
}
/** Host-owned registry of canvas renderers; extensions and DevOps reach it via `REMOTE_CanvasRendererRegistry`.
 *  Built-in canvases (stage board, dashboard instance) keep their hard-coded path. */
declare class CanvasRendererRegistry {
    private readonly byId;
    private order;
    /** Register (or replace by id) a renderer. Idempotent, so re-entering a ticket is safe. */
    register(descriptor: CanvasRendererDescriptor): void;
    unregister(id: string): void;
    get(id: string | undefined): CanvasRendererDescriptor | undefined;
    /** First renderer (by priority desc, then registration order) whose predicate claims the artifact. */
    match(artifact: {
        id?: string;
    }): CanvasRendererDescriptor | undefined;
    private reindex;
    static ɵfac: i0.ɵɵFactoryDeclaration<CanvasRendererRegistry, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CanvasRendererRegistry>;
}

type MiniHelpDeskFieldState = 'shown' | 'hidden' | 'disabled';
interface MiniHelpDeskField<T> {
    value?: T;
    state?: MiniHelpDeskFieldState;
}
interface MiniHelpDeskFields {
    message?: MiniHelpDeskField<string>;
    /** Model id, modelId or display name. */
    llmModel?: MiniHelpDeskField<string>;
    /** Ids or names. */
    scopes?: MiniHelpDeskField<string[]>;
    files?: MiniHelpDeskField<File[]>;
    slashSkills?: {
        state?: MiniHelpDeskFieldState;
    };
    /** Ids or names. */
    personas?: MiniHelpDeskField<string[]>;
    /** Ids or names. */
    skills?: MiniHelpDeskField<string[]>;
    memory?: MiniHelpDeskField<boolean>;
    autoApprove?: MiniHelpDeskField<boolean>;
}
type MiniHelpDeskFieldKey = keyof MiniHelpDeskFields;
interface MiniHelpDeskOrigin {
    type: string;
    subType?: string;
    id?: string;
}
interface MiniHelpDeskTicketRef {
    name: string;
    id?: string;
    title?: string;
    originContext?: MiniHelpDeskOrigin;
}
type MiniHelpDeskUrl = string | ((ticket: MiniHelpDeskTicketRef) => string);
interface MiniHelpDeskCommandRules {
    approvedCmdRegEx?: string[];
    rejectedCmdRegEx?: string[];
}
interface MiniHelpDeskPromptSuggestion {
    text: string;
    scopeIds?: string[];
    permission?: MiniHelpDeskCommandRules;
}
interface MiniHelpDeskPromptTemplate {
    name: string;
    description?: string;
    content: string;
    scopeIds?: string[];
    permission?: MiniHelpDeskCommandRules;
}
interface MiniHelpDeskHeader {
    title: string;
    subtitle?: string;
    source?: string;
}
interface MiniHelpDeskOpenConfig {
    fields?: MiniHelpDeskFields;
    advancedExpanded?: boolean;
    systemPrompt?: string;
    resourceContext?: string;
    origin?: MiniHelpDeskOrigin;
    tickets?: string[];
    allFallback?: boolean;
    ticketsLabel?: string;
    promptSuggestions?: MiniHelpDeskPromptSuggestion[];
    promptTemplates?: MiniHelpDeskPromptTemplate[];
    afterCreate?: {
        navigateTo?: MiniHelpDeskUrl;
    };
    fullViewUrl?: MiniHelpDeskUrl;
    header?: MiniHelpDeskHeader;
}

/** Host-singleton bridge between callers and the mini help desk widget. Inject via REMOTE_MiniHelpDesk, never by class. */
declare class MiniHelpDeskBridge {
    private readonly available;
    private readonly openRequests;
    readonly available$: Observable<boolean>;
    readonly open$: Observable<MiniHelpDeskOpenConfig>;
    get isAvailable(): boolean;
    /** Widget only. */
    setAvailable(available: boolean): void;
    open(config?: MiniHelpDeskOpenConfig): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<MiniHelpDeskBridge, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MiniHelpDeskBridge>;
}

declare class SubDestroyService extends Subject<void> implements OnDestroy {
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubDestroyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubDestroyService>;
}

declare class SearchableDatatableExtraAction {
    name: string;
    label: string;
    icon?: string;
    class?: string;
    isMenu?: boolean;
    helpKey?: string;
    isServiceAction?: boolean;
    restrictAccessForReadonlyUser?: boolean;
    constructor(attrs?: Partial<SearchableDatatableExtraAction>);
}

interface FilterChangeEvent {
    searchTerm: string;
}
declare class SearchableDatatableComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
    private zone;
    private _changeDetector;
    private elRef;
    private i18n;
    /** Whether or not to show the add button. */
    showAdd: boolean;
    addLabel: string;
    _disableAdd: boolean;
    _disableMessage: string;
    set disableAddWithAMessage(message: string);
    /** Whether or not to filter input. */
    showFilter: boolean;
    showCount: boolean;
    showEdit: boolean;
    showNew: boolean;
    showForceRefresh: boolean;
    extraActions: SearchableDatatableExtraAction[];
    loadingIndicator: boolean;
    extraButtonsAvailable: boolean;
    extraActionsButtonCaption: string;
    /** Whether or not to reset the view (pagination, etc.) when the rows change */
    resetOnChange: boolean;
    _rows: any[];
    rowsPerPage: number;
    rowsPerPageOptions: number[];
    columnMode: ColumnMode;
    includeHeader: boolean;
    isActionsFixed: boolean;
    footerHeight: number | boolean;
    searchTerm: string;
    set rows(rows: any[]);
    /** Properties for multiselect rows */
    enableCheckboxSelection: boolean;
    displayCheck: () => boolean;
    selected: any[];
    selectionType: any;
    getRowId: (x: any) => any;
    serviceActionFilter: (action: SearchableDatatableExtraAction, selectedServices: unknown[]) => boolean;
    /** To show alert message based on condition */
    showAlert: boolean;
    alertMessage: NgbAlert;
    columnTemplates: i0.Signal<readonly DataTableColumnDirective<any>[]>;
    tableColumns: i0.Signal<i4.TableColumn<any>[]>;
    rowDetailTpl?: DatatableRowDetailDirective;
    ownRowDetail?: DatatableRowDetailDirective;
    private rowDetailBridge?;
    table: DatatableComponent;
    add: EventEmitter<void>;
    action: EventEmitter<string>;
    edit: EventEmitter<void>;
    outputNewItem: EventEmitter<void>;
    forceRefresh: EventEmitter<void>;
    filter: EventEmitter<FilterChangeEvent>;
    select: EventEmitter<void>;
    skipResetOnce: boolean;
    isFixed: boolean;
    externalPaging: boolean;
    externalSorting: boolean;
    /** Sort to apply; a new array replaces the current sort (e.g. to restore one kept across re-renders). */
    sorts: SortPropDir[];
    totalCount: number;
    pageNumber: number;
    onPage: EventEmitter<{
        pageNumber: number;
        pageSize: number;
        totalCount: number;
    }>;
    onSort: EventEmitter<{
        sortBy: string;
        sortOrder: string;
    }>;
    constructor(zone: NgZone, _changeDetector: ChangeDetectorRef, elRef: ElementRef, i18n: TranslateService);
    addItem(): void;
    editItem(): void;
    emitNewItem(): void;
    emitRefresh(): void;
    getButtons(): SearchableDatatableExtraAction[];
    getMenus(): SearchableDatatableExtraAction[];
    getServiceActions(): SearchableDatatableExtraAction[];
    areAllButtonsRestricted(): void;
    hasMenus(): boolean;
    /** Resets the view (pagination, etc.) */
    reset(): void;
    extraActionClick(action: string): void;
    onLimitChange(limit: any): void;
    /** Refreshes the list by reapplying filters. */
    refresh(skipReset?: boolean): void;
    filterUpdate(value?: string): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    shouldSkipReset(rowChange: SimpleChange): boolean;
    startLoading(): void;
    stopLoading(): void;
    onSelect(selected: any[]): void;
    get showServiceActions(): boolean;
    unSelectAll(): void;
    sortCallback(sorts: any): void;
    pageCallback(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchableDatatableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchableDatatableComponent, "searchable-datatable", never, { "showAdd": { "alias": "showAdd"; "required": false; }; "addLabel": { "alias": "addLabel"; "required": false; }; "disableAddWithAMessage": { "alias": "disableAddWithAMessage"; "required": false; }; "showFilter": { "alias": "showFilter"; "required": false; }; "showCount": { "alias": "showCount"; "required": false; }; "showEdit": { "alias": "showEdit"; "required": false; }; "showNew": { "alias": "showNew"; "required": false; }; "showForceRefresh": { "alias": "showForceRefresh"; "required": false; }; "extraActions": { "alias": "extraActions"; "required": false; }; "extraActionsButtonCaption": { "alias": "extraActionsButtonCaption"; "required": false; }; "resetOnChange": { "alias": "resetOnChange"; "required": false; }; "_rows": { "alias": "_rows"; "required": false; }; "rowsPerPage": { "alias": "rowsPerPage"; "required": false; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; }; "columnMode": { "alias": "columnMode"; "required": false; }; "includeHeader": { "alias": "includeHeader"; "required": false; }; "isActionsFixed": { "alias": "isActionsFixed"; "required": false; }; "footerHeight": { "alias": "footerHeight"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "enableCheckboxSelection": { "alias": "enableCheckboxSelection"; "required": false; }; "displayCheck": { "alias": "displayCheck"; "required": false; }; "getRowId": { "alias": "getRowId"; "required": false; }; "serviceActionFilter": { "alias": "serviceActionFilter"; "required": false; }; "showAlert": { "alias": "showAlert"; "required": false; }; "externalPaging": { "alias": "externalPaging"; "required": false; }; "externalSorting": { "alias": "externalSorting"; "required": false; }; "sorts": { "alias": "sorts"; "required": false; }; "totalCount": { "alias": "totalCount"; "required": false; }; "pageNumber": { "alias": "pageNumber"; "required": false; }; }, { "add": "add"; "action": "action"; "edit": "edit"; "outputNewItem": "outputNewItem"; "forceRefresh": "forceRefresh"; "filter": "filter"; "select": "select"; "onPage": "onPage"; "onSort": "onSort"; }, ["columnTemplates", "rowDetailTpl", "alertMessage"], ["[datatable-filters]", "ngb-alert", "[datatable-actions]", "*"], false, never>;
}

interface CardGridSortField {
    label: string;
    key: string;
}
interface CardGridSortOption {
    label: string;
    sortBy: string;
    sortOrder: 'asc' | 'desc';
}
/** Default sort fields used by most card-grid lists. Override via the `sortFields` input. */
declare const DEFAULT_CARD_GRID_SORT_FIELDS: CardGridSortField[];
/**
 * Filters by an optional facet `predicate`, then `searchFields`, then sorts.
 * Order matters: filter option counts are built from the unfiltered list.
 */
declare function applyCardGridFilterSort<T>(items: T[], searchFields: string[], searchTerm: string, sortBy: string, sortOrder: 'asc' | 'desc', predicate?: (item: T) => boolean): T[];

declare class CardGridToolbarComponent implements OnInit {
    private destroy$;
    sortFields: CardGridSortField[];
    searchPlaceholder: string;
    showFilter: boolean;
    showSort: boolean;
    /** Initial field key to select. Defaults to the first field. */
    activeSortKey?: string;
    /** Initial sort direction. */
    sortDirection: 'asc' | 'desc';
    /** Seeds the input, so a page can restore a search from queryParams. */
    searchTerm: string;
    searchDebounce: number;
    filter: EventEmitter<FilterChangeEvent>;
    sortChange: EventEmitter<CardGridSortOption>;
    searchActiveChange: EventEmitter<boolean>;
    activeField?: CardGridSortField;
    private readonly search$;
    private lastSearchActive;
    constructor(destroy$: SubDestroyService);
    ngOnInit(): void;
    onSearchInput(term: string): void;
    /** Clears local input state and replaces any pending debounced term with ''. */
    resetSearch(): void;
    /** Emits only on transitions, so typing many characters emits once. */
    private emitSearchActive;
    selectField(field: CardGridSortField): void;
    toggleDirection(): void;
    private emitSort;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardGridToolbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardGridToolbarComponent, "app-card-grid-toolbar", never, { "sortFields": { "alias": "sortFields"; "required": false; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; }; "showFilter": { "alias": "showFilter"; "required": false; }; "showSort": { "alias": "showSort"; "required": false; }; "activeSortKey": { "alias": "activeSortKey"; "required": false; }; "sortDirection": { "alias": "sortDirection"; "required": false; }; "searchTerm": { "alias": "searchTerm"; "required": false; }; "searchDebounce": { "alias": "searchDebounce"; "required": false; }; }, { "filter": "filter"; "sortChange": "sortChange"; "searchActiveChange": "searchActiveChange"; }, never, ["[toolbar-filter]", "[toolbar-summary]"], true, never>;
}

/**
 * Features:
 * - Uses Angular CDK (officially supported)
 * - Synchronous API (no async/await needed)
 * - Automatic success/error toast notifications
 * - Built-in fallback handling by Angular CDK
 * - Works with all Angular versions 16-20+
 *
 * Migration from ngx-clipboard:
 * - Near drop-in replacement
 * - Same API signature: copy(text)
 * - No dependency on third-party libraries
 */
declare class ClipboardService {
    private clipboard;
    constructor(clipboard: Clipboard);
    /**
     * Copy text to clipboard using Angular CDK Clipboard
     *
     * @param text - Text to copy to clipboard
     * @param successMessage - Optional custom success message
     * @returns boolean - true if successful, false otherwise
     */
    copy(text: string, successMessage?: string): boolean;
    /**
     * Copy text to clipboard without showing toast notification
     * Useful when you want to handle the success/error messaging yourself
     *
     * @param text - Text to copy to clipboard
     * @returns boolean - true if successful, false otherwise
     */
    copySilent(text: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClipboardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClipboardService>;
}

declare class DuploToastrService {
    private toaster;
    constructor(toaster: ToastrService);
    shortSuccessMessage(message: string): void;
    longSuccessMessage(message: string): void;
    successMessage(message: string, timeOut?: number): void;
    errorMessage(message: string, timeOut?: number): void;
    shortErrorMessage(message: string): void;
    longErrorMessage(message: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploToastrService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploToastrService>;
}

declare class CodeBlockWithCopyComponent implements OnInit {
    private clipboardService;
    private toastrService;
    code: string;
    displayCode: string;
    successMessage: string;
    language: string;
    copied: boolean;
    constructor(clipboardService: ClipboardService, toastrService: DuploToastrService);
    ngOnInit(): void;
    /**
     * Format language name for better display
     */
    private formatLanguage;
    copyCode(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CodeBlockWithCopyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CodeBlockWithCopyComponent, "app-code-block-with-copy", never, { "code": { "alias": "code"; "required": false; }; "displayCode": { "alias": "displayCode"; "required": false; }; "successMessage": { "alias": "successMessage"; "required": false; }; "language": { "alias": "language"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SidecardComponent implements OnInit {
    private host;
    /** Customize the icon color. */
    iconColor: string;
    /** Pass an icon by name (uses feather icons) */
    icon: string;
    /** Pass a feather icon by name*/
    featherIcon: string;
    /** Pass a material icon (or custom icon) by name */
    matIcon: string;
    /** Pass the help key to show the help onhover */
    helpKey: string;
    /** Pass a custom icon section by a template */
    iconTpl: TemplateRef<any>;
    constructor(host: ViewContainerRef);
    ngOnInit(): void;
    getName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidecardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidecardComponent, "sidecard", never, { "iconColor": { "alias": "iconColor"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "featherIcon": { "alias": "featherIcon"; "required": false; }; "matIcon": { "alias": "matIcon"; "required": false; }; "helpKey": { "alias": "helpKey"; "required": false; }; }, {}, ["iconTpl"], ["*"], false, never>;
}
declare class ViewWithSidecardsComponent implements OnInit {
    private host;
    sideCards: QueryList<SidecardComponent>;
    hostName: any;
    constructor(host: ViewContainerRef);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewWithSidecardsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewWithSidecardsComponent, "view-with-sidecards", never, {}, {}, ["sideCards"], ["*", "sidecard, [side-content]"], false, never>;
}

interface ViewHeaderAction {
    text: string;
    handler: () => void;
}
declare class ViewHeaderCardComponent implements OnInit, AfterViewInit {
    /** Title passed as plain text. */
    title: string;
    /** Title passed as a template. */
    titleTpl: TemplateRef<any>;
    /** Subtitle passed as plain text. */
    subtitle: string;
    /** Subtitle passed as a template. */
    subtitleTpl: TemplateRef<any>;
    /** Whether or not to display the actions dropdown */
    showActions: boolean;
    /** Header actions passed as plain text and handlers. */
    actions: ViewHeaderAction[];
    /** Header actions passed as a template. */
    actionsTpl: TemplateRef<any>;
    /**
     * Optional inline toolbar rendered immediately before the actions button —
     * intended for compact filters (e.g. a Spec/Result `app-flat-status-filter`)
     * that sit next to the three-dot icon.
     */
    headerFilterTpl: TemplateRef<any>;
    /** Dynamic Placement of actions dropdown for grouped layout*/
    dynamicAction: boolean;
    /**
     * When true, the actions trigger is rendered as a three-dot vertical icon
     * button instead of the default "Actions" pill button. Opt-in per-page.
     */
    compactActions: boolean;
    constructor();
    ngAfterViewInit(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewHeaderCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewHeaderCardComponent, "view-header-card", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "showActions": { "alias": "showActions"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; "dynamicAction": { "alias": "dynamicAction"; "required": false; }; "compactActions": { "alias": "compactActions"; "required": false; }; }, {}, ["titleTpl", "subtitleTpl", "actionsTpl", "headerFilterTpl"], ["*"], false, never>;
}

declare class MiniCardComponent implements OnInit {
    /** Customize the icon color. */
    iconColor: string;
    /** Pass an icon by name (uses feather icons) */
    icon: string;
    /** Pass a feather icon by name*/
    featherIcon: string;
    /** Pass a material icon (or custom icon) by name */
    matIcon: string;
    hideHelp: boolean;
    /** Pass a custom icon section by a template */
    iconTpl: TemplateRef<any>;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MiniCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MiniCardComponent, "mini-card", never, { "iconColor": { "alias": "iconColor"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "featherIcon": { "alias": "featherIcon"; "required": false; }; "matIcon": { "alias": "matIcon"; "required": false; }; "hideHelp": { "alias": "hideHelp"; "required": false; }; }, {}, ["iconTpl"], ["*", "[minicard-detail]"], false, never>;
}

declare class ScrollableNavTabComponent implements AfterViewInit, OnDestroy {
    private destroy$;
    navDiv: ElementRef;
    ngbNav: NgbNav;
    startPos: number;
    listWidth: number;
    containerWidth: number;
    firstInViewIndex: number;
    lastInViewIndex: number;
    totalTabs: number;
    private sizeObserver?;
    get showLeftScroll(): boolean;
    get showRightScroll(): boolean;
    get needScroll(): boolean;
    constructor(destroy$: SubDestroyService);
    private navItemElement;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * Measuring once in ngAfterViewInit went stale on a window resize, a rail
     * collapse, a webfont landing, or tabs arriving from async data.
     */
    private observeSize;
    /** The projected tab list. firstChild broke if anything preceded the ul. */
    private tabListElement;
    setTabListWidth(): void;
    setTabInViewIndex(): void;
    scrollToActiveTab(): void;
    onScrollTabs(isPrev?: boolean): void;
    onScrollToPos(startPos: number): void;
    isTabInView(tabEle: HTMLElement): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollableNavTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollableNavTabComponent, "scrollable-nav-tab", never, {}, {}, ["ngbNav"], ["*"], false, never>;
}

/**
 * One page of items. Extracted from ApiListResponseWithPagination so callers whose payload
 * nests a page inside a larger view (rather than at the envelope's root) have a name for it.
 * Structurally identical to what that envelope always declared inline.
 */
interface PagedData<T> {
    items: T[];
    page: number;
    pageSize: number;
    totalCount: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
}
interface ApiListResponseWithPagination<T> {
    success: boolean;
    data: PagedData<T>;
    message: null;
    errors: null;
}
interface ApiListResponse<T> {
    success: boolean;
    data: T[];
    message: null;
    errors: null;
}
interface ApiSingleResponse<T> {
    success: boolean;
    data: T;
    message: null;
    errors: null;
    /**
     * Whether `data`'s `name` may currently be changed via PUT/PATCH — present on GetById/Create/Update
     * responses. Datasources that construct a typed model from `data` should copy this onto the
     * returned object's own `canUpdateName` (see `BaseEntity`) rather than letting the component guess;
     * the server is the only one that knows whether this specific row is locked.
     */
    canUpdateName?: boolean;
}
/**
 * Base entity class for all MongoDB entities
 */
declare abstract class BaseEntity {
    constructor(properties?: Partial<BaseEntity>);
    /**
     * Unique identifier for the entity
     */
    id?: string;
    /**
     * Name of the entity
     */
    name?: string;
    /**
     * Description of the entity
     */
    description?: string;
    /**
     * Date and time when the entity was created
     */
    createdAt?: string;
    /**
     * Date and time when the entity was last updated
     */
    updatedAt?: string;
    /**
     * Indicates if the entity is active or deleted (soft delete)
     */
    isActive?: boolean;
    /**
     * Version number for optimistic concurrency control
     * Incremented on each update to detect concurrent modifications
     */
    version?: number;
    /**
     * Additional metadata for the entity
     */
    metaData?: Record<string, string>;
    /**
     * Whether `name` may currently be changed via PUT/PATCH. Populated from the API response's
     * sibling field of the same name (see `ApiSingleResponse`) by the datasource method that fetched
     * this object — not set by the constructor, since it isn't part of `data` itself. Undefined on an
     * object that was never round-tripped through the API (e.g. a fresh Add-form draft); treat that
     * the same as `false` for display purposes.
     */
    canUpdateName?: boolean;
}
/**
 * Copies `response.canUpdateName` onto `entity` and returns it — the one-line merge every
 * datasource's GetById/Create/Update method needs after constructing a typed model from
 * `response.data`, since `canUpdateName` is a sibling field on the envelope (see
 * `ApiSingleResponse`), not part of `data` itself.
 */
declare function withCanUpdateName<T extends BaseEntity>(entity: T, response: ApiSingleResponse<unknown>): T;

declare const EMPTY_WORKSPACE_ID = "empty-workspace";
declare class AIWorkspaceBase implements BaseEntity {
    constructor(properties?: Partial<AIWorkspaceBase>);
    id: string;
    name: string;
    shortName?: string;
    description: string;
    personaIds: string[];
    createdAt?: string;
    updatedAt?: string;
    scopeIds?: string[];
    email?: string;
    role?: string;
    team?: string;
    agentIds: string[];
    analyticsId?: string;
    repoIds?: string[];
    knowledgeIds?: string[];
    projectIds?: string[];
    ticketIds?: string[];
    incidentIds?: string[];
    guardrailId?: string;
    quotaId?: string;
}
declare const EMPTY_WORKSPACE: AIWorkspaceBase;

type GenericFormInputType = 'number' | 'text' | 'checkbox' | 'password' | 'hidden' | 'textarea' | 'select' | 'monaco-editor' | 'selectmultiple' | 'json' | 'yaml' | 'password-with-show-option' | 'masked-textarea';
type JsonEditorSize = null | 'xlg' | 'lg' | 'md' | 'sm' | 'xsm';
declare class GenericFormInput {
    constructor(properties?: Partial<GenericFormInput>);
    label?: string;
    type?: GenericFormInputType;
    name: string;
    value?: any;
    required?: boolean;
    disabled?: boolean;
    minlen?: number;
    maxlen?: number;
    rows?: number;
    mask?: boolean;
    placeholder?: string;
    selectOptions?: SelectOptions[] | string[] | any[];
    selectBindLabel?: string;
    selectBindValue?: string;
    allowOtherValue?: boolean;
    otherValue?: string;
    pattern?: string;
    /**
     * Rendered as the input's `autocomplete` attribute when set; omitted otherwise. Use
     * 'new-password' on secret-value fields so browsers never autofill a saved login password.
     */
    autocomplete?: string;
    jsonEditorOptions?: object;
    jsonEditorSize?: JsonEditorSize;
    notExists?: string[];
    description?: string;
    loading?: boolean;
    groupBy?: string;
    alertIcon?: string;
    alertType?: string;
    alertTitle?: string;
    alertMessage?: string;
    /**
     * Resolves dot-notation selectBindValue / selectBindLabel paths once at load time,
     * adding __resolvedValue and __resolvedLabel flat keys to each option so that
     * ng-select can bind and search without recomputing on every change detection cycle.
     */
    static flattenDeepPaths(options: any[], bindValuePath?: string, bindLabelPath?: string): any[];
}
interface SelectOptions {
    label: string;
    value: string;
    disabled?: boolean;
}

/**
 * generate groups of 4 random characters
 * @example getUniqueId(1) : 607f
 * @example getUniqueId(2) : 95ca-361a
 * @example getUniqueId(4) : 6a22-a5e6-3489-896b
 */
declare function generateUniqueId(parts?: number): string;
declare class TableStatus$1 {
    text: string;
    style: string;
    constructor(text: string, style: string);
}
declare function generateHttpOptions(options?: any): {};
/**
 * Scrolls the parent element to make the child element visible within the parent's viewable area.
 * @param parent - The parent element that contains the child element.
 * @param child - The child element that needs to be made visible within the parent's viewable area.
 * @param topOffset - The additional offset from the top of the child element to scroll the parent element. Default is 0.
 * @param bottomOffset - The additional offset from the bottom of the child element to scroll the parent element. Default is 0.
 */
declare function scrollParentToChild(parent: HTMLElement, child: HTMLElement, topOffset?: number, bottomOffset?: number): void;
/**
 * Downloads a JavaScript object as a JSON file.
 * @param fileName - The name of the JSON file to be downloaded.
 * @param jsObject - The JavaScript object to be converted to JSON and downloaded.
 */
declare function downloadJsonAsFile(fileName: string, jsObject: object): void;
declare function formatNumberWithK(num: number): string | number;
declare function roundToTwoDecimals(num: number): string;
declare function openLinkInNewTab(url: string): void;
declare function scrollToBottomElement(element: HTMLElement): void;
declare function removeEmptyProperties<T extends Record<string, any>>(obj: T): T;
/**
 * Create a case-insensitive path getter with caching.
 * - Converts all enumerable string keys of the source object to lowercase (deeply) once.
 * - Returns a function that accepts a dot-separated path and resolves it case-insensitively.
 */
declare function createInsensitivePathGetter<T extends any>(source: T): (path: string, defaultValue?: any) => any;
declare function isNotEmptyValue(value: any): boolean;
/** @deprecated Do not use: labels come from config.json `labels` (one-release legacy fallback: `applyLegacyLabels`).
 *  Use `resolveLabel()` from common-lib/utils/ui-config (or the `aiLabelConfig` pipe); labels come from config.json `labels`. */
declare function getLabelFromSysConfig(aiSuiteConfigvalue?: string): (label: string) => string;
declare function downloadFileByUrl(url: string, fileName: string): void;
/**
 * Convert UTC date string to local Date object
 * @param utcDateString UTC date string (e.g., "1/16/2026 6:48:03 AM")
 * @returns Date object interpreted as local time
 */
declare function convertUtcToLocalISO(utcDateString: string | Date): string;
/**
 * Convert UTC date string to local Date object
 * @param utcDateString UTC date string (e.g., "1/16/2026 6:48:03 AM")
 * @returns Date object interpreted as local time
 */
declare function convertUtcToLocalDate(utcDateString: string | Date): string;

declare const TENANT_FEATURE_DENY_OPEN_ACCESS_TO_PUBLIC_LB = "deny_open_access_to_public_lb";
declare const TENANT_FEATURE_ENABLE_AWS_IOT = "enable_aws_iot";
declare const TENANT_FEATURE_AWS_IOT_TOPIC_PREFIX = "aws_iot_topic_prefix";
declare const TENANT_FEATURE_AWS_IOT_THING_PREFIX = "aws_iot_thing_prefix";
declare const TENANT_FEATURE_AZURE_ALLOW_PUBLIC_NETWORK_DB_AND_CACHE = "allow_public_network_to_azure_db_and_cache";
declare const TENANT_FEATURE_MAXIMUM_SESSION_DURATION = "maximum_session_duration";
declare const TENANT_FEATURE_MAXIMUM_K8S_SESSION_DURATION = "maximum_k8s_session_duration";
declare const TENANT_FEATURE_HEADER_COLOR = "tenant_header_bg-color";
declare const TENANT_FEATURE_AUTO_REBOOT_EC2_STATUS_CHECK = "auto_reboot_ec2_status_check";
declare const TENANT_FEATURE_AUTO_REBOOT_EC2_DISCONNECTED = "auto_reboot_ec2_disconnected";
declare const TENANT_FEATURE_SET_SNS_TOPIC_ALERTS = "alertssnstopic";
declare const EMPTY_GUID = "00000000-0000-0000-0000-000000000000";
declare const TENANT_FEATURE_CA_OVERPROVISIONING = "enable_ca_overprovisioning";
declare const TENANT_AI_STUDIO_ENABLED = "enabled_ai_studio_tenant";
declare const AI_HELPDESK_DEFAULT_ACTION_SELECTION = "AI_HELPDESK_DEFAULT_ACTION_SELECTION";
declare const AWS_SERVICES_TAG_BASED_OWNERSHIP_ENABLED = "AwsServicesTagBasedOwnershipEnabled";
declare const ENABLE_AI_SUITE = "ENABLE_AI";
declare const DISABLE_PLATFORM = "DISABLE_CORE_PLATFORM";
/**
 *  Aws Unavailable Services tenant feature
 */
declare enum AwsUnavailableServices {
    DATAPIPELINE = "datapipeline",
    MWAA_AIRFLOW = "mwaa_airflow",
    CLOUDFRONT = "cloudfront",
    EMRSERVERLESS = "emrserverless",
    TIMESATREAM = "timestream",
    APPRUNNER = "apprunner"
}
/**
 * Represents an agnostic reference.
 */
declare class Reference {
    static readonly DUPLO_V1_HOST = "duplo:v1/Host";
    QualifiedType: string;
    NativeId: string;
    Name?: string;
    constructor(properties?: Partial<Reference>);
    get IsKubernetes(): boolean;
    get IsDuplo(): boolean;
    get IsDocker(): boolean;
    get IsAws(): boolean;
    get iconName(): string;
}
/**
 * Represents search and pagination parameters.
 */
declare class SearchAndPaginationParams$1 {
    q?: string;
    sf?: string;
    sd?: string;
    max?: number;
    page?: number;
    constructor(properties?: Partial<SearchAndPaginationParams$1>);
    toUriPart(): string;
}
/**
 * Represents search and pagination results.
 */
declare class SearchAndPaginationResult<R> {
    Query?: string;
    SortField?: string;
    SortDescending: boolean;
    MaxItems: number;
    Page: number;
    TotalItems: number;
    TotalPages: number;
    Items: R[];
    constructor(properties?: Partial<SearchAndPaginationResult<R>>);
}
/**
 *  Represents the available features for a given tenant.
 */
declare class TenantFeatures {
    constructor(properties?: Partial<TenantFeatures>);
    Cloud: CloudPlatform$1;
    Region: string;
    IsKubernetesEnabled: boolean;
    KubernetesType: K8sPlatform;
    TenantMetadata?: CustomData[];
    PlanMetadata?: CustomData[];
    InfraMetadata?: CustomData[];
    AwsUnavailableServices?: string[];
    AppConfigs?: CustomDataEx[];
    IsK8sServerless?: boolean;
    /** Retrieves a tenant metadata value. */
    getMetadataValue(key: string): string;
    /** Checks if a tenant feature is enabled. */
    isEnabled(key: string): boolean;
    /** Retrieves a plan metadata value. */
    getPlanMetadataValue(key: string): string;
    /** Checks if a plan feature is enabled. */
    isPlanEnabled(key: string): boolean;
    /** Retrieves a infra metadata value. */
    getInfraMetadataValue(key: string): string;
    /** Checks if a plan feature is enabled. */
    isInfraEnabled(key: string): boolean;
    /** Human-readable name of the current cloud. */
    get CloudName(): string;
    /** Human-readable name of the CSP-managed Kubernetes in the current cloud. */
    get K8sName(): string;
    /** Human-readable name of the VNET in the current cloud.*/
    get VpcName(): "VNET" | "VPC";
    /** What to call a firewall in the current cloud. */
    get FirewallName(): "Firewall" | "Security Group";
    /** What to call a managed SSL certificate ID in the current cloud. */
    get CertificateArnName(): "GCP Certificate Name" | "Certificate ARN";
    /** new dictionary with service => region + partition */
    IsAwsServiceAvailable(serviceName: string): boolean;
    /** Check if Tenant Infra has GKE Standard/Non-Serverless cluster */
    get isGkeStandardCluster(): boolean;
    get runningOnEksAutoModeCluster(): boolean;
    get IsHelmV2Enabled(): boolean;
    get IsHelmOperatorReady(): boolean;
}
interface TenantFeaturesMap {
    [index: string]: TenantFeatures;
}
/**
 *  Represents the available features in the system.
 *
 *  This class is instantiated automatically by Angular's DI system, but data is only populated
 *  by the CommonRepository component.
 */
declare class SystemFeatures {
    IsSignupEnabled: boolean;
    IsComplianceEnabled: boolean;
    IsSiemEnabled: boolean;
    IsBillingEnabled: boolean;
    DisableOobData: boolean;
    IsKatkitEnabled: boolean;
    IsAwsCloudEnabled: boolean;
    IsOnPremEnabled: boolean;
    IsOracleCloudEnabled: boolean;
    AwsRegions: string[];
    DefaultAwsAccount: string;
    DefaultAwsRegion: string;
    DefaultAwsPartition: string;
    EksVersions: K8ClusterVersions;
    AksVersions?: K8ClusterVersions;
    IsAzureCloudEnabled: boolean;
    AzureRegions: string[];
    IsGoogleCloudEnabled: boolean;
    IsOtpNeeded: boolean;
    IsAwsAdminJITEnabled: boolean;
    GoogleRegions: string[];
    IsDuploOpsEnabled: boolean;
    DefaultInfraCloud: string;
    DevopsManagerHostname: string;
    TenantNameMaxLength: number;
    DuploShellFqdn?: string;
    IsTagsBasedResourceMgmtEnabled: boolean;
    EnabledFlags: string[];
    IsAiTenantAvailable: boolean;
    GcpDisableTenantPrefix?: boolean;
    GcpDisableDuploPrefix?: boolean;
    DisableVpcCreation?: boolean;
    AwsServicesTagBasedOwnershipEnabled?: string[];
    DisableRdsBlueGreen?: boolean;
    IsSecurityComplianceEnabled: boolean;
    AuthConfig: AuthConfig;
    AppConfigs?: CustomDataEx[];
    IsLoaded: boolean;
    AzureResourcePrefix?: AzureResourcePrefix;
    get CloudName(): string;
    get IsCommercialAws(): boolean;
    get IsBillingEnabledSetting(): boolean;
    set IsBillingEnabledSetting(value: boolean);
    get IsAWSDefaultInfraCloud(): boolean;
    IsSettingFlagEnabled(flag: string): boolean;
    getAppConfigByName(configName: string): CustomDataEx;
    IsAppConfigFlagEnabled(configName: string): boolean;
    getInfraRgPrefix(config: {
        AzureResourcePrefix: AzureResourcePrefix;
    }): string | undefined;
    private _enabledClouds;
    get EnabledClouds(): CloudPlatform$1[];
    get IsAIEnabled(): boolean;
    get IsPlatformDisabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SystemFeatures, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SystemFeatures>;
}
declare class AzureResourcePrefix {
    IsAzureCustomPrefixesEnabled: boolean;
    InfraRgPrefix: string;
    TenantRgPrefix: string;
    BackupRgPrefix: string;
    ResourceTypePrefix: ResourceTypePrefix[];
}
declare class ResourceTypePrefix {
    Type: string;
    Prefix: string;
}
declare class KeyStringValue {
    Key: string;
    Value: string;
}
declare class KeyStringValueUpdateRequest extends KeyStringValue {
    constructor(properties?: Partial<KeyStringValueUpdateRequest>);
    ComponentId: string;
    State?: string;
}
declare class CustomDataUpdate extends KeyStringValueUpdateRequest {
    constructor(properties?: Partial<CustomDataUpdate>);
}
declare class TenantTagRequest extends KeyStringValueUpdateRequest {
    constructor(properties?: Partial<TenantTagRequest>);
}
declare class CustomData extends KeyStringValue {
}
interface CustomDataSpec {
    Key: string;
    DataType: 'string' | 'boolean' | 'select';
    IsEditable: boolean;
    DisplayName?: string;
    Cloud?: CloudPlatform$1;
    Description?: string;
    Danger?: string;
}
interface EditableCustomData extends CustomData, CustomDataSpec {
}
declare class CustomDataEx extends CustomData {
    constructor(properties?: Object | CustomDataEx);
    Type: string;
    ComponentId?: string;
    State?: string;
}
declare enum AgentPlatform {
    DOCKER_LINUX = 0,
    DOCKER_WINDOWS = 5,
    EKS_LINUX = 7,
    NONE = 4,
    ECS = 8
}
declare class AgentPlatformUtils {
    static getAsString(p: AgentPlatform, cloud?: number): string;
    static getAsMap(isEksEnabled: boolean, cloud?: CloudPlatform$1, isEcsEnabled?: boolean): AgentPlatformDetails[];
}
declare class AgentPlatformDetails {
    name: string;
    display: string;
    value: number;
}
declare enum CloudPlatform$1 {
    AWS = 0,
    Oracle = 1,
    Azure = 2,
    Google = 3,
    BYOH = 4,
    Unknown = 5,
    Digital_Ocean = 6,
    OnPrem = 10
}
declare const CloudPlatformNames: _duplocloud_internal_ng_common_lib.EnumMapOf<string>;
declare enum K8sPlatform {
    EKS = 0,
    AKS = 2,
    GKE = 3,
    OKE = 1
}
declare enum K8sVendor {
    RANCHER = 0,
    GENERIC = 1,
    EKS = 2
}
declare class AuthConfig {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Object | AuthConfig);
    WAFDASHBOARDURL?: string;
    VPNADDRESSINGMETHOD?: string;
    ISVPNAUTHBYLDAP?: boolean;
}
declare class K8ClusterConfig {
    constructor(properties?: Object | K8ClusterConfig);
    Name: string;
    ApiServer: string;
    K8Provider: K8sPlatform;
    K8sVersion: string;
    Cloud?: CloudPlatform$1;
    Token?: string;
    AwsRegion?: string;
    Region?: string;
    CertificateAuthorityDataBase64?: string;
    IsServerless?: boolean;
    DefaultNamespace?: string;
    UpgradeConfig?: K8ClusterUpgradeStatus;
}
declare class K8ClusterUpgradeStatus {
    constructor(properties?: Partial<K8ClusterUpgradeStatus>);
    StartingVersion: string;
    TargetVersion: string;
    Status: string;
    InProgressId?: string;
    InProgressVersion?: string;
    DefaultOldNodeAction?: K8ClusterUpgradeNodeActionType;
    OldNodePrivateIps: CustomData[];
    OldNodeActions: K8ClusterUpgradeNodeAction[];
    ControlPlaneStartTime?: string;
    ControlPlaneEndTime?: string;
    readonly needsResolution: boolean;
    readonly oldNodesByTenant: {
        [tenantName: string]: string[];
    };
}
declare class K8ClusterAddOns {
    Name: string;
    CurrentVersion: string;
    TargetVersion: string;
    CurrentStatus: string;
    AllowUpgrade?: boolean;
    CanUpgrade?: boolean;
    AddOnStatus?: TableStatus$1;
    constructor(properties?: Partial<K8ClusterAddOns>);
    checkCanUpgrade(clusterV: string): boolean;
    get NameUpper(): string;
    get IsDegradedStatus(): boolean;
}
declare class K8ClusterUpgradeRequest {
    constructor(properties?: Partial<K8ClusterUpgradeRequest>);
    DefaultOldNodeAction: K8ClusterUpgradeNodeActionType;
}
declare enum K8ClusterUpgradeNodeActionType {
    None = 0,
    Remove = 1,
    Replace = 2
}
declare class K8ClusterUpgradeNodeAction {
    constructor(properties?: Partial<K8ClusterUpgradeNodeAction>);
    TenantName: string;
    TenantId: string;
    Action: K8ClusterUpgradeNodeActionType;
    OldNodePrivateIp: string;
    OldNodeInstanceId: string;
    OldNodeAsgProfile: string;
    NewNodeInstanceId: string;
}
declare class K8ClusterVersions {
    constructor(properties?: Partial<K8ClusterVersions>);
    DefaultVersion: string;
    SupportedVersions: string[];
    static GetDropdownOptions(versions: string[], defaultVersion: string): SelectOptions[];
}
declare enum LBType {
    Classic = 0,
    Application = 1,
    HealthCheck = 2,
    K8SClusterIP = 3,
    K8SNodePort = 4,
    SharedAlb = 5,
    NLB = 6,
    TargetGroupOnly = 7
}
declare const BASE_JSON_EDITOR_OPTIONS: any;
declare const TEXT_EDITOR_OPTIONS: any;
declare const INDENT_JSON_EDITOR_OPTIONS: any;
declare const READ_ONLY_JSON_EDITOR_OPTIONS: any;
declare const JSON_EDITOR_OPTIONS: any;
declare const YAML_EDITOR_OPTIONS: any;
declare const XML_EDITOR_OPTIONS: any;
declare const READ_ONLY_XML_EDITOR_OPTIONS: any;
declare const INI_EDITOR_OPTIONS: any;
declare const READ_ONLY_INI_EDITOR_OPTIONS: any;
declare class GcpRegionFeatures {
    constructor(properties?: Partial<GcpRegionFeatures>);
    GkeServerConfig: GkeServerConfig;
}
interface GkeServerConfig {
    channels: GkeReleaseChannel[];
    defaultClusterVersion: string;
    defaultImageType: string;
    validImageTypes: string[];
}
interface GkeReleaseChannel {
    channel: string;
    defaultVersion: string;
    validVersions: string[];
}
declare const K8S_SECRETS: ({
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        ARBITRARY_KEY1: string;
        ARBITRARY_KEY2: string;
        ".dockercfg"?: undefined;
        ".dockerconfigjson"?: undefined;
        username?: undefined;
        password?: undefined;
        "ssh-privatekey"?: undefined;
        "tls.key"?: undefined;
        "tls.crt"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
    name?: undefined;
} | {
    name: string;
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        ".dockercfg": string;
        ARBITRARY_KEY1?: undefined;
        ARBITRARY_KEY2?: undefined;
        ".dockerconfigjson"?: undefined;
        username?: undefined;
        password?: undefined;
        "ssh-privatekey"?: undefined;
        "tls.key"?: undefined;
        "tls.crt"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
} | {
    name: string;
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        ".dockerconfigjson": string;
        ARBITRARY_KEY1?: undefined;
        ARBITRARY_KEY2?: undefined;
        ".dockercfg"?: undefined;
        username?: undefined;
        password?: undefined;
        "ssh-privatekey"?: undefined;
        "tls.key"?: undefined;
        "tls.crt"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
} | {
    name: string;
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        username: string;
        password: string;
        ARBITRARY_KEY1?: undefined;
        ARBITRARY_KEY2?: undefined;
        ".dockercfg"?: undefined;
        ".dockerconfigjson"?: undefined;
        "ssh-privatekey"?: undefined;
        "tls.key"?: undefined;
        "tls.crt"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
} | {
    name: string;
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        "ssh-privatekey": string;
        ARBITRARY_KEY1?: undefined;
        ARBITRARY_KEY2?: undefined;
        ".dockercfg"?: undefined;
        ".dockerconfigjson"?: undefined;
        username?: undefined;
        password?: undefined;
        "tls.key"?: undefined;
        "tls.crt"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
} | {
    name: string;
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        "tls.key": string;
        "tls.crt": string;
        ARBITRARY_KEY1?: undefined;
        ARBITRARY_KEY2?: undefined;
        ".dockercfg"?: undefined;
        ".dockerconfigjson"?: undefined;
        username?: undefined;
        password?: undefined;
        "ssh-privatekey"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
})[];
declare function cloudToK8sName(cloud: CloudPlatform$1): string;
declare enum ContainerStatus$1 {
    Unknown = 0,
    Running = 1,
    Stopped = 2,
    Pending = 3,
    Waiting = 4,//FixMe
    Delete = 5,
    Deleted = 6,
    Failed = 7,
    SchedulingFailed = 8,
    ImageNotFound = 9,
    Evicted = 10
}
declare function formatPodStatus(val: string): string;
declare const podStatusBadgeStyles: Map<number, string>;
interface KubeConfigCluster {
    'certificate-authority-data'?: string;
    'insecure-skip-tls-verify'?: boolean;
    server: string;
}
interface KubeConfigClusterEntry {
    cluster: KubeConfigCluster;
    name: string;
}
interface KubeConfigContext {
    cluster: string;
    namespace: string;
    user: string;
}
interface KubeConfigContextEntry {
    context: KubeConfigContext;
    name: string;
}
interface KubeConfigUser {
    token?: string;
    exec?: any;
}
interface KubeConfigUserEntry {
    user: KubeConfigUser;
    name: string;
}
declare class KubeConfigFile {
    constructor(properties?: Partial<KubeConfigFile>);
    apiVersion: 'v1';
    clusters: KubeConfigClusterEntry[];
    users: KubeConfigUserEntry[];
    contexts: KubeConfigContextEntry[];
    'current-context'?: string;
    static fromK8ClusterConfig(input: K8ClusterConfig, name?: string, namespace?: string, addUser?: boolean): KubeConfigFile;
    static yamlKubeConfig(planId: string, k8Config: K8ClusterConfig, userConfig: {
        isAdmin: boolean;
        accountName: string;
        existingK8sNamespace: string;
    }): KubeConfigFile;
    static downloadKubeConfig(planId: string, k8Config: K8ClusterConfig, userConfig: {
        isAdmin: boolean;
        accountName: string;
        existingK8sNamespace: string;
    }): KubeConfigFile;
}
declare class SelectOption {
    constructor(properties?: Partial<SelectOption>);
    Label?: string;
    Value?: string | number | boolean;
}
declare class KeyValueConfig {
    constructor(properties?: Partial<KeyValueConfig>);
    Key?: string;
    Value?: string | number | boolean;
}
declare class AWSAccessToken {
    constructor(properties?: Partial<AWSAccessToken>);
    AccessKeyId: string;
    ConsoleUrl: string;
    Region: string;
    SecretAccessKey: string;
    SessionToken: string;
}

declare class AdminTenant {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Object | AdminTenant);
    TenantId: string;
    AccountName: string;
    AgentPools?: any[];
    AsgProfiles?: any[];
    CreationTime?: string;
    Devices?: any[];
    ECacheInstances?: any[];
    EcsServices?: any[];
    Expiry?: Date;
    ExistingK8sNamespace?: string;
    InfraOwner?: string;
    Metadata?: CustomData[];
    Minions?: any[];
    MonitoringCfg?: AdminTenantMonitoringConfig;
    NativeHosts?: any[];
    Networks?: any;
    NwProvider: number;
    OperationalPods?: any[];
    PlanID: string;
    PauseTime?: Date;
    RDSInstances?: any;
    ReplicationControllers?: any[];
    RegistryCredentials?: string;
    StorageAccounts?: any[];
    Tags?: KeyStringValue[];
    Tasks?: any[];
    TenantAccessGrants?: TenantAccessGrant[];
    KmsKeyInfos?: TenantPlanKmsKeyInfo[];
    Features?: TenantFeatures;
    aiWorkspace?: AIWorkspaceBase;
    isAIWorkspace?: boolean;
    isPlatformTenant?: boolean;
    get workspaceName(): string;
    get workspaceId(): string;
    /** Retrieves a User Tenant metadata value. */
    getMetaValueByKey(key: string): string;
}
declare class TenantPlanKmsKeyInfo {
    constructor(properties?: object | TenantPlanKmsKeyInfo);
    KeyName: string;
    KeyArn: string;
    KeyId?: string;
}
declare class AdminTenantMonitoringConfig {
    AlertPublishFrequency?: number;
}
declare class AdminTenantAuthInfo {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties: Object | AdminTenantAuthInfo);
    TenantId: string;
    AccountName: string;
    UserAccess: TenantUserAccess[];
    AccessByUser?: {
        [username: string]: TenantUserAccess;
    };
    ConfigData?: CustomDataEx[];
}
declare enum TenantNetworkSecurityRuleProtocol {
    TCP = "tcp",
    UDP = "udp",
    ICMP = "icmp"
}
declare enum TenantNetworkSecurityRuleSourceType {
    TENANT = 0,
    IP_ADDRESS = 1
}
declare class TenantNetworkSecurityRuleSource {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties: Object | TenantNetworkSecurityRuleSource);
    Description: string;
    Type: TenantNetworkSecurityRuleSourceType;
    Value: string;
}
declare class TenantNetworkSecurityRule {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties: Object | TenantNetworkSecurityRule);
    ServiceProtocol: TenantNetworkSecurityRuleProtocol;
    ServiceType: number;
    FromPort: number;
    ToPort: number;
    SourceInfos: TenantNetworkSecurityRuleSource[];
    getFlattenedSecurityRules(): FlattenedTenantNetworkSecurityRule[];
}
declare class FlattenedTenantNetworkSecurityRule {
    constructor(properties: Object | FlattenedTenantNetworkSecurityRule);
    ServiceProtocol: TenantNetworkSecurityRuleProtocol;
    ServiceType: number;
    FromPort: number;
    ToPort: number;
    Description: string;
    Type: TenantNetworkSecurityRuleSourceType;
    Value: string;
    toTenantExtConnSgRuleUpdate(): TenantExtConnSgRuleUpdate;
}
declare class GcpNetworkSecurityRule {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties: Object | GcpNetworkSecurityRule);
    name: string;
    description: string;
    direction: string;
    disabled: boolean;
    id: number;
    kind: string;
    network: string;
    priority: number;
    selfLink: string;
    sourceRanges: string[];
    sourceTags: string[];
    creationTimestamp: string;
    logConfig: GcpLogConfig;
    allowed: ProtoColAndPorts[];
    denied: ProtoColAndPorts[];
    get action(): string;
    private _protocolAndPorts;
    get protocolAndPorts(): string[];
    private _sourceRanges;
    get sourceRangesString(): string;
    private _sourceTenantName;
    get sourceTenantName(): string;
    private formatProtocolPortValues;
    toFlattenedGcpSecurityRule(): FlattenedGcpNetworkSecurityRule;
}
declare const IPv4Regex: RegExp;
declare const IPv6Regex: RegExp;
declare const Ipv4Ipv6CIDRRegex: RegExp;
declare class GcpNetworkSecurityRuleCreateRequest {
    constructor(properties?: Partial<GcpNetworkSecurityRuleCreateRequest>);
    Name: string;
    Description: string;
    ProtocolAndPorts: ServiceProtocolAndPorts[];
    SourceRanges: string[];
    Type: string;
}
declare class ServiceProtocolAndPorts {
    constructor(properties?: Object | ServiceProtocolAndPorts);
    ServiceProtocol: string;
    Ports: string[];
}
declare class GcpLogConfig {
    constructor(properties?: Object | GcpLogConfig);
    enabled: boolean;
}
declare class ProtoColAndPorts {
    constructor(properties?: Object | ProtoColAndPorts);
    IPProtocol: string;
    ports: string[];
}
declare enum GcpTenantNetworkSecurityRuleType {
    TENANT = "TENANT",
    IPADDRESS = "IPADDRESS"
}
declare class GcpTenantNetworkSecurityRuleCreateRequest extends GcpNetworkSecurityRuleCreateRequest {
    constructor(properties?: Partial<GcpTenantNetworkSecurityRuleCreateRequest>);
    TenantRuleType: GcpTenantNetworkSecurityRuleType;
    SourceSubscriptionId: string;
}
declare class FlattenedGcpNetworkSecurityRule {
    constructor(properties?: Partial<FlattenedGcpNetworkSecurityRule>);
    Name: string;
    Description: string;
    Type: string;
    SourceType: number;
    SourceRanges: string;
    ShowProtocolAndPorts: boolean;
    TcpEnabled: boolean;
    UdpEnabled: boolean;
    SctpEnabled: boolean;
    OtherProtocolEnabled: boolean;
    TcpPorts: string;
    UdpPorts: string;
    SctpPorts: string;
    OtherProtocol: string;
    toGcpNetworkSecurityRuleRequest(): GcpNetworkSecurityRuleCreateRequest;
    getServiceProtocolAndPorts(protocol: string, ports: string): ServiceProtocolAndPorts;
}
declare class AddTenantRequest {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Object | AddTenantRequest);
    AccountName: string;
    PlanID: string;
    TenantBlueprint: 'None';
    ExistingK8sNamespace?: string;
}
declare class TenantUserAccess {
    constructor(properties?: Partial<TenantUserAccess>);
    Username: string;
    Policy?: TenantAccessPolicy;
    user?: UserRoleInfo;
    get isReadOnly(): boolean;
}
declare class TenantAccessPolicy {
    constructor(properties?: Partial<TenantAccessPolicy>);
    IsReadOnly: boolean;
}
declare class UpdateUserAccessRequest extends TenantUserAccess {
    constructor(properties?: Partial<UpdateUserAccessRequest>);
    State?: string;
    TenantId: string;
}
declare class BatchAddUserTenantAccessRequest {
    constructor(properties?: Partial<BatchAddUserTenantAccessRequest>);
    Username: string;
    TenantAccessQueries: TenantAccessQuery;
    initializeTenantAccessQueries(tenantIdList: string[], accessType: boolean): void;
}
declare class TenantAccessQuery {
    constructor(properties?: Partial<TenantAccessQuery>);
    [key: string]: AccessType;
}
declare class AccessType {
    constructor(properties?: Partial<TenantAccessQuery>);
    IsReadOnly: boolean;
}
declare class UserTenantAccess {
    constructor(properties?: Partial<UserTenantAccess>);
    TenantId: string;
    AccountName: string;
    Policy?: TenantAccessPolicy;
    get isReadOnly(): boolean;
}
declare class TenantExtConnSgRuleUpdate {
    constructor(properties?: Object | TenantExtConnSgRuleUpdate);
    ServiceProtocol: string;
    FromPort: number;
    ToPort: number;
    SourceInfos: SGSourceInfos[];
    State?: string;
}
declare class SGSourceInfos {
    constructor(properties?: Object | TenantExtConnSgRuleUpdate);
    Description: string;
    Type: number;
    Value: string;
}
declare class TenantMetadataUpdateReq {
    constructor(properties?: Object | TenantMetadataUpdateReq);
    ComponentId: string;
    Key: string;
    Value: string;
    State?: string;
}
declare class TenantAlertConfig {
    constructor(properties?: Object | TenantAlertConfig);
    Dsn: string;
    RoutingKey: string;
    NrApiKey: string;
    OpsGenieApiKey: string;
    IncidentIoUrl: string;
    AlertPublishFrequency: number;
}
declare class TenantAccessGrant {
    constructor(properties?: Partial<TenantAccessGrant>);
    GrantorTenantId: string;
    GrantedArea: string;
    GrantorTenantName?: string;
    get otherTenantId(): string;
    get otherTenantName(): string;
}
declare class TenantAccessGrantee {
    constructor(properties?: Partial<TenantAccessGrantee>);
    GranteeTenantId: string;
    GrantedArea: string;
    GranteeTenantName?: string;
    get otherTenantId(): string;
    get otherTenantName(): string;
}
declare const TENANT_PLATFORM_SERVICES_CONFIGS: {
    "duplo-infra-svc-node-exporter": string;
    "duplo-infra-svc-node-exporter-k8s-4": string;
    "duplo-infra-svc-cadvisor": string;
    "duplo-infra-svc-cadvisor-k8s": string;
    "duplo-infra-svc-filebeat": string;
    "duplo-infra-svc-filebeat-k8s": string;
};
declare const AWS_SPECIFIC_TENANT_CONFIG: string[];
declare const TENANT_DEFAULT_CONFIGS: ({
    key: string;
    label: string;
    cloud: CloudPlatform$1;
    type?: undefined;
    default?: undefined;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    helpText?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    default: string;
    cloud: CloudPlatform$1;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    helpText?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    cloud?: undefined;
    type?: undefined;
    default?: undefined;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    helpText?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    alertMessage: string;
    alertType: string;
    alertTitle: string;
    alertIcon: string;
    helpText: string;
    cloud: CloudPlatform$1;
    default?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    helpText: string;
    default: string;
    cloud: CloudPlatform$1;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    helpText: string;
    cloud: CloudPlatform$1;
    type?: undefined;
    default?: undefined;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    default: string;
    alertMessage: string;
    alertType: string;
    alertTitle: string;
    alertIcon: string;
    helpText: string;
    cloud: CloudPlatform$1;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    cloud: CloudPlatform$1;
    default?: undefined;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    helpText?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    default: string;
    options: string[];
    helpText: string;
    cloud: CloudPlatform$1;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
})[];
declare class SessionDurationOption {
    value: number | 'custom';
    static readonly OPTIONS: SessionDurationOption[];
    label: string;
    constructor(value: number | 'custom');
}
declare class TenantHeaderColor {
    static readonly colorMap: Map<string, string>;
    static getColorByName(name: string): string;
    static getColorOptions(): string[];
}

declare const SystemConfigs: {
    SETTING_ENABLE_VPN: string;
    SETTING_DISABLE_KATKIT: string;
    SETTING_DUPLO_CUSTOM_TAGS: string;
    SETTING_AUTOMATED_RDS_PG_ENABLED_ENGINES: string;
    SETTING_S3_BUCKET_NAME_PREFIX: string;
    SETTING_RDS_AUTOMATED_BACKUP_RETENTION_DAYS: string;
    SETTING_DISABLE_SSH_KEY_DOWNLOAD: string;
    SETTING_ENABLE_STORAGE_ACCOUNT_INFRA_ENCRYPTION: string;
    SETTING_AZURE_DEFAULT_MYSQL_BACKUP_RETENTION_DAYS: string;
    SETTING_AZURE_DEFAULT_POSTGRESQL_FLEXI_BACKUP_RETENTION_DAYS: string;
    SETTING_AZURE_DEFAULT_MYSQL_GEO_REDUNDANT_BACKUP_ENABLED: string;
    SETTING_ADMIN_ONLY_SSH_KEY_DOWNLOAD: string;
    SETTING_ENABLE_ECS_READONLY_PROCESSING: string;
    AWS_APPROVED_RDS_FOR_TENANT_USERS_SETTING: string;
    AWS_RDS_RESTRICT_UPTO_INSTANCE_SIZE: string;
    SETTING_MAXIMUM_SESSION_DURATION: string;
    SETTING_MAXIMUM_K8S_SESSION_DURATION: string;
    SETTING_AD_ONLY_DOMAINS: string;
    SETTING_GSUITE_ONLY_DOMAINS: string;
    SETTING_O365_ONLY_DOMAINS: string;
    SETTING_ALLOW_DEDICATED_HOST_SHARING: string;
    SETTING_DENY_OPEN_ACCESS_TO_PUBLIC_LB: string;
    SETTING_DISABLE_HOST_CREATION_WITH_CUSTOM_AMI: string;
    SETTING_LIST_ALL_LAMBDA_LAYERS: string;
    SETTING_BLOCK_MASTER_VPC_CIDR_ALLOW_IN_EKS_SG: string;
    SETTING_ENABLE_INSTANCE_SCHEDULER: string;
    SETTING_ENABLE_USER_TOKEN_EXPIRATION_NOTIFICATION: string;
    SETTING_ENABLE_NEW_ADMIN_USER_NOTIFICATION: string;
    SETTING_USER_TOKEN_EXPIRATION_NOTIFICATION_EMAILS: string;
    SETTING_ENABLE_INACTIVE_USER_NOTIFICATION: string;
    SETTING_ENABLE_RDS_IAM_AUTH: string;
    SETTING_RDS_IAM_AUTH_DB_USERNAME: string;
    SETTING_ALWAYS_SHOW_VPN_UI: string;
    SETTING_ALLOW_READONLY_K8S_SECRETS: string;
    SETTING_VANTA_ENABLED: string;
    SETTING_INFRA_VPC_IMPORT_ENABLE: string;
    SETTING_ENABLE_AI: string;
    SETTING_DISABLE_MINI_AI_HELP_DESK: string;
    SETTING_DISABLE_PYLON: string;
    SETTING_DISABLE_PYLON_FOR_NON_ADMIN: string;
    SETTING_DUPLO_AUDIT_S3BUCKET: string;
    SETTING_DUPLO_AUDIT_S3BUCKET_REGION: string;
    SETTING_AUTHORIZATION_SESSION_EXPIRATION: string;
    SETTING_ENABLE_ADMIN_AWS_JIT_ACCESS: string;
    SETTING_DISABLE_NON_ADMIN_AWS_JIT: string;
    SETTING_DISABLE_IMAGE_HISTORY_TRACKING: string;
    SETTING_K8S_CONTAINER_EXEC_USE_SSM: string;
    SETTING_AZURE_APP_GATEWAY_SSL_POLICY: string;
    SETTING_ENABLE_USER_PUBLIC_KEY: string;
    SETTING_LOGIN_BANNERTEXT: string;
    SETTING_LOGIN_BUTTONTEXT: string;
    SETTING_ENABLE_BILLING_ALERTS: string;
    AI_URL: string;
    SETTING_KIBANA_BASE_URL: string;
    SETTING_KIBANA_BASE_URLS_PER_TENANT: string;
    SETTING_KIBANA_LOGS_URL_TEMPLATE: string;
    SETTING_KIBANA_LOGS_URL_TEMPLATE_ECS: string;
    SETTING_KIBANA_AUDIT_URL_TEMPLATE: string;
    SETTING_KIBANA_SERVICE_LOGS_URL_TEMPLATE: string;
    SETTING_KIBANA_ADMIN_DASHBOARD_URL_TEMPLATE: string;
    SETTING_CNAME_PREFIXES_TO_IGNORE: string;
    SETTING_NEW_USER_EMAIL_SUBJECT: string;
    SETTING_NEW_USER_EMAIL_BODY: string;
    SETTING_FIPS_ENABLED: string;
    /** @deprecated Do not use: read for one release only, as a fallback while config.json `labels` is empty.
     *  Use config.json `labels` via `resolveLabel()` from common-lib/utils/ui-config (or the `aiLabelConfig` pipe). */
    AI_SUITE_LABEL_CONFIG: string;
    ADMIN_INTERFACES_TO_HIDE: string;
    DISABLE_HELPDESK_NAV_COLLAPSE: string;
    REMOVE_VPN_PASSWORD_FROM_EMAIL: string;
    AI_HELPDESK_DEFAULT_ACTION_SELECTION: string;
    SETTING_ENABLE_K8S_PASS_THROUGH: string;
    SETTING_BACKUP_XMLDB_TO_CLOUD: string;
    SETTING_BACKUP_XMLDB_BUCKET_NAME: string;
};
declare class IframeConfigs {
    constructor(properties?: Object | IframeConfigs);
    UIPath: string;
    Links: CustomDataEx[];
}

declare class AccountSsoConfig {
    constructor(properties?: Partial<AccountSsoConfig>);
    DisableGoogle: boolean;
    DisableMicrosoft: boolean;
    MicrosoftClientId: string;
    MicrosoftOauthBaseUrl: string;
    MicrosoftTenantId: string;
    EnableKeycloak: boolean;
    KeycloakHost: string;
    KeycloakRealm: string;
    KeycloakClientId: string;
    KeycloakState: string;
    KeycloakNonce: string;
    EnableAzureAd: boolean;
    AzureAdClientId: string;
    AzureAdIssuer: string;
    EnableAzureAdUserSource: boolean;
    EnableOktaLogin: boolean;
    OktaClientId: string;
    OktaDomain: string;
    EnableOktaUserSource: boolean;
    OktaSamlUrl: string;
    LoginBannerText: string;
    LoginButtonText: string;
    /** Local-dev username/password login — enabled by the backend only when an admin password env var is set. */
    EnablePasswordLogin: boolean;
    get hasNonDuploUserSources(): boolean;
}
declare const EXPIRE_SECONDS_EARLY: number;
declare class JwtResponse {
    constructor(properties?: Partial<JwtResponse>);
    Token: string;
    IsAdmin: boolean;
    TenantId: string;
    ExpiresAt: Date;
    isValid(): boolean;
    get isExpired(): boolean;
}
interface DuploCiClientEndpoint {
    argoTenantId: string;
    apiUrl: string;
}
declare class DuploCiClientConfig extends JwtResponse {
    constructor(properties?: Partial<DuploCiClientConfig>);
    argoTenantId: string;
    apiUrl: string;
    duploToken: string;
}
declare class UserTenant {
    constructor(properties?: Partial<UserTenant>);
    TenantId: string;
    AccountName: string;
    PlanID?: string;
    Metadata?: CustomData[];
    InfraOwner?: string;
    ExistingK8sNamespace?: string;
    Tags?: TenantTags[];
    Features?: TenantFeatures;
    aiWorkspace?: AIWorkspaceBase;
    isAIWorkspace?: boolean;
    isPlatformTenant?: boolean;
    get workspaceName(): string;
    get workspaceId(): string;
    /** Retrieves a User Tenant metadata value. */
    getMetaValueByKey(key: string): string;
}
declare class TenantTags {
    constructor(properties?: Partial<TenantTags>);
    Key: string;
    Value: string;
}
declare class UserPublicKey {
    constructor(properties?: Partial<UserPublicKey>);
    PublicKey: string;
}
declare class UserApiToken {
    constructor(properties?: Partial<UserApiToken>);
    Name: string;
    Token: string;
    ExpirationDate: string;
}
declare class UserDevspace {
    constructor(properties?: Partial<UserDevspace>);
    IsAdmin: boolean;
    IsEnabled: boolean;
    Size: string;
    Username?: string;
}
declare enum UserRoleSource {
    Duplo = "Duplo",
    AzureAD = "AzureAd",
    Okta = "Okta"
}
interface UserSettings {
    /** null = never asked → prompt once. false = declined → don't re-prompt. */
    AnalyticsConsent?: boolean | null;
}
declare class UserRoleInfo {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Partial<UserRoleInfo>);
    ApiTokens?: UserApiToken[];
    Devspaces?: UserDevspace[];
    CurrentSessionToken?: string;
    IsConfirmationEmailSent?: boolean;
    IsReadOnly?: boolean;
    IsVpnConfigCreated?: boolean;
    Role?: string;
    Roles: UserRole[];
    Settings?: UserSettings;
    TenantAccess?: Record<string, TenantAccessPolicy>;
    UserSource?: UserRoleSource | '';
    Username: string;
    VpnPassword?: string;
    VpnServerUrl?: string;
    VpnStaticIp?: string;
    PublicKey?: string;
    get isDuploUser(): boolean;
    get isAdmin(): boolean;
    get isAiStudioAdmin(): boolean;
    isReadOnly(tenantId: string): boolean;
}
declare class UserAuthConfig {
    ISVPNAUTHBYLDAP: boolean;
    VPNADDRESSINGMETHOD: string;
    WAFDASHBOARDURL: string;
    VPNSERVERIP: string;
}
declare enum UserProvider {
    Google = "google",
    Microsoft = "microsoft",
    AzureAD = "azure-ad",
    Okta = "okta",
    Keycloak = "keycloak",
    Local = "local"
}
/** Error codes rendered by LoginComponent through the `/app/auth/:error` route. */
declare const AUTH_ERROR: {
    readonly NO_ROLE: "no-role";
    readonly NO_SUBSCRIPTION: "no-subscription";
    readonly NO_TENANT_ACCESS: "no-tenant-access";
    readonly TIMEOUT: "timeout";
};
declare enum UserRole {
    User = "User",
    Admin = "Administrator",
    Signup = "SignupUser",
    Security = "SecurityAdmin",
    AiStudioAdmin = "AIStudioAdmin"
}
declare const UserRoles: {
    LoggedIn: UserRole[];
    Security: UserRole[];
    Signup: UserRole[];
    User: UserRole[];
    Admin: UserRole[];
    AIStudioAdmin: UserRole[];
};
declare class UserPrincipal {
    id: string;
    provider: UserProvider;
    username?: string;
    email: string;
    roles?: Array<UserRole>;
    token?: string;
    isReadOnly?: boolean;
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Partial<UserPrincipal>);
    /** Try to find the best way to identify a user. */
    get fuzzyPrincipal(): string;
    isAdmin(): boolean;
    isAiStudioAdmin(): boolean;
    /**
     * Checks if the user has any one of the given roles (or the user is an administrator).
     *
     * @param access  A list of roles or role names to check
     * @returns true if the user passes any of the roles given.
     */
    hasAnyRole(access: Array<string | UserRole>): boolean;
}
/**
 *  Represents the currently logged-in user's session.
 *
 *  This class is instantiated automatically by Angular's DI system, but data is only populated
 *  by the AuthNZService.
 *
 *  - Manages applicable session state in the browser's localStorage  for:
 *    - userPrincipal
 *    - this._tenant
 *    - userProvider
 *  - Provides Observable(s) for:
 *    - currentUser
 *    - currentTenant
 *    - currentAccessibleTenants
 *  - Does not require any DI dependencies, so there are no circular references.
 */
declare class UserSession {
    private router;
    private _iframeConfigs;
    currentIframeCinfigs: Observable<Map<string, IframeConfigs[]>>;
    private _user;
    private _userRoleInfo;
    private _tenant;
    private _duploCi;
    private _accessibleTenants;
    readonly currentUser: Observable<UserPrincipal>;
    readonly currentTenant: Observable<UserTenant>;
    readonly currentDuploCi: Observable<DuploCiClientConfig>;
    readonly currentAccessibleTenants: Observable<UserTenant[]>;
    readonly currentUserRoleInfo: Observable<UserRoleInfo>;
    userAuthConfig: UserAuthConfig;
    private _defaultTenant;
    constructor(router: Router);
    clear(): void;
    get listRefreshFrequency(): number;
    getRefreshTimer(immediate?: boolean, frequency?: number): Observable<number>;
    getTenantRefreshTimer(immediate?: boolean, frequency?: number): Observable<[UserTenant, boolean]>;
    getDuploCiRefreshTimer(immediate?: boolean, frequency?: number): Observable<[UserTenant, boolean]>;
    get user(): UserPrincipal;
    get tenant(): UserTenant;
    get duploCi(): DuploCiClientConfig;
    get iframeConfigs(): Map<string, IframeConfigs[]>;
    get defaultTenant(): UserTenant;
    get accessibleTenants(): UserTenant[];
    get bearerToken(): string;
    get provider(): string;
    get userRoleInfo(): UserRoleInfo;
    set user(user: UserPrincipal);
    set tenant(tenant: UserTenant);
    set duploCi(duploCi: DuploCiClientConfig);
    set iframeConfigs(iframeConfigs: Map<string, IframeConfigs[]>);
    set accessibleTenants(accessibleTenants: UserTenant[]);
    set defaultTenant(tenant: UserTenant);
    set userRoleInfo(userRoleInfo: UserRoleInfo);
    set appConfigs(appConfigs: CustomDataEx[]);
    get appConfigs(): CustomDataEx[] | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserSession, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserSession>;
}

declare class RestrictElementAccess {
    protected session: UserSession;
    protected router: Router;
    constructor(session: UserSession, router: Router);
    isUserReadonly(): boolean;
}
/** Shared entry point for call sites that only need the readonly check, not the directive itself. */
declare function isSessionReadOnly(session: UserSession, router: Router): boolean;
declare class DisableForReadonlyUserDirective extends RestrictElementAccess implements OnInit, OnDestroy {
    private _el;
    private renderer;
    protected session: UserSession;
    protected router: Router;
    private _disableForReadonlyUser;
    set disableForReadonlyUser(value: boolean | string);
    private _unsubscribeAll;
    /**
     * Whether this directive is the one that currently has the element disabled.
     *
     * doReadonly() runs on every tenant-refresh tick, so both branches have to be idempotent.
     * Without this flag the non-readonly branch stripped the `disabled` attribute on every tick,
     * including from elements it never disabled — which silently cleared what a `[disabled]`
     * binding had set, and Angular does not rewrite a property binding whose value has not changed,
     * so the element stayed enabled until that expression next changed. The readonly branch had the
     * mirror problem: it wrapped the element in a fresh title span each tick, nesting spans for as
     * long as the page stayed open.
     */
    private _readonlyApplied;
    constructor(_el: ElementRef, renderer: Renderer2, session: UserSession, router: Router);
    ngOnInit(): void;
    doReadonly(): void;
    private wrapReadonlyTitleElement;
    private unwrapReadonlyTitleElement;
    private onClick;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DisableForReadonlyUserDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DisableForReadonlyUserDirective, "[disableForReadonlyUser]", never, { "disableForReadonlyUser": { "alias": "disableForReadonlyUser"; "required": false; }; }, {}, never, never, false, never>;
}
declare class HideForReadonlyUserDirective extends RestrictElementAccess implements OnInit, OnDestroy {
    private _el;
    protected session: UserSession;
    protected router: Router;
    private _hideForReadonlyUser;
    set hideForReadonlyUser(value: boolean | string);
    private _unsubscribeAll;
    constructor(_el: ElementRef, session: UserSession, router: Router);
    ngOnInit(): void;
    ngOnDestroy(): void;
    doReadonly(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HideForReadonlyUserDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HideForReadonlyUserDirective, "[hideForReadonlyUser]", never, { "hideForReadonlyUser": { "alias": "hideForReadonlyUser"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ViewJsonComponent extends RestrictElementAccess implements OnInit, OnChanges {
    private clipboardService;
    private toastr;
    protected session: UserSession;
    protected router: Router;
    messageObject: any;
    downloadFileName: string;
    enableEdit: boolean;
    heightToReduce: number;
    isEditMode: boolean;
    delaySizeChange: boolean;
    editedMessage: EventEmitter<string>;
    messageText: string;
    messageTextEdited: string;
    jsonEditorOptions: any;
    jsonEditorOptionsReadOnly: any;
    tooltipEdit: NgbTooltip;
    tooltipEditText: string;
    tooltipEditIcon: string;
    screenHeight: number;
    screenWidth: number;
    divHeight: string;
    constructor(clipboardService: ClipboardService, toastr: DuploToastrService, session: UserSession, router: Router);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewChecked(): void;
    getScreenSize(event?: any): void;
    getMessageAsText(): string;
    downloadJson(): void;
    copyTextToClipboard(): void;
    editJson(): void;
    updateMessage(): void;
    cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewJsonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewJsonComponent, "app-view-json-comp", never, { "messageObject": { "alias": "messageObject"; "required": false; }; "downloadFileName": { "alias": "downloadFileName"; "required": false; }; "enableEdit": { "alias": "enableEdit"; "required": false; }; "heightToReduce": { "alias": "heightToReduce"; "required": false; }; "isEditMode": { "alias": "isEditMode"; "required": false; }; "delaySizeChange": { "alias": "delaySizeChange"; "required": false; }; }, { "editedMessage": "editedMessage"; }, never, never, false, never>;
}

declare class ViewJsonModalComponent extends RestrictElementAccess {
    activeModal: NgbActiveModal;
    private clipboardService;
    private toastr;
    protected session: UserSession;
    protected router: Router;
    /** Allow supplying a plain-text title for the header. */
    headerText: string;
    /** Allow supplying a plain-text message or  object for the body. */
    messageText: string;
    showDownload: false;
    downloadFileName: string;
    enableEdit: boolean;
    isEditMode: boolean;
    fullScreen: boolean;
    editedMessage: EventEmitter<string>;
    messageTextEdited: string;
    jsonEditorOptions: any;
    jsonEditorOptionsReadOnly: any;
    tooltipEditText: string;
    tooltipEditIcon: string;
    tooltipEdit: NgbTooltip;
    constructor(activeModal: NgbActiveModal, clipboardService: ClipboardService, toastr: DuploToastrService, session: UserSession, router: Router);
    getHeaderAsText(): string;
    getMessageAsText(): string;
    downloadJson(): void;
    copyTextToClipboard(): void;
    editJson(): void;
    updateMessage(): void;
    cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewJsonModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewJsonModalComponent, "app-view-json", never, { "headerText": { "alias": "headerText"; "required": false; }; "messageText": { "alias": "messageText"; "required": false; }; "showDownload": { "alias": "showDownload"; "required": false; }; "downloadFileName": { "alias": "downloadFileName"; "required": false; }; "enableEdit": { "alias": "enableEdit"; "required": false; }; "isEditMode": { "alias": "isEditMode"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; }, { "editedMessage": "editedMessage"; }, never, never, false, never>;
}

declare class ViewYamlComponent extends RestrictElementAccess implements OnInit, OnChanges {
    private clipboardService;
    private toastr;
    protected session: UserSession;
    protected router: Router;
    messageObject: any;
    downloadFileName: string;
    heightToReduce: number;
    editedMessage: EventEmitter<string>;
    canEditYml: boolean;
    isEditMode: boolean;
    messageText: string;
    messageTextEdited: string;
    yamlEditorOptions: any;
    yamlEditorOptionsReadOnly: any;
    tooltipEditText: string;
    tooltipEditIcon: string;
    screenHeight: number;
    screenWidth: number;
    divHeight: string;
    tooltipEdit: NgbTooltip;
    constructor(clipboardService: ClipboardService, toastr: DuploToastrService, session: UserSession, router: Router);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    getScreenSize(event?: any): void;
    getMessageAsText(): string;
    downloadYAML(): void;
    copyTextToClipboard(): void;
    editYAML(): void;
    updateMessage(): void;
    cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewYamlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewYamlComponent, "app-view-yaml-comp", never, { "messageObject": { "alias": "messageObject"; "required": false; }; "downloadFileName": { "alias": "downloadFileName"; "required": false; }; "heightToReduce": { "alias": "heightToReduce"; "required": false; }; "canEditYml": { "alias": "canEditYml"; "required": false; }; "isEditMode": { "alias": "isEditMode"; "required": false; }; }, { "editedMessage": "editedMessage"; }, never, never, false, never>;
}

declare class RootImportsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RootImportsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RootImportsModule, never, [typeof i1.MonacoEditorModule, typeof i2.MarkdownModule], [typeof i1.MonacoEditorModule, typeof i2.MarkdownModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RootImportsModule>;
}

declare class RippleEffectDirective {
    private _elementRef;
    private _nativeElement;
    wave: string;
    /**
     * Constructor
     *
     * @param {ElementRef} _elementRef
     */
    constructor(_elementRef: ElementRef);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RippleEffectDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RippleEffectDirective, "[rippleEffect]", never, { "wave": { "alias": "wave"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FeatherIconDirective implements OnChanges {
    private _elementRef;
    private _changeDetector;
    name: string;
    class: string;
    size: string;
    constructor(_elementRef: ElementRef, _changeDetector: ChangeDetectorRef);
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FeatherIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FeatherIconDirective, "[data-feather]", never, { "name": { "alias": "data-feather"; "required": false; }; "class": { "alias": "class"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CoreDirectivesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreDirectivesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CoreDirectivesModule, [typeof RippleEffectDirective, typeof FeatherIconDirective], never, [typeof RippleEffectDirective, typeof FeatherIconDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CoreDirectivesModule>;
}

declare class InitialsPipe implements PipeTransform {
    transform(fullName: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitialsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<InitialsPipe, "initials", false>;
}

declare class FilterPipe implements PipeTransform {
    /**
     * Transform
     *
     * @param {any[]} items
     * @param {string} searchText
     * @param {string} key
     *
     * @returns {any}
     */
    transform(items: any[], searchText: string, key: string): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FilterPipe, "filter", false>;
}

declare class StripHtmlPipe implements PipeTransform {
    transform(value: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<StripHtmlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<StripHtmlPipe, "striphtml", false>;
}

/**
 * Sanitize HTML
 */
declare class SafePipe implements PipeTransform {
    protected _sanitizer: DomSanitizer;
    /**
     * Pipe Constructor
     *
     * @param _sanitizer: DomSanitezer
     */
    constructor(_sanitizer: DomSanitizer);
    /**
     * Transform
     *
     * @param value: string
     * @param type: string
     */
    transform(value: string, type: string): SafeHtml | SafeStyle | SafeScript | SafeUrl | SafeResourceUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<SafePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SafePipe, "safe", false>;
}

declare class OrderByPipe implements PipeTransform {
    transform(array: any[], field: string, order?: 'asc' | 'desc'): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderByPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OrderByPipe, "orderby", false>;
}

declare class UIConfigPipe implements PipeTransform {
    constructor();
    transform(key: string, fallback?: string | boolean): string | boolean | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UIConfigPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<UIConfigPipe, "uiConfig", false>;
}

declare class PrettyJsonPipe implements PipeTransform {
    transform(val: string): string;
    private syntaxHighlight;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrettyJsonPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<PrettyJsonPipe, "prettyJson", true>;
}

declare class PrettyYamlPipe implements PipeTransform {
    transform(val: string | object): string;
    private syntaxHighlight;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrettyYamlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<PrettyYamlPipe, "prettyYaml", true>;
}

declare class CorePipesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CorePipesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CorePipesModule, [typeof InitialsPipe, typeof FilterPipe, typeof StripHtmlPipe, typeof SafePipe, typeof OrderByPipe, typeof UIConfigPipe], [typeof PrettyJsonPipe, typeof PrettyYamlPipe], [typeof InitialsPipe, typeof FilterPipe, typeof StripHtmlPipe, typeof SafePipe, typeof OrderByPipe, typeof UIConfigPipe, typeof PrettyJsonPipe, typeof PrettyYamlPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CorePipesModule>;
}

declare class IconModule {
    constructor(matIconRegistry: MatIconRegistry, domSanitizer: DomSanitizer);
    static ɵfac: i0.ɵɵFactoryDeclaration<IconModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IconModule, never, [typeof i9.MatIconModule], [typeof i9.MatIconModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IconModule>;
}

declare class CoreCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CoreCommonModule, never, [typeof i3.CommonModule, typeof i2$1.FlexLayoutModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof CoreDirectivesModule, typeof CorePipesModule, typeof i9.MatIconModule, typeof IconModule], [typeof i3.CommonModule, typeof i2$1.FlexLayoutModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof CoreDirectivesModule, typeof CorePipesModule, typeof i9.MatIconModule, typeof IconModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CoreCommonModule>;
}

declare class RestrictElementAccessModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RestrictElementAccessModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RestrictElementAccessModule, [typeof DisableForReadonlyUserDirective, typeof HideForReadonlyUserDirective], [typeof i3.CommonModule, typeof CoreCommonModule, typeof i3$2.NgbTooltipModule, typeof i3$2.NgbPopoverModule, typeof i2.MarkdownModule], [typeof DisableForReadonlyUserDirective, typeof HideForReadonlyUserDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RestrictElementAccessModule>;
}

declare class CopyToClipboardComponent {
    private clipboardService;
    source: string | ElementRef<HTMLElement>;
    includeCopyText: boolean;
    manual: boolean;
    placement?: Placement;
    onclick: EventEmitter<void>;
    tooltip: NgbTooltip;
    constructor(clipboardService: ClipboardService);
    click($event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CopyToClipboardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CopyToClipboardComponent, "copy-to-clipboard", never, { "source": { "alias": "source"; "required": false; }; "includeCopyText": { "alias": "includeCopyText"; "required": false; }; "manual": { "alias": "manual"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; }, { "onclick": "click"; }, never, never, true, never>;
}

declare class HelpIconComponent implements OnInit {
    private readonly translateService;
    private readonly clipboard;
    private _key;
    help: string;
    header: string;
    placement: string;
    maxSize: string;
    set key(key: string);
    constructor(translateService: TranslateService, clipboard: ClipboardService);
    ngOnInit(): void;
    init(): void;
    copy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HelpIconComponent, "help-icon, [help-icon]", never, { "help": { "alias": "help"; "required": false; }; "header": { "alias": "header"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "key": { "alias": "key"; "required": false; }; }, {}, never, never, false, never>;
}

declare class HelpDirective implements AfterViewInit {
    private i18n;
    private host;
    naveItems: QueryList<ViewContainerRef>;
    hostName: any;
    constructor(i18n: TranslateService, host: ViewContainerRef);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HelpDirective, "[navHelp]", never, {}, {}, ["naveItems"], never, false, never>;
}

declare class HelpModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HelpModule, [typeof HelpIconComponent, typeof HelpDirective], [typeof i3.CommonModule, typeof CoreCommonModule, typeof i3$2.NgbTooltipModule, typeof i3$2.NgbPopoverModule, typeof i2.MarkdownModule], [typeof HelpIconComponent, typeof HelpDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HelpModule>;
}

declare class FlatStatusFilter {
    constructor(properties?: Partial<FlatStatusFilter>);
    name: string;
    label: string;
    count: number;
    hideWhenZero?: boolean;
    hideCount?: boolean;
    badgeClass?: string;
    group?: string;
}
declare class FlatStatusFilterComponent implements OnChanges {
    filters: FlatStatusFilter[];
    activeStatus: string;
    statusChanged: EventEmitter<string>;
    showAll: boolean;
    defaultAll: boolean;
    showCount: boolean;
    computedFilters: FlatStatusFilter[];
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    setStatusFilter(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FlatStatusFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlatStatusFilterComponent, "app-flat-status-filter", never, { "filters": { "alias": "filters"; "required": false; }; "activeStatus": { "alias": "activeStatus"; "required": false; }; "showAll": { "alias": "showAll"; "required": false; }; "defaultAll": { "alias": "defaultAll"; "required": false; }; "showCount": { "alias": "showCount"; "required": false; }; }, { "statusChanged": "changed"; }, never, never, true, never>;
}

interface FilterPill {
    value: string;
    label: string;
}
/**
 * A single-select facet, sized to sit beside a datatable's search box (project it
 * into `[datatable-filters]`). Unlike app-flat-status-filter it carries no counts;
 * past a handful of values, app-flat-dropdown-filter reads better in a toolbar.
 */
declare class FilterPillsComponent {
    readonly options: i0.InputSignal<FilterPill[]>;
    /** '' is the All pill. */
    readonly value: i0.InputSignal<string>;
    readonly allLabel: i0.InputSignal<string>;
    readonly showAll: i0.InputSignal<boolean>;
    /** Names the row for screen readers, which otherwise hear loose buttons. */
    readonly ariaLabel: i0.InputSignal<string>;
    readonly valueChange: i0.OutputEmitterRef<string>;
    /** Resolved here, not in a binding, so it runs once per input change. */
    readonly pills: i0.Signal<FilterPill[]>;
    select(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterPillsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterPillsComponent, "app-filter-pills", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "allLabel": { "alias": "allLabel"; "required": false; "isSignal": true; }; "showAll": { "alias": "showAll"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

/** Datatable footer text, e.g. "Showing 26 – 50 of 540 · 25 on this page". */
declare class DatatablePageSummaryPipe implements PipeTransform {
    transform(rowCount: number | undefined, pageSize: number, offset: number): string;
    private format;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatatablePageSummaryPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DatatablePageSummaryPipe, "datatablePageSummary", true>;
}

declare class SearchableDatatableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchableDatatableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SearchableDatatableModule, [typeof SearchableDatatableComponent], [typeof CoreCommonModule, typeof i3$2.NgbModule, typeof i4.NgxDatatableModule, typeof i5.NgSelectModule, typeof HelpModule, typeof RestrictElementAccessModule, typeof DatatablePageSummaryPipe], [typeof CoreCommonModule, typeof i3$2.NgbModule, typeof i4.NgxDatatableModule, typeof SearchableDatatableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SearchableDatatableModule>;
}

/**
 * A convenience type representing all types that we know how to extract error messages from.
 */
type ErrorMessage = string | HttpErrorResponse | ErrorEvent | Error;
/**
 * An interface for a class that knows how to report errors to the user.
 */
interface ErrorReporter {
    reportError: (error: ErrorMessage, title?: string) => void;
}
/**
 * Resolves to {@link SharedAlertsService} (toastr) unless the app provides its own.
 *
 * The root factory matters for components created outside a module's injector —
 * anything opened through NgbModal, for instance, is instantiated against the root
 * injector, so module-level `providers` are invisible to it. Without a default,
 * importing a common-lib module lazily (feature module, Module Federation remote)
 * left the token unresolvable and threw
 * `NullInjectorError: No provider for InjectionToken Duplo ErrorReporter`.
 * An explicit provider in the consuming app still wins over this default.
 */
declare const ERROR_REPORTER: InjectionToken<ErrorReporter>;
/**
 * An interface for a class that knows how to report success to the user.
 */
interface SuccessReporter {
    reportSuccess: (message: string, title?: string) => void;
}
/** Success counterpart of {@link ERROR_REPORTER}; same root-factory rationale. */
declare const SUCCESS_REPORTER: InjectionToken<SuccessReporter>;
/**
 * An interface for a class that knows how to report warnings to the user.
 */
interface WarningReporter {
    reportWarning: (message: string, title?: string) => void;
}
/** Warning counterpart of {@link ERROR_REPORTER}; same root-factory rationale. */
declare const WARNING_REPORTER: InjectionToken<WarningReporter>;
/**
 * Extracts an error message.
 */
declare function extractErrorMessage(err: ErrorMessage): string;
/** `ApiResponse.code` the backend sets when an entitlement guard refused a create. */
declare const LICENSE_REFUSAL_CODE = "license_limit_exceeded";
/** Whether an error is a license-limit refusal from the backend's entitlement guard. */
declare function isLicenseRefusal(err: ErrorMessage): boolean;
declare class SharedAlertsService implements ErrorReporter, SuccessReporter, WarningReporter {
    private toastr;
    constructor(toastr: ToastrService);
    reportSuccess(message: string, title?: string): void;
    reportWarning(message: string, title?: string): void;
    reportError(error: ErrorMessage, title?: string): void;
    systemDown(message: ErrorMessage): void;
    /** RxJS operator for system down detection. */
    catchAndReportSystemDown<T>(): OperatorFunction<T, T>;
    catchAndReportSystemDownToConsole<T>(): OperatorFunction<T, T>;
    /** RxJS operator for error handling. */
    catchAndReportError<T>(): OperatorFunction<T, T>;
    configureToast(override?: Partial<IndividualConfig>): Partial<IndividualConfig>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SharedAlertsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SharedAlertsService>;
}

declare class ConfirmationModalComponent {
    activeModal: NgbActiveModal;
    errorReporter: ErrorReporter;
    successReporter: SuccessReporter;
    /** Allow supplying a plain-text title for the header. */
    headerText: string;
    /** Allow supplying a template for the header. */
    headerTemplate: TemplateRef<void>;
    /** Allow supplying a plain-text message for the body. */
    messageText: string;
    /** Allow supplying a template for the header. */
    messageTemplate: TemplateRef<void>;
    data: any;
    showToggleSwitch: boolean;
    toggleText: string;
    tooltipText: string;
    toggleValue: boolean;
    constructor(activeModal: NgbActiveModal, errorReporter: ErrorReporter, successReporter: SuccessReporter);
    /** Convenience method used by ConfirmationModalRef.confirmThenAct() */
    getHeaderAsText(): string;
    /** Convenience method used by ConfirmationModalRef.confirmThenAct() */
    getMessageAsText(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmationModalComponent, "confirmation-modal", never, { "headerText": { "alias": "headerText"; "required": false; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; }; "messageText": { "alias": "messageText"; "required": false; }; "messageTemplate": { "alias": "messageTemplate"; "required": false; }; "data": { "alias": "data"; "required": false; }; "showToggleSwitch": { "alias": "showToggleSwitch"; "required": false; }; "toggleText": { "alias": "toggleText"; "required": false; }; "tooltipText": { "alias": "tooltipText"; "required": false; }; }, {}, never, never, false, never>;
}

declare class DeleteConfirmationModalComponent {
    activeModal: NgbActiveModal;
    errorReporter: ErrorReporter;
    successReporter: SuccessReporter;
    /** Allow supplying a plain-text title for the header. */
    headerText: string;
    /** Allow supplying a template for the header. */
    headerTemplate: TemplateRef<void>;
    /** Allow supplying a plain-text message for the body. */
    messageText: string;
    /** Allow supplying a template for the header. */
    messageTemplate: TemplateRef<void>;
    data: any;
    showToggleSwitch: boolean;
    toggleText: string;
    tooltipText: string;
    toggleValue: boolean;
    entityType: string;
    private _confirmationText;
    set confirmationText(value: string);
    get confirmationText(): string;
    confirmationInputValue: string;
    constructor(activeModal: NgbActiveModal, errorReporter: ErrorReporter, successReporter: SuccessReporter);
    /** Convenience method used by ConfirmationModalRef.confirmThenAct() */
    getHeaderAsText(): string;
    /** Convenience method used by ConfirmationModalRef.confirmThenAct() */
    getMessageAsText(): string;
    get isConfirmationTextMatched(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteConfirmationModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeleteConfirmationModalComponent, "delete-confirmation-modal", never, { "headerText": { "alias": "headerText"; "required": false; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; }; "messageText": { "alias": "messageText"; "required": false; }; "messageTemplate": { "alias": "messageTemplate"; "required": false; }; "data": { "alias": "data"; "required": false; }; "showToggleSwitch": { "alias": "showToggleSwitch"; "required": false; }; "toggleText": { "alias": "toggleText"; "required": false; }; "tooltipText": { "alias": "tooltipText"; "required": false; }; "entityType": { "alias": "entityType"; "required": false; }; "confirmationText": { "alias": "confirmationText"; "required": false; }; }, {}, never, never, false, never>;
}

/** A marker directive to make form information injectable into children. */
declare class FormRefDirective implements AfterViewInit {
    readonly elementRef: ElementRef<HTMLFormElement>;
    readonly formGroupDirective: FormGroupDirective;
    readonly ngForm: NgForm;
    readonly name: string | undefined;
    readonly form: NgForm | FormGroupDirective;
    constructor(elementRef: ElementRef<HTMLFormElement>, formGroupDirective: FormGroupDirective, ngForm: NgForm);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormRefDirective, [null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormRefDirective, "form", never, { "name": { "alias": "name"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * A simple utility directive to provide the parent form to a child component.
 *
 * - If you are using template-driven forms, the simplest approach is to add the `use-parent-form` attribute
 *   to some top-level container element in your child component.
 * - If you are using reactive forms, you should pass the formGroup to the child as an input instead.
 */
declare class UseParentFormDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<UseParentFormDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UseParentFormDirective, "[use-parent-form]", never, {}, {}, never, never, false, never>;
}

declare class FormFieldComponent implements OnInit, AfterContentInit {
    private _changeDetector;
    private _element;
    readonly formRef: FormRefDirective;
    private i18n;
    viewContainerRef: ViewContainerRef;
    private renderer2;
    private _control;
    private _modelElement;
    private _label;
    helpIcon: HelpIconComponent;
    private _labelViewContainerRef;
    constructor(_changeDetector: ChangeDetectorRef, _element: ElementRef<HTMLElement>, formRef: FormRefDirective, i18n: TranslateService, viewContainerRef: ViewContainerRef, renderer2: Renderer2);
    /** Allow passing the control as an input. */
    set control(control: NgControl);
    /** Allow discovering the control from the content. */
    set contentControl(control: NgControl);
    /** Allow discovering the control's host element from the content. */
    set modelElement(ref: ElementRef<HTMLElement>);
    /** Allow discovering the control's host element from the content. */
    set labelViewContainerRef(ref: ViewContainerRef);
    get control(): NgControl;
    get name(): string;
    get label(): HTMLLabelElement;
    get labelText(): string;
    ngAfterContentInit(): void;
    ngOnInit(): void;
    /**
     * Internal method to set up the ID (and possibley name) HTML attributes for the control.
     *
     * @returns the ID attribute for the control's host element
     */
    private setupControlIdentification;
    /**
     * Internal method to set up the label for the control.
     */
    private setupControlLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormFieldComponent, "form-field", never, { "control": { "alias": "control"; "required": false; }; }, {}, ["contentControl", "modelElement", "labelViewContainerRef"], ["*"], false, never>;
}

/**
 * Simple service for translating formatted messages with support for fallback keys.
 */
declare class MessageService {
    private i18n;
    constructor(i18n: TranslateService);
    /**
     *  Instantly translates a key.  Supports a list of keys to be used as fallback translations.
     *
     *  Unlike the TranslateService.instant function, this function will return `null` if no translation was found.
     *
     *  @param key      a single key, or a list of keys to look up in order
     *  @param params   message formatting parameters
     */
    instant(key: string | string[], params?: object): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MessageService>;
}

/**
 * Represents a summary of errors in the form.  Does not include individual field errors.
 */
declare class ErrorSummary {
    header?: ErrorMessage;
    messages?: ErrorMessage[];
    constructor(header?: ErrorMessage, messages?: ErrorMessage[]);
    hasErrors(): boolean;
}
declare class FormGroupErrorsComponent implements ErrorReporter {
    private messages;
    host: ElementRef;
    private cdr;
    showSummaryWhen: 'always' | 'submitted' | 'dirty' | 'touched' | 'never';
    showDetailsWhen: 'always' | 'submitted' | 'dirty' | 'touched' | 'never';
    form: NgForm | FormGroupDirective;
    summary: ErrorSummary;
    title: string;
    fields: {
        [name: string]: FormFieldErrorsComponent;
    };
    /** Convenience setter to set a single summary header message. */
    set summaryHeader(header: ErrorMessage);
    /** Convenience setter to set a single summary error message. */
    set summaryMessage(message: ErrorMessage);
    msgContainers: QueryList<ElementRef>;
    checkMsgDebounce: any;
    /** Allow this component to act as an ErrorReporter. */
    reportError(error: ErrorMessage): void;
    /**
     * Drops any reported summary error.
     *
     * `summaryMessage` only ever overwrites, so without this a reported error outlives the attempt
     * that produced it — visible again the next time the summary is shown. Callers that report into
     * this component should clear before each new attempt.
     */
    clearError(): void;
    constructor(messages: MessageService, formGropuDirective: FormGroupDirective, ngForm: NgForm, host: ElementRef, cdr: ChangeDetectorRef);
    /** Internal method, called by a FormFieldErrorsComponent, to add itself to the list. */
    add(field: FormFieldErrorsComponent): string;
    /** Internal method, called by a FormFieldErrorsComponent, to remove itself from the list. */
    remove(field: FormFieldErrorsComponent): string;
    /** Internal getter to return a formatted error summary header. */
    get summaryHeaderMessage(): string;
    /** Internal getter to return a list of formatted error summary messages. */
    get summaryMessages(): string[];
    /** Internal getter to return a list of formatted error detail messages. */
    get detailMessages(): string[];
    /**
     *  Whether or not any error messages (or the title!) need to be displayed.
     */
    get showErrors(): boolean;
    /**
     *  Whether or not summary errors should be displayed.
     */
    get showSummary(): boolean;
    /**
     *  Whether or not detailed errors should be displayed.
     */
    get showDetails(): boolean;
    /**
    * Check if any message content overflows its container and add the 'has-overflow' class accordingly
    */
    checkMessageOverflow(): void;
    toggleMsgView(container: HTMLElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormGroupErrorsComponent, [null, { optional: true; }, { optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormGroupErrorsComponent, "[form-group-errors], form-group-errors", never, { "showSummaryWhen": { "alias": "showSummaryWhen"; "required": false; }; "showDetailsWhen": { "alias": "showDetailsWhen"; "required": false; }; "form": { "alias": "form"; "required": false; }; "summary": { "alias": "summary"; "required": false; }; "title": { "alias": "title"; "required": false; }; "summaryHeader": { "alias": "summaryHeader"; "required": false; }; "summaryMessage": { "alias": "summaryMessage"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class FormFieldErrorsComponent implements AfterViewInit, OnDestroy {
    private messages;
    private elementRef;
    private formField;
    private formGroupErrors;
    control: NgControl;
    name: string | null;
    label: string | null;
    showWhen: 'always' | 'submitted' | 'dirty' | 'touched' | 'never';
    customErrorMessage: string;
    form: NgForm | FormGroupDirective;
    constructor(messages: MessageService, elementRef: ElementRef, formGroupDirective: FormGroupDirective, ngForm: NgForm, formField: FormFieldComponent, formGroupErrors: FormGroupErrorsComponent);
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    /**
     *  Whether or not errors should be displayed.
     */
    get showErrors(): boolean;
    /**
     *  Returns the field label, to be used for error messages.
     */
    get fieldLabel(): string;
    /**
     *  Returns the field name, to be used for i18n keys.
     */
    get fieldName(): string;
    /**
     *  Returns the form name, to be used for i18n keys.
     */
    get formName(): string;
    /**
     *  Returns a map of formatted errors.
     */
    get errors(): ValidationErrors;
    private getMessage;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldErrorsComponent, [null, null, { optional: true; }, { optional: true; }, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormFieldErrorsComponent, "form-field-errors, [form-field-errors]", never, { "control": { "alias": "control"; "required": false; }; "name": { "alias": "name"; "required": false; }; "label": { "alias": "label"; "required": false; }; "showWhen": { "alias": "showWhen"; "required": false; }; "customErrorMessage": { "alias": "customErrorMessage"; "required": false; }; "form": { "alias": "form"; "required": false; }; }, {}, never, never, false, never>;
}

declare class PasswordFieldComponent {
    input: GenericFormInput;
    change: EventEmitter<any>;
    onValueChange(event: any): void;
    /**
     * Closest enclosing form, resolved with `@Host()` so it matches the `ControlContainer`
     * the inner `NgModel` binds to via `[use-parent-form]` on this component's top-level
     * `<div>` (see password-field.component.html) — without `@Host()` this could resolve to
     * an unrelated ancestor form in templates with multiple sibling `<form>`s (e.g. accordion
     * panels). Used to pass `<form-field-errors>` a "submitted" signal, and to let error text
     * show the field's `label` — `<form-field>`'s own DOM-based label auto-discovery can't see
     * a control buried in this component's own template.
     */
    formDirective: NgForm | null;
    constructor(ngForm: NgForm);
    /**
     * Emits on every value change (ngModelChange), not just the native `change`/blur event.
     * Lets consumers propagate the value immediately — e.g. so a secret typed and submitted
     * via Enter (without blurring) is still captured. Additive; existing `(change)` users are unaffected.
     */
    valueChange: EventEmitter<any>;
    onModelChange(value: any): void;
    showPassword: boolean;
    togglePasswordVisibility(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordFieldComponent, [{ optional: true; host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PasswordFieldComponent, "password-field", never, { "input": { "alias": "input"; "required": false; }; }, { "change": "change"; "valueChange": "valueChange"; }, never, never, false, never>;
}

/**
 * Multi-line counterpart to `<password-field>`. HTML `<textarea>` has no `type="password"`,
 * so masking is done with a CSS class instead of swapping the element's native type: `text-masked`
 * (`-webkit-text-security`) where supported, falling back to `text-blurred` (`filter: blur`,
 * universally supported including Firefox) where it isn't. Either way the value starts hidden
 * and the toggle always renders — never a silent plaintext default.
 *
 * Both masking modes are visual-only, to the same degree native `-webkit-text-security` is: the
 * textarea's real DOM value (and whatever a screen reader announces) is unaffected either way —
 * this deters shoulder-surfing, it is not a security boundary against DevTools/DOM inspection or
 * assistive tech. Nothing about the blur fallback makes this worse than the primary path; a
 * control that hid the value from inspection/AT too would need a fundamentally different
 * implementation (rendering fake characters as a separate non-interactive overlay over a
 * differently-typed capture element), out of scope for this component.
 */
declare class MaskedTextareaComponent {
    input: GenericFormInput;
    change: EventEmitter<any>;
    onValueChange(event: any): void;
    formDirective: NgForm | null;
    constructor(ngForm: NgForm);
    valueChange: EventEmitter<any>;
    onModelChange(value: any): void;
    static readonly webkitMaskingSupported: boolean;
    readonly webkitMaskingSupported: boolean;
    showValue: boolean;
    toggleVisibility(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaskedTextareaComponent, [{ optional: true; host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MaskedTextareaComponent, "masked-textarea", never, { "input": { "alias": "input"; "required": false; }; }, { "change": "change"; "valueChange": "valueChange"; }, never, never, false, never>;
}

declare class ValidationErrorsDirective implements OnInit {
    private _container;
    private _control;
    showWhen: 'always' | 'submitted' | 'dirty' | 'touched' | 'never';
    customErrorMessage: string;
    form: NgForm | FormGroupDirective;
    /**
     * Explicit human-readable field name for error messages (e.g. "Credential Type Key"), for inputs
     * whose `name`/control name is a dynamically-generated string (an index or a UID, for a row in a
     * repeated/*ngFor group) rather than something FormFieldErrorsComponent.fieldLabel can turn into a
     * readable label on its own - it only knows how to strip a trailing _NUM suffix, and has no label
     * to read without a <form-field> wrapper. Passed straight through to
     * FormFieldErrorsComponent.label, which already prefers it over every other fallback.
     */
    label?: string;
    component: FormFieldErrorsComponent;
    constructor(_container: ViewContainerRef, _control: NgControl, formGropuDirective: FormGroupDirective, ngForm: NgForm);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidationErrorsDirective, [null, null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ValidationErrorsDirective, "[validation-errors]", never, { "showWhen": { "alias": "validation-errors"; "required": false; }; "customErrorMessage": { "alias": "customErrorMessage"; "required": false; }; "form": { "alias": "form"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ValidationStateDirective {
    private control;
    showWhen: 'always' | 'invalid' | 'submitted' | 'dirty' | 'touched' | 'never';
    private form;
    constructor(control: NgControl, formGropuDirective: FormGroupDirective, ngForm: NgForm);
    get isValid(): boolean;
    get isInvalid(): boolean;
    /**
     *  Whether or not validation state should be displayed.
     */
    get showState(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidationStateDirective, [{ self: true; }, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ValidationStateDirective, "[validation-state]", never, { "showWhen": { "alias": "validation-state"; "required": false; }; }, {}, never, never, false, never>;
}

declare class YamlValidationDirective {
    private _control;
    form: NgForm | FormGroupDirective;
    onSuccessfulYamlValidation?: (ctl: AbstractControl, parsedYaml: Record<string, string> | string) => void;
    constructor(_control: NgControl, formGropuDirective: FormGroupDirective, ngForm: NgForm);
    onKeyUp(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<YamlValidationDirective, [null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<YamlValidationDirective, "[yaml-validation]", never, { "form": { "alias": "form"; "required": false; }; "onSuccessfulYamlValidation": { "alias": "onSuccessfulYamlValidation"; "required": false; }; }, {}, never, never, false, never>;
}

declare class YamlMapValidationDirective {
    private _control;
    form: NgForm | FormGroupDirective;
    constructor(_control: NgControl, formGropuDirective: FormGroupDirective, ngForm: NgForm);
    onValidate(event: KeyboardEvent): void;
    private containsUnquotedNumbersOrBooleans;
    hasInvalidPairs(checkObject: {
        [keyName: string]: string;
    }): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<YamlMapValidationDirective, [null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<YamlMapValidationDirective, "[yaml-map-validation]", never, { "form": { "alias": "form"; "required": false; }; }, {}, never, never, false, never>;
}

declare class XmlValidationDirective {
    private readonly _control;
    form: NgForm | FormGroupDirective;
    constructor(_control: NgControl, formGroupDirective: FormGroupDirective, ngForm: NgForm);
    onKeyUp(event: KeyboardEvent): any;
    private setError;
    static ɵfac: i0.ɵɵFactoryDeclaration<XmlValidationDirective, [null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<XmlValidationDirective, "[xml-validation]", never, { "form": { "alias": "form"; "required": false; }; }, {}, never, never, false, never>;
}

declare class IniValidationDirective {
    private readonly _control;
    form: NgForm | FormGroupDirective;
    constructor(_control: NgControl, formGroupDirective: FormGroupDirective, ngForm: NgForm);
    onKeyUp(event: KeyboardEvent): any;
    private setError;
    static ɵfac: i0.ɵɵFactoryDeclaration<IniValidationDirective, [null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IniValidationDirective, "[ini-validation]", never, { "form": { "alias": "form"; "required": false; }; }, {}, never, never, false, never>;
}

declare class DuploValidators {
    /**
     * Validate a JSON object or JSON array of objects.
     *
     * @param type one of 'object' or 'array'
     * @returns an instance of ValidatorFn
     */
    static json(type?: 'object' | 'array'): ValidatorFn;
    static jsonObject: ValidatorFn;
    static jsonArray: ValidatorFn;
    /**
     * Validate a JSON object or JSON array of objects.
     *
     * @param type one of 'object' or 'array'
     * @returns an instance of ValidatorFn
     */
    static jsonKeyStringValue(): ValidatorFn;
    /**
     * Validates that a value does not appear in a list.
     *
     * @param list  list of any object
     * @param checkCase   whether or not to consider string case
     * @returns an instance of ValidatorFn
     */
    static notExists(list: any[], checkCase?: boolean): ValidatorFn;
    /**
     * Validates that:
     *  - the value does not appear in the list
     *  - the value does not start with item from the list
     *  - no item from the list starts with the value
     *
     * @param list  list of strings
     * @param checkCase   whether or not to consider string case
     * @returns an instance of ValidatorFn
     */
    static notStartsWith(list: string[], checkCase?: boolean): ValidatorFn;
    static cron(control: AbstractControl): ValidationErrors | null;
    static EMAIL_REGEX: RegExp;
    static email(control: AbstractControl): ValidationErrors | null;
    static equalityValidator(otherControlName: string, fieldOneLabel: string, fieldTwoLabel: string): ValidatorFn;
    static NON_UNICODE_REGEX: RegExp;
    /**
     * Validates the control value only contains unicode characters.
     * Angular's pattern validator does not support unicode with regular expressions.
     * Please refer to: https://github.com/angular/angular/issues/51000
     *
     * @returns {ValidatorFn} an instance of ValidatorFn
     */
    static unicode(): ValidatorFn;
    static PORT_RANGE_REGEX: RegExp;
    static readonly KMS_KEY_ID_PATTERN = "^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}|mrk-[0-9a-f]{32})$";
    static readonly KMS_KEY_ARN_PATTERN = "^arn:aws(-us-gov)?:kms:[a-z][a-z0-9\\-]+:[0-9]{12}:key\\/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}|mrk-[0-9a-f]{32})$";
    /**
     * Validates that:
     *  - the value should between the given min and max value
     *  - the value can be port range with hyphen separated
     *  - the value can be individual port
     *  - the value can be port range and individual port with comma separated
     *
     * @param minPort minimum number
     * @param maxPort maximum number
     * @returns an instance of ValidatorFn
     */
    static portRange(minPort: number, maxPort: number): ValidatorFn;
}
declare class NotExistsValidatorDirective implements Validator, OnChanges {
    list: any[];
    private onValidatorChange?;
    validate(control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotExistsValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotExistsValidatorDirective, "[notExists]", never, { "list": { "alias": "notExists"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Async sibling of [notExists] for cases where the "existing values" list is too large
 * to load upfront — checks uniqueness via a server call instead of a static in-memory list.
 * Debounces internally (400ms) so it's safe to bind directly to a fast-typing input.
 */
declare class AsyncNotExistsValidatorDirective implements AsyncValidator {
    checkFn: (value: string) => Observable<boolean>;
    validate(control: AbstractControl): Observable<ValidationErrors | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsyncNotExistsValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AsyncNotExistsValidatorDirective, "[asyncNotExists]", never, { "checkFn": { "alias": "asyncNotExists"; "required": false; }; }, {}, never, never, false, never>;
}
declare class NotExistsCaseValidatorDirective implements Validator, OnChanges {
    list: any[];
    private onValidatorChange?;
    validate(control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotExistsCaseValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotExistsCaseValidatorDirective, "[notExistsCase]", never, { "list": { "alias": "notExistsCase"; "required": false; }; }, {}, never, never, false, never>;
}
declare class NotStartsWithValidatorDirective implements Validator {
    list: string[];
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotStartsWithValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotStartsWithValidatorDirective, "[notStartsWith]", never, { "list": { "alias": "notStartsWith"; "required": false; }; }, {}, never, never, false, never>;
}
declare class NotStartsWithCaseValidatorDirective implements Validator {
    list: string[];
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotStartsWithCaseValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotStartsWithCaseValidatorDirective, "[notStartsWithCase]", never, { "list": { "alias": "notStartsWithCase"; "required": false; }; }, {}, never, never, false, never>;
}
declare class JsonObjectValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonObjectValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<JsonObjectValidatorDirective, "[jsonObject]", never, {}, {}, never, never, false, never>;
}
declare class JsonArrayValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonArrayValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<JsonArrayValidatorDirective, "[jsonArray]", never, {}, {}, never, never, false, never>;
}
declare class JsonKeyStringValueValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonKeyStringValueValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<JsonKeyStringValueValidatorDirective, "[jsonKeyStringValue]", never, {}, {}, never, never, false, never>;
}
declare class CronValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<CronValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CronValidatorDirective, "[validCron]", never, {}, {}, never, never, false, never>;
}
declare class EmailValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<EmailValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EmailValidatorDirective, "[validEmail], [type=\"email\"]", never, {}, {}, never, never, false, never>;
}
declare class NotEqualValidatorDirective implements Validator {
    validateAgainst: string;
    fieldOneLabel: string;
    fieldTwoLabel: string;
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotEqualValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotEqualValidatorDirective, "[notEqualValidator]", never, { "validateAgainst": { "alias": "notEqualValidator"; "required": false; }; "fieldOneLabel": { "alias": "fieldOneLabel"; "required": false; }; "fieldTwoLabel": { "alias": "fieldTwoLabel"; "required": false; }; }, {}, never, never, false, never>;
}
declare class UnicodeValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnicodeValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UnicodeValidatorDirective, "[unicode]", never, {}, {}, never, never, false, never>;
}
declare class PortRangeValidatorDirective implements Validator {
    minPort: number;
    maxPort: number;
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<PortRangeValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PortRangeValidatorDirective, "[portRangeValidator]", never, { "minPort": { "alias": "minPort"; "required": false; }; "maxPort": { "alias": "maxPort"; "required": false; }; }, {}, never, never, false, never>;
}

/** A marker directive to make label information injectable into children. */
declare class LabelRefDirective implements AfterViewInit {
    constructor();
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LabelRefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LabelRefDirective, "label", never, {}, {}, never, never, false, never>;
}

declare class InputTextTrimDirective implements OnInit {
    private ngControl;
    private readonly elementRef;
    private readonly ngForm;
    private destroy$;
    constructor(ngControl: NgControl, elementRef: ElementRef<HTMLInputElement>, ngForm: NgForm, valueAccessors: ControlValueAccessor[], destroy$: SubDestroyService);
    ngOnInit(): void;
    /**
     * Modifies the registerOnChange function of a value accessor to trim whitespace
     * from string inputs before passing them to the original change handler.
     * @param valueAccessor - The ControlValueAccessor bound to this input.
     */
    trimValueAccessor(valueAccessor: ControlValueAccessor): void;
    /**
     * Update the input element value to match the form control's value on form submission.
     */
    updateInputValueOnSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputTextTrimDirective, [null, null, { optional: true; }, { optional: true; self: true; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InputTextTrimDirective, "input[type=\"text\"][name]", never, {}, {}, never, never, false, never>;
}

declare class GenericFormFieldComponent implements OnInit, AfterViewInit {
    input: GenericFormInput;
    form: NgForm | FormGroupDirective;
    change: EventEmitter<any>;
    onValueChange(event: any): void;
    jsonEditorOptions: object;
    jsonEditorSize: JsonEditorSize;
    yamlEditorOptions: any;
    editorContainerEl: ElementRef<HTMLElement>;
    editorEl: ElementRef<HTMLElement>;
    constructor(formGroupDirective: FormGroupDirective, ngForm: NgForm);
    get jsonEditorContainerClass(): string;
    onJsonEditorInit(editor: any): void;
    getOptionLabel(option: any): string;
    get resolvedBindLabel(): string | null;
    get resolvedBindValue(): string | null;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    private updateHeight;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericFormFieldComponent, [{ optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GenericFormFieldComponent, "generic-form-field", never, { "input": { "alias": "input"; "required": false; }; "form": { "alias": "form"; "required": false; }; }, { "change": "change"; }, never, never, false, never>;
}

declare class FormFieldAlert {
    constructor(properties?: Partial<FormFieldAlert>);
    alertIcon?: string;
    alertType?: string;
    alertTitle?: string;
    alertMessage?: string;
}

declare class FormFieldAlertComponent implements OnInit {
    input: FormFieldAlert;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldAlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormFieldAlertComponent, "form-field-alert", never, { "input": { "alias": "input"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FormElementsCollapsableGroupComponent {
    label: string;
    isCollapsed: boolean;
    isCollapsedChanged: EventEmitter<boolean>;
    toggle(state?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormElementsCollapsableGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormElementsCollapsableGroupComponent, "app-form-elements-collapsable-group", never, { "label": { "alias": "label"; "required": false; }; "isCollapsed": { "alias": "isCollapsed"; "required": false; }; }, { "isCollapsedChanged": "isCollapsedChanged"; }, never, ["*"], false, never>;
}

declare class ExpandFormFieldIconComponent {
    isExpanded: boolean;
    expandToggle: EventEmitter<boolean>;
    toggleExpand(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpandFormFieldIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpandFormFieldIconComponent, "expand-form-field-icon", never, { "isExpanded": { "alias": "isExpanded"; "required": false; }; }, { "expandToggle": "expandToggle"; }, never, never, false, never>;
}

declare class ExpandableFieldDirective implements AfterViewInit {
    private el;
    private renderer;
    private viewContainerRef;
    private destroy$;
    expandableModalField: boolean;
    isExpanded: boolean;
    private expandIconRef;
    private hasMonacoEditor;
    private monacoEditorNormalHeight;
    get expandedClass(): boolean;
    constructor(el: ElementRef, renderer: Renderer2, viewContainerRef: ViewContainerRef, destroy$: SubDestroyService);
    ngAfterViewInit(): void;
    private addExpandIcon;
    private onExpandFieldModal;
    /**
     * Minimizes the expanded field modal by:
     * 1. Removing inline height and width styles from the host element
     * 2. Removing the modal backdrop element if it exists
     */
    private onMinimizeFieldModal;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpandableFieldDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExpandableFieldDirective, "form-field[expandableModalField]", never, { "expandableModalField": { "alias": "expandableModalField"; "required": false; }; "isExpanded": { "alias": "isExpanded"; "required": false; }; }, {}, never, never, false, never>;
}

declare class KeyValuePair {
    Key: string;
    Value: string;
    uid?: string;
    constructor(properties?: Partial<KeyValuePair>);
    /**
     * Collapses rows into a map, dropping rows with a blank key. Rows with a blank value are
     * dropped too unless `allowEmptyValue` is true, in which case they map to ''.
     */
    static getKeyValArrayToObject(vals: KeyValuePair[], allowEmptyValue?: boolean): Object;
    /** Expands a map into rows. Entries with an empty value are skipped unless `allowEmptyValue` is true. */
    static getObjectToKeyValArray(objMap: Object, allowEmptyValue?: boolean): KeyValuePair[];
}
declare class KeyValueConfigPair extends KeyValuePair {
    isMandatory: boolean;
    constructor(properties?: Partial<KeyValueConfigPair>);
    private _statusBadge;
    get statusBadge(): TableStatus;
}
declare const statusMap: Map<boolean, string>;
declare class TableStatus {
    text: string;
    style: string;
    constructor(text: string, style: string);
}

declare class FormKeyValFieldComponent {
    list: KeyValuePair[];
    listChange: EventEmitter<KeyValuePair[]>;
    keyId: string;
    valId: string;
    canAdd: boolean;
    keyLabel: string;
    maxCount: number;
    /**
     * When true, a row with a key but an empty value counts as complete, so it doesn't hide the
     * add button. Pair with `KeyValuePair.getKeyValArrayToObject(list, true)` so the empty value
     * is also kept on save (e.g. Azure tags, where `env=` is valid).
     */
    allowEmptyValue: boolean;
    fieldTracker: (field: any) => any;
    addKeyValuePair(): void;
    removeKeyValuePair(index: number): void;
    get showAddBtn(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormKeyValFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormKeyValFieldComponent, "app-form-key-val-field", never, { "list": { "alias": "list"; "required": false; }; "keyId": { "alias": "keyId"; "required": false; }; "valId": { "alias": "valId"; "required": false; }; "canAdd": { "alias": "canAdd"; "required": false; }; "keyLabel": { "alias": "keyLabel"; "required": false; }; "maxCount": { "alias": "maxCount"; "required": false; }; "allowEmptyValue": { "alias": "allowEmptyValue"; "required": false; }; }, { "listChange": "listChange"; }, never, never, false, never>;
}

declare class KeyValConfigFieldComponent {
    list: KeyValueConfigPair[];
    listChange: EventEmitter<KeyValueConfigPair[]>;
    readonly: boolean;
    keyId: string;
    valId: string;
    isMandatoryId: string;
    canAdd: boolean;
    keyLabel: string;
    maxCount: number;
    fieldTracker: (field: any) => any;
    addKeyValuePair(): void;
    removeKeyValuePair(index: number): void;
    get showAddBtn(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<KeyValConfigFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KeyValConfigFieldComponent, "app-key-val-config-field", never, { "list": { "alias": "list"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "keyId": { "alias": "keyId"; "required": false; }; "valId": { "alias": "valId"; "required": false; }; "isMandatoryId": { "alias": "isMandatoryId"; "required": false; }; "canAdd": { "alias": "canAdd"; "required": false; }; "keyLabel": { "alias": "keyLabel"; "required": false; }; "maxCount": { "alias": "maxCount"; "required": false; }; }, { "listChange": "listChange"; }, never, never, false, never>;
}

/** How many years before and after today a date field reaches when the call site sets no bound itself. */
declare const DATE_BOUNDS_DEFAULT_YEARS = 100;
/**
 * Caps a date field to {@link DATE_BOUNDS_DEFAULT_YEARS} years either side of today, so its calendar can't
 * be scrolled back to year 1 or forward forever. A bound the call site sets itself always wins.
 *
 * Covers every date control the apps use:
 * - `<input type="date">` / `<input type="datetime-local">` — takes over the `[min]`/`[max]` bindings and
 *   writes the default to the element when one is unset (null, undefined or ''). A date outside the bounds
 *   marks the control invalid with a `min`/`max` error (Angular's own min/max validators only run on
 *   `type="number"`), and is clamped to the nearest bound on blur — not on input, since typing a year digit
 *   by digit passes through values like `0002` on the way.
 * - `<ngb-datepicker>` / `input[ngbDatepicker]` — provides element-scoped `NgbDatepickerConfig` and
 *   `NgbInputDatepickerConfig` whose minDate/maxDate seed the calendar (the popup's, on an input); an
 *   explicit `[minDate]`/`[maxDate]` replaces them. ng-bootstrap checks a date typed into an
 *   `input[ngbDatepicker]` against an explicit `[minDate]`/`[maxDate]` only.
 * - `[mwlFlatpickr]` — provides element-scoped `FlatpickrDefaults` the same way.
 *
 * The host's `type` and today's date are read once, when the directive is created: a bound `[type]` is not
 * seen, and a page left open past midnight keeps the previous day's bounds.
 *
 * Usage:
 *   <input type="date" name="dateFrom" [(ngModel)]="filters.dateFrom" date-bounds />
 *   <input type="date" name="expiry" [(ngModel)]="expiry" [min]="today" date-bounds />
 *   <ngb-datepicker name="expiry" [(ngModel)]="expiry" [minDate]="minExpiryDate" date-bounds></ngb-datepicker>
 */
declare class DateBoundsDirective implements OnChanges, Validator {
    readonly min: i0.InputSignal<string>;
    readonly max: i0.InputSignal<string>;
    private readonly element;
    private readonly nativeType;
    private readonly defaults;
    protected readonly effectiveMin: i0.Signal<string>;
    protected readonly effectiveMax: i0.Signal<string>;
    private onValidatorChange?;
    ngOnChanges(changes: SimpleChanges): void;
    validate(control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    protected clampToBounds(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateBoundsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DateBoundsDirective, "[date-bounds]", never, { "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SharedFormsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SharedFormsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SharedFormsModule, [typeof FormRefDirective, typeof UseParentFormDirective, typeof FormFieldComponent, typeof FormFieldErrorsComponent, typeof FormGroupErrorsComponent, typeof PasswordFieldComponent, typeof MaskedTextareaComponent, typeof ValidationErrorsDirective, typeof ValidationStateDirective, typeof YamlValidationDirective, typeof YamlMapValidationDirective, typeof XmlValidationDirective, typeof IniValidationDirective, typeof NotExistsValidatorDirective, typeof NotExistsCaseValidatorDirective, typeof AsyncNotExistsValidatorDirective, typeof NotEqualValidatorDirective, typeof NotStartsWithValidatorDirective, typeof NotStartsWithCaseValidatorDirective, typeof JsonObjectValidatorDirective, typeof JsonArrayValidatorDirective, typeof JsonKeyStringValueValidatorDirective, typeof CronValidatorDirective, typeof EmailValidatorDirective, typeof UnicodeValidatorDirective, typeof PortRangeValidatorDirective, typeof LabelRefDirective, typeof InputTextTrimDirective, typeof GenericFormFieldComponent, typeof FormFieldAlertComponent, typeof FormElementsCollapsableGroupComponent, typeof ExpandFormFieldIconComponent, typeof ExpandableFieldDirective, typeof FormKeyValFieldComponent, typeof KeyValConfigFieldComponent], [typeof i3.CommonModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof i3$2.NgbModule, typeof i5.NgSelectModule, typeof i28.BlockUIModule, typeof i29.FlatpickrModule, typeof i30.ToastrModule, typeof i1.MonacoEditorModule, typeof CorePipesModule, typeof CoreCommonModule, typeof HelpModule, typeof DateBoundsDirective], [typeof i3.CommonModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof i1.MonacoEditorModule, typeof i3$2.NgbModule, typeof i5.NgSelectModule, typeof i28.BlockUIModule, typeof i29.FlatpickrModule, typeof i30.ToastrModule, typeof CoreCommonModule, typeof FormRefDirective, typeof UseParentFormDirective, typeof FormFieldComponent, typeof FormFieldErrorsComponent, typeof FormGroupErrorsComponent, typeof PasswordFieldComponent, typeof MaskedTextareaComponent, typeof ValidationErrorsDirective, typeof ValidationStateDirective, typeof YamlValidationDirective, typeof YamlMapValidationDirective, typeof XmlValidationDirective, typeof IniValidationDirective, typeof NotExistsValidatorDirective, typeof NotExistsCaseValidatorDirective, typeof AsyncNotExistsValidatorDirective, typeof NotEqualValidatorDirective, typeof NotStartsWithValidatorDirective, typeof NotStartsWithCaseValidatorDirective, typeof JsonObjectValidatorDirective, typeof JsonArrayValidatorDirective, typeof JsonKeyStringValueValidatorDirective, typeof CronValidatorDirective, typeof EmailValidatorDirective, typeof UnicodeValidatorDirective, typeof PortRangeValidatorDirective, typeof LabelRefDirective, typeof InputTextTrimDirective, typeof DateBoundsDirective, typeof GenericFormFieldComponent, typeof FormFieldAlertComponent, typeof FormElementsCollapsableGroupComponent, typeof ExpandFormFieldIconComponent, typeof ExpandableFieldDirective, typeof FormKeyValFieldComponent, typeof KeyValConfigFieldComponent, typeof HelpModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SharedFormsModule>;
}

declare class ConfirmationModalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationModalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfirmationModalModule, [typeof ConfirmationModalComponent, typeof DeleteConfirmationModalComponent], [typeof i3.CommonModule, typeof SharedFormsModule, typeof i3$2.NgbModule], [typeof ConfirmationModalComponent, typeof DeleteConfirmationModalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfirmationModalModule>;
}

/** Shared types for the detail-view components, and the one badge builder they all share. */
type DetailBadgeKind = 'ok' | 'info' | 'warn' | 'bad' | 'mute' | 'brand';
/** A status or flag chip beside the record name. */
interface DetailBadge {
    label: string;
    kind?: DetailBadgeKind;
}
/** One row of a label/value block in `main`. */
interface DetailKvRow {
    label: string;
    value: string;
    href?: string;
}
/** One row of the side's counts panel. */
interface DetailCountRow {
    label: string;
    value: string | number;
}
type DetailTimelineState = 'done' | 'now' | 'todo';
/** One step of a lifecycle in the side's timeline panel. */
interface DetailTimelineEvent {
    label: string;
    sub?: string;
    state: DetailTimelineState;
}
type DetailCalloutKind = 'warn' | 'danger' | 'info';
/** A severity-coded notice plated above or inside a detail view's main panel. */
interface DetailCallout {
    kind: DetailCalloutKind;
    heading: string;
    body: string;
}
/** Severity of a spec value, drawn as a dot after the value in `app-stat-card`. */
type StatDotKind = 'ok' | 'warn' | 'bad' | 'mute';
/**
 * The record's active state, for `app-detail-header`'s [status] — the one badge
 * every detail page shows the same way, so it is built here rather than per page.
 * `isActive` is optional on most payloads: undefined means the resource has no
 * such state, and inventing an "Active" chip for it would be a claim, so the
 * header stays bare.
 */
declare function activeStatusBadges(isActive?: boolean): DetailBadge[];

/**
 * The detail page header: a 3-column grid of optional slots. Row 1 is
 * icon | identity | actions; row 2 of the identity column is the description.
 */
declare class DetailHeaderComponent {
    readonly title: i0.InputSignal<string>;
    readonly subtitle: i0.InputSignal<string>;
    /** Plain text. The component owns the clamp and the more/less toggle. */
    readonly description: i0.InputSignal<string>;
    /** Glyph for the identity mark; falls back to the title's initial. */
    readonly mark: i0.InputSignal<string>;
    readonly status: i0.InputSignal<DetailBadge[]>;
    readonly showActions: i0.InputSignal<boolean>;
    readonly actions: i0.InputSignal<ViewHeaderAction[]>;
    readonly compactActions: i0.InputSignal<boolean>;
    readonly dynamicAction: i0.InputSignal<boolean>;
    /**
     * ngbDropdown's autoClose. 'outside' is what a projected cascade sub-menu needs:
     * the default dismisses the menu the moment the cascade's own trigger is clicked.
     */
    readonly autoClose: i0.InputSignal<boolean | "outside" | "inside">;
    /** 'body' teleports the menu out, for a header inside a clipping or scrolling ancestor. */
    readonly container: i0.InputSignal<"body">;
    /** Fires when the actions menu opens or closes, for pages holding their own sub-menu state. */
    readonly actionsOpenChange: i0.OutputEmitterRef<boolean>;
    /**
     * Extra class on the actions menu. [container] can teleport the menu out of
     * the consumer's DOM, so a page that wants to style its own menu items needs
     * a hook it can name; this component takes no view on what that style is.
     */
    readonly menuClass: i0.InputSignal<string>;
    readonly titleTpl: i0.Signal<TemplateRef<unknown>>;
    readonly subtitleTpl: i0.Signal<TemplateRef<unknown>>;
    readonly actionsTpl: i0.Signal<TemplateRef<unknown>>;
    readonly headerFilterTpl: i0.Signal<TemplateRef<unknown>>;
    readonly markGlyph: i0.Signal<string>;
    /** Unique per instance, so two headers on one page cannot share a checkbox. */
    readonly descId: string;
    /** Unique per instance, so two headers on one page cannot share an id. */
    readonly actionsId: string;
    /**
     * Whether one line was not enough. The only measured value here — CSS has
     * no way to detect truncation.
     */
    readonly clamped: i0.WritableSignal<boolean>;
    private static nextId;
    private readonly descText;
    private readonly descToggle;
    private readonly actionsDropdown;
    /**
     * Closes the actions menu. Needed because a projected item that is not an
     * ngbDropdownItem — a cascade's choice, say — does not close it by itself,
     * and autoClose="outside" deliberately ignores clicks inside the menu.
     */
    closeActions(): void;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailHeaderComponent, "app-detail-header", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "mark": { "alias": "mark"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "showActions": { "alias": "showActions"; "required": false; "isSignal": true; }; "actions": { "alias": "actions"; "required": false; "isSignal": true; }; "compactActions": { "alias": "compactActions"; "required": false; "isSignal": true; }; "dynamicAction": { "alias": "dynamicAction"; "required": false; "isSignal": true; }; "autoClose": { "alias": "autoClose"; "required": false; "isSignal": true; }; "container": { "alias": "container"; "required": false; "isSignal": true; }; "menuClass": { "alias": "menuClass"; "required": false; "isSignal": true; }; }, { "actionsOpenChange": "actionsOpenChange"; }, ["titleTpl", "subtitleTpl", "actionsTpl", "headerFilterTpl"], ["*"], true, never>;
}

/**
 * One fact in the side column. Renders a row, not a card: `app-detail-layout`
 * owns the panel frame, which is what makes 1 fact and 16 the same rule.
 */
declare class DetailFactComponent {
    /** Feather icon name. */
    readonly icon: i0.InputSignal<string>;
    /** Feather icon name; kept for parity with sidecard. */
    readonly featherIcon: i0.InputSignal<string>;
    /** Material or custom icon name. */
    readonly matIcon: i0.InputSignal<string>;
    /**
     * A model rather than an input: `app-detail-layout` derives the key and
     * writes it from the parent, which a read-only input would forbid.
     */
    readonly helpKey: i0.ModelSignal<string>;
    /** Custom icon markup, projected as `<ng-template #icon>`. */
    readonly iconTpl: i0.Signal<TemplateRef<unknown>>;
    private readonly host;
    /**
     * The fact's name for the help key: an explicit `name` attribute, else the
     * projected `.card-subtitle` text. Same contract as sidecard.getName().
     */
    getName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailFactComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailFactComponent, "app-detail-fact", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "featherIcon": { "alias": "featherIcon"; "required": false; "isSignal": true; }; "matIcon": { "alias": "matIcon"; "required": false; "isSignal": true; }; "helpKey": { "alias": "helpKey"; "required": false; "isSignal": true; }; }, { "helpKey": "helpKeyChange"; }, ["iconTpl"], ["*"], true, never>;
}

/** A counts panel for the side column. */
declare class DetailAttachedComponent {
    readonly title: i0.InputSignal<string>;
    readonly rows: i0.InputSignal<DetailCountRow[]>;
    /** Off: values wrap instead of ending in an ellipsis, and drop the tooltip. */
    readonly truncate: i0.InputSignal<boolean>;
    /** The tooltip only repeats the value, so it opens only when the ellipsis hides some of it. */
    openIfTruncated(tooltip: NgbTooltip, value: HTMLElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailAttachedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailAttachedComponent, "app-detail-attached", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "truncate": { "alias": "truncate"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** A tinted plate for a condition the reader has to act on. */
declare class DetailCalloutComponent {
    readonly kind: i0.InputSignal<DetailCalloutKind>;
    readonly heading: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailCalloutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailCalloutComponent, "app-detail-callout", never, { "kind": { "alias": "kind"; "required": false; "isSignal": true; }; "heading": { "alias": "heading"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * A lifecycle panel. Omitted entirely by pages whose record has no lifecycle.
 * Projected content renders inside the panel, under the action button.
 */
declare class DetailTimelineComponent {
    readonly title: i0.InputSignal<string>;
    readonly events: i0.InputSignal<DetailTimelineEvent[]>;
    readonly actionLabel: i0.InputSignal<string>;
    readonly action: i0.OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailTimelineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailTimelineComponent, "app-detail-timeline", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "events": { "alias": "events"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; }, { "action": "action"; }, never, ["*"], true, never>;
}

/** Marker only, no behaviour: lets app-detail-layout query side content reactively. */
declare class DetailSideContentDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailSideContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DetailSideContentDirective, "app-detail-attached, app-detail-timeline, app-detail-callout, [side-content]", never, {}, {}, never, never, true, never>;
}

/**
 * One layout for every detail page: main and side are both section lists.
 * "Layout 1" and "Layout 2" are side compositions, not separate layouts.
 */
declare class DetailLayoutComponent {
    /** Optional heading for the side panel. Unset invents no label. */
    readonly sidePanelTitle: i0.InputSignal<string>;
    readonly headerWidth: i0.InputSignal<"main" | "full">;
    readonly facts: i0.Signal<readonly DetailFactComponent[]>;
    readonly attached: i0.Signal<readonly DetailAttachedComponent[]>;
    readonly timeline: i0.Signal<readonly DetailTimelineComponent[]>;
    readonly callout: i0.Signal<readonly DetailCalloutComponent[]>;
    readonly sideContent: i0.Signal<readonly DetailSideContentDirective[]>;
    /**
     * A record with nothing for the side must not reserve its column. Both
     * queries are signals, so this stays correct as projected content changes.
     */
    readonly hasSide: i0.Signal<boolean>;
    private readonly host;
    constructor();
    /**
     * `SIDECARD.<Name>.<Label>`, from the host's Name attribute and each fact's
     * label. Drives contextual help and fails silently, so it is tested.
     */
    private assignHelpKeys;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailLayoutComponent, "app-detail-layout", never, { "sidePanelTitle": { "alias": "sidePanelTitle"; "required": false; "isSignal": true; }; "headerWidth": { "alias": "headerWidth"; "required": false; "isSignal": true; }; }, {}, ["facts", "attached", "timeline", "callout", "sideContent"], ["app-detail-header", "scrollable-nav-tab", "*", "app-detail-fact", "app-detail-attached, app-detail-timeline, app-detail-callout, [side-content]"], true, never>;
}

/**
 * A labelled block in the main column. Unframed on purpose: projected content
 * carries its own frame, and nesting the two reads as a card inside a card.
 */
declare class DetailSectionComponent {
    /** Unset renders no heading, so a section can be spacing alone. */
    readonly title: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailSectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailSectionComponent, "app-detail-section", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * One cell of `app-stat-grid`. Twin of mini-card, without the frame: the grid
 * owns it. The .minicard-* size classes are accepted but inert inside a grid.
 */
declare class StatCardComponent {
    readonly iconColor: i0.InputSignal<string>;
    readonly icon: i0.InputSignal<string>;
    readonly featherIcon: i0.InputSignal<string>;
    readonly matIcon: i0.InputSignal<string>;
    readonly hideHelp: i0.InputSignal<boolean>;
    /** Severity dot drawn after the value; null draws nothing. */
    readonly dot: i0.InputSignal<StatDotKind>;
    readonly iconTpl: i0.Signal<TemplateRef<unknown>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatCardComponent, "app-stat-card", never, { "iconColor": { "alias": "iconColor"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "featherIcon": { "alias": "featherIcon"; "required": false; "isSignal": true; }; "matIcon": { "alias": "matIcon"; "required": false; "isSignal": true; }; "hideHelp": { "alias": "hideHelp"; "required": false; "isSignal": true; }; "dot": { "alias": "dot"; "required": false; "isSignal": true; }; }, {}, ["iconTpl"], ["*", "[minicard-detail]"], true, never>;
}

/** The Overview panel. One grid rule, in one place. */
declare class StatGridComponent {
    readonly title: i0.InputSignal<string>;
    /** Theme token filling each card, without the `--`: 'surface' reads as a card, 'bg-color' as an inset panel. */
    readonly cardBackground: i0.InputSignal<string>;
    /**
     * Fixed column count, 1-4. Unset (the default) sizes the grid to the number of
     * cards, which is what every page wants until the values are long enough that
     * four across reads worse than two rows of two.
     */
    readonly columnCount: i0.InputSignal<number>;
    readonly cards: i0.Signal<readonly StatCardComponent[]>;
    /** The fallback keeps a card painted if a page names a token that does not exist. */
    readonly cardBackgroundValue: i0.Signal<string>;
    /** A class, not an inline grid-template-columns, which would beat the responsive step-downs. */
    readonly columns: i0.Signal<number>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatGridComponent, "app-stat-grid", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "cardBackground": { "alias": "cardBackground"; "required": false; "isSignal": true; }; "columnCount": { "alias": "columnCount"; "required": false; "isSignal": true; }; }, {}, ["cards"], ["*"], true, never>;
}

/**
 * The page header for a list view: what this collection is, on the left, and
 * whatever the page lets you do with it, on the right.
 *
 * Deliberately not app-detail-header — that one identifies a single record (mark,
 * status badges, a record's Actions menu). A list page names a collection and hangs
 * its own controls off the right, so it gets its own, smaller component.
 */
declare class ListHeaderComponent {
    readonly title: i0.InputSignal<string>;
    /** One line on what the collection is for. Omitted leaves no gap. */
    readonly description: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListHeaderComponent, "app-list-header", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, ["[actions]"], true, never>;
}

/** The row of summary cards above a list. One grid rule, in one place. */
declare class ListStatsComponent {
    /** Theme token filling each card, without the `--`: 'surface' reads as a card, 'bg-color' tints it. */
    readonly cardBackground: i0.InputSignal<string>;
    /** The fallback keeps a card painted if a page names a token that does not exist. */
    readonly cardBackgroundValue: i0.Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListStatsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListStatsComponent, "app-list-stats", never, { "cardBackground": { "alias": "cardBackground"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** Severity of a list summary value; colours the number it labels. */
type ListStatTone = 'default' | 'ok' | 'warn' | 'bad';
/**
 * One summary card above a list: a label, the number it counts, and an optional
 * hint spelling that number out. Framed in its own right, unlike the detail page's
 * app-stat-card, which is a cell of a divided panel.
 */
declare class ListStatCardComponent {
    readonly label: i0.InputSignal<string>;
    /** Left unset for a card whose value is projected markup — a badge, say. */
    readonly value: i0.InputSignal<string | number>;
    /** Secondary line under the value: `6 created · 2 imported`. */
    readonly hint: i0.InputSignal<string>;
    readonly tone: i0.InputSignal<ListStatTone>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListStatCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListStatCardComponent, "app-list-stat-card", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** A label/value block for `main`. */
declare class DetailKvComponent {
    readonly title: i0.InputSignal<string>;
    readonly rows: i0.InputSignal<DetailKvRow[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailKvComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailKvComponent, "app-detail-kv", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** An empty section, with exactly one exit. */
declare class DetailEmptyComponent {
    readonly heading: i0.InputSignal<string>;
    readonly message: i0.InputSignal<string>;
    readonly actionLabel: i0.InputSignal<string>;
    readonly action: i0.OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailEmptyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailEmptyComponent, "app-detail-empty", never, { "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; }, { "action": "action"; }, never, never, true, never>;
}

declare class CommonLibComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonLibComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonLibComponentsModule, [typeof SidecardComponent, typeof ViewWithSidecardsComponent, typeof ViewHeaderCardComponent, typeof MiniCardComponent, typeof ScrollableNavTabComponent, typeof ViewJsonComponent, typeof ViewJsonModalComponent, typeof ViewYamlComponent], [typeof i3.CommonModule, typeof i9.MatIconModule, typeof i3$2.NgbModule, typeof i28.BlockUIModule, typeof RootImportsModule, typeof RestrictElementAccessModule, typeof CodeBlockWithCopyComponent, typeof CopyToClipboardComponent, typeof CoreCommonModule, typeof HelpModule, typeof i3$1.FormsModule, typeof FlatStatusFilterComponent, typeof FilterPillsComponent, typeof SearchableDatatableModule, typeof ConfirmationModalModule, typeof DetailHeaderComponent, typeof DetailLayoutComponent, typeof DetailSectionComponent, typeof DetailFactComponent, typeof StatGridComponent, typeof StatCardComponent, typeof ListHeaderComponent, typeof ListStatsComponent, typeof ListStatCardComponent, typeof DetailKvComponent, typeof DetailEmptyComponent, typeof DetailAttachedComponent, typeof DetailTimelineComponent, typeof DetailCalloutComponent, typeof DetailSideContentDirective], [typeof i3.CommonModule, typeof CoreCommonModule, typeof i9.MatIconModule, typeof i3$2.NgbModule, typeof SidecardComponent, typeof ViewWithSidecardsComponent, typeof ViewHeaderCardComponent, typeof MiniCardComponent, typeof CopyToClipboardComponent, typeof ScrollableNavTabComponent, typeof RestrictElementAccessModule, typeof CodeBlockWithCopyComponent, typeof HelpModule, typeof ViewJsonComponent, typeof ViewJsonModalComponent, typeof ViewYamlComponent, typeof FlatStatusFilterComponent, typeof FilterPillsComponent, typeof SearchableDatatableModule, typeof ConfirmationModalModule, typeof i28.BlockUIModule, typeof RootImportsModule, typeof DetailHeaderComponent, typeof DetailLayoutComponent, typeof DetailSectionComponent, typeof DetailFactComponent, typeof StatGridComponent, typeof StatCardComponent, typeof ListHeaderComponent, typeof ListStatsComponent, typeof ListStatCardComponent, typeof DetailKvComponent, typeof DetailEmptyComponent, typeof DetailAttachedComponent, typeof DetailTimelineComponent, typeof DetailCalloutComponent, typeof DetailSideContentDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonLibComponentsModule>;
}

/** Options for a confirmation modal. */
interface ConfirmationModalOptions<T> {
    header: string | TemplateRef<void>;
    message: string | TemplateRef<void>;
    successMessage?: string;
    data?: T;
    showToggleSwitch?: boolean;
    toggleText?: string;
    tooltipText?: string;
    defaultToggleValue?: boolean;
}
/** A reference to a confirmation modal. */
declare class ConfirmationModalRef<T> {
    modal: NgbModalRef;
    component: ConfirmationModalComponent;
    successMessage: string;
    /**
     * Convenience method for handling a common workflow:
     *
     * - create an outer promise for the entire operation
     * - wait for the user to confirm
     * - run an action on confirmation
     *   - if it fails, report an error, and reject the promise
     *   - if it succeeds, report the success, and
     *
     * @param onconfirm   a confirmation handler that returns an "inner" promise to perform some action
     * @param fail        optional: the ErrorReporter to use for reporting an error
     * @param succeed     optional: the SuccessReporter to use for reporting success
     * @returns a promise that can be used to perform follow-up actions, on failure or success.
     */
    actIfConfirmed(onconfirm: (data: T, toggleValue: boolean) => Promise<any>, fail?: ErrorReporter, succeed?: SuccessReporter, blockUI?: NgBlockUI, blockMessage?: string, customSuccessMessage?: string, customErrorMessage?: string): Promise<T>;
}
declare class ConfirmationModalService {
    private _modals;
    constructor(_modals: NgbModal);
    open<T>(options: ConfirmationModalOptions<T>): ConfirmationModalRef<T>;
    openGeneric<T>(action: string, entityType: string, entityIdentifier: any, onconfirm: (data: T) => Promise<any>, blockUI?: NgBlockUI, customSuccessMessage?: string, customErrorMessage?: string): Promise<any>;
    openWithMessage<T>(header: string, message: string, successMessage: any, onconfirm: (data: T) => Promise<any>, blockUI?: NgBlockUI): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfirmationModalService>;
}

/** Options for a confirmation modal. */
interface DeleteConfirmationModalOptions<T> {
    header: string | TemplateRef<void>;
    message: string | TemplateRef<void>;
    entityType?: string;
    successMessage?: string;
    data?: T;
    showToggleSwitch?: boolean;
    toggleText?: string;
    tooltipText?: string;
    defaultToggleValue?: boolean;
    confirmationText?: string;
}
/** A reference to a confirmation modal. */
declare class DeleteConfirmationModalRef<T> {
    modal: NgbModalRef;
    component: DeleteConfirmationModalComponent;
    successMessage: string;
    /**
     * Convenience method for handling a common workflow:
     *
     * - create an outer promise for the entire operation
     * - wait for the user to confirm
     * - run an action on confirmation
     *   - if it fails, report an error, and reject the promise
     *   - if it succeeds, report the success, and
     *
     * @param onconfirm   a confirmation handler that returns an "inner" promise to perform some action
     * @param fail        optional: the ErrorReporter to use for reporting an error
     * @param succeed     optional: the SuccessReporter to use for reporting success
     * @returns a promise that can be used to perform follow-up actions, on failure or success.
     */
    actIfConfirmed(onconfirm: (data: T, toggleValue: boolean) => Promise<any>, fail?: ErrorReporter, succeed?: SuccessReporter, blockUI?: NgBlockUI, blockMessage?: string, customSuccessMessage?: string, customErrorMessage?: string): Promise<T>;
}
declare class DeleteConfirmationModalService {
    private _modals;
    constructor(_modals: NgbModal);
    open<T>(options: DeleteConfirmationModalOptions<T>): DeleteConfirmationModalRef<T>;
    openGeneric<T>(entityType: string, entityIdentifier: string, onconfirm: (data: T) => Promise<any>, blockUI?: NgBlockUI, action?: string, customSuccessMessage?: string, customErrorMessage?: string): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteConfirmationModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DeleteConfirmationModalService>;
}

declare class DiffMergeComponent implements OnChanges, OnDestroy {
    private zone;
    currentContent: string;
    incomingContent: string;
    currentFileName: string;
    incomingFileName: string;
    language: string;
    title: string;
    resolved: EventEmitter<string>;
    editorContainer: ElementRef;
    totalConflicts: number;
    resolvedConflicts: number;
    get noChanges(): boolean;
    private editor;
    private conflicts;
    private conflictMap;
    private decorationIds;
    private viewZoneIds;
    private resizeObserver;
    private rafId;
    private originalTotalConflicts;
    private monacoSub;
    constructor(zone: NgZone);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private initEditor;
    private updateEditorContent;
    private createEditor;
    private buildConflictMarkedContent;
    private wrapConflict;
    private scanConflicts;
    private applyDecorations;
    private applyViewZones;
    private createActionBar;
    resolveConflict(conflictId: number, resolution: 'current' | 'incoming' | 'both'): void;
    applyResult(): void;
    copyResult(): void;
    acceptAllCurrent(): void;
    acceptAllIncoming(): void;
    private resolveAllConflicts;
    private setupResizeObserver;
    static ɵfac: i0.ɵɵFactoryDeclaration<DiffMergeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DiffMergeComponent, "app-diff-merge", never, { "currentContent": { "alias": "currentContent"; "required": false; }; "incomingContent": { "alias": "incomingContent"; "required": false; }; "currentFileName": { "alias": "currentFileName"; "required": false; }; "incomingFileName": { "alias": "incomingFileName"; "required": false; }; "language": { "alias": "language"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, { "resolved": "resolved"; }, never, never, true, never>;
}

/**
 * Service to dynamically load CSS stylesheets on demand.
 * This enables lazy loading of third-party CSS (like xterm, diff2html)
 * only when the components that need them are actually used.
 */
declare class DynamicStyleLoaderService {
    private loadedStyles;
    /**
     * Loads a CSS file dynamically by injecting a <link> element into the <head>.
     * If the stylesheet is already loaded, it will not be loaded again.
     *
     * @param href - The URL or path to the CSS file
     * @returns Promise that resolves when the stylesheet is loaded
     */
    loadStyle(href: string): Promise<void>;
    /**
     * Checks if a stylesheet has already been loaded
     */
    isLoaded(href: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicStyleLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DynamicStyleLoaderService>;
}

type ThemePreference = 'light' | 'dark' | 'system';
type ThemeMode = 'light' | 'dark';
declare const THEME_STORAGE_KEY = "duplo-theme";
declare function isThemePreference(value: unknown): value is ThemePreference;
/** Mirrored by the boot theme block in src/assets/ui-config.js — keep in step. */
declare function resolveThemeMode(switcher: boolean, preference: ThemePreference, prefersDark: boolean): ThemeMode;
declare function readThemePreference(storage: Storage | null, configDefault: unknown): ThemePreference;
/** Owns <html data-theme> and data-theme-preference after boot; host and remote instances share them. */
declare class ThemeService {
    private readonly document;
    private readonly root;
    private readonly media;
    readonly switcherEnabled: boolean;
    private readonly _preference;
    private readonly _mode;
    readonly preference: i0.Signal<ThemePreference>;
    readonly mode: i0.Signal<ThemeMode>;
    constructor();
    setPreference(preference: ThemePreference): void;
    private initialPreference;
    private syncPreferenceFromRoot;
    private apply;
    private storage;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ThemeService>;
}

declare class DiffRenderComponent implements OnInit, OnChanges {
    private styleLoader;
    private themeService;
    title: string;
    oldString: string;
    newString: string;
    containerClass: string;
    currentFileName: string;
    incomingFileName: string;
    diffConfig: Diff2HtmlConfig;
    showFull: boolean;
    readonly diffHtml: i0.WritableSignal<string>;
    private renderedMode;
    constructor(styleLoader: DynamicStyleLoaderService, themeService: ThemeService);
    ngOnInit(): void;
    ngOnChanges(): void;
    generateDiff(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DiffRenderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DiffRenderComponent, "app-diff-render", never, { "title": { "alias": "title"; "required": false; }; "oldString": { "alias": "oldString"; "required": false; }; "newString": { "alias": "newString"; "required": false; }; "containerClass": { "alias": "containerClass"; "required": false; }; "currentFileName": { "alias": "currentFileName"; "required": false; }; "incomingFileName": { "alias": "incomingFileName"; "required": false; }; "diffConfig": { "alias": "diffConfig"; "required": false; }; "showFull": { "alias": "showFull"; "required": false; }; }, {}, never, never, true, never>;
}

/** How a card renders its 2.25rem mark. Exactly one field should be set. */
interface ListCardMark {
    initial?: string;
    svgIcon?: string;
    feather?: string;
}
/** One entry in a card's overflow menu. */
interface ListCardAction {
    label: string;
    icon: string;
    handler: () => void;
    disabled?: boolean;
    /** Hover text on the menu item — typically why a disabled action can't run. */
    tooltip?: string | null;
    hidden?: boolean;
}
/** First usable character of a name, for a card's letter tile. */
declare function listCardInitial(name: string): string;
/** Up to `max` word initials, for the avatar stack in a card footer. */
declare function listCardInitials(name: string, max?: number): string;
interface BadgeOverflow<T> {
    shown: T[];
    overflow: number;
}
/**
 * Caps a projected badge row to a character budget, so a record with nine
 * badges is the same card height as one with two. Always keeps one badge.
 */
declare function capBadges<T>(items: T[], label: (item: T) => string, budget?: number): BadgeOverflow<T>;

/**
 * How a row renders its mark. Extends ListCardMark — the same initial/svgIcon/
 * feather contract common-lib already defines — with the tone this list picks
 * per record.
 */
interface ExpandableListMark extends ListCardMark {
    /**
     * Which themed colour the tile takes. Omit to let the list cycle the
     * palette by row position, so consecutive rows never repeat a colour.
     */
    tone?: ExpandableListTone;
}
/**
 * The tile palette. Every entry maps to a theme var, so a deployment on the
 * blue or red bundle recolours with everything else — which a stored hex
 * per record could not.
 */
type ExpandableListTone = 'primary' | 'info' | 'secondary' | 'dark';
declare const EXPANDABLE_LIST_TONES: ExpandableListTone[];
/**
 * The tone for the row at this position. Cycling by index rather than
 * hashing the title means adjacent rows are never the same colour — a
 * hash can put two neighbours in the same bucket, which reads as if the
 * list forgot to colour one of them.
 */
declare function expandableListTone(index: number): ExpandableListTone;
/** Context handed to every row, mark, detail and actions template. */
interface ExpandableListContext<T = any> {
    $implicit: T;
    item: T;
    expanded: boolean;
    index: number;
}
/** One rendered row. Every display value is resolved here, never in a binding. */
interface ExpandableListRow<T = any> {
    id: string;
    item: T;
    title: string;
    description: string;
    mark: ExpandableListMark;
    /** Resolved here so the template binds a class, never a method call. */
    markClass: string;
    expanded: boolean;
    /** Target of the head button's aria-controls. */
    detailId: string;
    context: ExpandableListContext<T>;
}

/**
 * A searchable list whose rows expand in place.
 *
 * The component owns the chrome — the search bar, the rows, the chevron, the
 * expand/collapse state and the empty state. Everything inside a row is the
 * caller's, supplied as templates:
 *
 *   #elRow      the collapsed row's main content   (falls back to mark/title/description)
 *   #elMark     the tile at the left of a row      (falls back to a toned initial)
 *   #elDetail   what the row reveals when expanded
 *   #elActions  the controls at the right of a row
 *   #elToolbar  the controls at the right of the search bar
 *
 * Every template gets `{ $implicit: item, item, expanded, index }`.
 *
 *   <app-expandable-list [items]="rows" [searchFields]="['name', 'description']"
 *                        searchPlaceholder="Search personas">
 *     <ng-template #elToolbar><button …>Add persona</button></ng-template>
 *     <ng-template #elDetail let-item>…</ng-template>
 *   </app-expandable-list>
 *
 * Search is caller-declared rather than "every field": a persona's skillIds and
 * metaData would otherwise match on ids nobody can see, which reads as the box
 * being broken.
 */
declare class ExpandableListComponent<T extends Record<string, any> = any> {
    /** Distinguishes this list's generated element ids from another on the same page. */
    private static instances;
    private readonly uid;
    readonly items: i0.InputSignal<T[]>;
    /** Dot paths are supported, so 'spec.region' works as well as 'name'. */
    readonly searchFields: i0.InputSignal<string[]>;
    readonly searchPlaceholder: i0.InputSignal<string>;
    readonly showSearch: i0.InputSignal<boolean>;
    /** Identity for expand state and @for tracking. */
    readonly idKey: i0.InputSignal<string>;
    /** Default-row rendering, used only when no #elRow template is projected. */
    readonly titleKey: i0.InputSignal<string>;
    readonly descriptionKey: i0.InputSignal<string>;
    readonly emptyMessage: i0.InputSignal<string>;
    readonly noMatchMessage: i0.InputSignal<string>;
    readonly loading: i0.InputSignal<boolean>;
    /** Off by default: one open row at a time keeps the list scannable. */
    readonly multiExpand: i0.InputSignal<boolean>;
    readonly expandedChange: i0.OutputEmitterRef<string[]>;
    readonly searchChange: i0.OutputEmitterRef<string>;
    readonly rowTemplate: i0.Signal<TemplateRef<ExpandableListContext<T>>>;
    readonly detailTemplate: i0.Signal<TemplateRef<ExpandableListContext<T>>>;
    readonly actionsTemplate: i0.Signal<TemplateRef<ExpandableListContext<T>>>;
    readonly markTemplate: i0.Signal<TemplateRef<ExpandableListContext<T>>>;
    readonly toolbarTemplate: i0.Signal<TemplateRef<void>>;
    readonly term: i0.WritableSignal<string>;
    private readonly expandedIds;
    /**
     * The rendered rows, with every display value already resolved. Bindings
     * read plain fields off these — the repo forbids calling a method from a
     * template, and a context object rebuilt per pass would also make
     * ngTemplateOutlet re-apply it on every check.
     */
    readonly rows: i0.Signal<ExpandableListRow<T>[]>;
    readonly isFiltered: i0.Signal<boolean>;
    /**
     * Ids resolved over the full list, once. Items whose idKey is absent fall
     * back to their position — @for throws NG0955 the moment two rows track to
     * the same key, and every item resolving to '' is the easy way to get there.
     */
    private readonly keyed;
    /** Split from rows() so typing does not rebuild the view models of unmatched items. */
    private readonly matches;
    onSearch(value: string): void;
    /**
     * The whole row is a click target for convenience. Anything interactive
     * between the click and the row owns its own click instead — the chevron,
     * and whatever the caller projects into a slot.
     *
     * The ancestry comes from composedPath(), which the browser captures when
     * the event is dispatched, rather than from event.target. A handler earlier
     * in the bubble can detach the clicked node before this one runs: the
     * feather directive replaces the chevron's <svg> wholesale on the change
     * detection that follows the chevron's own click. closest() on the detached
     * node then walks an orphaned tree, misses the button, and toggles the row a
     * second time — which read as the arrow not working at all.
     */
    onRowClick(event: MouseEvent, id: string): void;
    toggle(id: string): void;
    private idOf;
    /** The mark a row shows when the caller projects no #elMark template. */
    private markOf;
    private textAt;
    /** Reads 'a.b.c' as well as 'a'. */
    private read;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpandableListComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpandableListComponent<any>, "app-expandable-list", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "searchFields": { "alias": "searchFields"; "required": false; "isSignal": true; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; "isSignal": true; }; "showSearch": { "alias": "showSearch"; "required": false; "isSignal": true; }; "idKey": { "alias": "idKey"; "required": false; "isSignal": true; }; "titleKey": { "alias": "titleKey"; "required": false; "isSignal": true; }; "descriptionKey": { "alias": "descriptionKey"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "noMatchMessage": { "alias": "noMatchMessage"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "multiExpand": { "alias": "multiExpand"; "required": false; "isSignal": true; }; }, { "expandedChange": "expandedChange"; "searchChange": "searchChange"; }, ["rowTemplate", "detailTemplate", "actionsTemplate", "markTemplate", "toolbarTemplate"], never, true, never>;
}

type FileNodeType = 'file' | 'directory';
interface FileNode {
    name: string;
    path: string;
    type: FileNodeType;
    content?: string;
    children?: FileNode[];
    loaded?: boolean;
    loading?: boolean;
    loadError?: boolean;
    /** Human-readable reason for loadError (e.g. a 403 from a restricted branch) — shown as a tooltip on Retry. */
    loadErrorMessage?: string;
    isExpanded?: boolean;
    size?: number;
    lastModified?: string;
    readOnly?: boolean;
}
type FileTreeActionTheme = 'primary' | 'secondary' | 'success' | 'info' | 'warning' | 'danger' | 'dark';
interface FileTreeAction {
    /** Stable identifier the parent matches on in the event handler. */
    type: string;
    /** Human-readable label shown in the menu. */
    title: string;
    /** Feather icon name. */
    icon: string;
    /** Visual theme. Maps to Bootstrap `text-{theme}`. Defaults to 'secondary'. */
    theme?: FileTreeActionTheme;
    /** Optional predicate — return false to hide for this node. */
    when?: (node: FileNode) => boolean;
    /** Optional predicate — return true to disable the item. */
    disabled?: (node: FileNode) => boolean;
    /** Tooltip shown when `disabled` returns true. */
    disabledTooltip?: string;
    /** Render a divider above this item. */
    divider?: boolean;
}
interface FileTreeActionEvent {
    actionType: string;
    node: FileNode;
}
interface FileEditorContentChange {
    path: string;
    content: string;
}
interface FileEditorSaveEvent {
    path: string;
    content: string;
}
type FileContentLoader = (node: FileNode) => Observable<string>;
type FileBinaryLoader = (node: FileNode) => Observable<Blob>;
type FolderLoader = (node: FileNode) => Observable<FileNode[]>;
type FileRenderKind = 'text' | 'image' | 'pdf' | 'office' | 'unsupported';
declare function getFileRenderKind(name: string): FileRenderKind;
type FileLangId = 'typescript' | 'javascript' | 'json' | 'yaml' | 'markdown' | 'python' | 'hcl' | 'html' | 'css' | 'plaintext';
declare const FILE_LANG_MAP: Record<string, FileLangId>;
interface FileBadge {
    label: string;
    bg: string;
    darkText?: boolean;
}
declare const FILE_BADGE_MAP: Record<FileLangId, FileBadge>;
declare const DEFAULT_FILE_BADGE: FileBadge;
declare const FOLDER_COLOR = "var(--warning)";
declare const EXT_BADGE_MAP: Record<string, FileBadge>;
/** Minimal shape a flat file listing needs to become FileNode children — matches any context-files entry structurally. */
interface FileTreeSourceEntry {
    name: string;
    isDirectory: boolean;
    size?: number;
    lastModified?: string;
    isReadOnly?: boolean;
}
/** Maps a flat listing into FileNode children, inheriting read-only from a locked ancestor folder. */
declare function mapEntriesToFileNodes(entries: FileTreeSourceEntry[], parentPath: string, parentReadOnly: boolean): FileNode[];
declare function getExt(name: string): string;
declare function getFileLang(name: string): FileLangId;

/** Minimal editor surface the animator drives. Implemented by CodeEditorComponent. */
interface IDocumentEditor {
    getContent(): string;
    setContent(content: string): void;
    insertTextAt(offset: number, text: string): void;
    deleteTextRange(from: number, to: number): void;
}
declare enum DocDiffOpType {
    Equal = "equal",
    Insert = "insert",
    Delete = "delete"
}
interface DocDiffOp {
    type: DocDiffOpType;
    text: string;
}
declare function getDiffOps(oldContent: string, newContent: string): DocDiffOp[];
declare class AnimationService {
    private animating;
    private abortController;
    private animationPromise;
    get isAnimating(): boolean;
    cancelAnimation(): void;
    applyContent(editor: IDocumentEditor, newContent: string): Promise<void>;
    private animateOps;
    private splitIntoLines;
    private countChangedLines;
    private getAdaptiveDelay;
    private sleep;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnimationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnimationService>;
}

declare class CodeEditorComponent implements AfterViewInit, OnChanges, OnDestroy, IDocumentEditor {
    private animation;
    private themeService;
    editorHost: ElementRef<HTMLDivElement>;
    content: string;
    language: FileLangId;
    readOnly: boolean;
    theme: 'light' | 'dark';
    lineWrap: boolean;
    contentChange: EventEmitter<FileEditorContentChange>;
    saveRequest: EventEmitter<void>;
    private view;
    private langCompartment;
    private editableCompartment;
    private themeCompartment;
    private suppressEmit;
    private currentLangExt;
    private currentPath;
    constructor(animation: AnimationService, themeService: ThemeService);
    ngAfterViewInit(): void;
    private _buildState;
    ngOnChanges(changes: SimpleChanges): void;
    getContent(): string;
    setContent(content: string): void;
    /** Animated content replacement (diff-driven typing). Suppresses change events. */
    applyContent(content: string): Promise<void>;
    insertTextAt(offset: number, text: string): void;
    deleteTextRange(from: number, to: number): void;
    focus(): void;
    /** Called by wrapper so emitted events carry the active file path. */
    setPath(path: string): void;
    ngOnDestroy(): void;
    private themeExtension;
    private applyTheme;
    private _applyLang;
    static ɵfac: i0.ɵɵFactoryDeclaration<CodeEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CodeEditorComponent, "app-code-editor", never, { "content": { "alias": "content"; "required": false; }; "language": { "alias": "language"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "lineWrap": { "alias": "lineWrap"; "required": false; }; }, { "contentChange": "contentChange"; "saveRequest": "saveRequest"; }, never, never, true, never>;
}

interface FileEditorConfigOpts {
    tree: FileNode[];
    contentLoader?: FileContentLoader;
    binaryLoader?: FileBinaryLoader;
    folderLoader?: FolderLoader;
    readOnly?: boolean;
    initialPath?: string | null;
    autoOpenFirst?: boolean;
    /**
     * When set, file-row clicks delegate to this handler instead of pushing to
     * openPaths$. Lets a host (e.g. the manage-ticket tree tab) route opens into
     * its own canvas-block flow instead of the in-place tab strip.
     */
    openFileHandler?: (path: string) => void;
}
declare class FileEditorService implements OnDestroy {
    readonly tree$: BehaviorSubject<FileNode[]>;
    readonly openPaths$: BehaviorSubject<string[]>;
    readonly activePath$: BehaviorSubject<string>;
    readonly dirtyPaths$: BehaviorSubject<Set<string>>;
    readonly treeCollapsed$: BehaviorSubject<boolean>;
    readonly loadingPath$: BehaviorSubject<string>;
    readonly savingPath$: BehaviorSubject<string>;
    readonly save$: Subject<FileEditorSaveEvent>;
    readonly contentChange$: Subject<FileEditorContentChange>;
    private originalByPath;
    private currentByPath;
    private nodeByPath;
    private binaryUrlByPath;
    private recentStack;
    private readOnly;
    private contentLoader?;
    private binaryLoader?;
    private folderLoader?;
    private openFileHandler?;
    readonly binaryUrlsTick$: BehaviorSubject<number>;
    configure(opts: FileEditorConfigOpts): void;
    openFile(path: string): void;
    selectTab(path: string): void;
    setActive(path: string): void;
    closeTab(path: string): void;
    toggleTree(): void;
    updateContent(path: string, content: string): void;
    save(path: string): void;
    markSaving(path: string): void;
    clearSaving(): void;
    isSaving(path: string | null): boolean;
    cancel(path: string): void;
    expandFolder(path: string): void;
    getContent(path: string): string;
    isDirty(path: string): boolean;
    getNode(path: string): FileNode | undefined;
    getRenderKind(path: string | null): FileRenderKind;
    getBinaryUrl(path: string | null): string | null;
    ngOnDestroy(): void;
    reset(): void;
    private _revokeAllBinaryUrls;
    private _revokeBinaryUrl;
    /** Selects the next active tab after `closedPath` is removed from `open`. */
    _pickNextActive(closedPath: string, open: string[]): string | null;
    /**
     * Drops the cached content for `path` and re-triggers the content loader.
     * Clears any dirty state. Used by the Refresh toolbar action.
     */
    refreshContent(path: string): void;
    private _ensureContent;
    private _seedContent;
    private _indexTree;
    private _firstFile;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileEditorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileEditorService>;
}

interface TabCloseRequest {
    path: string;
    isDirty: boolean;
}
declare class FileTabsComponent {
    closeRequest: EventEmitter<TabCloseRequest>;
    readonly service: FileEditorService;
    readonly vm$: rxjs.Observable<{
        openPaths: string[];
        activePath: string;
        dirtyPaths: Set<string>;
    }>;
    basename(path: string): string;
    onTabClick(path: string): void;
    onCloseClick(event: MouseEvent, path: string, isDirty: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileTabsComponent, "app-file-tabs", never, {}, { "closeRequest": "closeRequest"; }, never, never, true, never>;
}

interface EntityFileEntry {
    name: string;
    relativePath: string;
    isDirectory: boolean;
    lastModified?: string;
    size?: number;
}
/** Structural contract for entity file services — no ai-studio compile-time dependency. */
interface EntityFilesContract {
    listFiles(entityId: string, relativePath?: string): Observable<EntityFileEntry[]>;
    downloadFile(entityId: string, filePath: string): Observable<Blob>;
    uploadFile(entityId: string, filePath: string, file: File): Observable<void>;
    createFolder(entityId: string, folderPath: string): Observable<void>;
    deleteFile(entityId: string, filePath: string): Observable<void>;
}

declare class EntityFileEditorWrapperComponent implements OnChanges, OnInit, OnDestroy {
    private successReporter;
    private errorReporter;
    service: EntityFilesContract;
    entityId: string;
    entityName: string;
    basePath: string;
    readOnly: boolean;
    theme: 'light' | 'dark';
    treeMinWidth: number;
    treeMaxWidth: number;
    fileActions: FileTreeAction[];
    folderActions: FileTreeAction[];
    save: EventEmitter<FileEditorSaveEvent>;
    contentChange: EventEmitter<FileEditorContentChange>;
    fileAction: EventEmitter<FileTreeActionEvent>;
    folderAction: EventEmitter<FileTreeActionEvent>;
    private editor?;
    blockUI: NgBlockUI;
    readonly editorService: FileEditorService;
    private readonly destroy$;
    private readonly confirmSvc;
    private readonly clipboard;
    private readonly hostEl;
    private readonly sanitizer;
    copySuccess: boolean;
    downloadSuccess: boolean;
    private copyResetTimer?;
    private downloadResetTimer?;
    treeWidth: number;
    isResizingTree: boolean;
    private lastTreeX;
    constructor(successReporter: SuccessReporter | null, errorReporter: ErrorReporter | null);
    isRootLoading: boolean;
    rootError: string | null;
    readonly activePath$: rxjs.BehaviorSubject<string>;
    readonly treeCollapsed$: rxjs.BehaviorSubject<boolean>;
    readonly savingPath$: rxjs.BehaviorSubject<string>;
    readonly vm$: rxjs.Observable<{
        activePath: string;
        kind: FileRenderKind;
        isDirty: boolean;
        isSaving: boolean;
        content: string;
        lang: FileLangId;
        imageUrl: string;
        pdfUrl: SafeResourceUrl;
    }>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    startTreeResize(event: MouseEvent): void;
    onMouseMove(event: MouseEvent): void;
    stopResize(): void;
    ngOnChanges(changes: SimpleChanges): void;
    loadRoot(): void;
    onCloseRequest({ path, isDirty }: TabCloseRequest): void;
    onSaveActive(): void;
    onCancelActive(): void;
    onCloseActive(): void;
    onCopyContent(): void;
    onDownloadActive(): void;
    onRefreshActive(): void;
    onEditorContentChange(event: FileEditorContentChange): void;
    private _langFor;
    isDirty(path: string | null): boolean;
    _mapEntriesToFileNodes(entries: EntityFileEntry[], parentQueryPath: string): FileNode[];
    refreshTree(): void;
    refreshFolder(path: string): void;
    private _buildFolderLoader;
    private _buildContentLoader;
    private _buildBinaryLoader;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntityFileEditorWrapperComponent, [{ optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntityFileEditorWrapperComponent, "app-entity-file-editor-wrapper", never, { "service": { "alias": "service"; "required": false; }; "entityId": { "alias": "entityId"; "required": false; }; "entityName": { "alias": "entityName"; "required": false; }; "basePath": { "alias": "basePath"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "treeMinWidth": { "alias": "treeMinWidth"; "required": false; }; "treeMaxWidth": { "alias": "treeMaxWidth"; "required": false; }; "fileActions": { "alias": "fileActions"; "required": false; }; "folderActions": { "alias": "folderActions"; "required": false; }; }, { "save": "save"; "contentChange": "contentChange"; "fileAction": "fileAction"; "folderAction": "folderAction"; }, never, never, true, never>;
}

declare class FileDetailsModalComponent {
    activeModal: NgbActiveModal;
    node: FileNode;
    isReport: boolean;
    reportCategory: string;
    formatSize?: (n?: number) => string;
    constructor(activeModal: NgbActiveModal);
    get isFile(): boolean;
    get typeLabel(): string;
    get sizeText(): string;
    private _defaultFormatSize;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileDetailsModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileDetailsModalComponent, "app-file-details-modal", never, { "node": { "alias": "node"; "required": false; }; "isReport": { "alias": "isReport"; "required": false; }; "reportCategory": { "alias": "reportCategory"; "required": false; }; "formatSize": { "alias": "formatSize"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FileEditorWrapperComponent implements OnChanges, OnInit, OnDestroy {
    tree: FileNode[];
    contentLoader?: FileContentLoader;
    readOnly: boolean;
    theme: 'light' | 'dark';
    initialPath?: string | null;
    treeMinWidth: number;
    treeMaxWidth: number;
    fileActions: FileTreeAction[];
    folderActions: FileTreeAction[];
    save: EventEmitter<FileEditorSaveEvent>;
    contentChange: EventEmitter<FileEditorContentChange>;
    fileAction: EventEmitter<FileTreeActionEvent>;
    folderAction: EventEmitter<FileTreeActionEvent>;
    private editor?;
    readonly service: FileEditorService;
    private readonly destroy$;
    private readonly confirmSvc;
    private readonly hostEl;
    treeWidth: number;
    isResizingTree: boolean;
    private lastTreeX;
    readonly activePath$: rxjs.BehaviorSubject<string>;
    readonly treeCollapsed$: rxjs.BehaviorSubject<boolean>;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    startTreeResize(event: MouseEvent): void;
    onMouseMove(event: MouseEvent): void;
    stopResize(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onCloseRequest({ path, isDirty }: TabCloseRequest): void;
    onSaveActive(): void;
    onCancelActive(): void;
    onCloseActive(): void;
    onEditorContentChange(event: FileEditorContentChange): void;
    langFor(path: string | null): FileLangId;
    contentFor(path: string | null): string;
    isDirty(path: string | null): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileEditorWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileEditorWrapperComponent, "app-file-editor-wrapper", never, { "tree": { "alias": "tree"; "required": false; }; "contentLoader": { "alias": "contentLoader"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "initialPath": { "alias": "initialPath"; "required": false; }; "treeMinWidth": { "alias": "treeMinWidth"; "required": false; }; "treeMaxWidth": { "alias": "treeMaxWidth"; "required": false; }; "fileActions": { "alias": "fileActions"; "required": false; }; "folderActions": { "alias": "folderActions"; "required": false; }; }, { "save": "save"; "contentChange": "contentChange"; "fileAction": "fileAction"; "folderAction": "folderAction"; }, never, never, true, never>;
}

declare class FileIconComponent implements OnChanges {
    name: string;
    type: FileNodeType;
    expanded: boolean;
    badge: FileBadge;
    darkText: boolean;
    ngOnChanges(): void;
    private _needsDarkText;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileIconComponent, "app-file-icon", never, { "name": { "alias": "name"; "required": false; }; "type": { "alias": "type"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FileTreeNodeComponent implements OnChanges {
    node: FileNode;
    depth: number;
    activePath: string | null;
    dirtyPaths: Set<string>;
    service: FileEditorService;
    fileActions: FileTreeAction[];
    folderActions: FileTreeAction[];
    fileAction: EventEmitter<FileTreeActionEvent>;
    folderAction: EventEmitter<FileTreeActionEvent>;
    /** Whether the node exposes any action — drives the kebab *ngIf. Recomputed on input change. */
    hasActions: boolean;
    /** Action view-model rendered in the open menu. Recomputed only when the dropdown opens,
     *  so dynamic predicates (e.g. add/remove-report) stay correct without per-CD work. */
    menuItems: {
        action: FileTreeAction;
        disabled: boolean;
        tooltip: string | null;
    }[];
    ngOnChanges(changes: SimpleChanges): void;
    onNodeClick(): void;
    onMenuOpen(open: boolean): void;
    private _actionsFor;
    emitAction(type: string, node: FileNode): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileTreeNodeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileTreeNodeComponent, "app-file-tree-node", never, { "node": { "alias": "node"; "required": false; }; "depth": { "alias": "depth"; "required": false; }; "activePath": { "alias": "activePath"; "required": false; }; "dirtyPaths": { "alias": "dirtyPaths"; "required": false; }; "service": { "alias": "service"; "required": false; }; "fileActions": { "alias": "fileActions"; "required": false; }; "folderActions": { "alias": "folderActions"; "required": false; }; }, { "fileAction": "fileAction"; "folderAction": "folderAction"; }, never, never, true, never>;
}

declare class FileTreeComponent implements OnInit, OnChanges {
    readonly service: FileEditorService;
    basePath: string;
    fileActions: FileTreeAction[];
    folderActions: FileTreeAction[];
    fileAction: EventEmitter<FileTreeActionEvent>;
    folderAction: EventEmitter<FileTreeActionEvent>;
    /** Emitted by the header "Hide" button. Hosts may use it to collapse their pane. */
    collapse: EventEmitter<void>;
    rootNode: FileNode;
    /** Whether the root row shows any action — drives the root-row *ngIf. Visibility (`when`) is static. */
    hasRootActions: boolean;
    /** Root action view-model for the open menu; rebuilt on open (see onRootMenuOpen). */
    rootMenuItems: {
        action: FileTreeAction;
        disabled: boolean;
        tooltip: string | null;
    }[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onRootMenuOpen(open: boolean): void;
    private _computeRootVisibility;
    /** Mirrors FileTreeNodeComponent's per-node menuItems shape ({action, disabled, tooltip}). */
    private _buildRootMenuItems;
    readonly vm$: rxjs.Observable<{
        tree: FileNode[];
        activePath: string;
        dirtyPaths: Set<string>;
    }>;
    emitRootAction(type: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileTreeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileTreeComponent, "app-file-tree", never, { "basePath": { "alias": "basePath"; "required": false; }; "fileActions": { "alias": "fileActions"; "required": false; }; "folderActions": { "alias": "folderActions"; "required": false; }; }, { "fileAction": "fileAction"; "folderAction": "folderAction"; "collapse": "collapse"; }, never, never, true, never>;
}

declare class FlatDropdownFilter {
    constructor(properties?: Partial<FlatDropdownFilter>);
    name: string;
    label: string;
    count?: number;
    hideWhenZero?: boolean;
    badgeClass?: string;
    group?: string;
    disabled?: boolean;
}
declare class FlatDropdownFilterComponent implements OnChanges {
    activeOption: string;
    options: FlatDropdownFilter[];
    showIfNoOptions?: boolean;
    placeholder?: string;
    showCount?: boolean;
    showGroup?: boolean;
    hideAll?: boolean;
    showAllOption?: boolean;
    activeOptionChange: EventEmitter<any>;
    activeGroupChange: EventEmitter<any>;
    ngOnChanges(changes: SimpleChanges): void;
    optionSelectionHandler(name?: string, grpName?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FlatDropdownFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlatDropdownFilterComponent, "app-flat-dropdown-filter", never, { "activeOption": { "alias": "activeOption"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showIfNoOptions": { "alias": "showIfNoOptions"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "showCount": { "alias": "showCount"; "required": false; }; "showGroup": { "alias": "showGroup"; "required": false; }; "hideAll": { "alias": "hideAll"; "required": false; }; "showAllOption": { "alias": "showAllOption"; "required": false; }; }, { "activeOptionChange": "activeOptionChange"; "activeGroupChange": "activeGroupChange"; }, never, never, true, never>;
}

declare class NgbTimeNativeDateAdapter extends NgbTimeAdapter<Date> {
    fromModel(value: Date | null): NgbTimeStruct | null;
    toModel(time: NgbTimeStruct | null): Date | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgbTimeNativeDateAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NgbTimeNativeDateAdapter>;
}

/**
 * Validates that a control's value is valid YAML that parses to the expected top-level kind
 * (`'array'` or `'object'`), allowing ANY element/property types. YAML is a superset of JSON,
 * so JSON flow syntax (`[1,2,3]`, `{"a":1}`) is accepted too.
 *
 * Attaches an inline error message so it renders without an i18n entry.
 *
 * Usage: `<ngx-monaco-editor yamlValue="array" ...>` or `yamlValue="object"`.
 */
declare class YamlValueValidationDirective implements Validator {
    /** `'array'` = list only, `'object'` = map only, `'json'` = either (any structured value). */
    kind: 'array' | 'object' | 'json';
    validate(control: AbstractControl): ValidationErrors | null;
    private error;
    static ɵfac: i0.ɵɵFactoryDeclaration<YamlValueValidationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<YamlValueValidationDirective, "[yamlValue]", never, { "kind": { "alias": "yamlValue"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TableHelpDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<TableHelpDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TableHelpDirective, "[appTableHelp]", never, {}, {}, never, never, false, never>;
}

/**
 * Turns a failed request into something a person can act on: what went wrong, why it usually
 * happens, and the raw message kept separately as a detail.
 */
interface K8sErrorView {
    title: string;
    message: string;
    /** The server's own message, shown small under the explanation. */
    detail: string | null;
    /** Feather icon for the state panel. */
    icon: string;
}

/**
 * Lean shapes for the raw Kubernetes objects the explorer reads. Only the fields the explorer
 * touches are typed; everything else stays reachable through the index signatures.
 */
interface K8sOwnerReference {
    apiVersion?: string;
    kind: string;
    name: string;
    uid?: string;
    controller?: boolean;
}
interface K8sObjectMeta {
    name: string;
    namespace?: string;
    uid?: string;
    creationTimestamp?: string;
    deletionTimestamp?: string;
    resourceVersion?: string;
    generation?: number;
    labels?: Record<string, string>;
    annotations?: Record<string, string>;
    ownerReferences?: K8sOwnerReference[];
    finalizers?: string[];
    managedFields?: unknown[];
    [key: string]: unknown;
}
interface K8sObject {
    apiVersion?: string;
    kind?: string;
    metadata: K8sObjectMeta;
    spec?: any;
    status?: any;
    [key: string]: any;
}
interface K8sList<T = K8sObject> {
    apiVersion?: string;
    kind?: string;
    metadata?: {
        resourceVersion?: string;
        continue?: string;
    };
    items: T[];
}
/** The operators a label selector expression can use. Anything else matches nothing. */
type K8sLabelSelectorOperator = 'In' | 'NotIn' | 'Exists' | 'DoesNotExist';
interface K8sLabelSelectorRequirement {
    key: string;
    operator: K8sLabelSelectorOperator;
    values?: string[];
}
interface K8sLabelSelector {
    matchLabels?: Record<string, string>;
    matchExpressions?: K8sLabelSelectorRequirement[];
}
/** Pod logs as the logs endpoint returns them: one string, one timestamp per line. */
interface K8sPodLogs {
    podName: string;
    namespace: string;
    container?: string | null;
    logs: string;
    lineCount?: number;
    hasMoreLogs?: boolean;
}

/** Public types for `<app-k8s-explorer>`. Everything a host passes in or receives back lives here. */
/** Namespace value meaning "every namespace the scope permits". */
declare const K8S_ALL_NAMESPACES = "*";
/** The object open in the details panel, identified the way a URL would carry it. */
interface K8sExplorerSelection {
    kind: string;
    namespace?: string | null;
    name: string;
}
/**
 * What the explorer is showing. Emitted on every user-driven change so a host can mirror it
 * into the URL, and accepted back through the `state` input to restore it.
 */
interface K8sExplorerState {
    kind: string;
    /** Selected namespace, `'*'` for all. Kept while a cluster-scoped kind is shown, so it survives switching back. */
    namespace: string | null;
    selected: K8sExplorerSelection | null;
}
/** Switches for the explorer's optional capabilities. */
interface K8sExplorerFeatures {
    /** kubectl and pod shell tabs in the dock. */
    terminal: boolean;
    /** Pod and workload logs tabs in the dock. */
    logs: boolean;
    /** REST actions (restart, delete pod) and typed kubectl actions. */
    actions: boolean;
    /** Lets a viewer reveal a Secret value in the details panel. */
    secretReveal: boolean;
}
declare const DEFAULT_K8S_EXPLORER_FEATURES: K8sExplorerFeatures;
/** One Kubernetes scope (cluster connection) and the namespaces it permits. */
interface K8sScopeInfo {
    scopeId: string;
    scopeName: string;
    providerName?: string;
    namespaces: string[];
    isStaticTokenCredential?: boolean;
}
/** Which list call to make: the kind's API group/version, its plural, and whether it takes a namespace. */
interface K8sResourceRef {
    apiVersion: string;
    plural: string;
    namespaced: boolean;
}
interface K8sPodLogsOptions {
    container?: string;
    tailLines?: number;
    sinceSeconds?: number;
}
type K8sRestartableKind = 'deployments' | 'statefulsets';
/**
 * Every backend call the explorer makes. Hosts pass one as a plain object, never as an
 * injection token: extensions bundle their own copy of this library, so a token would not be
 * the same object as the host's. Leaving an optional method out hides the capability it backs.
 */
interface K8sExplorerApi {
    /**
     * Workspace the API reads through, for APIs scoped to one. The same scope id can be reached
     * from two workspaces, so the dock keys its cached credentials and its tabs by it too.
     */
    readonly workspaceId?: string;
    getScope(scopeId: string): Observable<K8sScopeInfo>;
    /** Lists one kind. `namespace` is ignored for cluster-scoped kinds. */
    listResources(scopeId: string, resource: K8sResourceRef, namespace?: string | null): Observable<K8sList<K8sObject>>;
    getPodLogs(scopeId: string, namespace: string, pod: string, options?: K8sPodLogsOptions): Observable<K8sPodLogs>;
    /** Short-lived cluster credentials for the kubectl and shell tabs. */
    getJitAccess?(scopeId: string, namespace?: string): Observable<K8ClusterConfig>;
    restartWorkload?(scopeId: string, namespace: string, kind: K8sRestartableKind, name: string): Observable<unknown>;
    deletePod?(scopeId: string, namespace: string, pod: string): Observable<unknown>;
    /** Whether a static-token scope may still open terminals. Defaults to the AI Studio system setting. */
    allowStaticTokenAccess?(): Observable<boolean>;
}
/** Refresh interval the explorer uses unless the host passes one. */
declare const DEFAULT_K8S_REFRESH_INTERVAL_MS = 10000;
/** Slowest refresh used when "All namespaces" fans out across many namespaces. */
declare const K8S_FAN_OUT_REFRESH_FLOOR_MS = 30000;
/** Above this many namespaces, "All namespaces" refreshes at the floor interval. */
declare const K8S_FAN_OUT_SLOW_THRESHOLD = 5;
/**
 * Default number of namespace requests run at once for "All namespaces". The limit applies to each
 * fan-out on its own: the Overview lists pods and events side by side, so it can have twice this
 * many namespace requests in flight, plus its node and namespace calls.
 */
declare const DEFAULT_K8S_FAN_OUT_CONCURRENCY = 4;

/** Colour role of a cell or badge. Mapped to theme classes, never to raw colours. */
type K8sTone = 'ok' | 'warn' | 'bad' | 'mute' | 'info';
/** One container brick in the Pods table: green when ready, red when failing, grey when done. */
interface K8sBrick {
    name: string;
    tone: K8sTone;
    state: string;
}
/** How a column renders. The list template switches on this. */
type K8sCellType = 'name' | 'text' | 'mono' | 'status' | 'age' | 'bricks' | 'restarts' | 'ratio'
/** A percentage with a thin bar under it, for requested-vs-allocatable columns. */
 | 'usage';
interface K8sColumnDef {
    id: string;
    label: string;
    cell: K8sCellType;
    /**
     * Share of the table's width. The table runs in `flex` mode, so every column grows with the
     * window in proportion: text columns (names, images, owners) carry large shares, counts and
     * ages small ones, and a wide screen widens all of them rather than only the name.
     * There is deliberately no max width: ngx-datatable drops the width a capped column gives
     * up (and force mode mis-splices its column list), which leaves a gap at the table's edge.
     */
    flexGrow?: number;
    /**
     * Narrowest the column may get, for content that must stay readable (a usage bar, a status
     * badge). The list also keeps every column wide enough for its header label, so short labels
     * need no value here; a table whose minimums add up past its width scrolls sideways.
     */
    minWidth?: number;
    sortable?: boolean;
}
/** A display value computed once per fetch, never in the template. */
interface K8sCellValue {
    text: string;
    sub?: string;
    tone?: K8sTone;
    /** Sort key when it differs from `text` (numbers, ages). */
    sort?: string | number;
    /** Tooltip, when it should say more than the text (an exact time behind an age). */
    title?: string;
    bricks?: K8sBrick[];
    /** Fill of a `usage` cell's bar, 0–100. Unset while the value is loading or unknown. */
    meter?: number;
    /** Still being worked out, e.g. an enrichment column; shown as moving dots. */
    loading?: boolean;
}
/**
 * What a row offers. REST actions call the existing endpoints; everything else becomes a
 * kubectl command typed into a dock tab, which runs only when the user presses Enter.
 */
type K8sActionId = 'logs' | 'shell' | 'restart' | 'delete-pod' | 'scale' | 'describe' | 'edit' | 'delete' | 'rollout-restart' | 'cordon' | 'uncordon' | 'drain' | 'previous-logs' | 'cronjob-run' | 'cronjob-suspend';
type K8sKindGroupId = 'cluster' | 'workloads' | 'config' | 'network' | 'storage' | 'access' | 'observe';
interface K8sKindGroup {
    id: K8sKindGroupId;
    label: string;
    kinds: string[];
}
/** A status badge, as the details panel header shows it. */
interface K8sStatusBadge {
    label: string;
    tone: K8sTone;
}
/**
 * One entry of the kind registry. A single definition drives the sidebar, the table columns,
 * the filter pills, the details panel badge, the row actions and whether the namespace filter shows.
 */
interface K8sKindDef {
    id: string;
    group: K8sKindGroupId;
    /** Plural label for the sidebar and the list title. */
    label: string;
    /** Singular label for the details panel. */
    singular: string;
    /** Feather icon name. */
    icon: string;
    apiVersion: string;
    plural: string;
    /** Resource name kubectl understands, e.g. `deployment`. */
    kubectlName: string;
    namespaced: boolean;
    columns: K8sColumnDef[];
    /**
     * Builds the kind's cells. Name and age cells are added for every kind; a kind's own cell
     * replaces them (Nodes and StorageClasses add a sub-line to the name, Events show last seen as the age).
     */
    cells(raw: K8sObject, now: number): Record<string, K8sCellValue>;
    /**
     * The filter pills above the table: each row falls in one bucket (`Ready`, `Failed`,
     * `Helm release`…). Chosen per kind from what real clusters hold, e.g. ReplicaSets split
     * into active and scaled-to-zero because most are old revisions.
     */
    facet?: K8sFacetDef;
    /**
     * Columns that need pods from elsewhere (pods per node, pods per namespace, pods using a
     * claim). The list loads them after its own rows and fills these cells in.
     */
    enrich?: K8sEnrichDef;
    /** Badge for the details panel header. */
    status?(raw: K8sObject): K8sStatusBadge | null;
    /** Extra searchable text beyond name and namespace. Secrets must never include values. */
    searchText?(raw: K8sObject): string;
    /** Column the list sorts by first, e.g. newest events on top. */
    defaultSort?: {
        column: string;
        dir: 'asc' | 'desc';
    };
    actions: K8sActionId[];
    /** True for synthetic pages, such as Overview, that aren't a list of one kind. */
    synthetic?: boolean;
}
interface K8sFacetDef {
    /** Accessible name of the pill group. */
    label: string;
    /** The bucket a row falls in. */
    of(raw: K8sObject): string;
    /** Bucket order for the pills; unlisted buckets follow alphabetically. */
    order?: string[];
    /** Bucket selected when the kind opens, e.g. `Active` for ReplicaSets. */
    initial?: string;
}
interface K8sEnrichDef {
    /** `all` lists pods in every permitted namespace (nodes, namespaces); `selection` follows the namespace filter. */
    pods: 'all' | 'selection';
    /** Column ids it fills, so they can say "unavailable" when the pods can't be listed. */
    columns: string[];
    /** Returns the cells to merge into each row, keyed by row id. */
    apply(rows: readonly K8sRow[], pods: readonly K8sObject[], now: number, coverage?: K8sPodCoverage): Map<string, Record<string, K8sCellValue>>;
}
/** Which namespaces' pods an enrichment pod list actually holds. */
interface K8sPodCoverage {
    /** Namespaces whose pods were read. */
    read: ReadonlySet<string>;
    /** Permitted namespaces whose pod list failed, so their pods are missing. */
    failed: readonly string[];
    /**
     * Namespaces the cluster has that weren't read because the scope doesn't include them, so
     * their pods are missing too. 0 when unknown.
     */
    unread: number;
}
/** One table row: every display value computed once, plus the raw object for the details panel. */
interface K8sRow {
    /** uid, or namespace/name when the API omits it. Also the datatable row identity. */
    id: string;
    name: string;
    namespace: string | null;
    cells: Record<string, K8sCellValue>;
    /** Flat sort keys, read by the datatable through `sort.<columnId>`. */
    sort: Record<string, string | number>;
    /** The row's facet bucket, when the kind has a facet. */
    facet: string | null;
    search: string;
    raw: K8sObject;
}

/**
 * Turns a raw object into the details panel's sections. Pure: everything the template shows
 * is computed here once, never in a binding.
 */
interface K8sDetailRow {
    label: string;
    value: string;
    mono?: boolean;
}
interface K8sContainerView {
    name: string;
    image: string;
    init: boolean;
    /** A native sidecar: an init container with `restartPolicy: Always`, running beside the app. */
    sidecar: boolean;
    /** `init`, `sidecar`, or '' for an app container: the badge beside the name. */
    role: string;
    /** `Sidecar`, `Init container` or `Container`. */
    typeLabel: string;
    state: string;
    tone: K8sTone;
    /** The state pill's colour class for `tone`. */
    badgeClass: string;
    ready: boolean;
    restarts: number;
    /** Ports, command, env names, mounts, probes, resources — what `kubectl describe pod` lists per container. */
    rows: K8sDetailRow[];
    /** Has run at least once (running, finished or restarted), so it has logs. */
    started: boolean;
    /** Running, and an app container or a sidecar: a shell can open in it. */
    shellable: boolean;
}

type K8sActionChannel = 'rest' | 'kubectl' | 'dock';
/** One entry of a row menu or the details panel's actions. */
interface K8sActionItem {
    id: K8sActionId;
    label: string;
    icon: string;
    channel: K8sActionChannel;
    danger: boolean;
    disabled: boolean;
    /** Why it's disabled, for the tooltip. */
    reason: string | null;
}
interface K8sTerminalAvailability {
    /** False hides terminal controls entirely (feature off, or the API can't mint credentials). */
    visible: boolean;
    enabled: boolean;
    reason: string | null;
}
/** What decides a container's actions: whether it has run, restarted, and can take a shell. */
type K8sContainerActionTarget = Pick<K8sContainerView, 'started' | 'restarts' | 'shellable' | 'init' | 'sidecar'>;
/** Decides which actions a kind offers, and runs them. One instance per explorer. */
declare class K8sActionsService {
    private readonly store;
    private readonly dock;
    private readonly confirmation;
    private readonly settings;
    private readonly kubeconfigDownload;
    private readonly error;
    private readonly success;
    private readonly allowStaticToken;
    /** Set after a JIT call is refused, the only way the UI learns `k8s.jit` is missing. */
    readonly jitDenied: i0.WritableSignal<boolean>;
    /** APIs whose static-token setting to load; a newer one cancels an answer still on its way. */
    private readonly settingsFor$;
    constructor();
    readonly terminal: i0.Signal<K8sTerminalAvailability>;
    /** Loads the static-token setting for a newly selected API. */
    loadSettings(api: K8sExplorerApi): void;
    private allowStaticTokenFor;
    actionsFor(kind: K8sKindDef | undefined): K8sActionItem[];
    /**
     * The kind's actions for one object: Shell and Logs turned off where that pod can't serve them,
     * Suspend offered as Resume on a CronJob that is already suspended, only the one of
     * Cordon / Uncordon that changes the node, and Scale / Edit turned off on a ReplicaSet whose
     * controller would undo them.
     */
    actionsForRow(kind: K8sKindDef | undefined, row: K8sRow | null): K8sActionItem[];
    /**
     * Logs, Shell and Previous logs for one container of a pod: the kind's items, each turned off
     * with a reason where this container can't serve it. The container's own state decides, not the
     * pod-wide rules of {@link actionsForRow}, so each item gives this container's reason.
     * Run them with `run(id, kind, row, name)`.
     */
    actionsForContainer(kind: K8sKindDef | undefined, container: K8sContainerActionTarget): K8sActionItem[];
    /** Runs an action on a row. `container` targets one container for logs and shell. */
    run(action: K8sActionId, kind: K8sKindDef, row: K8sRow, container?: string): void;
    /** Shows the namespace's kubectl tab, opening one if needed; `newTab` always opens another. */
    openKubectl(newTab?: boolean): void;
    /**
     * Downloads a kubeconfig with fresh credentials, not the dock's cached ones: the file outlives
     * the page, so its token should have its whole lifetime left.
     */
    downloadKubeconfig(): void;
    /**
     * Records a refused JIT call so terminal controls show why they're off. A 403 is already
     * toasted as "Access denied" by the app's error interceptor, so only other failures are reported.
     */
    onJitError(err: ErrorMessage): void;
    /**
     * Namespace a terminal runs in. JIT tokens are minted per namespace and must be permitted by
     * the scope, so cluster-scoped objects use the selected namespace or the first permitted one.
     */
    terminalNamespace(kind: K8sKindDef | null, row: K8sRow | null): string;
    private typeKubectl;
    private openShell;
    private openLogs;
    private confirmRestart;
    private confirmDeletePod;
    /**
     * Holds auto-refresh while the confirmation is open and refreshes once it's done, dropping the
     * cached pod lists so the changed pods show at once. The confirmation reports success and
     * failure itself, so the rejection is only swallowed here.
     */
    private withPausedPolling;
    private reportTerminalLimit;
    static ɵfac: i0.ɵɵFactoryDeclaration<K8sActionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<K8sActionsService>;
}

/** A pod that needs a look: not ready, or restarted in the last hour. */
interface K8sProblemPod {
    id: string;
    name: string;
    namespace: string;
    status: string;
    tone: K8sTone;
    ready: string;
    restarts: number;
    /** `OOMKilled · 4m ago`, when it restarted. */
    restartNote: string;
    age: string;
}
interface K8sWarningEvent {
    id: string;
    /** The Event object's own name, to open it in the details panel. */
    name: string;
    reason: string;
    objectKind: string;
    objectName: string;
    /** Registry id of the involved object's kind (`pods`), when the explorer lists that kind. */
    objectKindId: string | null;
    /** The involved object's namespace; '' for a cluster-scoped object such as a Node. */
    objectNamespace: string;
    /** The Event's own namespace. */
    namespace: string;
    message: string;
    count: number;
    /** `×1,698`, or '' for a one-off. */
    countLabel: string;
    lastSeen: string;
    lastSeenTitle: string;
}
/** Requested share of what the nodes can hand out. */
interface K8sCapacityMeter {
    label: string;
    used: number;
    total: number;
    percent: number;
    /** Bar fill, capped at 100 when requests overcommit. */
    fill: number;
    tone: K8sTone;
    usedLabel: string;
    totalLabel: string;
}
/** Nodes grouped by instance type: `t3.medium × 7` in `us-west-2a, us-west-2b`. */
interface K8sNodeGroup {
    instanceType: string;
    count: number;
    ready: number;
    zones: string;
}
interface K8sOverviewData {
    /** Most common kubelet version across nodes, short form. The kubelets', not the API server's `/version`. */
    version: string | null;
    /** Distinct kubelet versions, short form; more than one means an upgrade is part way. */
    versions: string[];
    nodes: number | null;
    nodesReady: number | null;
    nodesCordoned: number;
    /** Set when listing nodes failed, usually because the scope has no cluster-level access. */
    nodesError: string | null;
    namespaces: number;
    clusterNamespaces: number | null;
    pods: number;
    podsReady: number;
    podsNotReady: number;
    podsCompleted: number;
    restarts: number;
    /** Null without node access: there is nothing to compare requests against. */
    capacity: K8sCapacityMeter[] | null;
    /**
     * True when requests are a lower bound: the scope sees fewer namespaces than the cluster has, or
     * some namespaces' pods didn't load.
     */
    partialRequests: boolean;
    problemPods: K8sProblemPod[];
    problemPodCount: number;
    warnings: K8sWarningEvent[];
    warningCount: number;
    warningsLastHour: number;
    /** True when events couldn't be listed. */
    eventsError: boolean;
    /** True while pods are still loading: pod figures, requests and problem pods aren't known yet. */
    podsLoading: boolean;
    /** True while events are still loading. */
    eventsLoading: boolean;
    nodeGroups: K8sNodeGroup[];
    /** Namespaces whose pods didn't load. */
    failedNamespaces: string[];
    /** Namespaces whose events didn't load: the warnings leave them out. */
    eventsFailedNamespaces: string[];
}

/** One facet pill: the bucket and how many rows fall in it. */
interface K8sFacetBucket {
    value: string;
    count: number;
}
/** Objects for the details panel, and whether listing them failed. */
interface K8sRelatedResult {
    items: K8sObject[];
    /** Why the list failed, or null. */
    error: string | null;
    errorStatus: number | null;
}
/**
 * State for one explorer instance: scope, selected kind and namespace, the visible rows,
 * polling, and the open object. Provided on `<app-k8s-explorer>`, so every embedded explorer
 * has its own. Async state lives in signals; the component tree is OnPush.
 */
declare class K8sExplorerStateService {
    private readonly zone;
    private readonly destroyRef;
    readonly api: i0.WritableSignal<K8sExplorerApi>;
    readonly scopeId: i0.WritableSignal<string>;
    readonly features: i0.WritableSignal<K8sExplorerFeatures>;
    readonly readOnly: i0.WritableSignal<boolean>;
    readonly refreshIntervalMs: i0.WritableSignal<number>;
    readonly autoRefresh: i0.WritableSignal<boolean>;
    readonly fanOutConcurrency: i0.WritableSignal<number>;
    readonly allowedKinds: i0.WritableSignal<string[]>;
    readonly namespaceFilter: i0.WritableSignal<string[]>;
    readonly lockNamespace: i0.WritableSignal<boolean>;
    readonly scope: i0.WritableSignal<K8sScopeInfo>;
    readonly scopeLoading: i0.WritableSignal<boolean>;
    readonly scopeError: i0.WritableSignal<string>;
    /** HTTP status of the scope failure, so the UI can say why (no access, not found, timeout). */
    readonly scopeErrorStatus: i0.WritableSignal<number>;
    /** Namespaces the scope permits, narrowed by the host's `namespaces` input. */
    readonly namespaces: i0.Signal<string[]>;
    readonly kinds: i0.Signal<K8sKindDef[]>;
    readonly kindId: i0.WritableSignal<string>;
    readonly kind: i0.Signal<K8sKindDef>;
    /** Selected namespace, `'*'` for all. Only applies to namespaced kinds. */
    readonly namespace: i0.WritableSignal<string>;
    readonly search: i0.WritableSignal<string>;
    /** Selected facet bucket (`Ready`, `Helm release`…); '' shows every row. */
    readonly facet: i0.WritableSignal<string>;
    readonly rows: i0.WritableSignal<K8sRow[]>;
    /** Kind the current rows belong to, so a table never renders rows under another kind's columns. */
    readonly rowsKindId: i0.WritableSignal<string>;
    readonly loading: i0.WritableSignal<boolean>;
    /** True while any request for the visible page is in flight, including silent ticks. */
    readonly refreshing: i0.WritableSignal<boolean>;
    readonly error: i0.WritableSignal<string>;
    /** HTTP status behind `error`, e.g. 403 when the scope's credentials can't list this kind. */
    readonly errorStatus: i0.WritableSignal<number>;
    readonly failedNamespaces: i0.WritableSignal<string[]>;
    readonly lastUpdated: i0.WritableSignal<number>;
    readonly overview: i0.WritableSignal<K8sOverviewData>;
    /** Moves every few seconds; drives the "Updated Xs ago" label. */
    readonly now: i0.WritableSignal<number>;
    readonly selectedId: i0.WritableSignal<string>;
    private readonly selectedSnapshot;
    /** A container of the open pod that the details panel shows instead of the pod, or null for the pod. */
    readonly selectedContainer: i0.WritableSignal<string>;
    /** Selection requested before its rows exist (deep link or owner link). */
    private pendingSelection;
    /** The open row, kept after it vanishes so the panel can say it was deleted. */
    readonly selectedRow: i0.Signal<K8sRow>;
    /**
     * True when the open object is gone from a fresh list. A namespace that failed to list says
     * nothing about whether its objects still exist, so those don't count.
     */
    readonly selectedDeleted: i0.Signal<boolean>;
    private readonly pauseTokens;
    readonly paused: i0.Signal<boolean>;
    readonly isAllNamespaces: i0.Signal<boolean>;
    /** True when the current page lists across namespaces one request at a time. */
    readonly isFanOut: i0.Signal<boolean>;
    /** Refresh interval, slowed to the floor when a fan-out spans many namespaces. */
    readonly effectiveIntervalMs: i0.Signal<number>;
    readonly intervalLabel: i0.Signal<string>;
    readonly updatedLabel: i0.Signal<string>;
    readonly kindRows: i0.Signal<K8sRow[]>;
    /**
     * The facet pills: buckets in the kind's order, then any others alphabetically. Empty
     * buckets are left out, except the selected one, so the pill being looked at never vanishes.
     */
    readonly facetBuckets: i0.Signal<K8sFacetBucket[]>;
    readonly visibleRows: i0.Signal<K8sRow[]>;
    /** Load requests; null cancels the one in flight (a new scope). */
    private readonly load$;
    private readonly relatedCache;
    /** Pod lists by namespace (`'*|<namespaces>'` for every permitted one). Kept across kind switches; a manual refresh drops them. */
    private readonly podsCache;
    /** Last enrichment cells, re-applied to fresh rows on a tick so the columns don't blink back to `…`. */
    private enrichment;
    private enrichSubscription;
    private scopeSubscription;
    private ticker;
    private requestSeq;
    /** The host's namespace rules (`namespaces`, `lockNamespace`) the shown namespace was picked under. */
    private namespaceRules;
    /** When the last load finished, good or not. Ticks count from here, so a failing refresh doesn't retry every second. */
    private lastAttempt;
    /** Failed loads in a row; each doubles the wait before the next tick, up to {@link REFRESH_BACKOFF_MAX_STEPS}. */
    private failedRefreshes;
    constructor();
    /** Loads a scope and its namespaces, then the current kind. */
    initScope(api: K8sExplorerApi, scopeId: string, preferredNamespace: string | null): void;
    /**
     * Sets the kind before the scope loads (initial state, allowed kinds), without a reload.
     * Once a scope is showing it switches like {@link setKind}, so the new kind loads.
     */
    presetKind(kindId: string): void;
    setKind(kindId: string): void;
    /** Switches namespace. Ignored while the host pins the namespace. */
    setNamespace(namespace: string | null): void;
    /**
     * Switches kind and namespace in one step, with a single reload. Used by the Overview's
     * namespace rows and links, and the node panel's "Show pods", which pre-fill the search or a facet.
     */
    openObjectList(kindId: string, namespace: string | null, search?: string, facet?: string): void;
    /** Selects an object once its rows load, for a deep link read before the scope is ready; null drops it. */
    queueSelection(selection: K8sExplorerSelection | null): void;
    /** Opens a row in the details panel. */
    select(row: K8sRow | null): void;
    /** Opens one container of a pod in the details panel, which links back to the pod. */
    selectContainer(row: K8sRow, container: string): void;
    closeSelection(): void;
    /**
     * Opens an object that may live under another kind or namespace (owner links, deep links).
     * Switches there first, then selects it once its rows load. `listNamespace` picks the list to
     * show it in (e.g. a URL's namespace); by default "All namespaces" stays selected, since that
     * list already holds the object, and otherwise the object's own namespace is shown.
     */
    openObject(selection: K8sExplorerSelection, listNamespace?: string | null): void;
    /** Re-fetches the visible page. `manual` also lists pods afresh. */
    reload(reason: 'context' | 'tick' | 'manual'): void;
    /** Stops auto-refresh while a menu or dialog is open, so it isn't re-rendered away. */
    pause(token: string): void;
    resume(token: string): void;
    /**
     * Raw objects of one kind in one namespace (null for a cluster-scoped kind), cached briefly.
     * Used by the details panel for events and related pods. A failed list comes back empty;
     * {@link listRelatedResult} says why.
     */
    listRelated(kindId: string, namespace: string | null): Observable<K8sObject[]>;
    /**
     * {@link listRelated} with the failure kept: `error` is set when the list couldn't be read
     * (e.g. a 403), so the panel can say so instead of "none". Successful lists are cached for
     * {@link RELATED_TTL_MS}; a list still loading is shared; failures aren't cached.
     */
    listRelatedResult(kindId: string, namespace: string | null): Observable<K8sRelatedResult>;
    /**
     * Drops one related list from the cache, so the next {@link listRelated} or
     * {@link listRelatedResult} for it lists afresh. Callers already subscribed keep their answer.
     */
    invalidateRelated(kindId: string, namespace: string | null): void;
    private fetchRelated;
    /** One list call: in `namespace` for a namespaced kind, cluster-wide otherwise. */
    private listOne;
    /** Stamps a good related list so it's reused; drops a failed one so the next caller asks again. */
    private settleRelated;
    private isAllowedKind;
    /** The namespace to switch to: `requested`, or the current one while the host pins it. */
    private namespaceFor;
    /** Where to look for an object: the list already shown when it spans every namespace, else the object's own. */
    private objectNamespace;
    /**
     * Re-picks the namespace when the host's namespace rules changed since it was picked, and
     * reloads: the old one may no longer be allowed, and "All namespaces" now spans other ones.
     * Pinning while on "All namespaces" moves to one namespace, as {@link pickNamespace} would.
     */
    private applyNamespaceRules;
    /** The host's `namespaces` and `lockNamespace`, as one comparable value. */
    private currentNamespaceRules;
    private pickNamespace;
    private clearRows;
    /** Drops every cached pod list and cancels any still loading. */
    private clearPodsCache;
    private refFor;
    /** {@link fetch}, with any failure turned into an error result, so one bad response never stops the explorer. */
    private safeFetch;
    private failure;
    private fetch;
    /**
     * The Overview's lists. Opening it paints as soon as nodes and namespaces arrive, then fills in
     * pods and events as each fan-out lands; a tick waits for everything so the page doesn't flicker.
     */
    private fetchOverview;
    /** One Overview result. `pods` is null and `events` undefined while they load. */
    private overviewResult;
    private applyResult;
    /** Puts a list's rows on screen, keeping enrichment, the facet and the open object in step. */
    private applyRows;
    /** Records a finished load. Failures in a row stretch the wait before the next tick. */
    private noteAttempt;
    private isCurrent;
    /**
     * Fills the kind's enrichment columns (pods per node, pods using a claim) from a pod list,
     * after the rows are on screen. A failed pod list turns the columns into `—` with a reason.
     * `listedObjects` is how many objects the rows came from.
     */
    private loadEnrichment;
    /**
     * How many namespaces the cluster has (the Overview's count), or null when they can't be
     * listed. The Namespaces kind's own rows already are that list.
     */
    private clusterNamespaceCount;
    /**
     * Pods in one namespace, or in every permitted one for `'*'`, shared by the Overview and the
     * enrichment columns. A list is reused while it loads and for {@link PODS_TTL_MS} after it
     * arrives, so a slow fan-out is never started twice; `force` lists afresh unless one is loading.
     * A list with a failed namespace is reused only for {@link PARTIAL_PODS_TTL_MS}.
     */
    private listPods;
    /**
     * Opens the queued selection once its kind's rows are on screen. While the object's namespace
     * failed to list, or any namespace did when its namespace is unknown, it stays queued for a later
     * load that reads it.
     */
    private resolvePendingSelection;
    /**
     * A check every {@link TICKER_STEP_MS} outside Angular's zone, so an idle explorer doesn't run
     * app-wide change detection every second. It writes signals only when the clock should move
     * (every {@link CLOCK_STEP_MS}, while visible and showing something) or a refresh is due.
     */
    private startTicker;
    private onTick;
    /** Due one interval after the last load finished, doubled for each failure in a row. */
    private isDue;
    /** Back on the tab: the clock catches up at once, and a refresh that fell due while hidden runs. */
    private onVisibilityChange;
    static ɵfac: i0.ɵɵFactoryDeclaration<K8sExplorerStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<K8sExplorerStateService>;
}

/**
 * A Lens-style Kubernetes explorer for one scope: categories on the left, a list
 * per kind, a details panel, and a dock for kubectl, pod shells and logs.
 *
 * One card. Its top row has the page title over the sidebar, then the scope (a host projects its
 * own picker with `[k8sExplorerScope]`, else the scope's name shows) and the page's controls:
 * auto-refresh, Refresh, kubectl and kubeconfig.
 *
 * The only required input is `scopeId`. It calls the existing AI Studio endpoints itself
 * through the host's `REMOTE_DuploHttpClient`, so it works the same in AI Studio and inside an
 * extension; a host without that client passes its own `api`. It has no routes: hosts that want
 * the URL to follow it listen to `stateChange` and pass the state back through `state`. The host
 * must give it a bounded height, from its own stylesheet or with `fitViewport`.
 *
 * ```html
 * <app-k8s-explorer class="k8s-host" [scopeId]="scopeId"></app-k8s-explorer>
 * ```
 * ```scss
 * .k8s-host { height: calc(100vh - 10rem); }
 * ```
 */
declare class K8sExplorerComponent {
    protected readonly store: K8sExplorerStateService;
    protected readonly actions: K8sActionsService;
    /** Optional: a host that passes its own `api` needs neither of these. */
    private readonly http;
    private readonly session;
    private readonly host;
    /** The Kubernetes scope (cluster connection) to explore. */
    readonly scopeId: i0.InputSignal<string>;
    /**
     * Workspace for the user endpoints. Defaults to the session's current AI workspace, followed as
     * the user switches workspace. Set, it wins over the session.
     */
    readonly workspaceId: i0.InputSignal<string>;
    /** Which built-in endpoints to call. Ignored when `api` is set. */
    readonly mode: i0.InputSignal<"user" | "admin">;
    /** A custom API as a plain object, e.g. an extension proxying through its own controller. */
    readonly api: i0.InputSignal<K8sExplorerApi>;
    /** Admin mode only: scope name and token type, which the admin endpoints don't return. */
    readonly scopeHint: i0.InputSignal<Partial<K8sScopeInfo>>;
    /**
     * Kind, namespace and open object to show; read on start and whenever it changes. A `null`
     * namespace means All namespaces; one left out keeps the namespace shown.
     */
    readonly state: i0.InputSignal<Partial<K8sExplorerState>>;
    /** Narrows the namespaces offered to a subset of the scope's. */
    readonly namespaces: i0.InputSignal<string[]>;
    /** Pins the namespace filter, e.g. on a namespace's own page. */
    readonly lockNamespace: i0.InputSignal<boolean>;
    /** Limits the kinds shown, by registry id (`overview`, `pods`, …). Empty shows all. */
    readonly kinds: i0.InputSignal<string[]>;
    /** Hides every action that changes the cluster. */
    readonly readOnly: i0.InputSignal<boolean>;
    readonly features: i0.InputSignal<Partial<K8sExplorerFeatures>>;
    readonly refreshIntervalMs: i0.InputSignal<number>;
    readonly autoRefresh: i0.InputSignal<boolean>;
    readonly fanOutConcurrency: i0.InputSignal<number>;
    /**
     * Sizes the explorer from its top edge to the bottom of the window, and keeps it there as the
     * window or the page above it changes. Off by default: the host's own height applies.
     */
    readonly fitViewport: i0.InputSignal<boolean>;
    /**
     * Shows the scope's name beside the page title. Hosts that project their own scope picker with
     * `[k8sExplorerScope]` turn it off.
     */
    readonly showScopeName: i0.InputSignal<boolean>;
    /**
     * The host's scope picker offers other scopes, so a scope that can't be opened also suggests
     * picking another one.
     */
    readonly canSwitchScope: i0.InputSignal<boolean>;
    /** Emitted when the kind, namespace or open object changes, for URL sync. */
    readonly stateChange: i0.OutputEmitterRef<K8sExplorerState>;
    protected readonly navCollapsed: i0.WritableSignal<boolean>;
    protected readonly tooltipDelay = 500;
    /** Height set by `fitViewport`, or null to leave it to the host. */
    protected readonly fitHeight: i0.WritableSignal<number>;
    protected readonly scopeErrorView: i0.Signal<K8sErrorView>;
    /** A collapsed sidebar is too narrow for the page title, so the toolbar leads with it. */
    protected readonly titleInToolbar: i0.Signal<boolean>;
    /** The scope whose name the toolbar shows, or null when the host projects its own picker. */
    protected readonly shownScope: i0.Signal<K8sScopeInfo>;
    /** The session's AI workspace, kept current as the user switches workspace. */
    private readonly sessionWorkspaceId;
    /** Rebuilt, and the scope reloaded, when the mode, custom API, scope hint or workspace changes. */
    private readonly effectiveApi;
    private initialized;
    /** The scope last loaded, so a new one can start from a `state` that came with it. */
    private loadedScopeId;
    private lastEmitted;
    /** The `state` last acted on: read at start, applied, or held for later. Echoes of it are skipped. */
    private seenState;
    /** A `state` that arrived while the scope was loading, applied once it has. */
    private pendingState;
    constructor();
    protected retryScope(): void;
    /**
     * Keeps the explorer's height at "top edge to window bottom", measured at most once a frame;
     * returns the cleanup. The stylesheet's `min-height` is the floor, so a short window scrolls the
     * page rather than squashing the explorer.
     */
    private trackViewport;
    /**
     * Narrows the kinds offered. If the open kind is no longer among them, the first allowed one
     * opens: switched to (and loaded) once a scope is showing, preset before that.
     */
    private applyAllowedKinds;
    private applyState;
    private isAllowed;
    private isSelected;
    static ɵfac: i0.ɵɵFactoryDeclaration<K8sExplorerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<K8sExplorerComponent, "app-k8s-explorer", never, { "scopeId": { "alias": "scopeId"; "required": true; "isSignal": true; }; "workspaceId": { "alias": "workspaceId"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "api": { "alias": "api"; "required": false; "isSignal": true; }; "scopeHint": { "alias": "scopeHint"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "namespaces": { "alias": "namespaces"; "required": false; "isSignal": true; }; "lockNamespace": { "alias": "lockNamespace"; "required": false; "isSignal": true; }; "kinds": { "alias": "kinds"; "required": false; "isSignal": true; }; "readOnly": { "alias": "readOnly"; "required": false; "isSignal": true; }; "features": { "alias": "features"; "required": false; "isSignal": true; }; "refreshIntervalMs": { "alias": "refreshIntervalMs"; "required": false; "isSignal": true; }; "autoRefresh": { "alias": "autoRefresh"; "required": false; "isSignal": true; }; "fanOutConcurrency": { "alias": "fanOutConcurrency"; "required": false; "isSignal": true; }; "fitViewport": { "alias": "fitViewport"; "required": false; "isSignal": true; }; "showScopeName": { "alias": "showScopeName"; "required": false; "isSignal": true; }; "canSwitchScope": { "alias": "canSwitchScope"; "required": false; "isSignal": true; }; }, { "stateChange": "stateChange"; }, never, ["[k8sExplorerScope]"], true, never>;
}

/** A centred message for an empty or failed area: icon, heading, explanation, details and one action. */
declare class K8sStatePanelComponent {
    readonly icon: i0.InputSignal<string>;
    /** Not `title`, which would also set the host's native tooltip from a static attribute. */
    readonly heading: i0.InputSignal<string>;
    readonly message: i0.InputSignal<string>;
    readonly detail: i0.InputSignal<string>;
    readonly actionLabel: i0.InputSignal<string>;
    /** Feather icon before the action label; empty for none. */
    readonly actionIcon: i0.InputSignal<string>;
    readonly tone: i0.InputSignal<"danger" | "neutral">;
    readonly action: i0.OutputEmitterRef<void>;
    protected readonly isDanger: i0.Signal<boolean>;
    /** A failure interrupts (`alert`); anything else is announced politely (`status`). */
    protected readonly liveRole: i0.Signal<"status" | "alert">;
    static ɵfac: i0.ɵɵFactoryDeclaration<K8sStatePanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<K8sStatePanelComponent, "app-k8s-state-panel", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "detail": { "alias": "detail"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; "actionIcon": { "alias": "actionIcon"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, { "action": "action"; }, never, never, true, never>;
}

/**
 * The calls the user and admin explorer APIs share. Both expose the same `.../scopes/{id}/k8s/...`
 * endpoints under a different base, so each only says where its scope lives and how it reads one.
 */
declare abstract class ScopedK8sExplorerDataSource implements K8sExplorerApi {
    protected readonly http: HttpClient;
    constructor(http: HttpClient);
    abstract getScope(scopeId: string): Observable<K8sScopeInfo>;
    listResources(scopeId: string, resource: K8sResourceRef, namespace?: string | null): Observable<K8sList<K8sObject>>;
    getPodLogs(scopeId: string, namespace: string, pod: string, options?: K8sPodLogsOptions): Observable<K8sPodLogs>;
    getJitAccess(scopeId: string, namespace?: string): Observable<K8ClusterConfig>;
    /** The scope's `.../k8s` base URL, without a trailing slash. */
    protected abstract scopeUrl(scopeId: string): string;
}

/**
 * The explorer API for a workspace user, over the existing
 * `/v1/aiservicedesk/user/data/workspaces/{ws}/scopes/{scopeId}/k8s/...` endpoints.
 * `http` is the host's `REMOTE_DuploHttpClient`, which adds auth and the API base URL.
 * Built with `new` rather than injected: the workspace is an input of the explorer.
 */
declare class UserK8sExplorerDataSource extends ScopedK8sExplorerDataSource {
    readonly workspaceId: string;
    private readonly scopesUrl;
    constructor(http: HttpClient, workspaceId: string);
    getScope(scopeId: string): Observable<K8sScopeInfo>;
    restartWorkload(scopeId: string, namespace: string, kind: K8sRestartableKind, name: string): Observable<unknown>;
    deletePod(scopeId: string, namespace: string, pod: string): Observable<unknown>;
    protected scopeUrl(scopeId: string): string;
}

/**
 * The explorer API for an administrator, over `/v1/aiservicedesk/admin/data/scopes/{id}/k8s/...`.
 * Admin has no single-scope endpoint, so the scope's name and token type come from `scopeHint`
 * and its namespaces from the admin namespaces call. Admin has no restart or delete endpoints,
 * so those methods are left out and the explorer hides the actions.
 * Built with `new` rather than injected: the scope hint is an input of the explorer.
 */
declare class AdminK8sExplorerDataSource extends ScopedK8sExplorerDataSource {
    private readonly scopeHint?;
    constructor(http: HttpClient, scopeHint?: Partial<K8sScopeInfo> | null);
    getScope(scopeId: string): Observable<K8sScopeInfo>;
    protected scopeUrl(scopeId: string): string;
}

/** Every kind the explorer knows, in sidebar order. */
declare const K8S_KIND_LIST: readonly K8sKindDef[];
/** Kind definitions by id. */
declare const K8S_KIND_REGISTRY: ReadonlyMap<string, K8sKindDef>;
/**
 * Sidebar groups, in order. Each group lists the kinds whose `group` names it, in
 * {@link K8S_KIND_LIST} order, so a kind is placed by its own definition alone.
 */
declare const K8S_KIND_GROUPS: readonly K8sKindGroup[];
/** The kind the explorer opens on when nothing else is asked for. */
declare const DEFAULT_K8S_KIND = "pods";
declare function getK8sKind(id: string | null | undefined): K8sKindDef | undefined;
/**
 * Builds a table row: every display value is computed here, once per fetch. Each per-kind
 * function is guarded: one that throws leaves its cells empty and the row still shows.
 */
declare function toK8sRow(kind: K8sKindDef, raw: K8sObject, now?: number): K8sRow;
/** Merges enrichment cells into rows, keeping sort keys in step. Rows without new cells are returned as they are. */
declare function applyK8sEnrichment(rows: readonly K8sRow[], extra: Map<string, Record<string, K8sCellValue>>): K8sRow[];

/**
 * The card grid for AI Admin list pages. One auto-fill rule serves every
 * breakpoint, so pages carry no grid CSS of their own.
 */
declare class ListCardGridComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ListCardGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListCardGridComponent, "app-list-card-grid", never, {}, {}, never, ["*"], true, never>;
}

/**
 * One card in an AI Admin list. The frame is fixed; each page projects its own
 * metadata into the [card-badges] and [card-footer] slots.
 */
declare class ListCardComponent {
    private readonly router;
    private readonly route;
    mark: i0.InputSignal<ListCardMark>;
    title: i0.InputSignal<string>;
    description: i0.InputSignal<string>;
    emptyDescription: i0.InputSignal<string>;
    link: i0.InputSignal<string | any[]>;
    actions: i0.InputSignal<ListCardAction[]>;
    /** computed() caches and only recomputes when actions() changes — the modern answer to the old filtering setter. */
    visibleActions: i0.Signal<ListCardAction[]>;
    /**
     * The whole card is the click target. The title is also a real anchor, which
     * is what makes it keyboard-reachable — routerLink on a host is not.
     */
    onCardClick(event?: MouseEvent): void;
    runAction(action: ListCardAction, event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListCardComponent, "app-list-card", never, { "mark": { "alias": "mark"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "emptyDescription": { "alias": "emptyDescription"; "required": false; "isSignal": true; }; "link": { "alias": "link"; "required": false; "isSignal": true; }; "actions": { "alias": "actions"; "required": false; "isSignal": true; }; }, {}, never, ["[card-badges]", "[card-footer]"], true, never>;
}

/**
 * Record count and primary action for an AI Admin list page. Deliberately has no
 * heading: the shell header's current breadcrumb crumb is the page title.
 */
declare class ListPageHeaderComponent {
    /** Plural noun for the records, e.g. 'workspaces'. */
    noun: i0.InputSignal<string>;
    total: i0.InputSignal<number>;
    shown: i0.InputSignal<number>;
    filtering: i0.InputSignal<boolean>;
    clearAll: i0.OutputEmitterRef<void>;
    count: i0.Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListPageHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListPageHeaderComponent, "app-list-page-header", never, { "noun": { "alias": "noun"; "required": false; "isSignal": true; }; "total": { "alias": "total"; "required": false; "isSignal": true; }; "shown": { "alias": "shown"; "required": false; "isSignal": true; }; "filtering": { "alias": "filtering"; "required": false; "isSignal": true; }; }, { "clearAll": "clearAll"; }, never, ["[header-actions]"], true, never>;
}

declare const duploDarkCodeMirror: Extension;
declare const duploDarkHighlightStyle: HighlightStyle;
/** basicLight in light (unchanged), the token-driven dark theme and syntax colours in dark. */
declare function codeMirrorTheme(mode: ThemeMode): Extension;
/** Theme for editors without their own Compartment: views re-theme live when ThemeService.mode() changes. */
declare class CodeMirrorThemeService {
    private readonly mode;
    private readonly compartment;
    private readonly views;
    private readonly tracker;
    constructor();
    /** Add to a new editor state's extensions. */
    extension(): Extension;
    static ɵfac: i0.ɵɵFactoryDeclaration<CodeMirrorThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CodeMirrorThemeService>;
}

type EditMode = 'edit' | 'preview';
declare class MarkdownEditModalComponent implements AfterViewInit, OnDestroy {
    activeModal: NgbActiveModal;
    private cmTheme;
    editorContainer: ElementRef;
    title: string;
    content: string;
    isEditable: boolean;
    fullScreen: boolean;
    saved: EventEmitter<string>;
    activeMode: EditMode;
    previewContent: string;
    private view;
    constructor(activeModal: NgbActiveModal, cmTheme: CodeMirrorThemeService);
    ngAfterViewInit(): void;
    setMode(mode: EditMode): void;
    save(): void;
    close(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarkdownEditModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MarkdownEditModalComponent, "app-markdown-edit-modal", never, { "title": { "alias": "title"; "required": false; }; "content": { "alias": "content"; "required": false; }; "isEditable": { "alias": "isEditable"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; }, { "saved": "saved"; }, never, never, true, never>;
}

interface MarkdownEditModalOptions {
    title?: string;
    content?: string;
    isEditable?: boolean;
    fullScreen?: boolean;
    size?: 'sm' | 'lg' | 'xl';
}
declare class MarkdownEditModalService {
    private modalService;
    constructor(modalService: NgbModal);
    open(options: MarkdownEditModalOptions): NgbModalRef;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarkdownEditModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MarkdownEditModalService>;
}

type MarkdownEditorMode = 'edit' | 'preview';
/**
 * Inline markdown editor with an Edit/Preview toggle — the embeddable counterpart of
 * MarkdownEditModalComponent, sharing its CodeMirror setup and preview rendering.
 *
 * Implements ControlValueAccessor, so it drops into template-driven forms like any input:
 *   <markdown-editor name="notes" [(ngModel)]="notes" required minlength="10"
 *                    validation-state validation-errors></markdown-editor>
 *
 * With [readOnly] it doubles as a viewer for markdown a page already holds:
 *   <markdown-editor [ngModel]="persona.promptMd" [readOnly]="true"></markdown-editor>
 * Consumers need MarkdownModule.forRoot() provided at their root (both apps already do).
 */
declare class MarkdownEditorComponent implements OnInit, AfterViewInit, OnDestroy, ControlValueAccessor {
    private editorContainer;
    /**
     * Height of the editing/preview area (any CSS length). Defaults to filling the host, which
     * in an auto-height container means sizing to the document — pass a length to cap it.
     */
    height: string;
    /** Caps the editing/preview area; longer content scrolls inside it. */
    maxHeight?: string;
    /**
     * Display-only: the document cannot be typed into, the toggle reads Code rather than Edit,
     * and the component opens on the rendered view instead of the source.
     */
    readOnly: boolean;
    /** Mode toggle labels. The source tab shows `codeLabel` when read-only, `editLabel` otherwise. */
    editLabel: string;
    codeLabel: string;
    previewLabel: string;
    activeMode: MarkdownEditorMode;
    previewContent: string;
    private view?;
    private pendingValue;
    private disabled;
    private readonly editableCompartment;
    private readonly cmTheme;
    private onChange;
    /**
     * Set only while writeValue() is pushing a programmatic value into the editor. CodeMirror reports
     * that dispatch as a normal document change, and Angular's ControlValueAccessor contract forbids
     * writeValue from invoking the registered onChange — doing so marks the NgModel dirty on a form
     * reset / resolver patch / tenant switch, firing unsaved-changes guards and submitted-state errors.
     */
    private writingValue;
    private onTouched;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    setMode(mode: MarkdownEditorMode): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarkdownEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MarkdownEditorComponent, "markdown-editor", never, { "height": { "alias": "height"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "editLabel": { "alias": "editLabel"; "required": false; }; "codeLabel": { "alias": "codeLabel"; "required": false; }; "previewLabel": { "alias": "previewLabel"; "required": false; }; }, {}, never, never, true, never>;
}

declare class RenderFilePreviewModalComponent {
    activeModal: NgbActiveModal;
    private clipboard;
    private success;
    content: string | Blob;
    fileName: string;
    title: string;
    copyLink: string;
    canDownload: boolean;
    constructor(activeModal: NgbActiveModal, clipboard: ClipboardService, success: SuccessReporter);
    copyLinkToClipboard(): void;
    downloadFile(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RenderFilePreviewModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RenderFilePreviewModalComponent, "app-render-file-preview-modal", never, { "content": { "alias": "content"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "title": { "alias": "title"; "required": false; }; "copyLink": { "alias": "copyLink"; "required": false; }; "canDownload": { "alias": "canDownload"; "required": false; }; }, {}, never, never, true, never>;
}

declare enum SupportedFileType {
    Markdown = "markdown",
    Html = "html",
    Code = "code",
    Image = "image",
    Pdf = "pdf",
    Docx = "docx",
    Pptx = "pptx",
    Unsupported = "unsupported"
}
/** All file extensions that can be rendered as code in Monaco */
declare const SUPPORTED_FILE_EXTENSIONS: string[];
declare function getFileType(fileName: string): SupportedFileType;
declare function getMonacoLanguage(fileName: string): string;
declare function isPreviewSupported(fileName: string): boolean;

declare class RenderFileComponent implements OnChanges, OnDestroy {
    private sanitizer;
    private zone;
    content: string | Blob;
    fileName: string;
    readonly SupportedFileType: typeof SupportedFileType;
    readonly SecurityContext: typeof SecurityContext$1;
    readonly MAX_PREVIEW_BYTES: number;
    readonly MAX_OFFICE_BYTES: number;
    private static readonly LEGACY_OFFICE_EXTS;
    fileType: SupportedFileType;
    textContent: string;
    safeHtmlContent: SafeHtml;
    imageUrl: string;
    pdfUrl: SafeResourceUrl;
    officeBlob: Blob | null;
    monacoLanguage: string;
    isLoading: boolean;
    isTooLarge: boolean;
    unsupportedTitle: string;
    editorOptions: any;
    private objectUrl;
    constructor(sanitizer: DomSanitizer, zone: NgZone);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private reset;
    private prepare;
    private prepareFromString;
    private prepareFromBlob;
    private revokeObjectUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<RenderFileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RenderFileComponent, "app-render-file", never, { "content": { "alias": "content"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ServersideDatatableExtraAction {
    name: string;
    label: string;
    icon?: string;
    class?: string;
    isMenu?: boolean;
    helpKey?: string;
    restrictAccessForReadonlyUser?: boolean;
    /** Listed in the selection actions dropdown, which shows while rows are selected. */
    isSelectionAction?: boolean;
    constructor(attrs?: Partial<ServersideDatatableExtraAction>);
}
declare class ServersideDatatableStatus {
    itemsPerPage: number;
    page: number;
    totalPages: number;
    totalItems: number;
    constructor(attrs?: Partial<ServersideDatatableStatus>);
}
declare class SearchAndPaginationParams {
    q?: string;
    sf?: string;
    sd?: string;
    max?: number;
    page?: number;
    constructor(properties?: Partial<SearchAndPaginationParams>);
    toUriPart(): string;
}

type RowKey = string | number;
declare class ServersideDatatableComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
    private _changeDetector;
    private elRef;
    private i18n;
    private destroy$;
    /** Minimum time between server updates, in milliseconds. */
    minUpdateFrequency: number;
    /** Quiet period (ms) to wait after the last search keystroke before querying. */
    searchDebounce: number;
    /** Minimum search-term length before a server query fires; 0 (default) disables the gate. Clearing the box always re-queries regardless of this. */
    minSearchLength: number;
    /** Whether or not to show the add button. */
    showAdd: boolean;
    /** Whether or not to filter input. */
    showFilter: boolean;
    showEdit: boolean;
    extraActions: ServersideDatatableExtraAction[];
    loadingIndicator: boolean;
    /** Whether or not to reset the view (pagination, etc.) when the rows change */
    resetOnChange: boolean;
    _rows: any[];
    page: SearchAndPaginationParams;
    itemsPerPageOptions: number[];
    status: ServersideDatatableStatus;
    columnMode: "force";
    includeHeader: boolean;
    /** Pins the toolbar under the app header while the page scrolls. */
    isActionsFixed: boolean;
    searchTerm: string;
    set rows(rows: any[]);
    /** Checkbox selection kept across pages; search, sort and reset() clear it. */
    enableCheckboxSelection: i0.InputSignal<boolean>;
    /** Required with checkbox selection: every fetch returns new row objects, so rows are matched by key. */
    getRowId: (row: any) => RowKey;
    /** Hides a row's checkbox and leaves the row out of select-all. */
    displayCheck: (row: any) => boolean;
    /** Names a row in its checkbox's accessible label ("Select <label>"); without it every checkbox reads "Select row". */
    getRowLabel: (row: any) => string;
    selectionActionsLabel: string;
    selectionChange: EventEmitter<any[]>;
    private selection;
    private pageRows;
    private pageNotice;
    selectedRows: i0.Signal<any[]>;
    selectedCount: i0.Signal<number>;
    selectablePageRows: i0.Signal<any[]>;
    private pageSelectedCount;
    private offPageCount;
    pageSelectState: i0.Signal<"some" | "none" | "all">;
    selectionMessage: i0.Signal<string>;
    selectionActions: ServersideDatatableExtraAction[];
    selectHeaderTpl: TemplateRef<HeaderCellContext>;
    selectCellTpl: TemplateRef<CellContext>;
    columnTemplates: i0.Signal<readonly DataTableColumnDirective<any>[]>;
    tableColumns: i0.Signal<TableColumn<any>[]>;
    rowDetailTpl?: DatatableRowDetailDirective;
    ownRowDetail?: DatatableRowDetailDirective;
    private rowDetailBridge?;
    table: DatatableComponent;
    add: EventEmitter<void>;
    action: EventEmitter<string>;
    edit: EventEmitter<void>;
    update: EventEmitter<SearchAndPaginationParams>;
    serverUpdater: Subject<SearchAndPaginationParams>;
    searchUpdater: Subject<void>;
    skipResetOnce: boolean;
    constructor(_changeDetector: ChangeDetectorRef, elRef: ElementRef, i18n: TranslateService, destroy$: SubDestroyService);
    addItem(): void;
    editItem(): void;
    getButtons(): ServersideDatatableExtraAction[];
    getMenus(): ServersideDatatableExtraAction[];
    hasMenus(): boolean;
    /** Resets the view (pagination, sort, etc.) */
    reset(): void;
    extraActionClick(action: string): void;
    onItemsPerPageChange(limit: any): void;
    onSearchChange(text: string | undefined): void;
    onSortChange(sorts: SortPropDir[]): void;
    onPageChange(nr: any): void;
    /** Refreshes the list by reapplying filters. */
    refresh(skipReset?: boolean): void;
    serverRefresh(): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    get shouldSkipReset(): boolean;
    startLoading(): void;
    stopLoading(): void;
    isRowSelected(row: any): boolean;
    toggleRow(row: any): void;
    /** Selects or unselects the current page only; selections on other pages are kept. */
    togglePage(): void;
    unSelectAll(): void;
    unSelectRow(row: any): void;
    private setSelection;
    private refreshSelectedRows;
    private selectionColumn;
    private countLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServersideDatatableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ServersideDatatableComponent, "serverside-datatable", never, { "minUpdateFrequency": { "alias": "minUpdateFrequency"; "required": false; }; "searchDebounce": { "alias": "searchDebounce"; "required": false; }; "minSearchLength": { "alias": "minSearchLength"; "required": false; }; "showAdd": { "alias": "showAdd"; "required": false; }; "showFilter": { "alias": "showFilter"; "required": false; }; "showEdit": { "alias": "showEdit"; "required": false; }; "extraActions": { "alias": "extraActions"; "required": false; }; "resetOnChange": { "alias": "resetOnChange"; "required": false; }; "_rows": { "alias": "_rows"; "required": false; }; "page": { "alias": "page"; "required": false; }; "itemsPerPageOptions": { "alias": "itemsPerPageOptions"; "required": false; }; "columnMode": { "alias": "columnMode"; "required": false; }; "includeHeader": { "alias": "includeHeader"; "required": false; }; "isActionsFixed": { "alias": "isActionsFixed"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "enableCheckboxSelection": { "alias": "enableCheckboxSelection"; "required": false; "isSignal": true; }; "getRowId": { "alias": "getRowId"; "required": false; }; "displayCheck": { "alias": "displayCheck"; "required": false; }; "getRowLabel": { "alias": "getRowLabel"; "required": false; }; "selectionActionsLabel": { "alias": "selectionActionsLabel"; "required": false; }; }, { "selectionChange": "selectionChange"; "add": "add"; "action": "action"; "edit": "edit"; "update": "update"; }, ["columnTemplates", "rowDetailTpl"], ["[datatable-filters]", "*"], false, never>;
}

declare class ServersideDatatableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ServersideDatatableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ServersideDatatableModule, [typeof ServersideDatatableComponent], [typeof CoreCommonModule, typeof i3$2.NgbModule, typeof i4.NgxDatatableModule, typeof i5.NgSelectModule, typeof HelpModule, typeof RestrictElementAccessModule, typeof DatatablePageSummaryPipe], [typeof CoreCommonModule, typeof i3$2.NgbModule, typeof i4.NgxDatatableModule, typeof ServersideDatatableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ServersideDatatableModule>;
}

declare class SpinnerComponent {
    size: number;
    spinnerClass?: string;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SpinnerComponent, "app-spinner", never, { "size": { "alias": "size"; "required": false; }; "spinnerClass": { "alias": "spinnerClass"; "required": false; }; }, {}, never, never, true, never>;
}

declare class StatusWithStyleComponent {
    status?: string;
    statusBadgeStyles: Map<string, string> | ReadonlyMap<string, string>;
    statusStyle: string;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatusWithStyleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatusWithStyleComponent, "status-with-style", never, { "status": { "alias": "status"; "required": false; }; "statusBadgeStyles": { "alias": "statusBadgeStyles"; "required": false; }; }, {}, never, never, true, never>;
}

interface TokenPaginatedPage<T = any> {
    rows: T[];
    nextToken?: string;
}
interface LoadPageEvent {
    pageIndex: number;
    token?: string;
    pageSize?: number;
}

declare class TokenPaginatedDatatableComponent implements AfterViewInit, OnDestroy {
    private _changeDetector;
    showForceRefresh: boolean;
    columnMode: "force";
    includeHeader: boolean;
    isActionsFixed: boolean;
    footerHeight: number | boolean;
    pageSizeOptions: number[];
    loadingIndicator: boolean;
    columnTemplates: i0.Signal<readonly DataTableColumnDirective<any>[]>;
    tableColumns: i0.Signal<i4.TableColumn<any>[]>;
    rowDetailTpl?: DatatableRowDetailDirective;
    ownRowDetail?: DatatableRowDetailDirective;
    private rowDetailBridge?;
    table: DatatableComponent;
    loadPage: EventEmitter<LoadPageEvent>;
    forceRefresh: EventEmitter<void>;
    pageSizeChange: EventEmitter<number>;
    private pageCache;
    currentPageIndex: number;
    currentRows: any[];
    private currentNextToken;
    pageSize: number;
    constructor(_changeDetector: ChangeDetectorRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    setPageData(pageIndex: number, rows: any[], nextToken?: string): void;
    clearCache(): void;
    get hasPreviousPage(): boolean;
    get hasNextPage(): boolean;
    goToPreviousPage(): void;
    goToNextPage(): void;
    emitRefresh(): void;
    onPageSizeChange(value: number): void;
    startLoading(): void;
    stopLoading(): void;
    get displayPageNumber(): number;
    getTokenForPage(pageIndex: number): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<TokenPaginatedDatatableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TokenPaginatedDatatableComponent, "token-paginated-datatable", never, { "showForceRefresh": { "alias": "showForceRefresh"; "required": false; }; "columnMode": { "alias": "columnMode"; "required": false; }; "includeHeader": { "alias": "includeHeader"; "required": false; }; "isActionsFixed": { "alias": "isActionsFixed"; "required": false; }; "footerHeight": { "alias": "footerHeight"; "required": false; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; }; }, { "loadPage": "loadPage"; "forceRefresh": "forceRefresh"; "pageSizeChange": "pageSizeChange"; }, ["columnTemplates", "rowDetailTpl"], ["*"], false, never>;
}

declare class TokenPaginatedDatatableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TokenPaginatedDatatableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TokenPaginatedDatatableModule, [typeof TokenPaginatedDatatableComponent], [typeof CoreCommonModule, typeof i3$2.NgbModule, typeof i4.NgxDatatableModule, typeof i5.NgSelectModule], [typeof CoreCommonModule, typeof i3$2.NgbModule, typeof i4.NgxDatatableModule, typeof TokenPaginatedDatatableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TokenPaginatedDatatableModule>;
}

type DataViewFormat = 'json' | 'yaml';
declare class ViewDataModalComponent {
    activeModal: NgbActiveModal;
    private clipboardService;
    headerText: string;
    showDownload: boolean;
    downloadFileName: string;
    fullScreen: boolean;
    private _dataObject;
    activeFormat: DataViewFormat;
    formattedContent: string;
    copySuccess: boolean;
    downloadSuccess: boolean;
    jsonEditorOptionsReadOnly: any;
    yamlEditorOptionsReadOnly: any;
    constructor(activeModal: NgbActiveModal, clipboardService: ClipboardService);
    set dataObject(value: any);
    get dataObject(): any;
    get editorOptions(): any;
    setFormat(format: DataViewFormat): void;
    private updateFormattedContent;
    getHeaderAsText(): string;
    downloadData(event?: Event): void;
    private showDownloadSuccess;
    copyToClipboard(event?: Event): void;
    private showCopySuccess;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewDataModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewDataModalComponent, "app-view-data-modal", never, { "headerText": { "alias": "headerText"; "required": false; }; "showDownload": { "alias": "showDownload"; "required": false; }; "downloadFileName": { "alias": "downloadFileName"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "dataObject": { "alias": "dataObject"; "required": false; }; }, {}, never, never, true, never>;
}

interface ViewDataModalOptions {
    headerText: string;
    dataObject: any;
    downloadFileName?: string;
    showDownload?: boolean;
    fullScreen?: boolean;
    size?: 'sm' | 'lg' | 'xl';
    defaultFormat?: DataViewFormat;
}
declare class ViewDataModalRef {
    modal: NgbModalRef;
    component: ViewDataModalComponent;
}
declare class ViewDataModalService {
    private modalService;
    constructor(modalService: NgbModal);
    open(options: ViewDataModalOptions): ViewDataModalRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewDataModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ViewDataModalService>;
}

/** Options for a ViewJson modal. */
interface ViewJsonModalOptions<T> {
    downloadFileName?: string;
    showDownload?: boolean;
    headerText: string;
    messageText?: string;
    messageObject: object;
    size?: "xs:" | "sm" | "lg" | "xl";
    enableEdit?: boolean;
    isEditMode?: boolean;
    fullScreen?: boolean;
}
/** A reference to a ViewJson modal. */
declare class ViewJsonModalRef<T> {
    modal: NgbModalRef;
    component: ViewJsonModalComponent;
}
declare class ViewJsonModalService {
    private _modals;
    constructor(_modals: NgbModal);
    open<T>(options: ViewJsonModalOptions<T>): ViewJsonModalRef<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewJsonModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ViewJsonModalService>;
}

declare class XtermBlockComponent implements OnInit, OnDestroy {
    private styleLoader;
    private themeService;
    cmdText: string;
    cmdTextChange: EventEmitter<string>;
    cmdOutput: string;
    rows: number;
    isEditable: boolean;
    canResize: boolean;
    terminalOptions: ITerminalOptions;
    containerClass: string;
    scrollBottom: boolean;
    terminalContainer: ElementRef;
    private terminal;
    private fitAddon;
    private commandBuffer;
    private resizeObserver;
    private resizeHandler;
    constructor(styleLoader: DynamicStyleLoaderService, themeService: ThemeService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    writeOutput(output: string, autoScroll?: boolean, appendCmdText?: boolean): void;
    ngOnDestroy(): void;
    private getTerminalOptions;
    /** Re-grounds a live terminal when the app theme changes. */
    private applyTheme;
    /** Fits the terminal to its container size */
    private fitTerminal;
    /** Writes the shell prompt */
    writePrompt(): void;
    handleInput(data: string): void;
    private formatTerminalOutput;
    writeCommandOutput(output: string): void;
    scrollToBottom(): void;
    scrollToLine(line: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<XtermBlockComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<XtermBlockComponent, "app-xterm-block", never, { "cmdText": { "alias": "cmdText"; "required": false; }; "cmdOutput": { "alias": "cmdOutput"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "isEditable": { "alias": "isEditable"; "required": false; }; "canResize": { "alias": "canResize"; "required": false; }; "terminalOptions": { "alias": "terminalOptions"; "required": false; }; "containerClass": { "alias": "containerClass"; "required": false; }; "scrollBottom": { "alias": "scrollBottom"; "required": false; }; }, { "cmdTextChange": "cmdTextChange"; }, never, never, true, never>;
}

declare const XTERM_CLEAR_COMMAND = "echo '-----------------------' ; clear";
declare const XTERM_TERMINAL_CONFIG: {
    minCols: number;
    minRows: number;
    widthReduction: number;
    charWidth: number;
    charHeight: number;
};
declare class XtermCommand {
    cmdText: string;
    cmdId: string;
    output: string;
    constructor(properties?: Partial<XtermCommand>);
}

declare class XtermSocketService {
    private api;
    private _xtermUrl;
    constructor(api: HttpClient);
    getXtermUrl(): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<XtermSocketService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<XtermSocketService>;
}

declare class XtermSocketComponent implements OnInit, OnDestroy {
    private destroy$;
    private cdr;
    private xtermSocketService;
    session: any;
    private error;
    private styleLoader;
    private themeService;
    rows: number;
    queryParams: Record<string, string>;
    serverUrl: string;
    canResize: boolean;
    terminalOptions: ITerminalOptions;
    containerClass: string;
    /** Fewest rows the terminal fits to. Lower it for a terminal docked in a short panel. */
    minRows: number;
    /** Fills the parent's height instead of keeping the 400px minimum, for dock-style layouts. */
    fill: boolean;
    terminalReady: EventEmitter<boolean>;
    commandComplete: EventEmitter<XtermCommand>;
    terminalContainer: ElementRef;
    blockUI: NgBlockUI;
    connected: boolean;
    canSendOutput: boolean;
    private terminal;
    private socket;
    private resizeObserver;
    private resizeHandler;
    private cmdQ;
    /** Settles once xterm's stylesheet is in, loaded or failed. */
    private stylesReady;
    private destroyed;
    /** Output that arrives before the terminal is open, written once it is. */
    private earlyOutput;
    /** Set to `sh` after a pod shell found no bash, and sent as the server's `shell` param. */
    private shellFallback;
    private podOutputHead;
    /** Set once the pod is known to have no shell at all, so later output is written as it comes. */
    private noShellReported;
    /**
     * False until the server has a shell to type into. It only listens for input once the shell is up (`k8s-ready`
     * for a pod, `shell-ready` after env-config), so queued commands wait; sent earlier they were dropped and the
     * queue stalled on them.
     */
    private shellReady;
    /** Input waiting for the shell, in order: queued commands (with Enter) and typed text (without). */
    private heldCommands;
    private shellReadyTimer;
    /** Set once the user types or pastes: the session is live, so its output is no longer checked for a missing shell. */
    private userTyped;
    /** A forced size send skipped while the terminal measured 0 (hidden); sent once it can be measured. */
    private resizePending;
    /**
     * A pod shell's kubeconfig waiting for the terminal to open. The server starts the shell when k8s-config arrives,
     * at the size it has then, so it goes after the first size (DUPLO-45017).
     */
    private pendingKubeconfig;
    constructor(destroy$: SubDestroyService, cdr: ChangeDetectorRef, xtermSocketService: XtermSocketService, session: any, error: ErrorReporter, styleLoader: DynamicStyleLoaderService, themeService: ThemeService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private getTerminalUrl;
    private initSocketConnection;
    /**
     * socket.io fires `connect_error` on every failed attempt, including its own automatic retries while
     * the socket is still `active`. Only a final failure (the server refused it, so no retry follows) is
     * reported to the host; a retry is just noted in the terminal, as before.
     */
    private onConnectError;
    /**
     * Sends a pod shell's kubeconfig once the terminal is open, so its first size has gone ahead of it. Sent again on
     * every `k8s-config-required`, as before: a copy that reaches the server before it listens is dropped, and it
     * takes only the first one after.
     */
    private sendK8sConfig;
    private flushK8sConfig;
    /** Writes to the terminal, or holds the text until it opens (it opens once its stylesheet loads). */
    private writeOrHold;
    private initTerminal;
    /** Queued commands go once the server has a shell; until then they're held, in order. */
    private runWhenShellReady;
    /**
     * Types text without Enter once the server has a shell to take it, so nothing runs until the user
     * confirms. Held in order with queued commands while the shell is starting or the socket reconnects;
     * a new session (a reconnect with another shell) drops what was held.
     */
    typeWhenShellReady(text: string): void;
    private markShellReady;
    private sendHeld;
    private clearShellReadyTimer;
    /**
     * Watches a pod shell's first output for a missing shell, when no shell was asked for. No bash
     * (alpine and slim images) reopens it with sh; no sh either (distroless images) says plainly that
     * the container has no shell, instead of the OCI error. Returns true when it handled the output.
     */
    private reopenWithoutBash;
    /** Fits the terminal to its container size */
    private fitTerminal;
    checkIfXtermOpen(): void;
    private disconnect;
    runCommand(command: string): void;
    /** Sends a paste in parts the server accepts, in order (DUPLO-45020). */
    private sendPaste;
    runStringCommand(cmdStr: string): void;
    addToRunningQueue(cmdQueue: string[]): void;
    clear(): void;
    loadCommandHistory(history: XtermCommand[]): void;
    private updateTerminalDimensions;
    private getTerminalOptions;
    /** Re-grounds a live terminal when the app theme changes. */
    private applyTheme;
    static ɵfac: i0.ɵɵFactoryDeclaration<XtermSocketComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<XtermSocketComponent, "app-xterm-socket", never, { "rows": { "alias": "rows"; "required": false; }; "queryParams": { "alias": "queryParams"; "required": false; }; "serverUrl": { "alias": "serverUrl"; "required": false; }; "canResize": { "alias": "canResize"; "required": false; }; "terminalOptions": { "alias": "terminalOptions"; "required": false; }; "containerClass": { "alias": "containerClass"; "required": false; }; "minRows": { "alias": "minRows"; "required": false; }; "fill": { "alias": "fill"; "required": false; }; }, { "terminalReady": "terminalReady"; "commandComplete": "commandComplete"; }, never, never, true, never>;
}

interface YamlSnippet {
    label: string;
    /** Content to insert. When `parent` is set, this is the value under the parent key (no wrapper). */
    yaml: string;
    group?: string;
    /**
     * Top-level YAML key to merge under. When set, the snippet yaml is treated as the value:
     *   - array value → appended to any existing array under `parent`
     *   - object/scalar value → replaces the existing value under `parent`
     * When absent, all top-level keys in the snippet are merged into the document (always replacing).
     */
    parent?: string;
}
interface SnippetGroup {
    group: string | null;
    items: YamlSnippet[];
}
declare class YamlSnippetEditorComponent implements ControlValueAccessor, OnDestroy {
    snippets: YamlSnippet[];
    placeholder: string;
    minHeight: string;
    private monacoComp?;
    value: string;
    disabled: boolean;
    flashingLabel: string | null;
    readonly editorOptions: {
        language: string;
        minimap: {
            enabled: boolean;
        };
        scrollBeyondLastLine: boolean;
        wordWrap: "on";
        fontSize: number;
        lineNumbers: "on";
        folding: boolean;
        glyphMargin: boolean;
        lineDecorationsWidth: number;
        lineNumbersMinChars: number;
        automaticLayout: boolean;
    } & {
        theme: _duplocloud_internal_ng_common_lib.MonacoThemeName;
    };
    private _flashTimer?;
    private onChange;
    private onTouched;
    private get rawEditor();
    get groupedSnippets(): SnippetGroup[];
    onEditorChange(v: string): void;
    insertSnippet(snippet: YamlSnippet, event: MouseEvent): void;
    /**
     * Merge snippet keys into the current YAML document (always replacing — handles
     * multi-key snippets like command+args and flat annotation dicts).
     * Falls back to concat when either side isn't a plain object.
     */
    private smartMerge;
    /**
     * Merge a snippet value under a specific parent key.
     *   - snippet value is array  → append items to existing array (or create one)
     *   - snippet value is object → replace existing value
     */
    private mergeIntoParent;
    private isPlainObject;
    private concatYaml;
    writeValue(v: string): void;
    registerOnChange(fn: (v: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<YamlSnippetEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<YamlSnippetEditorComponent, "app-yaml-snippet-editor", never, { "snippets": { "alias": "snippets"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Mirrors the server-side `SettingValueType` enum (string-serialised).
 * Case-sensitive — send exactly as shown.
 */
declare enum AISettingValueType {
    String = "String",
    Number = "Number",
    Bool = "Bool",
    Json = "Json"
}
/**
 * Friendly, user-facing label for each type. Single source of truth — the Add form's
 * type dropdown, the list badge text (`displayType`), and the badge-style map all derive from this.
 */
declare const AI_SETTING_TYPE_LABELS: Map<AISettingValueType, string>;
/**
 * Badge-style map keyed by the friendly label (`displayType`) — used by the list table.
 * Defined at module level (not inside a class) per project conventions.
 */
declare const aiSettingTypeStyleMap: Map<string, string>;
/**
 * Badge-style map for Bool-typed values (keyed lowercase — `displayValue` for a Bool setting is
 * `String(value)`, i.e. `'true'` / `'false'`). Defined at module level per project conventions.
 */
declare const aiSettingBoolValueStyleMap: Map<string, string>;
/**
 * Parse a raw form value into the typed value the API expects. Throws on invalid input
 * (non-numeric Number, YAML that doesn't parse to a structured value) so callers fail loud
 * instead of silently sending a type-mismatched value. Bool is handled by the toggle, not this
 * function. Json values are authored as YAML (a superset of JSON) and must be a list or a map.
 */
declare function parseSettingValue(raw: string | number, type: AISettingValueType): unknown;
/**
 * Represents a system-wide key-value setting as returned by every read endpoint.
 * Domain identity is `name` (immutable), but admin CRUD writes (create/update/delete) address
 * records by `id`.
 */
declare class AISystemSetting {
    id?: string;
    name: string;
    type: AISettingValueType;
    value: any;
    labels: string[];
    description?: string;
    createdAt?: string;
    updatedAt?: string;
    isActive?: boolean;
    version?: number;
    /** Display-safe string for the value cell — derived once in the constructor. */
    displayValue: string;
    /** Display-safe string for type badge — derived once in the constructor. */
    displayType: string;
    /**
     * Friendly name shown in the list. Set by the list component from the AI Suite catalog
     * (display-label when the name matches a predefined setting, else the raw name). Kept a plain
     * field — not derived in the constructor — so the model does not import the catalog (which
     * imports AISettingValueType from here; a constructor lookup would create a circular import).
     */
    displayName?: string;
    /**
     * Display-safe "Last Modified" string. Set by the list component in refreshAll (formatted via
     * DateUtils) so the column is both rendered and searchable without a template date pipe.
     */
    displayUpdatedAt?: string;
    constructor(props?: Partial<AISystemSetting>);
    private _toDisplayType;
    private _toDisplayValue;
}
/**
 * Request body for Create (POST) and Update (PUT).
 * `name` is ignored by the server on Update — the URL segment is authoritative.
 */
declare class AISystemSettingRequest {
    name: string;
    type: AISettingValueType;
    value: any;
    labels?: string[];
    description?: string;
    constructor(props?: Partial<AISystemSettingRequest>);
}

/**
 * Canonical AI Suite ai-system-setting names — never use a magic string.
 * Keep this file import-free: the './Menu' federation chunk takes a name from here, and the
 * catalog in `aisuite-settings.ts` would drag `yaml` into that chunk.
 */
declare const AISUITE_SETTING: {
    readonly COLLAPSE_ADVANCED_OPTIONS: "add-hd-ticket-collapse-advanced";
    readonly LANGFUSE_URL: "langfuse-url";
    readonly MENU_HIDDEN_ITEMS: "ai-menu-hidden-items";
    readonly K8S_ALLOW_STATIC_TOKEN_JIT_ACCESS: "k8s-allow-static-token-jit-access";
    readonly NAV_HEADER_HIDDEN_ITEMS: "ai-nav-header-hidden-items";
    readonly HIDE_SINGLE_WORKSPACE_SELECTOR: "ai-hide-single-workspace-selector";
    readonly DISABLE_PRODUCT_ANALYTICS: "ai-disable-product-analytics";
    readonly ENABLE_HELPDESK_PYLON: "ai-enable-helpdesk-pylon";
    readonly WORKSPACE_MEMORY_DEFAULT: "ai-workspace-memory-default";
    readonly NETWORK_EGRESS_ENABLED: "networkEgress.enabled";
    readonly NETWORK_EGRESS_ALLOWED_DOMAINS: "networkEgress.allowedDomains";
    readonly NETWORK_EGRESS_DENIED_DOMAINS: "networkEgress.deniedDomains";
    readonly NETWORK_EGRESS_ALLOW_DEFAULTS: "networkEgress.allowDefaults";
    readonly NETWORK_EGRESS_DERIVE_HOSTS: "networkEgress.deriveHosts";
};
/**
 * Ids accepted by `ai-nav-header-hidden-items` — the right-hand navbar icons. The `-non-admin`
 * suffix is load-bearing: that flag hides the icon from User-role users only, never from admins.
 */
declare const NAV_HEADER_ITEM: {
    readonly FAULTS_NOTIFICATION_NON_ADMIN: "faults-notification-non-admin";
    readonly TRUST_CENTER: "trust-center";
    readonly HELP: "help";
};
/**
 * AI Suite sidebar ids `ai-menu-hidden-items` can hide, in sidebar order. Excludes Settings'
 * `dummy` children, which never render. remote-menu.spec.ts keeps this in step with the menu.
 */
declare const AI_MENU_WORKSPACE_ITEM_IDS: readonly string[];
/**
 * Administration sidebar ids `ai-menu-hidden-items` can hide, in sidebar order. Only the System
 * Setting reaches this sidebar. `ai-suite-admin` is its root, so hiding it hides the whole sidebar.
 * remote-menu.spec.ts keeps this in step with the menu.
 */
declare const AI_MENU_ADMIN_ITEM_IDS: readonly string[];
/** Canonical setting labels — the API reads settings by label (`getByLabel`). */
declare const AISUITE_SETTING_LABEL: {
    readonly SSO_PROXY: "sso-proxy";
    readonly NETWORK_EGRESS: "network-egress";
};
/** Labels always offered as suggestions in the Add/Edit setting forms. */
declare const AISUITE_SETTING_LABELS: string[];
type AiSuiteSettingName = typeof AISUITE_SETTING[keyof typeof AISUITE_SETTING];

/** A selectable option for a predefined setting. `value` must match the owning setting's type. */
interface AiSuiteSettingOption {
    label: string;
    value: string | number | boolean;
}
/**
 * A predefined system setting — a template that fixes the name/type and, optionally, a set of
 * selectable options. When `options` is present the value renders as a single-select dropdown;
 * otherwise it renders as the type's normal input.
 *
 * The help fields are optional plain text (no markdown): `description` is also prefilled into the
 * saved Description field, so any markup would show up raw in the settings list. The form hides
 * whatever is left out — no `description` and no `whenUnset` hides the About box entirely.
 */
interface AiSuiteSetting {
    /** Setting identity (immutable). Use an `AISUITE_SETTING.*` value. */
    name: string;
    /** Data type. Json entries never carry options (they use the YAML editor). */
    type: AISettingValueType;
    /** UI display name — distinct from the stored setting's grouping labels. */
    displayName: string;
    /** What the setting does. Shown in the form's About box and prefilled into Description. */
    description?: string;
    /** What happens while the setting doesn't exist. Shown in the form's About box. */
    whenUnset?: string;
    /** Format or effect of the value. Shown under the Value control. */
    valueHint?: string;
    /** Optional placeholder for the plain typed field. */
    placeholder?: string;
    /**
     * Optional value prefilled into the Add form. Must match `type` — Json takes a list or map
     * (not a YAML string), and an `options` entry must match one option's `value`.
     */
    defaultValue?: string | number | boolean | unknown[] | Record<string, any>;
    /** Optional single-select options (scalar types only). Present → dropdown; absent → typed field. */
    options?: AiSuiteSettingOption[];
}
/** The Add/Edit setting form's About box. */
interface SettingAbout {
    title: string;
    text?: string;
    facts: {
        label: string;
        value: string;
    }[];
}
/** About-box text for the Custom Setting choice. */
declare const CUSTOM_SETTING_HELP: string;
/** About-box note on labels for the Custom Setting choice. */
declare const CUSTOM_SETTING_LABELS_HELP = "Some features read every setting with a given label, such as sso-proxy.";
/** Hint under a custom setting's Value control, per type. */
declare const CUSTOM_SETTING_VALUE_HINTS: Map<AISettingValueType, string>;
/**
 * Predefined settings selectable from both the admin AI System Settings form and the
 * per-workspace Settings form. A workspace value takes priority over the global one for these.
 */
declare const AISUITE_SETTINGS_COMMON: AiSuiteSetting[];
/**
 * Network-egress policy (DUPLOAI-2420), authored only on Admin → Agent Policies. Kept in the catalog
 * for that page's labels; excluded from generic System Settings lists and Add dropdowns.
 */
declare const AISUITE_SETTINGS_AGENT_POLICY: AiSuiteSetting[];
/**
 * Predefined settings selectable only from the admin AI System Settings form — never offered
 * as a predefined choice in the per-workspace Settings form. These are always read globally.
 */
declare const AISUITE_SETTINGS_ADMIN: AiSuiteSetting[];
/**
 * Predefined settings selectable only from the per-workspace Settings form — never offered
 * as a predefined choice in the admin AI System Settings form.
 */
declare const AISUITE_SETTINGS_WORKSPACE: AiSuiteSetting[];
/** Predefined choices selectable from the admin AI System Settings form. */
declare const AISUITE_SETTINGS_FOR_ADMIN: AiSuiteSetting[];
/** Predefined choices selectable from the per-workspace Settings form. */
declare const AISUITE_SETTINGS_FOR_WORKSPACE: AiSuiteSetting[];
/**
 * The full predefined catalog, regardless of scope. Each entry's `name` must be an
 * `AISUITE_SETTING.*` value; option values must match the entry `type`. Used for name→entry
 * lookups (`AISUITE_SETTING_BY_NAME`, `AISUITE_SETTING_NAME_TO_DISPLAY_NAME`) that don't care
 * which form the setting was created from.
 */
declare const AISUITE_SETTINGS: AiSuiteSetting[];
/**
 * The workspace form's Hidden Menu Items prefill. A workspace value replaces the System Setting's
 * list, so the ids that list hides start true and an unedited save keeps them hidden. Administration
 * ids are left out: that sidebar reads only the System Setting.
 */
declare function workspaceHiddenMenuPrefill(globalHiddenIds: readonly string[]): Record<string, boolean>;
/** True for names authored only on Agent Policies → Network Egress (DUPLOAI-4770). */
declare function isAgentPolicySetting(name: string): boolean;
/** Names the generic Add form must treat as taken, so a custom setting cannot collide with egress. */
declare function reservedGenericSettingNames(existing?: readonly string[]): string[];
/** Predefined setting by name. */
declare const AISUITE_SETTING_BY_NAME: ReadonlyMap<string, AiSuiteSetting>;
/** Setting name → display label (for the list's Name column). */
declare const AISUITE_SETTING_NAME_TO_DISPLAY_NAME: ReadonlyMap<string, string>;

declare enum ResourceStatus {
    New = "New",
    Updated = "Updated",
    TicketCreated = "TicketCreated",
    Processing = "Processing",
    Complete = "Complete",
    Failed = "Failed",
    Blocked = "Blocked",
    WaitingForApproval = "WaitingForApproval",
    DeProvisioning = "DeProvisioning",
    DeProvisioned = "DeProvisioned",
    DeprovisionInitiated = "DeprovisionInitiated",
    DeprovisionFailed = "DeprovisionFailed"
}
declare enum ResourceMode {
    Create = "Create",
    Import = "Import"
}
interface StatusBadge {
    readonly label: string;
    readonly cls: string;
}
/**
 * Single canonical status → badge lookup for ResourceStatus — the platform's generic
 * provisioning/ticket status, shared by every resource model. Live external state specific
 * to one resource (e.g. AWS EC2 instance state, MSK cluster state, K8s PVC phase) is NOT
 * ResourceStatus and does not belong here — it stays local to that resource's own model file.
 * Mirrors the backend's ResourceStatusExtensions.ToDisplayLabel() in ResourceBase.cs;
 * keep both in sync when adding a new ResourceStatus value.
 */
declare const ALL_STATUS_BADGES: ReadonlyMap<string, StatusBadge>;
/**
 * label (lowercased) -> badge color, for binding to `<status-with-style [statusBadgeStyles]>`.
 * Derived once here so every resource model shares the same instance instead of re-deriving it.
 */
declare const STATUS_BADGE_STYLES: ReadonlyMap<string, string>;
/** Resolves the display badge for a resource status. Every resource model uses this. */
declare function resourceStatusBadge(status?: ResourceStatus): StatusBadge;
declare enum TicketExecutionStatus {
    Pending = "Pending",
    Running = "Running",
    Succeeded = "Succeeded",
    Failed = "Failed",
    Cancelled = "Cancelled"
}
interface TicketStatusResponse {
    ticketId: string | null;
    ticketName?: string;
    executionStatus: TicketExecutionStatus | string | null;
    isRunning: boolean;
}
interface ResourceViewTemplate {
    resourceType: string;
    subType: string;
    label: string;
    icon?: string;
    idField: string;
    groups: TemplateGroup[];
    subTemplates?: Record<string, SubTemplate>;
}
interface SubTemplate {
    groups: TemplateGroup[];
}
/**
 * Conditional-visibility predicate. When attached to a group or field, the
 * renderer evaluates `path` against the data and hides the element when the
 * resolved value satisfies `equals` / `notEquals`. Simpler than a general
 * expression evaluator and covers the engine-branch use case (e.g.
 * `hideWhen: { path: "spec.engine", equals: "Memcached" }`).
 */
interface HideWhen {
    path: string;
    equals?: any;
    notEquals?: any;
}
interface TemplateGroup {
    name: string;
    fields: TemplateField[];
    hideWhen?: HideWhen;
}
type TemplateField = SingleField | MultiField | TableField | RawField | KeyValueField;
interface SingleField {
    key: string;
    label: string;
    type: 'single';
    value: string;
    isTemplate?: boolean;
    suffix?: string;
    mono?: boolean;
    fullWidth?: boolean;
    hideWhenEmpty?: boolean;
    hideWhen?: HideWhen;
    detailSource?: string;
    details?: FieldDetails;
    cardMenus?: MenuAction[];
    copy?: boolean;
    sensitive?: boolean;
}
interface MultiField {
    key: string;
    label: string;
    type: 'multi';
    source: string;
    valueField?: string;
    hideWhen?: HideWhen;
    cardMenus?: MenuAction[];
}
interface TableField {
    key: string;
    label: string;
    type: 'table';
    source: string;
    sourceType?: 'map' | 'wrap' | 'nested';
    flatten?: string;
    filter?: {
        field: string;
        value: string | number | boolean;
    };
    columns: TemplateColumn[];
    details?: FieldDetails;
    hideWhen?: HideWhen;
    rowMenus?: MenuAction[];
    cardMenus?: MenuAction[];
}
interface FieldDetails {
    mode: 'template' | 'yaml' | 'inline';
    ref?: string;
    groups?: TemplateGroup[];
    titleField?: string;
    subtitleField?: string;
}
interface TemplateColumn {
    key: string;
    label: string;
    isStatus?: boolean;
}
/** One item in a kebab menu (row- or card-level). Defined in the template JSON. */
interface MenuAction {
    id: string;
    label: string;
    icon?: string;
}
/** Emitted up the component chain when the user clicks any kebab menu item. */
interface MenuActionEvent {
    menuId: string;
    level: 'row' | 'card';
    fieldKey: string;
    row?: any;
}
interface RawField {
    key: string;
    label: string;
    type: 'raw';
    source: string;
    expanded?: boolean;
    hideWhen?: HideWhen;
    cardMenus?: MenuAction[];
}
/**
 * Renders the object at `source` as read-only key→value rows. Scalar values are
 * shown inline with a copy affordance; nested objects/arrays are truncated to a
 * one-line preview with a "More" button that opens the full value in a modal.
 * Use for dumping a whole attributes object as a friendly Overview (vs `raw`,
 * which shows the same object as collapsible JSON).
 */
interface KeyValueField {
    key: string;
    label?: string;
    type: 'keyvalue';
    source: string;
    fullWidth?: boolean;
    hideWhen?: HideWhen;
    cardMenus?: MenuAction[];
}
/** The health buckets behind the Ready / In progress / Needs attention cards. */
interface ResourceHealthCounts {
    ready: number;
    inProgress: number;
    inProgressDetail: string;
    attention: number;
    attentionDetail: string;
}
/**
 * Buckets ResourceStatus for a list page's summary cards. Lives here beside the status
 * enum and its badge map, so every ticket-backed resource list (networks, clusters,
 * Terraform deployments) reads the same statuses the same way.
 */
declare function resourceHealthCounts(resources: {
    status: ResourceStatus;
}[]): ResourceHealthCounts;

/**
 * Temporary AWS credentials + federated AWS Console sign-in URL returned by
 * POST .../resource-groups/{rgId}/aws/jitAccess. Serialized as camelCase to
 * match the platform-wide JSON convention.
 */
declare class AwsAccessInfo {
    constructor(properties?: Partial<AwsAccessInfo>);
    consoleUrl: string;
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken: string;
    region: string;
    validity: number;
    expiration: string;
}

declare enum TicketStatus {
    Open = "open",
    InProgress = "inProgress",
    Closed = "closed"
}
declare const TicketStatusBadgeMap: Map<TicketStatus, string>;
declare class ResourceTicket {
    constructor(props?: Partial<ResourceTicket>);
    id?: string;
    lastModified: string;
    createTime: string;
    createdAt?: string;
    updatedAt?: string;
    createdBy?: string;
    title: string;
    name: string;
    history: {
        statuses?: {
            status: string;
            disposition?: string;
        }[];
    };
    isProcessingMessage?: boolean;
    originContext?: {
        type?: string;
        metadata?: Record<string, string>;
    };
    _currentStatus: string;
    get currentStatus(): string;
    _statusBadge: string;
    _disposition: string;
    _createdOn: string;
    _updatedOn: string;
    static setTicketStatus(ticket: ResourceTicket): void;
}

declare enum AIProviderCategory {
    Cloud = "cloud",
    Kubernetes = "kubernetes",
    Observability = "observability",
    IncidentManagement = "incidentManagement",
    SourceControl = "sourceControl",
    Grc = "grc",
    Notification = "notification",
    Sales = "sales",
    Marketing = "marketing",
    VectorDatabase = "vectorDatabase",
    Llm = "llm",
    Other = "other"
}
declare enum AiCloudProvider {
    Aws = "aws",
    Azure = "azure",
    Gcp = "gcp",
    Oci = "oci",
    Duplo = "duplo"
}
declare class Scope implements BaseEntity {
    constructor(properties?: Partial<Scope>);
    id?: string;
    name: string;
    providerId: string;
    credentialName: string;
    mcpServerId?: string;
    description?: string;
    createdAt?: string;
    updatedAt?: string;
    isActive?: boolean;
    version?: number;
    /** Whether `name` may currently be renamed — set from the API response, see `ApiSingleResponse.canUpdateName`. */
    canUpdateName?: boolean;
    resourceMap?: Record<string, any>;
    awsResourceSearchFilter?: AwsScopeData;
    kubernetesFilterConfig?: KubernetesScopeData;
    gitResourceFilter?: SourceControlScopeData;
    metaData?: Record<string, string>;
    userCredentialEnabled?: boolean | null;
    userCredentialName?: string;
    /**
     * True when this is a Kubernetes scope whose credential is a static,
     * long-lived bearer token rather than something JIT-mintable. Computed
     * server-side, never carries the token itself — just this flag, used to
     * gate kubectl/kubeconfig actions behind a system setting.
     */
    isStaticTokenCredential?: boolean;
    /** Stamped client-side once per scope (see `applyGating()` in list-scopes/scope-list) —
     *  true when kubectl/Download-kubeconfig should be disabled for this scope right now,
     *  combining `isStaticTokenCredential` with the current value of the allow-setting. */
    isJitGated?: boolean;
    /** True for a KB scope backing no collection — the only one safe to delete here (DUPLOAI-3555). */
    isDeletableKbScope?: boolean;
}
declare class AwsScopeData {
    region: string;
    resourceTypesRegEx: string[];
    tags: {
        key: string;
        value: string;
    }[];
    constructor(properties?: Partial<AwsScopeData>);
}
declare class KubernetesScopeData {
    namespaceRegex: string[];
    namespacedResourceTypes?: string[];
    clusterResourceTypes?: string[];
    constructor(properties?: Partial<KubernetesScopeData>);
}
declare class SourceControlScopeData {
    repositoriesRegEx: string[];
    branchesRegEx: string[];
    /**
     * Restricts a minted GitHub App installation token's permissions below whatever the App
     * installation was actually granted — GitHub's mint API can only narrow, never broaden, an
     * installation's own permission grant. Keyed by GitHub's own permission names (e.g.
     * "contents", "actions"), valued "read"/"write"/"admin"; a key absent here means "don't
     * restrict — inherit the App's own grant". Deliberately a plain map rather than a fixed set
     * of fields: the admin UI populates the available keys dynamically from the App installation's
     * actual granted permissions (see AdminProvidersDataSource.getGithubPermissions), not a
     * hardcoded list, since GitHub's permission set is large and grows over time. GitHub-only:
     * ignored server-side for a PAT credential, which never mints a token at all.
     */
    permissions?: Record<string, string>;
    constructor(properties?: Partial<SourceControlScopeData>);
}

/** How much description a table cell carries before the tooltip takes over. */
declare const DESCRIPTION_LIMIT = 100;
/**
 * Type of a skill: either a built-in prebuilt skill or a custom one
 */
declare enum SkillType {
    External = "External",
    Custom = "Custom"
}
declare enum SkillFormatType {
    SkillMd = "SkillMd",
    Package = "Package",
    PrivateGitRepo = "PrivateGitRepo"
}
declare class GitRepoConfig {
    constructor(properties?: Partial<GitRepoConfig>);
    scopeId: string;
    name: string;
    orgName: string;
    branch: string;
    folderPath?: string;
}
declare class Skill {
    constructor(properties?: Partial<Skill>);
    name: string;
    id: string;
    description: string;
    type: SkillType;
    skillMd?: string;
    data: any;
    packagePath?: string;
    vendor?: string;
    updatedAt?: string;
    createdAt?: string;
    format: SkillFormatType;
    gitRepo?: GitRepoConfig;
    isBuiltIn?: boolean;
    metaData?: Record<string, string>;
    usedBy?: string[];
    private _descriptionShort;
    /** The description as a table cell shows it; the full text goes in the tooltip. */
    get descriptionShort(): string;
    get content(): string;
    set content(value: string);
    get lastModified(): string;
    set lastModified(value: string);
    get usedByDisplay(): string;
    get usedByBadges(): {
        visible: string[];
        remaining: number;
    };
    get isCustomPackage(): boolean;
    static readonly skillTypeStatusMap: Map<string, string>;
}

interface BreadcrumbLink {
    name: string;
    isLink: boolean;
    link?: string;
}
interface Breadcrumb {
    type?: string;
    alignment?: string;
    links?: BreadcrumbLink[];
}
interface CoreConfig {
    app: {
        appName: string;
        appTitle: string;
        appLogoImage: string;
        appLogoImageDark?: string;
    };
    layout: {
        skin: CoreConfigLayoutSkin;
        type: 'vertical' | 'horizontal';
        menu: {
            hidden: boolean;
            collapsed: boolean;
        };
        header?: {
            hidden?: boolean;
            title?: string;
            breadcrumbs?: Breadcrumb;
            extraBreadcrumbs?: BreadcrumbLink[];
            noTenantSwitchImpact?: boolean;
        };
        navbar: {
            hidden: boolean;
            type: 'navbar-static-top' | 'fixed-top' | 'floating-nav' | 'd-none';
            background: 'navbar-dark' | 'navbar-light';
            customBackgroundColor: boolean;
            backgroundColor: string;
        };
        footer: {
            hidden: boolean;
            type: 'footer-static' | 'footer-sticky' | 'd-none';
            background: 'footer-dark' | 'footer-light';
            customBackgroundColor: boolean;
            backgroundColor: string;
        };
        enableLocalStorage: boolean;
        customizer: boolean;
        scrollTop: boolean;
    };
}
type CoreConfigLayoutSkin = 'default' | 'bordered' | 'dark' | 'semi-dark';

interface CoreMenuItem {
    id: string;
    title: string;
    shortMenu?: string;
    shortTitle?: string;
    url?: string;
    type: 'section' | 'collapsible-section' | 'collapsible' | 'item' | 'dummy';
    role?: Array<string>;
    translate?: string;
    icon?: string;
    matIcon?: string;
    featherIcon?: string;
    disabled?: boolean;
    hidden?: boolean;
    classes?: string;
    exactMatch?: boolean;
    externalUrl?: boolean;
    openInNewTab?: boolean;
    badge?: {
        title?: string;
        translate?: string;
        classes?: string;
    };
    children?: CoreMenuItem[];
    hideSearch?: boolean;
    /** Sort key within its sibling group; lower first, none last. Built-ins use 10, 20, 30… */
    order?: number;
}
interface CoreMenu extends CoreMenuItem {
    children?: CoreMenuItem[];
}

/**
 * Read-only, globally-shared access to system settings (any authenticated user).
 * Write operations (create/update/delete) live in the admin-only
 * `AdminAISystemSettingsDataSource` under the ai-studio admin module.
 */
declare class AISystemSettingsDataSource {
    private api;
    private readonly baseUrl;
    constructor(api: HttpClient);
    /**
     * GET /v1/aiservicedesk/user/data/systemsettings?type={type}&label={label}
     * Both query params are optional. Returns active settings only.
     */
    listSettings(options?: {
        type?: AISettingValueType;
        label?: string;
    }): Observable<AISystemSetting[]>;
    /**
     * GET /v1/aiservicedesk/user/data/systemsettings/{id}
     */
    getById(id: string): Observable<AISystemSetting>;
    /**
     * GET /v1/aiservicedesk/user/data/systemsettings/by-name/{name}?suppressNotFound=true
     * A missing setting is a real 404 by default; suppressNotFound=true opts into a 200 with
     * `data: null` instead (duplo-ai-helpdesk PR #449) — same envelope the workspace endpoint uses.
     */
    getByName(name: string): Observable<AISystemSetting | null>;
    /**
     * GET /v1/aiservicedesk/user/data/systemsettings/by-label/{label}
     * Returns every active setting carrying the label. No suppressNotFound here — this endpoint
     * never 404s on its own (a missing label is just an empty array) and the server does not
     * accept the parameter.
     */
    getByLabel(label: string): Observable<AISystemSetting[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AISystemSettingsDataSource, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AISystemSettingsDataSource>;
}

/**
 * Central, cached, read-oriented access to global AI system settings — the AI-suite analogue of
 * SystemFeatures. Injectable anywhere; caches per name for the session (explicit invalidate()).
 * For workspace-scoped settings use WorkspaceSystemSettingsService.
 */
declare class AISystemSettingsService {
    private ds;
    private features?;
    private readonly cache;
    private readonly inFlight;
    private readonly labelCache;
    private readonly labelInFlight;
    constructor(ds: AISystemSettingsDataSource, features?: {
        IsAIEnabled?: boolean;
    });
    /**
     * The endpoint lives behind /v1/aiservicedesk, so reads are pointless when the AI suite is off.
     * Fails open when the token is absent (bare TestBed) — unknown is treated as enabled.
     */
    private get aiDisabled();
    getString(name: string, defaultValue?: string | null): Observable<string | null>;
    getNumber(name: string, defaultValue?: number | null): Observable<number | null>;
    getBool(name: string, defaultValue?: boolean | null): Observable<boolean | null>;
    getJson<T = unknown>(name: string, defaultValue?: T | null): Observable<T | null>;
    /** { [settingName]: value } for every active setting carrying the label. */
    getByLabel(label: string): Observable<Record<string, unknown>>;
    /** Drop cached entries so the next read refetches. name → that entry; no arg → clear all. */
    invalidate(name?: string): void;
    private resolve;
    static ɵfac: i0.ɵɵFactoryDeclaration<AISystemSettingsService, [null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AISystemSettingsService>;
}

/**
 * Read-only, workspace-scoped access to system settings for cross-module consumers. The server
 * resolves scope: by-name falls back workspace→global; by-label merges the two (workspace wins on
 * a name collision). Pass `excludeGlobal=true` to restrict to the workspace. Responses are wrapped
 * in `ApiResponse<T>` — this unwraps `.data`. Writes live in the ai-studio settings feature.
 */
declare class WorkspaceSystemSettingsDataSource {
    private api;
    private readonly baseUrl;
    constructor(api: HttpClient);
    private settingsUrl;
    /**
     * GET .../workspaces/{workspaceId}/systemsettings/by-name/{name}?excludeGlobal={bool}&suppressNotFound=true
     * Workspace-first with a global fallback. Like the system-level by-name endpoint, a missing
     * setting is a real 404 by default and suppressNotFound=true opts into a 200 with `data: null`
     * instead — this endpoint is not graceful on its own.
     */
    getByName(workspaceId: string, name: string, excludeGlobal?: boolean): Observable<AISystemSetting | null>;
    /**
     * GET .../workspaces/{workspaceId}/systemsettings/by-label/{label}?excludeGlobal={bool}
     * Merged across workspace and global scopes (workspace wins on a name collision) unless
     * `excludeGlobal` is true. No suppressNotFound here — this endpoint never 404s on its own (a
     * missing label is just an empty array) and the server does not accept the parameter.
     */
    getByLabel(workspaceId: string, label: string, excludeGlobal?: boolean): Observable<AISystemSetting[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkspaceSystemSettingsDataSource, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WorkspaceSystemSettingsDataSource>;
}

/**
 * Options for the workspace-scoped reads. `workspaceId` defaults to the session's current
 * workspace when omitted; `excludeGlobal` (default false) restricts the read to the workspace,
 * disabling the server-side global fallback/merge.
 */
interface WorkspaceSettingOpts {
    workspaceId?: string;
    excludeGlobal?: boolean;
}
/**
 * Central, cached, read-oriented access to workspace-scoped AI system settings. The server resolves
 * scope (by-name falls back workspace→global; by-label merges the two, workspace winning) unless
 * `excludeGlobal` is set. Cache entries are keyed by (workspaceId, excludeGlobal, name/label) so
 * they stay isolated per workspace and are retained across workspace switches; call `invalidate`
 * after a write. For global-only settings use AISystemSettingsService.
 */
declare class WorkspaceSystemSettingsService {
    private ds;
    private session?;
    private features?;
    private readonly cache;
    private readonly inFlight;
    private readonly labelCache;
    private readonly labelInFlight;
    constructor(ds: WorkspaceSystemSettingsDataSource, session?: {
        tenant?: {
            aiWorkspace?: {
                id?: string;
            };
        };
    }, features?: {
        IsAIEnabled?: boolean;
    });
    /**
     * The endpoint lives behind /v1/aiservicedesk, so reads are pointless when the AI suite is off.
     * Fails open when the token is absent (bare TestBed) — unknown is treated as enabled.
     */
    private get aiDisabled();
    getString(name: string, defaultValue?: string | null, opts?: WorkspaceSettingOpts): Observable<string | null>;
    getNumber(name: string, defaultValue?: number | null, opts?: WorkspaceSettingOpts): Observable<number | null>;
    getBool(name: string, defaultValue?: boolean | null, opts?: WorkspaceSettingOpts): Observable<boolean | null>;
    getJson<T = unknown>(name: string, defaultValue?: T | null, opts?: WorkspaceSettingOpts): Observable<T | null>;
    /** { [settingName]: value } for every setting carrying the label in the resolved workspace scope. */
    getByLabel(label: string, opts?: WorkspaceSettingOpts): Observable<Record<string, unknown>>;
    /**
     * Invalidate cache after a write. `name` drops that setting (both merge-modes) plus the
     * workspace's label caches (a changed setting may appear in any label set); no `name` drops all
     * of the workspace's entries. `workspaceId` defaults to the session workspace.
     */
    invalidate(name?: string, workspaceId?: string): void;
    /** Clears `name` for every cached workspace after a global write — `invalidate()` alone
     *  only clears the current one. Pass `labels` (the setting's labels before ∪ after the write)
     *  to scope the label-cache clearing to just those — an empty array means the setting has no
     *  labels, so nothing to clear; omitted (unknown) falls back to a full clear. Same-bundle
     *  only — ai-studio and portal hold separate instances. */
    invalidateAcrossWorkspaces(name: string, labels?: string[]): void;
    private deleteByWorkspace;
    /** Deletes every cache entry for `name`, regardless of which workspace or merge-mode it's under. */
    private deleteByName;
    private resolveWorkspaceId;
    private key;
    private resolve;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkspaceSystemSettingsService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WorkspaceSystemSettingsService>;
}

/**
 * Where an extension surface renders. `workspace` (the default) is the AI DevOps side, scoped to the
 * selected workspace; `admin` is the AI Admin side, backed by the system Admin Workspace.
 */
type ExtensionScope = 'workspace' | 'admin';
declare enum AppType {
    Platform = "Platform",
    AISuite = "AI DevOps",
    Admin = "AI Admin"
}
/**
 * A runtime-loaded extension's menu tree, passed from the host into the remote menu builder.
 * The host owns the loaded-extension snapshot (its app initializer fetches `…/extensions/ui-manifest`);
 * `@common-lib` is NOT a federation singleton, so the data is passed by value across the './Menu' call
 * boundary rather than read from a shared module. Structurally matches the host's `ExtensionMenuNode`.
 */
interface RemoteMenuExtensionNode {
    id: string;
    title: string;
    type?: 'section' | 'collapsible-section' | 'collapsible' | 'item' | 'dummy';
    matIcon?: string;
    icon?: string;
    order?: number;
    relativeUrl?: string;
    role?: string[];
    /** Top-level node only: `admin` renders the tree in AI Admin, anything else in AI DevOps. */
    scope?: ExtensionScope;
    children?: RemoteMenuExtensionNode[];
}
/**
 * The agent the backend files an extension under (ui-manifest `extensions[i].agent`): a manifest-named agent
 * (`id` "manifest:<name>") or a customer's own nav placement (`source` "customer"). `order` places the agent's nav
 * heading; `position`, when sent, places the extension among the heading's members. Either may be omitted.
 */
interface ResolvedAgent {
    id: string;
    name: string;
    order?: number | null;
    position?: number | null;
    source: 'manifest' | 'customer';
    /** Customer placements only: the id of the heading the extension is filed under, built-in, agent or custom. */
    headingId?: string;
    /** Customer placements only: the title a custom heading is created with when no heading has `headingId`. */
    headingTitle?: string;
    /** Customer placements only: the heading child the extension follows; null or omitted is first. */
    afterId?: string | null;
}
/** A validated extension setup page, passed by value to the remote's menu builder. */
interface RemoteMenuExtensionSetup {
    extensionId: string;
    name: string;
    /** Label of the setup prompt's action button, default "Set up". The Agent Setup nav shows the agent's name, not this. */
    title: string;
    relativeUrl: string;
}
interface RemoteMenuExtensionTree {
    node: RemoteMenuExtensionNode;
    /**
     * The owning extension's resolved agent, passed through as the backend sent it. Absent when it resolved none.
     * An older backend may send something else here; the menu builder treats that as no agent.
     */
    agent?: ResolvedAgent;
    /** Legacy single-menu path: merge into a top-level group whose id matches. New menus[] omit this. */
    legacyParentGroupId?: string;
}
/** A Providers menu group (built-in IT/GTM or admin-authored custom). Shared shape between
 * `AiMenuDeps.getProviderGroups`, the host's own registry DTO, and the remote's in-memory cache -
 * declared once here instead of three structurally-identical inline object types. */
interface AiMenuProviderGroup {
    groupId: string;
    label: string;
    order: number;
    icon?: string;
}
/**
 * Contract for a remote module's './Menu' federation expose.
 * Pure function: must not touch Angular DI, components, or globals.
 * Every remote that contributes sidebar nav exports `buildMenu` matching this type.
 * `extensionMenus` (optional) carries runtime-loaded extensions' menu trees for the builder to
 * find-or-create by title; omitted by callers that don't surface extensions.
 * `extensionSetups` (optional) carries the validated `frontend.setup` entries for the AI Admin Agent Setup group; older hosts omit it.
 */
type RemoteMenuBuilder = (features: SystemFeatures, session: UserSession, appType: AppType, extensionMenus?: RemoteMenuExtensionTree[], extensionSetups?: RemoteMenuExtensionSetup[]) => CoreMenu[];
/**
 * Everything the host hands a remote so it can load its own menu config. Build it per call:
 * `appType` changes at runtime and the scope derives from it plus the session's workspace.
 * Services are passed as instances, not resolved on the remote side — `@common-lib` is not shared
 * across the federation boundary, so class identity differs; method dispatch is duck-typed.
 */
interface AiMenuDeps {
    features: SystemFeatures;
    session: UserSession;
    appType: AppType;
    /** Global / admin scope. */
    aiSettings: AISystemSettingsService;
    /** Workspace scope; the server falls back to the global value. */
    workspaceSettings: WorkspaceSystemSettingsService;
    /**
     * Fetches the effective (built-in + custom) Providers menu group registry - a plain async
     * function rather than an injected service, so `remote-menu.ts` stays free of Angular DI and the
     * host controls auth/HTTP. Only supplied for `AppType.Admin` (the only app type that renders the
     * Providers admin section) and only when the session actually holds the AIStudioAdmin role;
     * omitted otherwise so a non-admin session never calls the admin-only endpoint. Deliberately
     * REJECTS on failure (network error, 403) rather than resolving `[]` - the remote's
     * loadProviderGroups() catches the rejection and leaves its cache at `null` so the next
     * ensureMenuConfig() call retries, instead of caching a false "genuinely empty" result for the
     * rest of the session.
     */
    getProviderGroups?: () => Promise<AiMenuProviderGroup[]>;
}
/** The subset of the './Menu' federation expose that the host calls. */
interface AiMenuRemote {
    buildMenu: RemoteMenuBuilder;
    ensureMenuConfig?: (deps: AiMenuDeps) => Promise<boolean>;
    /**
     * Lets the host register a callback the remote invokes whenever `invalidateMenuConfig()` runs a
     * full (non-scope-scoped) reset - e.g. after the custom-provider-type wizard creates a group.
     * Without this, the group registry cache clears but nothing tells the host to rebuild, so the new
     * group doesn't appear in the sidebar until the next unrelated app-type/tenant change (watchScope())
     * or a full browser refresh.
     */
    onMenuConfigInvalidated?: (listener: () => void) => void;
}

type DeepPartial<T> = {
    [P in keyof T]?: T[P] extends Record<string, unknown> ? DeepPartial<T[P]> : T[P];
};

declare class ProviderCredentialData {
    constructor(properties?: Partial<ProviderCredentialData>);
    key: string;
    value: string;
    type?: string;
    isSensitive?: boolean;
}
interface ApiTokenSettings {
    defaultExpiryDays: number;
    callerIsSuperUser: boolean;
}
interface CreateApiTokenRequest {
    name: string;
    expiresAt?: string | null;
    canBeUsedForImpersonation?: boolean;
}
interface ApiTokenCreateResponse {
    token: HelpdeskApiToken;
    plainToken: string;
}
declare class HelpdeskApiToken implements BaseEntity {
    id: string;
    name: string;
    userId: string;
    tokenHint: string;
    createdAt: string;
    lastUsedAt?: string;
    expiresAt?: string;
    isActive: boolean;
    canBeUsedForImpersonation: boolean;
    private _isExpired;
    private _statusLabel;
    constructor(properties?: Partial<HelpdeskApiToken>);
    get isExpired(): boolean;
    get statusLabel(): string;
}
declare class CredentialPayload {
    constructor(properties?: Partial<CredentialPayload>);
    name?: string;
    dataEx?: ProviderCredentialData[];
    metaData?: Record<string, any>;
}
declare class UserCredential implements BaseEntity {
    constructor(properties?: Partial<UserCredential>);
    id?: string;
    name?: string;
    description?: string;
    ownerEmail?: string;
    scopeId?: string;
    isEnabled: boolean;
    credential?: CredentialPayload;
    createdAt?: string;
    updatedAt?: string;
    isActive?: boolean;
    version?: number;
    metaData?: Record<string, any>;
}

declare class HdUserProfileDataSource {
    private api;
    private baseUrl;
    constructor(api: HttpClient);
    getSettings(): Observable<ApiTokenSettings>;
    listTokens(): Observable<HelpdeskApiToken[]>;
    createToken(request: CreateApiTokenRequest): Observable<ApiTokenCreateResponse>;
    revokeToken(id: string): Observable<void>;
    deleteToken(id: string): Observable<void>;
    getAllowedWorkspaces(): Observable<AIWorkspaceBase[]>;
    private credUrl;
    getUserCredential(scopeId: string): Observable<UserCredential | null>;
    upsertUserCredential(scopeId: string, credential: Partial<UserCredential>): Observable<UserCredential>;
    deleteUserCredential(scopeId: string): Observable<void>;
    toggleUserCredential(scopeId: string, isEnabled: boolean): Observable<UserCredential>;
    getCredentialTemplate(scopeId: string): Observable<ProviderCredentialData[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HdUserProfileDataSource, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HdUserProfileDataSource>;
}

declare const DEFAULT_INFRA: {
    Name: string;
    Accountid: string;
    Cloud: number;
    ProvisioningStatus: string;
    Vnet: {
        Subnets: any[];
        SecurityGroups: any[];
    };
};
declare const INFRA_K8S_VERSION = "K8sVersion";
declare const INFRA_EKS_VISIBILITY = "EksEndpointVisibility";
declare const INFRA_EKS_LOGGING = "EksControlplaneLogs";
declare const INFRA_EKS_VPN_ACCESS = "EnableVpnAccessToEks";
declare const INFRA_EKS_CSI_SNAPSHOT = "EksEbsCsiSnapshotController";
declare const INFRA_DUPLO_CI_TENANT = "DuploCiTenant";
declare const INFRA_DUPLO_CI_CERTIFICATE = "DuploCiCertificate";
declare const INFRA_CLUSTER_AUTOSCALER = "EnableClusterAutoscaler";
declare const ALERT_PRIOR_AUTOSCALING = "AlertPriorAutoscaling";
declare const INFRA_EKS_LOG_TYPES: string[];
declare const INFRA_GKE_VISIBILITY = "GkeEndpointVisibility";
declare const INFRA_OKE_VISIBILITY = "OkeEndpointVisibility";
declare const INFRA_MAXIMUM_K8S_SESSION_DURATION = "MaximumK8sSessionDuration";
declare const GKE_MIN_PORTS_PER_VM = "GkeMinPortsPerVm";
declare const INFRA_HELM_OPERATOR_FLUXV2 = "EnableHelmOperatorFluxV2";
declare const INFRA_HELM_OPERATOR_FLUXV2_DISABLED = "DisableHelmOperatorFluxV2";
declare const INFRA_GCP_DYNAMIC_PORT_ALLOCATION = "DynamicPortAllocation";
declare const INFRA_HELM_OPERATOR_VERSION = "K8sHelmOperator";
declare const INFRA_HELM_OPERATOR_FlUXV1 = "RemoveHelmOperatorFluxV1";
declare const INFRA_GKE_RELEASE_CHANNEL = "GkeChannel";
declare const INFRA_ENABLE_EKS_WINDOWS_WORKLOAD = "EnableK8sWindowsWorkload";
declare const INFRA_GKE_GATEWAY_API = "GkeGatewayAPI";
declare const INFRA_AZURE_NAT_GATEWAY = "EnableNATGateway";
declare enum CloudPlatform {
    AWS = 0,
    Oracle = 1,
    Azure = 2,
    Google = 3,
    BYOH = 4,
    Unknown = 5,
    Digital_Ocean = 6,
    OnPrem = 10
}
declare const INFRA_CUSTOM_DATA_SPECS: CustomDataSpec[];
declare class InfrastructureECSConfigUpdate {
    constructor(properties?: Object | InfrastructureECSConfigUpdate);
    EnableECSCluster: boolean;
    EnableContainerInsights: boolean;
}
declare class InfrastructureEKSConfigUpdate {
    constructor(properties?: Object | InfrastructureEKSConfigUpdate);
    EnableK8Cluster: boolean;
    K8sVersion: string;
}
declare class Infrastructure {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Object | Infrastructure);
    Name: string;
    Accountid?: string;
    Cloud: CloudPlatform;
    Vnet: Vnet;
    Region: string;
    AzCount: number;
    EnableK8Cluster: boolean;
    ClusterIpv4Cidr: string;
    CustomData: CustomData[];
    ProvisioningStatus?: string;
    AksConfig: InfrastructureAksConfig;
    VpcPeers: Array<string>;
    VpcPeerSubnets: Array<any>;
    EnableECSCluster: boolean;
    EnableContainerInsights: boolean;
    OnPremConfig?: OnPremConfig;
    IsServerlessKubernetes?: boolean;
    RegionReconcilable?: boolean;
    selected?: boolean;
    toggled?: boolean;
    ImportVpcConfig?: {
        VpcId?: string;
        EnableMasterVpcPeering?: boolean;
    };
    HubName: string;
    Type: number;
    LogAnalyticsConfig: LogAnalyticsConfig;
    RecoveryVaultConfig: RecoveryVaultConfig;
    private _statusColor;
    get StatusColor(): string;
    get IsRegionSkipped(): boolean;
    private _status;
    get Status(): string;
    get IsInfraFailed(): boolean;
    /** Human-readable name of the current cloud. */
    get CloudName(): string;
    /** Human-readable name of the CSP-managed Kubernetes in the current cloud. */
    get K8sName(): string;
    get isGKE(): boolean;
    /** Human-readable name of the VNET in the current cloud.*/
    get VpcName(): "VNET" | "VPC";
    /** What to call a firewall in the currently selected cloud. */
    get FirewallName(): "Firewall" | "Security Group";
    get isAWS(): boolean;
    get isAzure(): boolean;
    get isOracle(): boolean;
    /** Whether or not Kubernetes is available for the currently selected cloud. */
    get isK8sAvailable(): boolean;
    get K8sVersion(): string;
    set K8sVersion(value: string);
    get EksVisibility(): string;
    set EksVisibility(value: string);
    get GkeReleaseChannel(): string;
    set GkeReleaseChannel(value: string);
    get isNatGatewayEnabled(): boolean;
    getCustomDataValue(key: string): string;
    deleteCustomData(key: string): void;
    putCustomData(key: string, value: string): void;
}
interface Vnet {
    AddressPrefix: string;
    SubnetCidr: number;
    Subnets: Subnet[];
    SecurityGroups: SecurityGroup[];
    P2SRootCerts: any[];
    Id: string;
    Name: string;
    CustomPublicSubnetCidrs: string[];
    CustomPrivateSubnetCidrs: string[];
}
declare class OnPremConfig {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Partial<OnPremConfig>);
    Datacenter: string;
    OnPremK8Config: OnPremK8Config;
}
declare class OnPremK8Config {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Partial<OnPremK8Config>);
    Name: string;
    ClusterEndpoint: string;
    ApiToken: string;
    CertificateAuthorityDataBase64: string;
    Vendor: K8sVendor;
    OnPremEKSConfig: OnPremEKSConfig;
}
declare class OnPremEKSConfig {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Partial<OnPremEKSConfig>);
    PrivateSubnets: string[];
    PublicSubnets: string[];
    VpcId: string;
    IngressSecurityGroupIds: string[];
    get PrivateSubnetString(): string;
    get PublicSubnetString(): string;
    get IngressSecurityGroupIdString(): string;
}
interface SecurityGroup {
    Name: string;
    SystemId?: string;
    Rules: SecurityGroupRule[];
    ReadOnly?: boolean;
    SgType?: string;
    SubnetName?: string;
}
declare class SecurityGroupRule {
    constructor(properties?: Object | SecurityGroupRule);
    Name: string;
    SrcRuleType: number;
    SrcAddressPrefix?: string;
    DstRuleType: number;
    SourcePortRange?: string;
    Protocol: string;
    Direction: string;
    RuleAction: string;
    Priority: number;
    DstAddressPrefix?: string;
    DestinationPortRange?: string;
}
declare class Subnet {
    constructor(properties?: Object | Subnet);
    AddressPrefix: string;
    InfrastructureName?: string;
    NameEx: string;
    Id: string;
    SubnetType?: string;
    ServiceEndpoints?: any[];
    IsolatedNetwork?: boolean;
    [index: string]: any;
    toggled?: boolean;
}
declare class CloudCredential {
    Platform: CloudPlatform;
    username: string;
    password: string;
    email: string;
    AccountId: string;
    MetaData?: CustomData[];
    /** Only set by the UI. */
    constructor(properties?: any | CloudCredential);
    /** Human-readable name of the current cloud. */
    get CloudName(): string;
    get DisplayName(): string;
    set DisplayName(value: string);
    get Fingerprint(): string;
    set Fingerprint(value: string);
    get ObjectId(): string;
    set ObjectId(value: string);
    get TenantId(): string;
    set TenantId(value: string);
    get canUpdate(): boolean;
    get canDelete(): boolean;
    getMetadataValue(key: string): string;
    deleteMetadata(key: string): void;
    putMetadata(key: string, value: string): void;
}
declare class CloudCredentialRequest extends CloudCredential {
    State: 'delete' | null;
    constructor(properties?: Partial<CloudCredentialRequest>);
}
interface LogAnalyticsConfig {
    Name: string;
    SharedKey: string;
    CustomerId: string;
}
interface RecoveryVaultConfig {
    Name: string;
    ResourceGroup: string;
}
declare class InfrastructureASG {
    constructor(properties?: Object | InfrastructureASG);
    "properties.provisioningState": string;
    etag: string;
    id: string;
    name: string;
    type: string;
    location: string;
}
declare class SecurityGroupRuleRequest {
    constructor(properties?: Object | SecurityGroupRuleRequest);
    Name: string;
    SgName: string;
    RulesToAdd: SecurityGroupRule[];
    [index: string]: any;
}
declare class EnableAzureSettings {
    constructor(properties?: Object | EnableAzureSettings);
    name: string;
    resourceGroup: string;
}
declare const subnetTypes: {
    value: string;
    label: string;
}[];
declare const serviceEndpointTypes: {
    label: string;
    value: number;
}[];
declare class LogAnalyticsWorkSpace {
    constructor(properties?: Object | LogAnalyticsWorkSpace);
    "properties.provisioningState": string;
    "properties.customerId": string;
    "properties.sku": PropertiesSku;
    "properties.retentionInDays": number;
    "properties.publicNetworkAccessForIngestion": string;
    "properties.publicNetworkAccessForQuery": string;
    location: string;
    id: string;
    name: string;
    type: string;
}
interface PropertiesSku {
    name: string;
}
declare class RecoveryServicesVault {
    constructor(properties?: Object | RecoveryServicesVault);
    properties: RsvProperties;
    sku: Sku;
    location: string;
    id: string;
    name: string;
    type: string;
    eTag: string;
}
interface RsvProperties {
    provisioningState: string;
    privateEndpointStateForBackup: string;
    privateEndpointStateForSiteRecovery: string;
}
interface Sku {
    name: string;
}
declare class AzureK8sSupportedVersion {
    constructor(properties?: Partial<AzureK8sSupportedVersion>);
    Version: string;
    PatchVersions: string[];
}
declare class VmSize {
    constructor(properties?: Partial<VmSize>);
    Name: string;
    NumberOfCores: number;
    MemoryInMB: number;
}
declare class VaultBackupPolicy {
    constructor(properties?: Partial<VaultBackupPolicy>);
    properties: VbpProperties;
    id: string;
    name: string;
    type: string;
    get scheduledTime(): string;
}
declare class VbpProperties {
    constructor(properties?: Partial<VbpProperties>);
    instantRPDetails: InstantRPDetails;
    schedulePolicy: SchedulePolicy;
    retentionPolicy: RetentionPolicy;
    instantRpRetentionRangeInDays: number;
    timeZone: string;
    protectedItemsCount: number;
    backupManagementType: string;
}
interface InstantRPDetails {
}
declare class RetentionPolicy {
    constructor(properties?: Partial<RetentionPolicy>);
    dailySchedule: DailySchedule;
    retentionPolicyType: string;
    weeklySchedule: WeeklySchedule;
}
declare class DailySchedule {
    constructor(properties?: Partial<DailySchedule>);
    retentionTimes: string[];
    retentionDuration: RetentionDuration;
}
declare class WeeklySchedule {
    constructor(properties?: Partial<WeeklySchedule>);
    daysOfTheWeek: string[];
    retentionTimes: string[];
    retentionDuration: RetentionDuration;
}
declare class RetentionDuration {
    constructor(properties?: Object | RetentionDuration);
    count: number;
    durationType: string;
}
declare class SchedulePolicy {
    constructor(properties?: Object | SchedulePolicy);
    scheduleRunFrequency: string;
    scheduleRunTimes: string[];
    scheduleRunDays: string[];
    schedulePolicyType: string;
}
declare class AadConfig {
    constructor(properties?: Partial<AadConfig>);
    IsManagedAadEnabled?: boolean;
    IsAzureRbacEnabled?: boolean;
    TenantId?: string;
    AdminGroupObjectIds?: string[];
}
declare class InfrastructureAksConfig {
    constructor(properties?: Object | InfrastructureAksConfig);
    Name: string;
    VmSize: string;
    CreateAndManage: boolean;
    State: string;
    K8sVersion?: string;
    PrivateCluster?: boolean;
    NetworkPlugin?: string;
    NodeResourceGroup?: string;
    OutboundType?: string;
    EnableAutoScaling?: boolean;
    NodeCount?: number;
    MaxCount?: number;
    MinCount?: number;
    MaxPods?: number;
    PricingTier: string;
    ImageCleanerIntervalInDays?: number;
    EnableImageCleaner?: boolean;
    DisableRunCommand?: boolean;
    EnableBlobCsiDriver?: boolean;
    EnableWorkloadIdentity?: boolean;
    SystemAgentPoolTaints?: string[];
    AddCriticalTaintToSystemAgentPool?: boolean;
    AadConfig: AadConfig;
    LinuxAdminUsername?: string;
    LinuxSshPublicKey?: string;
    get NetworkPluginString(): string;
    get OutboundTypeString(): string;
}
declare class VpcEndpoint {
    constructor(properties?: Object | Partial<VpcEndpoint>);
    VpcEndpointId: string;
    Tags: KeyStringValue[];
    SubnetIds: string[];
    State: ValueObj;
    ServiceName: string;
    RouteTableIds: string[];
    RequesterManaged: boolean;
    PrivateDnsEnabled: boolean;
    PolicyDocument: string;
    OwnerId: string;
    NetworkInterfaceIds: string[];
    LastError: LastError;
    IpAddressType: string;
    Groups: SecurityGroupIdentifier[];
    DnsOptions: DnsOptions;
    DnsEntries: DnsEntry[];
    CreationTimestamp: string;
    VpcEndpointType: ValueObj;
    VpcId: string;
    get PrivateDnsStatus(): string;
}
interface LastError {
    Code: string;
    Message: string;
}
interface SecurityGroupIdentifier {
    GroupId: string;
    GroupName: string;
}
interface DnsOptions {
    DnsRecordIpType: string;
}
interface DnsEntry {
    DnsName: string;
    HostedZoneId: string;
}
interface ValueObj {
    Value: string;
}
declare class CreateVpcEndpointRequest {
    constructor(properties?: Object | Partial<CreateVpcEndpointRequest>);
    VpcEndpointType: ValueObj;
    ServiceName: string;
}
declare class ServiceDetail {
    constructor(properties?: Object | Partial<ServiceDetail>);
    AcceptanceRequired: boolean;
    AvailabilityZones: string[];
    BaseEndpointDnsNames: string[];
    ManagesVpcEndpoints: boolean;
    owner: string;
    PayerResponsibility: ValueObj;
    PrivateDnsName: string;
    PrivateDnsNames: PrivateDnsDetails[];
    PrivateDnsNameVerificationState: ValueObj;
    ServiceId: string;
    ServiceName: string;
    ServiceType: ServiceTypeDetail[];
    SupportedIpAddressTypes: string[];
    Tags: KeyStringValue[];
    VpcEndpointPolicySupported: boolean;
}
interface PrivateDnsDetails {
    PrivateDnsName: string;
}
interface ServiceTypeDetail {
    ServiceType: ValueObj;
}
declare class GcpInfraPeering {
    constructor(properties?: Partial<GcpInfraPeering>);
    PeeringName: string;
    SourceVpc: string;
    DestinationVpc: string;
    ExportCustomRoutes: boolean;
    ImportCustomRoutes: boolean;
    ImportSubnetRoutesWithPublicIp: boolean;
    ExportSubnetRoutesWithPublicIp: boolean;
    Status?: string;
    get sourceInfra(): string;
    get destinationInfra(): string;
    get statusBadge(): TableStatus$1;
    static InfraPeeringStatusMap: Map<string, string>;
    get showDelete(): boolean;
}
declare class GkeEnableK8s {
    constructor(properties?: Partial<GkeEnableK8s>);
    EnableK8Cluster: boolean;
    IsServerlessKubernetes: boolean;
    K8sVersion: string;
    GkeEndpointVisibility: string;
    GkeChannel: string;
    ClusterIpv4Cidr: string;
    static readonly K8sServerlessOption: {
        value: boolean;
        label: string;
    }[];
    static readonly ChannelOptions: SelectOption[];
    static readonly VisibilityOptions: {
        value: string;
        label: string;
    }[];
}
declare class GkeClusterMaintenancePolicy {
    constructor(properties?: Partial<GkeClusterMaintenancePolicy>);
    Exclusions: GkeMaintenanceExclusion[];
    DailyMaintenanceStartTime?: Date;
    RecurringWindow: GkeMaintenanceRecurringWindow;
}
declare class GkeMaintenanceRecurringWindow {
    constructor(properties?: Partial<GkeMaintenanceRecurringWindow>);
    StartTime: string;
    EndTime: string;
    Recurrence: string;
    StartTimeError: string;
    EndTimeError: string;
}
declare class GkeMaintenanceExclusion {
    constructor(properties?: Partial<GkeMaintenanceExclusion>);
    StartTime: string;
    EndTime: string;
    Scope: string;
    StartTimeError: string;
    EndTimeError: string;
}
declare enum GkeMaintenanceExclusionScope {
    NO_UPGRADES = "No upgrades",
    NO_MINOR_UPGRADES = "No minor upgrades",
    NO_MINOR_OR_NODE_UPGRADES = "No minor or node upgrades"
}
declare const OracleRegionOptions: string[];
interface AzureResourceType {
    Namespace: string;
    Type: string;
}
interface AzureResourceId {
    ResourceType: AzureResourceType;
    Name: string;
    Parent?: AzureResourceId;
    SubscriptionId?: string;
    ResourceGroupName?: string;
}
interface AzureNatGatewayPublicIPAddress {
    Id: AzureResourceId;
}
interface AzureNatGatewaySubnet {
    Id: AzureResourceId;
}
interface AzureNatGatewayLocation {
    Name: string;
    DisplayName: string;
}
interface AzureNatGatewayUpdateRequest {
    NatGatewayName: string;
    VirtualNetworkName: string;
    SubnetsToBeAttached: string[];
}
declare class AzureNatGateway {
    SkuName: any;
    Zones: string[];
    ETag: any;
    IdleTimeoutInMinutes: number;
    PublicIPAddresses: AzureNatGatewayPublicIPAddress[];
    PublicIPAddressesV6: any[];
    PublicIPPrefixes: any[];
    PublicIPPrefixesV6: any[];
    Subnets: AzureNatGatewaySubnet[];
    ResourceGuid: string;
    ProvisioningState: any;
    Id: AzureResourceId;
    Name: string;
    ResourceType: AzureResourceType;
    Location: AzureNatGatewayLocation;
    Tags: {
        [key: string]: string;
    };
    constructor(properties?: Partial<AzureNatGateway>);
}

declare class UsersInfo {
    constructor(properties?: Object | UsersInfo);
    Username: string;
    Roles: UserRole[];
    Role: UserRole;
    UserSource?: UserRoleSource | '';
    VpnPassword: string;
    VpnStaticIp?: string;
    ApiTokens: UserApiToken[];
    IsReadOnly: boolean;
    IsVpnConfigCreated: boolean;
    IsConfirmationEmailSent: boolean;
    Devspaces: UserDevspace;
    VpnServerUrl?: string;
    LastLoggedIn?: string;
    get isDuploUser(): boolean;
    get isOktaUser(): boolean;
    get isAdmin(): boolean;
}
declare class UserTenantNames {
    constructor(name?: string);
    name: string;
}
declare class UserVPNConfig {
    constructor(properties?: Partial<UserVPNConfig>);
    "access_from.0": string;
    "access_to.0": string;
    conn_ip: string;
    pvt_password_digest: string;
    type: string;
}
declare class UserUpdateRequest extends UsersInfo {
    constructor(properties?: object | UserUpdateRequest);
    ReallocateVpnAddress: boolean;
    RegenerateVpnPassword: boolean;
    ResetVpnConfig: boolean;
    State: string;
    Permissions?: string[];
    PermissionGroups?: string[];
}
declare class UserTokenResponse {
    constructor(properties?: object | UserTokenResponse);
    Name: string;
    Token: string;
}
declare class UpdateUserVPNInfo {
    constructor(properties?: object | UpdateUserVPNInfo);
    Username: string;
    State: string;
    ReallocateVpnAddress: string;
    RegenerateVpnPassword: string;
    IsReadOnly: boolean;
    ResetVpnConfig: true;
}
declare class BatchAddUserAccessRequest {
    constructor(properties?: Partial<BatchAddUserAccessRequest>);
    Username: string;
    TenantAccessQueries: TenantAccessQuery;
    AddToAllTenants: boolean;
    AddToAllExceptDefault: boolean;
}
declare class AssignMultipleUsersToTenantRequest {
    constructor(properties?: Partial<AssignMultipleUsersToTenantRequest>);
    Users: string[];
    TenantAccessQueries: TenantAccessQuery;
}
declare class UserConstants {
    static readonly roleBadgeStyles: Map<UserRole, string>;
}

/**
 * Runtime configuration consumed by common-lib services. Supplied by each host app
 * (portal, ai-studio, …) via `CommonLibModule.forRoot(...)` so the library owns no
 * consumer-specific environment values and stays publishable.
 */
interface CommonLibConfig {
    /** API base URL. `DuploApiInterceptor` prepends this to root-relative requests. */
    apiUrl: string;
    /** Mixpanel project token. Empty/undefined disables analytics. */
    mixpanelToken?: string;
}
/**
 * Defaults used when a consumer does not call `forRoot` (or omits fields).
 *  - `apiUrl: '/'` keeps root-relative requests same-origin: `'/v1/x'` → `'/' + 'v1/x'`.
 *  - `mixpanelToken: ''` leaves analytics disabled.
 */
declare const DEFAULT_COMMON_LIB_CONFIG: CommonLibConfig;
/**
 * Tree-shakable root-provided token. Resolves to the defaults above when no provider
 * is registered, so services never fail injection. `CommonLibModule.forRoot(...)`
 * overrides it at the app's root injector.
 */
declare const COMMON_LIB_CONFIG: InjectionToken<CommonLibConfig>;

/**
 * Root configuration module for common-lib. Import once per app via
 * `CommonLibModule.forRoot({ apiUrl, mixpanelToken })`. Any omitted field falls back
 * to {@link DEFAULT_COMMON_LIB_CONFIG}. Apps that skip `forRoot` entirely still work,
 * resolving the defaults through the {@link COMMON_LIB_CONFIG} token's root factory.
 */
declare class CommonLibModule {
    static forRoot(config?: Partial<CommonLibConfig>): ModuleWithProviders<CommonLibModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonLibModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonLibModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonLibModule>;
}

/**
 * Convert raw text containing ANSI escape sequences into colored, XSS-safe HTML.
 *
 * `ansi-to-html` (with `escapeXML: true`) escapes &lt;/&gt;/&amp; in the source text BEFORE
 * inserting its own `<span style="color:...">` tags — so the post-conversion string
 * is safe to mark trusted. We only bypass sanitization on the converted output.
 *
 * SECURITY INVARIANT: `escapeXML: true` is the XSS control here — the input is
 * attacker-influenceable customer CLI output (terraform/git logs). It MUST stay true.
 * Do not switch to `DomSanitizer.sanitize(SecurityContext.HTML, …)`: that strips the
 * inline-style color spans the converter emits, defeating the purpose.
 *
 * Use inside a `<pre>` so newlines + monospace render correctly.
 */
declare class AnsiToHtmlPipe implements PipeTransform {
    private readonly converter;
    private readonly sanitizer;
    transform(text: string | null | undefined): SafeHtml;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnsiToHtmlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<AnsiToHtmlPipe, "ansiToHtml", true>;
}

declare class CustomDataKeyToValue implements PipeTransform {
    transform(dataArray: Array<{
        Key: string;
        Value: any;
    }>, key: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomDataKeyToValue, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CustomDataKeyToValue, "customDataKeyToValue", false>;
}

declare class TimeAgoPipe implements PipeTransform {
    transform(value: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimeAgoPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TimeAgoPipe, "timeAgo", true>;
}

declare class AILabelConfigPipe implements PipeTransform {
    transform(label: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AILabelConfigPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<AILabelConfigPipe, "aiLabelConfig", true>;
}

/**
 * Pure value-coercion helpers shared by the settings services. Each returns the typed value when
 * the setting matches the expected type — coercing (with a console.warn) for String/Number, and
 * falling back to the caller default for Bool/Json mismatches and for a missing setting (null).
 * `context` is used only in the warning message (e.g. the calling service name).
 */
declare function asString(s: AISystemSetting | null, name: string, def: string | null, context?: string): string | null;
declare function asNumber(s: AISystemSetting | null, name: string, def: number | null, context?: string): number | null;
declare function asBool(s: AISystemSetting | null, name: string, def: boolean | null, context?: string): boolean | null;
declare function asJson<T>(s: AISystemSetting | null, name: string, def: T | null, context?: string): T | null;

declare class AIAutomationService {
    isInIframe: boolean;
    activeActionId: string;
    private _event$;
    get events$(): Observable<{
        eventName: string;
        actionId: string;
        [key: string]: any;
    }>;
    constructor();
    initMessageListener(): Promise<void>;
    removeMessageListener(): void;
    private _handleParentMessages;
    /**
     * Emits an event either to the parent window via postMessage or through the internal subject
     * @param eventName - Name of the event to emit
     * @param actionId - Optional identifier for the action (default: undefined)
     * @param additionalData - Optional additional data to include with the event (default: null)
     */
    private _emitEvent;
    /**
     * Simulates a sequence of user interactions based on provided actions
     * @param actions - Array of AIUIAction objects defining the user interactions to perform
     * @param actionId - Unique identifier for this sequence of actions
     * @returns Promise that resolves when all actions have been completed
     */
    private _simulateUserFlow;
    private _wait;
    private _simulateHover;
    private _simulateInput;
    /**
     * Attempts to find an HTML element using the provided selector with multiple retries
     * @param selector - CSS selector string to find the element
     * @param maxRetries - Maximum number of retry attempts (default: 3)
     * @param retryDelay - Delay in milliseconds between retry attempts (default: 2000)
     * @returns Promise resolving to the found HTMLElement or null if not found
     */
    private _findElementWithRetry;
    /**
     * Simulates a sequence of user interactions based on provided actions
     * @param actions - Array of AIUIAction objects defining the user interactions to perform
     * @param actionId - Unique identifier for this sequence of actions
     * @returns Promise that resolves when all actions have been completed
     */
    private _highlightElement;
    /**
     * Cleans up highlight effects and disconnects observer
     * @param element - The highlighted element
     * @param chevIcon - The chevron icon element
     * @param observer - The mutation observer
     */
    private _cleanupHighlight;
    static ɵfac: i0.ɵɵFactoryDeclaration<AIAutomationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AIAutomationService>;
}

declare class AIUIAction {
    constructor(properties?: Partial<AIUIAction>);
    action: string;
    selector?: string;
    action_type?: string;
    value?: string;
    waitBefore?: number;
    waitAfter?: number;
    uid?: string;
    href?: string;
}
declare class AIUIActionEvent {
    eventName: string;
    actions?: AIUIAction[];
    actionId?: string;
    [key: string]: any;
    constructor(properties?: Partial<AIUIActionEvent>);
}
declare function sendToHelpDesk(eventName: string, data?: {
    [key: string]: any;
}): void;
declare const DUPLO__AUTO_HELPDESK_START_ACTION = "DUPLO__AUTO_HELPDESK_START_ACTION";
declare const DUPLO__AUTO_ACTIONS_IFRAME_READY = "DUPLO__AUTO_ACTIONS_IFRAME_READY";
declare const DUPLO__AUTO_ACTIONS_IFRAME_START = "DUPLO__AUTO_ACTIONS_IFRAME_START";
declare const DUPLO__AUTO_ACTIONS_IFRAME_DONE = "DUPLO__AUTO_ACTIONS_IFRAME_DONE";

/**
 * Builds the application's main menu. Supplied by the consuming app (portal, ai-studio, …)
 * via `CoreMenuService.registerMenuBuilder` so this generic service holds no app-specific
 * menu definition and no dependency on the host's source tree. See `setMainMenu`.
 */
type MenuBuilderFn = (features: SystemFeatures, session: UserSession, appType?: AppType) => CoreMenu[];
interface AppTile {
    name: string;
    icon: string;
    route: string;
    disabled?: boolean;
    type: AppType;
}
declare class CoreMenuService {
    private session;
    private location;
    private features;
    currentUser: UserPrincipal;
    readonly onItemCollapsed: Subject<any>;
    readonly onItemCollapseToggled: Subject<any>;
    readonly onSectionCollapsed: Subject<any>;
    readonly onSectionCollapseToggled: Subject<any>;
    readonly onMenuScrolled: Subject<void>;
    private _onMenuRegistered;
    private _onMenuUnregistered;
    private _onMenuChanged;
    private _currentMenuKey;
    private _registry;
    private _currentAppType$;
    private _menuBuilder;
    /**
     * Constructor
     *
     * @param {Router} _router
     * @param {AuthNZService} _authnz
     */
    constructor(session: UserSession, location: Location, features: SystemFeatures);
    get onMenuRegistered(): Observable<any>;
    get onMenuUnregistered(): Observable<any>;
    get onMenuChanged(): Observable<any>;
    get currentAppType(): AppType;
    get currentAppType$(): Observable<AppType>;
    replace(key: any, menu: any): void;
    /**
     * Register the provided menu with the provided key
     *
     * @param key
     * @param menu
     */
    register(key: any, menu: any): void;
    /**
     * Unregister the menu from the registry
     *
     * @param key
     */
    unregister(key: any): void;
    /**
     * Get menu from registry by key
     *
     * @param key
     * @returns {any}
     */
    getMenu(key: any): any;
    /**
     * Get current menu
     *
     * @returns {any}
     */
    getCurrentMenu(): any;
    /**
     * Set menu with the key as the current menu
     *
     * @param key
     */
    setCurrentMenu(key: any): void;
    getUrlByTitle(children: any[], fullPath: string): string | null;
    setUrlBasedAppType(routeUrl?: string): CoreMenu[];
    /**
     * Registers the host application's menu builder. Call once during app bootstrap
     * (before anything triggers `setMainMenu`) — the portal does this in
     * `AppComponent`'s constructor. Keeps the menu definition in the host so this
     * library stays free of any dependency on the consuming app's source tree.
     */
    registerMenuBuilder(build: MenuBuilderFn): void;
    setMainMenu(appType?: AppType): CoreMenu[];
    getAvailableApps(): AppTile[];
    getDefaultAppType(): AppType;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreMenuService>;
}

declare class AuthNZGuard {
    private _router;
    private _session;
    private static readonly BROWSER_IGNORE_PATHS;
    constructor(_router: Router, _session: UserSession);
    /**
     * Checks if a given browser URL is ignored for auth guards.
     *
     * @param routerUrl a browser URL as formatted by the Angular router (which omits the origin)
     * @returns true, if this browser URL is ignored for auth guards, false otherwise
     */
    static isUrlIgnored(routerUrl: string): boolean;
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree>;
    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthNZGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthNZGuard>;
}
/**
 * NOTE:  This must run *AFTER* the AuthNZGuard.
 */
declare class SubscriptionsGuard {
    private _router;
    private _session;
    private _error;
    constructor(_router: Router, _session: UserSession, _error: ErrorReporter);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean | UrlTree>;
    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean | UrlTree>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionsGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionsGuard>;
}
declare class SystemSettingGuard {
    private _coreMenuService;
    private _features;
    private _router;
    constructor(_coreMenuService: CoreMenuService, _features: SystemFeatures, _router: Router);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean | UrlTree>;
    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean | UrlTree>;
    private checkAccess;
    static ɵfac: i0.ɵɵFactoryDeclaration<SystemSettingGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SystemSettingGuard>;
}

/**
 * Simple middleware to inject the user's bearer token into a Duplo API call.
 */
declare class BearerTokenInterceptor implements HttpInterceptor {
    private session;
    constructor(session: UserSession);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BearerTokenInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BearerTokenInterceptor>;
}
/**
 * Simple middleware to inject the Duplo CI JWT token into a Duplo CI API call.
 */
declare class DuploCiTokenInterceptor implements HttpInterceptor {
    private session;
    constructor(session: UserSession);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploCiTokenInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploCiTokenInterceptor>;
}
declare class DuploCiApiInterceptor implements HttpInterceptor {
    private session;
    constructor(session: UserSession);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploCiApiInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploCiApiInterceptor>;
}
declare const SILENT_403: HttpContextToken<boolean>;
/**
 * Simple middleware to handle authnz failures by redirecting to a login or error page.
 */
declare class ErrorInterceptor implements HttpInterceptor {
    private session;
    private router;
    private injector;
    constructor(session: UserSession, router: Router, injector: Injector);
    intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>>;
    private getLocationPath;
    private get toastrService();
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorInterceptor>;
}

interface CacheEntry<T> {
    data: T;
    timestamp: number;
    key: string;
}
/**
 * Base class providing generic caching functionality for HTTP responses.
 * Services can extend this class to get caching capabilities.
 */
declare abstract class CacheResponseService {
    protected cache: Map<string, CacheEntry<any>>;
    protected readonly CACHE_TTL: number;
    /**
     * Check if a cached entry is still valid based on TTL
     */
    protected isCacheValid(key: string): boolean;
    /**
     * Get data from cache or fetch from source if cache is invalid/missing
     * @param key - Cache key
     * @param fetchFn - Function that returns Observable to fetch fresh data
     * @returns Observable of cached or fetched data
     */
    protected getCacheOrFetch<T>(key: string, fetchFn: () => Observable<T>): Observable<T>;
    /**
     * Invalidate cache entries by exact key or pattern matching
     * @param keyOrPattern - Exact key to delete, or undefined to clear all
     * @param additionalPattern - Additional pattern to match (for multi-part keys)
     */
    protected invalidateCache(keyOrPattern?: string, additionalPattern?: string): void;
    /**
     * Delete a specific cache entry by exact key
     */
    protected deleteCache(key: string): void;
    /**
     * Clear all cache entries
     */
    protected clearCache(): void;
}

declare const CORE_CUSTOM_CONFIG: InjectionToken<unknown>;
declare class CoreConfigService {
    private _router;
    private _config;
    localConfig: CoreConfig;
    private readonly _defaultConfig;
    private _configSubject;
    /**
     * Constructor
     *
     * @param _config
     * @param {Router} _router
     */
    constructor(_router: Router, _config: any);
    set config(data: DeepPartial<CoreConfig>);
    get config$(): Observable<CoreConfig>;
    /**
     * Get default config
     *
     * @returns {CoreConfig}
     */
    get defaultConfig(): CoreConfig;
    /**
     * Initialize
     *
     * @private
     */
    private _initConfig;
    /**
     * Saves the configuration to the local storage if the `enableLocalStorage` flag is set in the configuration.
     * It creates a clone of the configuration object, removes the `enableLocalStorage` property, and then saves the
     * configuration to the local storage.
     *
     * @param {CoreConfig} config - The configuration object to be saved.
     */
    private _saveInLocalStorage;
    /**
     * Set config
     *
     * @param data
     * @param {{emitEvent: boolean}} param
     */
    setConfig(data: DeepPartial<CoreConfig>, param?: {
        emitEvent: boolean;
    }): void;
    /**
     * Get config
     *
     * @returns {Observable<CoreConfig>}
     */
    getConfig(): Observable<CoreConfig>;
    /**
     * Get config Subject current value
     *
     * @returns {CoreConfig}
     */
    getConfigValue(): CoreConfig;
    /**
     * Reset to the default config
     */
    resetConfig(): void;
    setLastExtraBreadcrumbs(label: string): void;
    setExtraBreadcrumbs(o: BreadcrumbLink[]): void;
    removeLastBreadcrumb(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreConfigService>;
}

/**
 *  The DuploHttpClient programming API is exactly the same as angular's HttpClient, but all headers
 *  have been added for you.
 *
 *  An alternative pattern to the UI v1 app.service.ts
 *
 *   - Retains all type-safety of HttpClient methods (no more wrapping with "any")
 *   - Does not need to "reimplement" or "expose" HttpClient methods.
 *
 *  See:
 *   - https://indepth.dev/posts/1455/how-to-split-http-interceptors-between-multiple-backends
 */

declare const DUPLO_HTTP_INTERCEPTORS: InjectionToken<HttpInterceptor[]>;
declare const DUPLO_CI_HTTP_INTERCEPTORS: InjectionToken<HttpInterceptor[]>;
declare class InterceptingHandler implements HttpHandler {
    private backend;
    private interceptors;
    private chain;
    constructor(backend: HttpBackend, interceptors: HttpInterceptor[]);
    handle(req: HttpRequest<any>): Observable<HttpEvent<any>>;
    private buildChain;
}
declare class DuploApiInterceptor implements HttpInterceptor {
    private config;
    constructor(config: CommonLibConfig);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploApiInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploApiInterceptor>;
}
declare class DuploHttpClient extends HttpClient {
    constructor(backend: HttpBackend, standardInterceptors: HttpInterceptor[], duploInterceptors: HttpInterceptor[]);
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploHttpClient, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploHttpClient>;
}
declare class DuploCiHttpClient extends HttpClient {
    private zone;
    private session;
    constructor(backend: HttpBackend, zone: NgZone, session: UserSession, standardInterceptors: HttpInterceptor[], duploInterceptors: HttpInterceptor[]);
    loadEventSource<E>(url: string): Observable<MessageEvent<E>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploCiHttpClient, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploCiHttpClient>;
}

/**
 * Builds a kubeconfig YAML from a {@link K8ClusterConfig} and triggers a
 * browser download. Pure presentation/file-IO concern — JIT access loading
 * stays at the call site since the data source varies (cluster-baselines vs.
 * scopes vs. plans), so callers fetch their own config and hand it to
 * {@link download}.
 *
 * Used by:
 *   - Cluster Baseline view's "Download Kubeconfig" menu item
 *     ({@link ViewClusterBaselineComponent}).
 *
 * Add new callers by injecting this service and calling {@link download} with
 * the loaded K8ClusterConfig + a cluster name. No module wiring required —
 * `providedIn: 'root'`.
 *
 * Note: the YAML carries the JIT token verbatim, which is short-lived (TTL
 * minutes-to-hours depending on backend config). Callers wanting a long-lived
 * `duplo-jit`-backed kubeconfig should use the portal-side
 * `KubeconfigDownloadComponent` instead — it bakes in the exec credential
 * plugin + portal session context.
 */
declare class KubeconfigDownloadService {
    /**
     * Builds the kubeconfig YAML and triggers a browser download. Returns the
     * filename used.
     *
     * @throws Error when {@link K8ClusterConfig.ApiServer} or
     *   {@link K8ClusterConfig.Token} is missing — these mean the cluster isn't
     *   provisioned yet or the JIT response was incomplete.
     */
    download(k8Config: K8ClusterConfig, clusterName: string, namespace?: string): string;
    /**
     * Loads JIT access from `loader$` and downloads the resulting kubeconfig, reporting success
     * and build/download errors via `reporters` — the shared shape every call site (Admin/Workspace
     * scope lists, K8s Resources pages, Namespace list/detail) otherwise repeats verbatim.
     * `loader$` errors (the JIT request itself failing) are NOT reported here — the caller still
     * owns subscribing (with its own `takeUntil`/cleanup) and its own `error` handler for those.
     */
    downloadFrom(loader$: Observable<K8ClusterConfig>, clusterName: string, fallbackNamespace: string, reporters: {
        error: ErrorReporter;
        success: SuccessReporter;
    }): Observable<void>;
    /**
     * Builds + downloads using the modern Blob + temporary anchor approach.
     * No `file-saver` dependency — every browser we target supports this.
     */
    private triggerBrowserDownload;
    static ɵfac: i0.ɵɵFactoryDeclaration<KubeconfigDownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KubeconfigDownloadService>;
}

interface ListQueryState {
    q: string;
    sortBy: string;
    sortOrder: 'asc' | 'desc';
    /** One entry per facet key; null means unfiltered. */
    facets: Record<string, string | null>;
}
interface ListQueryDefaults {
    sortBy: string;
    sortOrder: 'asc' | 'desc';
}
/**
 * Puts a card list's search, facets and sort in the URL, so the view survives a
 * refresh and can be shared. Sort is omitted at its default to keep URLs clean.
 */
declare class ListQueryStateService {
    private readonly location;
    read(route: ActivatedRoute, facetKeys: string[], defaults: ListQueryDefaults): ListQueryState;
    write(state: ListQueryState, defaults: ListQueryDefaults): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListQueryStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ListQueryStateService>;
}

declare class CoreMediaService {
    private _mediaObserver;
    currentMediaQuery: string;
    onMediaUpdate: BehaviorSubject<string>;
    /**
     * Constructor
     *
     * @param {MediaObserver} _mediaObserver
     */
    constructor(_mediaObserver: MediaObserver);
    /**
     * Initialize
     *
     * @private
     */
    private _init;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreMediaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreMediaService>;
}

interface NamespacedTracker {
    pageView(page: string, props?: Record<string, unknown>): void;
    action(name: string, props?: Record<string, unknown>): void;
}

declare class MixpanelService {
    private config;
    isInitialized: boolean;
    isEnabled: boolean;
    private readonly warnedNamespaces;
    constructor(config: CommonLibConfig);
    /** No project token means init() no-ops, so nothing can ever be tracked. */
    get isConfigured(): boolean;
    initMixpanel(): void;
    grantConsent(): void;
    revokeConsent(): void;
    setDistinctId(id?: string): void;
    identifyUser(user: UserPrincipal): Promise<void>;
    disableMixpanel(): Promise<void>;
    track(eventName: string, properties?: Record<string, any>): void;
    /** First-party tracker: `<namespace>.<event>` with a ≥3-segment reverse-DNS namespace. */
    ns(namespace: string, defaults?: Record<string, unknown>): NamespacedTracker;
    static ɵfac: i0.ɵɵFactoryDeclaration<MixpanelService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MixpanelService>;
}

/** Internal representation only — the wire format is a tri-state boolean on UserSettings. */
declare enum AnalyticsConsent {
    Granted = "granted",
    Declined = "declined",
    Unset = "unset"
}
interface AnalyticsConsentState {
    globalEnabled: boolean;
    consent: AnalyticsConsent;
    /** DuploCloud staff: treated as consented, so there is nothing to ask or toggle. */
    internal: boolean;
}
declare function isInternalEmail(email: string | null | undefined): boolean;
declare class AnalyticsConsentService {
    private features;
    private aiSettings;
    private session;
    private api;
    private tracker;
    private _state;
    readonly state$: Observable<AnalyticsConsentState>;
    private principal;
    constructor(features: SystemFeatures, aiSettings: AISystemSettingsService, session: UserSession, api: DuploHttpClient, tracker: MixpanelService);
    get isGloballyEnabled(): boolean;
    get consent(): AnalyticsConsent;
    get isTrackingAllowed(): boolean;
    get shouldPrompt(): boolean;
    resolve(user: UserPrincipal): Observable<AnalyticsConsentState>;
    record(value: boolean | null): Observable<void>;
    private gateOnTracker;
    private readConsent;
    private toConsent;
    reset(): void;
    private publish;
    private applyToTracker;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnalyticsConsentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnalyticsConsentService>;
}

type AnalyticsProps = Record<string, string | number | boolean | null | string[] | number[] | boolean[]>;
/** What an extension gets: events land as `<manifest id>.<event>`, sent only with the user's consent. */
interface ExtensionAnalytics {
    pageView(page: string, properties?: AnalyticsProps): void;
    action(name: string, properties?: AnalyticsProps): void;
}

declare class NavBackService {
    private router;
    private location;
    private previousRoute;
    private currentRoute;
    constructor(router: Router, location: Location);
    /**
       * Tracks and stores the previous and current routes during navigation.
       *
       * Listens to router navigation events and updates the previousRoute and currentRoute
       * properties whenever a navigation is completed, allowing tracking of route history.
       */
    storeLast(): void;
    /**
       * Retrieves the deepest activated route in the current router state.
       *
       * @returns The most specific ActivatedRoute in the current navigation hierarchy.
       */
    private getCurrentActivatedRoute;
    /**
     * Generates a serialized URL for a relative path based on a given route context.
     *
     * @param relativePath The relative path to convert to a full URL.
     * @param route Optional ActivatedRoute to use as the base context. Defaults to the current route.
     * @returns A fully serialized URL string.
     */
    private getRelativePath;
    /**
     * Navigates back to a route relative to the current route context.
     *
     * @param relativePath A relative path to navigate back to within the current module (e.g., '../' or '../../').
     */
    relativeGoBack(relativePath: string, navExtra?: NavigationExtras): void;
    /**
     * Navigates back to a relevant route within the specified module.
     * If the previous route was within the module, it navigates back.
     * Otherwise, it navigates to the module's base route.
     *
     * @param moduleBasePath The base path of the current module (e.g., '/app/service').
     * @param defaultBackRoute (Optional) A specific route within the module to navigate to if no relevant history is found. Defaults to the moduleBasePath.
     */
    navigateBackToModule(moduleBasePath: string, defaultBackRoute?: string, navExtra?: NavigationExtras): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavBackService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NavBackService>;
}

declare const DEFAULT_REFRESH_INTERVAL: number;
declare class RefreshTimerService {
    /**
     * Creates a refresh timer observable that emits on a fixed interval.
     * @param immediate - If true, emits immediately (delay = 0); otherwise waits one full interval.
     * @param frequency - Interval in ms (default 30 000).
     */
    getTimer(immediate?: boolean, frequency?: number): Observable<number>;
    /**
     * Combines a context observable with a periodic timer and emits `[context, changed]` tuples.
     *
     * Works standalone (pass any `BehaviorSubject.asObservable()`) or inside a
     * domain service such as `ResourceK8sService` / `ResourceAWSService`.
     *
     * @param context$    - Observable that emits the current context value.
     * @param idExtractor - Pure function that pulls a comparable identity from the context
     *                      (e.g. `ctx => ctx.cluster?.scopeId`). Return `null`/`undefined`
     *                      for "no context".
     * @param immediate   - When `true` the very first emission is delivered; when `false`
     *                      the first tick is suppressed (useful when the caller already has
     *                      data and only wants refreshes).
     * @param frequency   - Interval in ms (default 30 000).
     * @param currentId   - Optional starting identity so the first emission can correctly
     *                      report `changed`. When `immediate` is `true` this defaults to
     *                      `null` so the first emission always shows `changed = true`.
     */
    getContextRefreshTimer<T>(context$: Observable<T>, idExtractor: (ctx: T) => string | null | undefined, immediate?: boolean, frequency?: number, currentId?: string | null): Observable<[T, boolean]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RefreshTimerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RefreshTimerService>;
}

declare class TabService {
    constructor();
    activateTabHook(router: Router, destroy$: SubDestroyService, action: (url: string, load: boolean) => void): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TabService>;
}

interface Locale {
    lang: string;
    data: TranslationObject;
}
declare class CoreTranslationService {
    private _translateService;
    private httpClient;
    /**
     * Constructor
     *
     * @param {TranslateService} _translateService
     */
    constructor(_translateService: TranslateService, httpClient: HttpClient);
    /**
     * Translate
     *
     * @param {Locale} args
     */
    translate(...args: Locale[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreTranslationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreTranslationService>;
}

declare const DUPLO_DARK_THEME = "duplo-dark";
type MonacoThemeName = 'vs' | typeof DUPLO_DARK_THEME;
/** Monaco theme for the current <html data-theme>; defines duplo-dark first so Monaco never falls back to light. */
declare function monacoTheme(): MonacoThemeName;
/** Adds `theme` as a getter so every spread/assign copy picks up the theme at editor creation. */
declare function withMonacoTheme<T extends object>(options: T): T & {
    theme: MonacoThemeName;
};
/** Applies the global Monaco theme and keeps it in sync; idempotent. False while Monaco isn't loaded. */
declare function syncMonacoTheme(): boolean;
/** Tears down the observer and create listeners; the next syncMonacoTheme() starts fresh. */
declare function stopMonacoThemeSync(): void;

declare const XTERM_BACKGROUND = "#0F0416";
/** Dark grounds the default terminal on --code-surface so it matches its frame; a caller's own background wins. */
declare function xtermTheme(mode: ThemeMode, theme: ITheme): ITheme;
/** Chat command-block colours (--terminal-bg/--terminal-fg), the same in both modes. */
declare function commandBlockTheme(): ITheme;

declare const THEME_DEFAULTS_STYLE_ID = "duplo-theme-defaults";
declare const THEME_DEFAULTS_CSS = "\n:where(:root) {\n  --agent-icon-g1-from: #6d5efc;\n  --agent-icon-g1-to: #a597ff;\n  --agent-icon-g2-from: #0ea5c6;\n  --agent-icon-g2-to: #38d3e8;\n  --agent-icon-g3-from: #f97316;\n  --agent-icon-g3-to: #fbbf24;\n  --agent-icon-g4-from: #10b981;\n  --agent-icon-g4-to: #4ade80;\n  --agent-icon-g5-from: #e11d48;\n  --agent-icon-g5-to: #fb7185;\n  --agent-icon-g6-from: #334155;\n  --agent-icon-g6-to: #64748b;\n  --agent-icon-g7-from: #2563eb;\n  --agent-icon-g7-to: #60a5fa;\n  --agent-icon-g8-from: #7c3aed;\n  --agent-icon-g8-to: #c084fc;\n  --agent-icon-g9-from: #0d9488;\n  --agent-icon-g9-to: #2dd4bf;\n  --backdrop: rgba(34, 41, 47, 0.5);\n  --border-raised: rgba(34, 41, 47, 0.05);\n  --code-surface: var(--primary-900);\n  --danger-text: var(--danger-darken-10);\n  --dark-text: var(--dark);\n  --hover-bg: color-mix(in srgb, var(--headings-color) 4%, transparent);\n  --info-text: var(--info);\n  --input-bg: #fff;\n  --input-disabled-bg: #efefef;\n  --marketplace-band-bottom: #0c0e1d;\n  --marketplace-band-glow: rgba(16, 185, 166, 0.38);\n  --marketplace-band-ink: #0e1020;\n  --marketplace-band-top: #0f1124;\n  --on-primary: var(--white);\n  --primary-text: var(--primary);\n  --secondary-text: var(--secondary);\n  --shadow-raised: 0 5px 25px rgba(34, 41, 47, 0.1);\n  --shadow-selected: 1px 1px 5px 0 #afbbe3;\n  --sidebar-text: var(--sidebar);\n  --success-text: var(--success-darken-10);\n  --surface: #fff;\n  --surface-raised: #fff;\n  --surface-subtle: #f6f6f6;\n  --terminal-bg: #050505;\n  --terminal-fg: #ececec;\n  --warning-text: var(--warning-darken-15);\n}\n:where(:root[data-theme='dark']) {\n  --backdrop: rgba(0, 0, 0, 1);\n  --border-raised: #4a4a53;\n  --code-surface: color-mix(in srgb, var(--primary) 14%, var(--surface));\n  --danger-text: color-mix(in srgb, var(--danger) 65%, #fff);\n  --dark-text: var(--body-color);\n  --info-text: color-mix(in srgb, var(--info) 55%, #fff);\n  --input-bg: #171719;\n  --input-disabled-bg: #212124;\n  --primary-text: color-mix(in srgb, var(--primary) 55%, #fff);\n  --secondary-text: color-mix(in srgb, var(--secondary) 70%, #fff);\n  --shadow-raised: 0 8px 24px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(255, 255, 255, 0.08);\n  --shadow-selected: 0 0 4px 0 rgba(175, 187, 227, 0.35);\n  --sidebar-text: color-mix(in srgb, var(--sidebar) 55%, #fff);\n  --success-text: color-mix(in srgb, var(--success) 75%, #fff);\n  --surface: #171719;\n  --surface-raised: #232327;\n  --surface-subtle: var(--neutral-50);\n  --warning-text: var(--warning);\n}\n";
/** Adds the defaults <style> to `doc` once; it stays for the page's life, as remotes can render outside routes. */
declare function ensureThemeDefaults(doc: Document): void;

/** Picks the ECharts `[theme]` for the app mode; ngx-echarts re-inits the chart when it changes. */
declare class EchartsThemeService {
    private readonly mode;
    private readonly themes;
    /** Light returns `light` unchanged; dark layers the token-built dark theme onto it, rebuilt on each switch. */
    chartTheme(light?: ThemeOption | null): Signal<ThemeOption | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EchartsThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EchartsThemeService>;
}

/**
 * Returns a deterministic avatar color for a display name using a palette-level WeakMap cache.
 */
declare const DEFAULT_AVATAR_PALETTE: readonly ["var(--blue)", "var(--purple)", "var(--pink)", "var(--red)", "var(--orange)", "var(--green)", "var(--teal)", "var(--cyan)", "var(--info)", "var(--danger)"];
declare function resolveAvatarColor(displayText: string, palette?: readonly string[]): string;

declare class CommonUtils {
    static formatDate(date: Date): string;
    /** Tooltip shown on a disabled Deprovision/Delete action; null when not protected. */
    static deprovisionBlockedReason(resourceType: string, name: string, isDeleteProtected: boolean): string | null;
    /**
     * Tooltip shown on a disabled Delete action (entities without deprovision, e.g. Workspace); null when
     * not protected. Points the user at the Metadata tab, which is where protection is turned off.
     */
    static deleteBlockedReason(resourceType: string, isDeleteProtected: boolean): string | null;
    /** True when a metadata map has `key` set to 'true' (case- and whitespace-insensitive). */
    static isMetadataFlagTrue(metaData: Record<string, string> | undefined, key: string): boolean;
    static isNullOrEmpty(value: any): boolean;
    static formatFileSize(bytes: number): string;
}

declare const REMOTE_UserSession: InjectionToken<unknown>;
declare const REMOTE_DuploHttpClient: InjectionToken<HttpClient>;
declare const REMOTE_SystemFeatures = "REMOTE_SystemFeatures";
declare const REMOTE_CoreConfigService = "REMOTE_CoreConfigService";
declare const REMOTE_AIAutomationService = "REMOTE_AIAutomationService";
declare const REMOTE_AuthNZService = "REMOTE_AuthNZService";
/** @deprecated Do not use: read for one release only, as a fallback while config.json `labels` is empty.
 *  Use config.json `labels` via `resolveLabel()` from common-lib/utils/ui-config (or the `aiLabelConfig` pipe). */
declare const AI_SUITE_LABEL_CONFIG = "AI_SUITE_LABEL_CONFIG";
declare const DISABLE_HELPDESK_NAV_COLLAPSE = "DISABLE_HELPDESK_NAV_COLLAPSE";
declare const DEFAULT_ACTION_SELECTION = "DEFAULT_ACTION_SELECTION";
declare const HELPDESK_DEFAULT_AGENT_NAME = "helpdesk-default-agent-name";
declare const DELETE_PROTECTION_METADATA_KEY = "delete_protection";
declare const REMOTE_CanvasRendererRegistry = "REMOTE_CanvasRendererRegistry";
declare const REMOTE_MiniHelpDesk: InjectionToken<MiniHelpDeskBridge>;
declare const REMOTE_ExtensionAnalytics: InjectionToken<ExtensionAnalytics>;
declare const REMOTE_LoadRemoteModule: InjectionToken<(options: {
    remoteEntry: string;
    exposedModule: string;
}) => Promise<unknown>>;

interface AnyObject {
    [key: string]: any;
}
declare function convertKeysToLowerCase(obj: AnyObject): AnyObject;

/** A colour token as hex, for consumers that reject rgb() and var() (Monaco, ECharts canvas); null when unset or invalid. */
declare function tokenHex(name: string): string | null;
/** Computed `rgb()/rgba()` or `color(srgb …)` as #rrggbb[aa]; null for anything else or non-finite channels. */
declare function cssColorToHex(value: string): string | null;

declare class DateUtils {
    static parseOrEmpty(text: string): Date;
    static nowPlusSeconds(offset: number): Date;
    static duration(from: Date, to: Date): number;
    static durationOrEmpty(from: Date, to: Date): number;
    static durationText(duration: number): string;
    static durationTextOrEmpty(duration: number): string;
    static getDurationBetweenTimestamps(startTime: string, endTime: string): string;
    static getTimeFromDate(date: Date, needSecond?: boolean): string;
    static getDateFromTime(timeStr: string, needSecond?: boolean): Date;
    /**
     * Wraps Angular's `formatDate` — accepts the same format strings as the `date` pipe.
     * Returns an empty string if the input is invalid instead of throwing.
     *
     * @example
     *   DateUtils.formatDate('2026-03-27T10:30:00Z', 'mediumDate')    // 'Mar 27, 2026'
     *   DateUtils.formatDate('2026-03-27T10:30:00Z', 'short')         // '3/27/26, 10:30 AM'
     *   DateUtils.formatDate('2026-03-27T10:30:00Z', 'MMM d, h:mm a') // 'Mar 27, 10:30 AM'
     */
    static formatDate(dateStr: string, format?: string, locale?: string): string;
    private static readonly _mediumFormatter;
    private static getTzAbbr;
    static formatWithTzAbbr(value: string | Date | number, formatter?: Intl.DateTimeFormat): string;
    /**
     * `<input type="date">` yields a bare "yyyy-MM-dd" with no offset. Only the frontend knows
     * the viewer's real offset, so these resolve the ambiguity here and send precise instants:
     * `new Date(\`${d}T00:00:00\`)` parses as browser-local midnight and `.toISOString()` carries
     * that instant's UTC offset through to the wire.
     *
     * Shared by every keyset-paged search filter bar (Audit Trail, Langfuse Sessions) — the
     * backend's ComputeDateBounds trusts these as instants rather than re-deriving a calendar day.
     */
    static toDateFromBound(date?: string): string | undefined;
    /** Local midnight at the START of the day AFTER `date` — the exclusive upper bound the
     * backend needs, since an inclusive "<=" on the selected day's own midnight would exclude
     * virtually the whole day. */
    static toDateToBound(date?: string): string | undefined;
}

declare const DUPLOCONST: {
    sso_url_suffix: string;
    ossec_agent_type: string;
    cloud_resource_prefix: string;
};
declare const TENANT_CONSTS: {
    default_tenant_name: string;
};
declare const DUPLO_CUSTOM_EVENTS: {
    sidebarToggle: string;
};

declare const DARK_CHART_FAINT_LINE = "rgba(255, 255, 255, 0.08)";
/** Dark ECharts theme from the live tokens, layered onto `base`; call it after <html data-theme> is dark. */
declare function duploDarkEchartsTheme(base?: ThemeOption): ThemeOption;
/** Westros with its light-only grounds (tooltip, axis shadow, dataZoom) swapped for dark ones. */
declare function westrosDarkEchartsTheme(): ThemeOption;

interface EnumMapOfString<V> {
    [index: string]: V;
}
interface EnumMapOf<V> {
    [index: number]: V;
}
interface EnumMapName<V> {
    [index: string]: V;
}
interface EnumSelectOption<E> {
    value: E;
    label: string;
}
interface NumberSelectOption {
    label: string;
    value: number;
}
interface StringSelectOption {
    label: string;
    value: string;
    subLabel?: string;
}
declare class EnumUtils {
    static SKIP_ENTRY: symbol;
    /**
     * Maps enum entries to a new map, keyed by enum key.
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static mapByKey<T extends Record<StringKeyOf<T>, number>, R>(enumObj: T, mapper: (key: StringKeyOf<T>, value?: number) => R): EnumMapName<R>;
    /**
     * Maps enum entries to a new map, keyed by string key.
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static mapByStringKey<T extends Record<StringKeyOf<T>, string>, R>(enumObj: T, mapper: (key: StringKeyOf<T>, value?: string) => R): EnumMapOfString<R>;
    /**
     * Maps enum entries to a new map, keyed by numeric value.
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static mapByValue<T extends Record<StringKeyOf<T>, number>, R>(enumObj: T, mapper: (key: StringKeyOf<T>, value?: number) => R): EnumMapOf<R>;
    /**
     * Maps enum entries to a new map, keyed by string value.
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static mapByStringValue<T extends Record<StringKeyOf<T>, string>, R>(enumObj: T, mapper: (key: StringKeyOf<T>, value?: string) => R): EnumMapOfString<R>;
    static enumToSelectOptions(enumObj: object): NumberSelectOption[];
    /**
     * Maps an enum value map to select options
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static byValueToSelectOptions<E, V>(valueMap: EnumMapOf<V>): EnumSelectOption<E>[];
    /**
     * Maps an enum value map to select options
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static byStringValueToSelectOptions<E, V>(valueMap: EnumMapOfString<V>): EnumSelectOption<E>[];
    static convertToSelectOptions(s: object): object[];
}

declare class FilterTableUtils {
    static searchByFields: (item: any, keys: string[], searchTerm: any) => boolean;
    static searchInAllFields: (item: any, searchTerm: any) => boolean;
    static getObjectValuesAsStringArray: (obj: any, accu: string[]) => void;
}

declare class JSONUtils {
    static clone(d: any): any;
    static fullClone<T>(d: T): T;
    static isEmptyObject(o: any): boolean;
    static isNotEmptyObject(o: any): boolean;
    static moveAttributeIfExists(source: object, dest: object, attr: string): void;
    static deleteIfExists(o: object, key: any): any;
    static merge(source: object, toBeMerged: object): {};
    static getAndDeletePropertyIfExists(o: any, key: string): string;
    static stringifyPretty(s: any): any;
    static stringifyCompact(s: any): any;
    static isValidJSON(s: string): boolean;
    static parse(s: string): any;
    /**
     * Like parse() but does NOT strip non-ASCII characters (e.g. emoji).
     * Use when the input may contain Unicode beyond printable ASCII.
     */
    static parseSafe(s: string): any;
    static setObjectIfNotEmpty(mainObject: any, key: string, toBeMerged: any): void;
    static setIfNotEmpty(mainObject: any, key: string, toBeMerged: any): any;
    static removeEmptyKeys(obj: any): {};
    static omitPrivate(obj: any): any;
    static isMatchingClass<T>(json: string | any, ClassType: new () => T, options?: {
        checkTypes?: boolean;
        strict?: boolean;
        partial?: boolean;
    }): boolean;
    /**
     * Recursively compares two objects.
     */
    static deepCompare(parsed: any, instance: any, options?: {
        checkTypes?: boolean;
        strict?: boolean;
        partial?: boolean;
    }): boolean;
}

/**
 * Builds the `MARKED_OPTIONS` value for `MarkdownModule.forRoot()`, with one
 * renderer override: links open in a new tab, focusable, with
 * `nofollow noopener noreferrer`.
 *
 * Provide it at the app root only, e.g.
 *   MarkdownModule.forRoot({
 *     markedOptions: { provide: MARKED_OPTIONS, useFactory: markedOptionsFactory }
 *   })
 */
declare function markedOptionsFactory(): {
    renderer: marked.Renderer<string, string>;
    gfm: boolean;
    breaks: boolean;
    pedantic: boolean;
};
/**
 * Rewrites the tokens of one versions-view parse in place, before marked renders them:
 * - raw HTML (block and inline — both `html` tokens) becomes a text token, which marked escapes;
 * - an image becomes a link labelled with its alt text (the URL when there is none) when its
 *   source is `https:`, and plain alt text otherwise.
 *
 * A token walk rather than renderer overrides: ngx-markdown passes every parse's renderer to the
 * global `marked.use()`, so an overridden `image`/`html` would outlive this parse and change every
 * other <markdown> in the app. `walkTokens` passed as a parse option applies to that call only.
 */
declare function neutralizeReleaseNoteTokens(token: Token): void;
/**
 * `MARKED_OPTIONS` for third-party release notes (the Marketplace versions view). Starts from
 * {@link markedOptionsFactory} — same link rules — and adds:
 *
 * 1. `breaks: true` — plain-text changelogs keep their single-newline line breaks.
 * 2. Markdown images never become `<img>` (see {@link neutralizeReleaseNoteTokens}), so nothing is
 *    fetched until the user clicks.
 * 3. Raw HTML renders HTML-escaped. Angular's sanitizer strips `on*=` but keeps a plain
 *    `<img src>`, which would still load a tracking pixel.
 *
 * Provide it on a component-level `MarkdownService` only; the root instance keeps
 * {@link markedOptionsFactory}.
 */
declare function versionMarkedOptionsFactory(): {
    breaks: boolean;
    walkTokens: typeof neutralizeReleaseNoteTokens;
    renderer: marked.Renderer<string, string>;
    gfm: boolean;
    pedantic: boolean;
};

declare const UI_CONFIG_DEFAULTS: {
    labels: {};
    helpMenu: {};
    'ai-menu': {
        hiddenIds: string[];
        order: Record<string, number>;
    };
    theme: {
        switcher: boolean;
        default: string;
    };
    links: {
        docsBase: string;
        helpTextJson: string;
        awsIntegrationTemplate: string;
        jitReleases: string;
        docs: {};
    };
};
/** Logo keys with an optional `<key>Dark` sibling in config.json `images`. */
type ThemedImageKey = 'headerLogoImage' | 'splashLogoImage';
/**
 * `undefined` falls back to the bundled default; `null` is kept and means "off".
 * Read leaf paths: an object read returns the configured object as-is, without filling missing keys from defaults.
 */
declare function getUiConfig<T = unknown>(path: string): T;
/** Mirrors resolveDarkImage in src/assets/ui-config.js: explicit `<key>Dark`, else stock dark while `<key>` is stock. */
declare function resolveDarkImage(key: ThemedImageKey): string | null;
declare function brandTitle(): string;
declare function isCustomBrand(): boolean;
declare function brandText(template: string): string;
/** Exact, case-insensitive whole-label override from config.json `labels`. */
declare function resolveLabel(label: string): string;
/**
 * One-release glue: the legacy "AI Suite Label Config" fills config.json `labels` when that is empty. Never throws.
 * TODO(DUPLOAI-3860): remove next release.
 */
declare function applyLegacyLabels(appConfigs: unknown): void;
/** The trimmed string, or null for a blank or non-string config value. */
declare function nonEmptyString(value: unknown): string | null;
/** Named in-app docs links and their default paths under `links.docsBase`. */
declare const DOCS_LINKS: {
    readonly awsJit: "/aws/use-cases/jit-access#access-using-the-command-line";
    readonly awsBilling: "/aws/use-cases/cost-management";
    readonly licenseUsage: "/aws/use-cases/cost-management/duplocloud-license-usage";
    readonly iamRoleAws: "/getting-started/integrating-providers/amazon-web-services-aws";
    readonly iamRoleEks: "/getting-started/integrating-providers/amazon-elastic-kubernetes-service-eks";
    readonly kubectlShell: "/aws/prerequisites/kubectl-shell";
    readonly productUpdates: "/product-updates";
    readonly faqs: "/faqs";
    readonly documentation: "/";
    readonly docsHome: "";
};
type DocsLinkName = keyof typeof DOCS_LINKS;
/** `links.docs.<name>` wins (full URL; `null` hides it); otherwise `docsBase` + the default path. */
declare function docsLink(name: DocsLinkName): string | null;
/** `<a>` HTML for a docs link, escaped; null when the link is off or not http(s). */
declare function docsLinkHtml(name: DocsLinkName): string | null;

/**
 * Subscribes to NavigationStart events on the given Router and dismisses all
 * open modals managed by the given NgbModal instance.
 *
 * ### Why this function exists (Module Federation context)
 * When `@ng-bootstrap/ng-bootstrap` is NOT declared as a shared singleton in
 * webpack-shared-lib.js, each Module Federation bundle (host + remotes) gets
 * its own independent NgbModal instance. A single `providedIn: 'root'` service
 * cannot cover both — it can only hold one NgbModal reference.
 *
 * The solution is for each bundle to call this function with its own NgbModal,
 * while sharing the same Router singleton (which IS shared via webpack-shared-lib).
 *
 * ### Usage
 * Call once on application/module init and unsubscribe on destroy:
 *
 * ```typescript
 * // In AppComponent or a root NgModule constructor:
 * this._navSub = closeModalsOnNavigation(this._router, this._modalService);
 *
 * // In ngOnDestroy / module cleanup:
 * this._navSub.unsubscribe();
 * ```
 *
 * @param router       The Angular Router (shared singleton across MF bundles).
 * @param modalService The NgbModal instance local to the current bundle.
 * @returns A Subscription — unsubscribe it when the calling context is destroyed.
 */
declare function closeModalsOnNavigation(router: Router, modalService: NgbModal): Subscription;

declare class NameUtils {
    static resourceLengthConstraint: {
        s3BucketName: {
            allowedLength: number;
            prefixLength: number;
        };
        lambdaFunctionName: {
            allowedLength: number;
            prefixLength: number;
        };
        elasticSearchDomainName: {
            allowedLength: number;
            prefixLength: number;
        };
        loadBalancerName: {
            allowedLength: number;
            prefixLength: number;
        };
        bigtableInstanceId: {
            allowedLength: number;
            prefixLength: number;
        };
        bigtableClusterId: {
            allowedLength: number;
            prefixLength: number;
        };
    };
    /** Convenience method for feeding a notExists validation.
     *
     *  Returns a list of names *BOTH* with the prefix remove and the prefix present.
     */
    static withAndWithout(prefix: string, list: string[]): string[];
    /** Convenience method for feeding a notExists validation.
     *
     *  Returns a list of names that also includes name versions that have the prefix removed.
     */
    static withAndWithoutDuploServices(tenant: string | UserTenant, list: string[]): string[];
    static fieldAllowedLength(fieldName: string, tenantName: string, allowed?: number, noPrefix?: boolean): number;
}

declare const REMOTE_ENTRY_CACHE_TAG: string;
declare function withCacheTag(url: string): string;
declare function extensionRemoteEntry(remoteEntry: string, apiUrl: string | null | undefined, version?: string | null): string;

/** Segment depth of the shared `view/:envId/rg/:rgId` prefix every flat full-page
 * resource route is declared under — used as `route.url.length - ENV_RG_PREFIX_DEPTH`
 * to strip a matched flat route back to that prefix before appending the real list path. */
declare const ENV_RG_PREFIX_DEPTH = 4;
/**
 * Navigates up out of the route that failed to resolve — typically back to
 * a resource's list page — instead of leaving the router parked on a broken
 * `view/:id` (or similar) url with no way back. Call this from a resolver's
 * `catchError` alongside `return EMPTY`.
 *
 * `segments` is the number of trailing URL segments to strip, at raw segment
 * granularity — Angular's `../` resolution only escalates to the parent
 * route once `segments` exceeds the current route's own segment count, so a
 * single flat multi-segment route (e.g. `view/:envId/rg/:rgId/app-services/:asId/edit`
 * declared as ONE `Route`) can be partially unwound to land mid-route (back
 * to `.../app-services`) by passing `route.url.length - ENV_RG_PREFIX_DEPTH`.
 *
 * Defaults to `route.url.length`, which strips this route's own segments in
 * full and lands on its immediate parent — correct whenever the resolver's
 * route is a genuine sibling of the page to land on (`view/:id`, `edit/:id`,
 * `:id/ticket/:ticketId`, ...).
 *
 * `appendPath`, when the real list page isn't a sibling at all — e.g. a
 * flat full-page route declared under a different segment name than its
 * embedded counterpart (`.../node-groups/:ngId/edit` vs. the real list at
 * `.../kubernetes-resources/nodes`). Pass the shared-prefix segment count to
 * strip plus the literal path to land on instead.
 */
declare function redirectToParentOnError(router: Router, route: ActivatedRouteSnapshot, segments?: number, appendPath?: string): void;

declare class StringUtils {
    static isEmpty(s: string): boolean;
    static isNotEmpty(s: string): boolean;
    static safetrim(s: string): string;
    static awsUrlEncode(s: string): string;
    static doubleEncode(s: string): string;
    static urlSafeBase64Encode(s: string): string;
    static toFirstLetterUpperCase(s: string): string;
    static removeSpacesInString(srcString: string): string;
    /**
     * The first `limit` characters plus an ellipsis, cut at a word boundary when one
     * falls in the last fifth of the allowance so the tail is not a broken word.
     * Text that already fits comes back untouched, which is how a cell decides
     * whether it needs to offer the full value on hover.
     */
    static truncate(text?: string, limit?: number): string;
    /**
     * Up to `cap` values spelled out, the rest as `+N`, so a summary hint cannot run
     * away. A narrow cell (four cards across a modal) passes a lower cap.
     */
    static truncatedList(values: string[], cap?: number): string;
    /**
     * `6 created · 2 imported`, dropping the parts that are zero — a bucket with
     * nothing in it is noise, not information.
     */
    static summaryLine(parts: [number, string][]): string;
    /** The `n` most frequent values as summaryLine parts; ties break alphabetically. */
    static topCounts(values: string[], n?: number): [number, string][];
    /**
     * The word for `count` things: `singular` for exactly one, else `plural` (the singular plus
     * `s` unless given). Just the word, so the caller places the number: `${n} ${pluralize(n, 'rule')}`.
     */
    static pluralize(count: number, singular: string, plural?: string): string;
    static splitByCapitalLetter(s: string): string;
}

declare class YamlUtils {
    /**
     * Returns the yaml string for the specified json string
     * @param s JSON in string format
     * @returns
     */
    static jsonStringToYaml(s: any): any;
    /**
     *
     * @param y Parse the yaml string into javascript object
     * @returns
     */
    static parse(y: string): any;
    /**
     *  Converts and returns specified javascript object into the yaml string
     * @param o
     * @returns
     */
    static stringify(o: any): string;
    /**
     * Converts yaml string into json string
     *
     * @param y
     * @returns
     */
    static yamlToJsonString(y: string): string;
    /**
     * Parse the yaml string into javascript object after safe trim.
     * Similar to parse with *StringUtils.safetrim* added.
     *
     * @param y
     * @returns
     */
    static parseSafeTrim(y: string): any;
}

/**
 * Renders a declarative resource view template. One sub-tab per group (via ngbNav)
 * with fields rendered by <app-field-renderer>. Pure presentation — all data
 * access goes through `resolvePath` utilities.
 *
 * Fields of type `single` are grouped into a responsive tile grid at the top of
 * each sub-panel; other field types follow.
 */
declare class ResourceTemplateViewComponent implements OnChanges {
    template?: ResourceViewTemplate | null;
    /**
     * Opt in to the refreshed tile/table styling. Off by default: this renderer is
     * shared by many resource views, and none of them asked to change appearance.
     */
    refreshedStyle: boolean;
    data: any;
    menuAction: EventEmitter<MenuActionEvent>;
    activeGroup: string;
    ngOnChanges(changes: SimpleChanges): void;
    trackByIndex(i: number): number;
    /** Visible groups — hides any group whose `hideWhen` predicate matches the data. */
    visibleGroups(): TemplateGroup[];
    singleFields(group: TemplateGroup): TemplateField[];
    fullWidthSingleFields(group: TemplateGroup): TemplateField[];
    otherFields(group: TemplateGroup): TemplateField[];
    /** True when the data satisfies the predicate (i.e. the field/group should be hidden). */
    private matchesHideWhen;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResourceTemplateViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ResourceTemplateViewComponent, "app-resource-template-view", never, { "template": { "alias": "template"; "required": false; }; "refreshedStyle": { "alias": "refreshedStyle"; "required": false; }; "data": { "alias": "data"; "required": false; }; }, { "menuAction": "menuAction"; }, never, never, false, never>;
}

/** One rendered key→value row in a `keyvalue` field. */
interface KvRow {
    key: string;
    display: string;
    copyText: string;
    isComplex: boolean;
    isEmpty: boolean;
    raw: any;
}
/**
 * Renders one template field against the passed `data`. Switches on `field.type`:
 *   single   → labeled tile (clickable when `details` + `detailSource` are set)
 *   multi    → pill list
 *   table    → Bootstrap table (with optional filter + nested-path columns + drilldown)
 *   keyvalue → read-only key→value rows (scalar = inline + copy; nested = preview + "More")
 *   raw      → collapsible JSON viewer
 *
 * Both SingleField and TableField share the same `FieldDetails` drilldown config
 * and the same modal-opening logic via `openDetailModal()`.
 */
declare class FieldRendererComponent implements OnInit, OnChanges {
    private modalService;
    private clipboardService;
    private success;
    private viewDataModal;
    private detailModal;
    field: TemplateField;
    data: any;
    subTemplates?: Record<string, SubTemplate>;
    menuAction: EventEmitter<MenuActionEvent>;
    rawOpen: boolean;
    showSensitive: boolean;
    /** Built once per input change: rebuilding per check recreated the rows' DOM and swallowed clicks on More. */
    kvRowList: KvRow[];
    toggleSensitive(event: MouseEvent): void;
    cardMenus(): MenuAction[] | undefined;
    onRowMenu(event: MouseEvent, menuId: string, row: any): void;
    onCardMenu(event: MouseEvent, menuId: string): void;
    constructor(modalService: NgbModal, clipboardService: ClipboardService, success: SuccessReporter, viewDataModal: ViewDataModalService, detailModal: Type<unknown>);
    ngOnInit(): void;
    ngOnChanges(): void;
    trackByKvKey(_: number, row: KvRow): string;
    asSingle(): SingleField;
    asMulti(): MultiField;
    asTable(): TableField;
    asRaw(): RawField;
    asKv(): KeyValueField;
    singleValue(): string;
    /** Copy the single field's resolved value to the clipboard (used when the field has `copy: true`). */
    copySingle(event: MouseEvent): void;
    multiItems(): string[];
    tableRows(): any[];
    cellValue(row: any, colKey: string): string;
    hasSingleDetail(): boolean;
    openSingleDetail(): void;
    rawJson(): string;
    /** Parsed object for the JSON viewer (null-stripped); `{}` when nothing resolves. */
    rawObject(): any;
    private static readonly KV_PREVIEW_MAX;
    /** Read-only key→value rows for a `keyvalue` field. Empty when the source is
     *  missing or not an object (the template renders a "No data" line instead). */
    private kvRows;
    private toKvRow;
    openKvDetail(row: KvRow): void;
    private stripNulls;
    toggleRaw(): void;
    openDetail(row: any, field: TableField): void;
    private openDetailModal;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldRendererComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FieldRendererComponent, "app-field-renderer", never, { "field": { "alias": "field"; "required": false; }; "data": { "alias": "data"; "required": false; }; "subTemplates": { "alias": "subTemplates"; "required": false; }; }, { "menuAction": "menuAction"; }, never, never, false, never>;
}

/**
 * Generic detail popup opened when the user clicks a drillable table row.
 * Renders sub-template groups with the row object as the data context (`{ row }`),
 * so all field paths in sub-templates use the `row.*` prefix.
 */
declare class ResourceDetailModalComponent {
    modal: NgbActiveModal;
    title: string;
    subtitle?: string;
    row: any;
    groups: TemplateGroup[];
    subTemplates?: Record<string, SubTemplate>;
    activeGroup: string;
    get rowData(): any;
    constructor(modal: NgbActiveModal);
    singleFields(g: TemplateGroup): TemplateField[];
    otherFields(g: TemplateGroup): TemplateField[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ResourceDetailModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ResourceDetailModalComponent, "app-resource-detail-modal", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "row": { "alias": "row"; "required": false; }; "groups": { "alias": "groups"; "required": false; }; "subTemplates": { "alias": "subTemplates"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ResourceTemplateViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ResourceTemplateViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ResourceTemplateViewModule, [typeof ResourceTemplateViewComponent, typeof FieldRendererComponent, typeof ResourceDetailModalComponent], [typeof i3.CommonModule, typeof CoreCommonModule, typeof i28.BlockUIModule, typeof SharedFormsModule, typeof i3$2.NgbModule, typeof i9.MatIconModule, typeof IconModule, typeof SpinnerComponent, typeof AILabelConfigPipe, typeof CommonLibComponentsModule, typeof YamlSnippetEditorComponent], [typeof ResourceTemplateViewComponent, typeof FieldRendererComponent, typeof ResourceDetailModalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ResourceTemplateViewModule>;
}

declare const RESOURCE_DETAIL_MODAL: InjectionToken<Type<unknown>>;

/**
 * Walks a dot-path into `obj`.
 *
 *   resolvePath({result: {vpc: {vpcId: 'vpc-1'}}}, 'result.vpc.vpcId') // 'vpc-1'
 *   resolvePath({result: {subnets: [{id:'a'},{id:'b'}]}}, 'result.subnets.1.id') // 'b'
 *
 * The caller passes the root object (e.g. `{ result: network.result }`), so
 * template paths walk as written — no prefix stripping.
 */
declare function resolvePath(obj: any, dotPath: string): any;
/**
 * Resolve a `single` field's display value. Supports `isTemplate:true` for
 * `{dot.path}:{other.path}` interpolation and `suffix` appending.
 */
declare function resolveSingle(data: any, field: {
    value: string;
    isTemplate?: boolean;
    suffix?: string;
}): string;
/**
 * Resolve a `table` or `multi` source into an array. Applies `sourceType:'map'`
 * projection and `filter:{field, value}` pruning.
 */
declare function resolveSource(data: any, field: {
    source: string;
    sourceType?: 'map' | 'wrap' | 'nested';
    flatten?: string;
    filter?: {
        field: string;
        value: any;
    };
}): any[];
/**
 * Nested dot-path lookup on a table row. Column keys like `Ebs.VolumeId` or
 * `resources.requests.cpu` resolve through the row.
 *
 * Supports `||`-separated fallback paths: the first path that resolves to a
 * non-null, non-empty value wins. Example:
 *   `status.containerStatuses.0.state.waiting.reason||status.phase`
 */
declare function resolveRowValue(row: any, colKey: string): string;

interface ShellHeaderTag {
    label: string;
    value: string;
}
interface ShellSidecard {
    featherIcon: string;
    label: string;
    value: string;
    valueSuffix?: string;
    /** When set, renders the value as a pill badge with this Bootstrap color class (e.g. 'success', 'danger'). */
    badgeClass?: string;
    /** Wraps the value instead of truncating it, for values users copy (e.g. endpoints). */
    wrap?: boolean;
}
/** A sidecard with its tooltip resolved: the full value, or '' when it wraps. */
interface ShellSidecardRow extends ShellSidecard {
    tooltip: string;
}
declare class RcBaselineResourceViewShellComponent implements OnInit, OnChanges {
    readonly ResourceStatus: typeof ResourceStatus;
    private readonly analytics;
    /** Analytics are DevOps-only: nothing is sent unless the host opts in. */
    trackAnalytics: boolean;
    resourceType?: string;
    trackPageView: boolean;
    featherIcon: string;
    name: string;
    description?: string;
    headerTags: ShellHeaderTag[];
    /**
     * When true, the caller projects its own main-panel content via `slot="raw-main"`
     * and the shell suppresses the stock Spec/Result toggle + inner Spec-tab wrapper.
     * Default false — RDS / ElastiCache / view-rds-cluster use the stock rendering.
     */
    customMainPanel: boolean;
    extraSidecards: ShellSidecard[];
    statusLabel: string;
    attachedTitle: string;
    attachedRows: DetailCountRow[];
    /** Off: attached values wrap instead of truncating (e.g. subnet IDs). */
    attachedTruncate: boolean;
    status: ResourceStatus;
    badgeClass: string;
    badgeLabel: string;
    blockedReason?: string;
    subStatus?: string;
    isAnimating: boolean;
    /** Resource-specific condition the caller wants plated (e.g. a live health check result)
     *  — rendered only when there's nothing stronger to say: an approval/blocked state from
     *  the platform's own lifecycle always wins over it. Default null — existing consumers
     *  are unaffected. */
    extraCallout: DetailCallout | null;
    readyLabel: string;
    deprovisionedLabel: string;
    createdAt?: string;
    updatedAt?: string;
    activePanel: 'spec' | 'result';
    activePanelChange: EventEmitter<"spec" | "result">;
    panelFilters: FlatStatusFilter[];
    showResultFilter: boolean;
    /**
     * Adds a "Metadata" tab alongside "Spec" in the Spec panel, fed by
     * `slot="metadata-content"`. Default false — opt in per resource type;
     * existing consumers are unaffected.
     */
    showMetadataTab: boolean;
    viewTemplate: ResourceViewTemplate | null;
    templateData: {
        result: any;
    };
    /**
     * Set true when the caller projects custom content via `[slot=result-content]`
     * (e.g. Azure Storage PE list) instead of using the generic template view.
     * Keeps the slot projection opt-in so existing consumers are unaffected.
     */
    customResultContent: boolean;
    provisioningTicket?: {
        name?: string;
    };
    showEditAction: boolean;
    showBackButton: boolean;
    /** Show the Deprovision action regardless of whether a provisioning ticket exists.
     *  Set to true for directly-provisioned resources (ConfigMap, Secret) that have no ticket. */
    showDeprovisionAction: boolean;
    /** Suppress the Deprovision action even when a provisioning ticket is bound. Used by
     *  flows where the resource has no real cloud-deprovision path (e.g. Terraform: destroy
     *  lives behind the ticket action menu, not the shell kebab). */
    hideDeprovisionAction: boolean;
    /** Disables the Deprovision action (e.g. delete-protection metadata) without hiding it. */
    deprovisionDisabled: boolean;
    /** Tooltip shown on the Deprovision action while {@link deprovisionDisabled} is true. */
    deprovisionDisabledReason: string | null;
    /** The page creates a ticket on diagnoseClick, so Ask the Agent shows without one once
     *  the resource is past New. */
    canCreateTicket: boolean;
    /** Created without an agent ticket, so a bound ticket is a diagnostic one: Ask the Agent
     *  opens it, but it drives neither Track Status nor Deprovision. */
    provisionedDirectly: boolean;
    /** Hide the Track Status button entirely. Set for logical resources
     *  that never provision via an agent ticket (e.g. a Kubernetes-only Resource Group). */
    hideProvisioningButton: boolean;
    backClick: EventEmitter<void>;
    openTicketClick: EventEmitter<void>;
    deprovisionClick: EventEmitter<void>;
    editClick: EventEmitter<void>;
    diagnoseClick: EventEmitter<void>;
    menuAction: EventEmitter<MenuActionEvent>;
    /** Fires when the kebab (`⋮`) dropdown itself opens/closes — for callers that project
     *  their own stateful sub-menus (e.g. a cascade) via `shell-menu-actions` and need to
     *  reset that state when the kebab is dismissed by an outside click. */
    menuOpenChange: EventEmitter<boolean>;
    private header?;
    activeSpecTab: string;
    /** Status chip beside the name. */
    headerBadges: DetailBadge[];
    /** extraSidecards with their tooltips. */
    sidecardRows: ShellSidecardRow[];
    /** Provisioning lifecycle, newest step first. */
    timelineEvents: DetailTimelineEvent[];
    /** Label for the timeline's button; '' hides it. */
    trackLabel: string;
    /** Whether the header shows the Ask the Agent button. */
    showAgentButton: boolean;
    /** Whether the kebab offers Deprovision. */
    deprovisionVisible: boolean;
    /** The one condition worth a plate, or null. */
    callout: DetailCallout | null;
    /**
     * Whether the sub-status plate has anything to show. isAnimating alone is not
     * enough: app-sub-status-display renders nothing without text, so the plate
     * would be an empty framed box.
     */
    showSubStatus: boolean;
    ngOnInit(): void;
    ngOnChanges(): void;
    onEdit(): void;
    /** Without a ticket the host creates one and fires `ask-agent` itself on success. */
    onAskAgent(): void;
    onTrackStatus(): void;
    /** Names mirror DevopsPages/DevopsEvents; common-lib can't import `environment/`. */
    private track;
    trackBySidecardLabel(_: number, card: ShellSidecardRow): string;
    /** The tooltip only repeats the value, so it opens only when an ellipsis hides some of
     *  it — on the value itself or on its pill, which truncates on its own. */
    openIfTruncated(tooltip: NgbTooltip, value: HTMLElement): void;
    /** Closes the kebab — for callers whose projected `shell-menu-actions` content
     *  clicks (e.g. a cascade's Read-only/Read-write choice) don't close it on their own.
     *  `autoClose="outside"` only auto-closes on a click outside the menu, not on a click
     *  on a projected item, regardless of whether that item is `ngbDropdownItem`. */
    closeMenu(): void;
    private refreshDerived;
    /** Bootstrap badge class -> the detail-header's badge vocabulary. */
    private static readonly BADGE_KINDS;
    private buildSidecardRows;
    private buildHeaderBadges;
    /**
     * Newest step first: Ready (or Deprovisioned), the step in flight, then Created.
     */
    private buildTimeline;
    /** '' hides the button. Some resources never provision by ticket. */
    private buildTrackLabel;
    /** Hidden while New: a ticket opened then races the provisioning one or stalls the Worker. */
    private buildShowAgentButton;
    private buildDeprovisionVisible;
    /** Carries the copy the old footer strip showed under the main panel. */
    private buildCallout;
    get isWaitingForApproval(): boolean;
    get isBlocked(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<RcBaselineResourceViewShellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RcBaselineResourceViewShellComponent, "app-rc-baseline-resource-view-shell", never, { "trackAnalytics": { "alias": "trackAnalytics"; "required": false; }; "resourceType": { "alias": "resourceType"; "required": false; }; "trackPageView": { "alias": "trackPageView"; "required": false; }; "featherIcon": { "alias": "featherIcon"; "required": false; }; "name": { "alias": "name"; "required": false; }; "description": { "alias": "description"; "required": false; }; "headerTags": { "alias": "headerTags"; "required": false; }; "customMainPanel": { "alias": "customMainPanel"; "required": false; }; "extraSidecards": { "alias": "extraSidecards"; "required": false; }; "statusLabel": { "alias": "statusLabel"; "required": false; }; "attachedTitle": { "alias": "attachedTitle"; "required": false; }; "attachedRows": { "alias": "attachedRows"; "required": false; }; "attachedTruncate": { "alias": "attachedTruncate"; "required": false; }; "status": { "alias": "status"; "required": false; }; "badgeClass": { "alias": "badgeClass"; "required": false; }; "badgeLabel": { "alias": "badgeLabel"; "required": false; }; "blockedReason": { "alias": "blockedReason"; "required": false; }; "subStatus": { "alias": "subStatus"; "required": false; }; "isAnimating": { "alias": "isAnimating"; "required": false; }; "extraCallout": { "alias": "extraCallout"; "required": false; }; "readyLabel": { "alias": "readyLabel"; "required": false; }; "deprovisionedLabel": { "alias": "deprovisionedLabel"; "required": false; }; "createdAt": { "alias": "createdAt"; "required": false; }; "updatedAt": { "alias": "updatedAt"; "required": false; }; "activePanel": { "alias": "activePanel"; "required": false; }; "panelFilters": { "alias": "panelFilters"; "required": false; }; "showResultFilter": { "alias": "showResultFilter"; "required": false; }; "showMetadataTab": { "alias": "showMetadataTab"; "required": false; }; "viewTemplate": { "alias": "viewTemplate"; "required": false; }; "templateData": { "alias": "templateData"; "required": false; }; "customResultContent": { "alias": "customResultContent"; "required": false; }; "provisioningTicket": { "alias": "provisioningTicket"; "required": false; }; "showEditAction": { "alias": "showEditAction"; "required": false; }; "showBackButton": { "alias": "showBackButton"; "required": false; }; "showDeprovisionAction": { "alias": "showDeprovisionAction"; "required": false; }; "hideDeprovisionAction": { "alias": "hideDeprovisionAction"; "required": false; }; "deprovisionDisabled": { "alias": "deprovisionDisabled"; "required": false; }; "deprovisionDisabledReason": { "alias": "deprovisionDisabledReason"; "required": false; }; "canCreateTicket": { "alias": "canCreateTicket"; "required": false; }; "provisionedDirectly": { "alias": "provisionedDirectly"; "required": false; }; "hideProvisioningButton": { "alias": "hideProvisioningButton"; "required": false; }; }, { "activePanelChange": "activePanelChange"; "backClick": "backClick"; "openTicketClick": "openTicketClick"; "deprovisionClick": "deprovisionClick"; "editClick": "editClick"; "diagnoseClick": "diagnoseClick"; "menuAction": "menuAction"; "menuOpenChange": "menuOpenChange"; }, never, ["[shell-menu-actions]", "[shell-primary-actions]", "[slot=raw-main]", "[slot=spec-content]", "[slot=metadata-content]", "[slot=result-content]"], false, never>;
}

declare class SubStatusDisplayComponent implements AfterViewInit, OnChanges, OnDestroy {
    private zone;
    private cdr;
    subStatus?: string;
    /** Shows the pulse while the status is still changing. */
    isAnimating: boolean;
    /** Unique per instance, so two on one page cannot share a checkbox. */
    readonly toggleId: string;
    /** Whether there is any text; blank or whitespace-only renders nothing, pulse included. */
    hasText: boolean;
    /** Whether five lines were not enough — the only measured value here. */
    clamped: boolean;
    private static nextId;
    private textEl?;
    private toggleEl?;
    private observer?;
    private observedEl?;
    constructor(zone: NgZone, cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private observe;
    /**
     * Expanded, the clamp is released and scrollHeight equals clientHeight, which
     * would read as "fits" and hide the control that collapses it again. So the
     * measurement only runs while collapsed.
     */
    private measure;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubStatusDisplayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubStatusDisplayComponent, "app-sub-status-display", never, { "subStatus": { "alias": "subStatus"; "required": false; }; "isAnimating": { "alias": "isAnimating"; "required": false; }; }, {}, never, never, true, never>;
}

declare class RcBaselineResourceViewShellModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RcBaselineResourceViewShellModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RcBaselineResourceViewShellModule, [typeof RcBaselineResourceViewShellComponent], [typeof i3.CommonModule, typeof CoreCommonModule, typeof i28.BlockUIModule, typeof SharedFormsModule, typeof i3$2.NgbModule, typeof i9.MatIconModule, typeof IconModule, typeof SpinnerComponent, typeof AILabelConfigPipe, typeof CommonLibComponentsModule, typeof YamlSnippetEditorComponent, typeof ResourceTemplateViewModule, typeof SubStatusDisplayComponent], [typeof RcBaselineResourceViewShellComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RcBaselineResourceViewShellModule>;
}

/**
 * Whether a resource's platform-level status represents an in-flight lifecycle transition
 * (initial provisioning, or an already-requested deprovision) rather than a settled state
 * (Complete/Failed/DeProvisioned/etc.). Used to gate list-row actions like Deprovision so a
 * resource mid-transition can't be acted on again concurrently.
 */
declare function isResourceInFlight(status: ResourceStatus): boolean;
/** A deprovision has been requested: queued, running, failed or finished. */
declare function isDeprovisionStatus(status: string | null | undefined): boolean;
/** Names for the timeline's target step, for resources whose badges word them differently. */
interface LifecycleTargetLabels {
    ready?: string;
    deprovisioned?: string;
}
/**
 * Provisioning-rail timeline, newest step first: the target step, the step in flight,
 * then Created. The target is Ready, or Deprovisioned once a deprovision is requested.
 * Once reached, the target *is* the current step, so no in-flight row is added.
 */
declare function buildLifecycleTimeline(status: string | null | undefined, currentLabel: string | null | undefined, createdAt?: string | null, updatedAt?: string | null, targets?: LifecycleTargetLabels): DetailTimelineEvent[];
/** Medium local date, or '' — the timeline would otherwise print 'Invalid Date'. */
declare function formatTimelineDate(value?: string | null): string;
declare const TICKET_POLL_TIMEOUT_MS = 30000;
/**
 * Repeats `lookup` until it returns a named ticket, letting a slow lookup finish instead of
 * cancelling it. Emits null if none appears within {@link TICKET_POLL_TIMEOUT_MS}.
 */
declare function pollForTicket<T extends {
    name?: string;
}>(lookup: () => Observable<T | null>): Observable<T | null>;

/**
 * Inline "masked value + reveal eye icon" for a secret the server never includes in its normal
 * GET/List response (e.g. an RDS master password or ElastiCache auth token hidden behind
 * `[SecretValue(ExcludeFromResponse = true)]`). Purely presentational: it owns only the
 * show/hide toggle, never the fetch. The parent supplies the already-fetched `value` (or
 * `errorMessage`) via inputs and listens for `(reveal)` to trigger its own backend call —
 * emitted once per value, the first time the user clicks while nothing has been fetched yet.
 *
 * Does not cache or re-emit the value itself. On hide, it emits `(hide)` so the parent clears
 * its own `value` — the next reveal always re-fetches rather than redisplaying a stale secret
 * from memory. If the parent instead resets `value` to `null` out from under a still-`visible`
 * instance (e.g. the entity it's showing a secret for changed), `ngOnChanges` drops `visible`
 * back to false so the masked state and the Reveal/Hide button label stay consistent.
 */
declare class RevealSecretValueComponent implements OnChanges {
    /** The decrypted value, once the parent's reveal call has completed successfully. */
    value: string | null;
    /** True while the parent's reveal call is in flight. */
    revealing: boolean;
    /** Set by the parent when the reveal call fails (e.g. "No master password is stored"). */
    errorMessage: string | null;
    /** Emitted when the user asks to reveal and nothing has been successfully fetched yet. */
    reveal: EventEmitter<void>;
    /** Emitted when the user hides a revealed value — the parent should clear its `value` so the
     *  secret doesn't linger in memory and the next reveal re-fetches instead of redisplaying it. */
    hide: EventEmitter<void>;
    visible: boolean;
    ngOnChanges(changes: SimpleChanges): void;
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RevealSecretValueComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RevealSecretValueComponent, "app-reveal-secret-value", never, { "value": { "alias": "value"; "required": false; }; "revealing": { "alias": "revealing"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; }, { "reveal": "reveal"; "hide": "hide"; }, never, never, true, never>;
}

interface ListFilterOption {
    value: string;
    label: string;
    /** Shown beside the label in the open panel only, never in the trigger. */
    count?: number;
    /** Muted second line under the label in the open panel. */
    hint?: string;
}

/**
 * Single-select list facet. The field label stays visible next to the value, so
 * a chosen filter still says which field it belongs to.
 */
declare class ListFilterSelectComponent {
    readonly label: i0.InputSignal<string>;
    readonly options: i0.InputSignal<ListFilterOption[]>;
    readonly value: i0.InputSignal<string>;
    /** Label of the option that clears this facet. Doubles as the empty-state text. */
    readonly allLabel: i0.InputSignal<string>;
    readonly showCounts: i0.InputSignal<boolean>;
    readonly searchable: i0.InputSignal<boolean>;
    /** Hides the clearing option, for facets that must always hold a value. */
    readonly showAll: i0.InputSignal<boolean>;
    /** Prefix for data-testid hooks: <id>-toggle, <id>-selected-name, <id>-search-input, <id>-item-<label>. */
    readonly testId: i0.InputSignal<string>;
    /** Falls back to the field label when unset. */
    readonly ariaLabel: i0.InputSignal<string>;
    /** Count for the clearing option; omitted when null. */
    readonly totalCount: i0.InputSignal<number>;
    /** Keeps the facet in place, greyed out, when it has nothing to filter by. */
    readonly disabled: i0.InputSignal<boolean>;
    /** CSS width (e.g. '20rem') for both the field and its open panel; unset keeps the 15rem default. */
    readonly width: i0.InputSignal<string>;
    readonly valueChange: i0.OutputEmitterRef<string>;
    protected readonly open: i0.WritableSignal<boolean>;
    protected readonly term: i0.WritableSignal<string>;
    private readonly searchBox;
    private readonly panel;
    protected readonly selected: i0.Signal<ListFilterOption>;
    protected readonly displayValue: i0.Signal<string>;
    protected readonly accessibleName: i0.Signal<string>;
    protected readonly visibleOptions: i0.Signal<ListFilterOption[]>;
    protected select(option: ListFilterOption | null): void;
    protected onOpenChange(open: boolean): void;
    protected onSearch(value: string): void;
    protected focusFirstOption(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListFilterSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListFilterSelectComponent, "app-list-filter-select", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "allLabel": { "alias": "allLabel"; "required": false; "isSignal": true; }; "showCounts": { "alias": "showCounts"; "required": false; "isSignal": true; }; "searchable": { "alias": "searchable"; "required": false; "isSignal": true; }; "showAll": { "alias": "showAll"; "required": false; "isSignal": true; }; "testId": { "alias": "testId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "totalCount": { "alias": "totalCount"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

/**
 * Common Kubernetes API models
 * Based on Kubernetes API v1.26
 * https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.26/
 */
interface TypeMeta {
    apiVersion?: string;
    kind?: string;
}
interface ObjectMeta {
    name?: string;
    namespace?: string;
    uid?: string;
    resourceVersion?: string;
    generation?: number;
    creationTimestamp?: string;
    deletionTimestamp?: string;
    deletionGracePeriodSeconds?: number;
    labels?: {
        [key: string]: string;
    };
    annotations?: {
        [key: string]: string;
    };
    ownerReferences?: OwnerReference[];
    finalizers?: string[];
    managedFields?: ManagedFieldsEntry[];
}
interface OwnerReference {
    apiVersion: string;
    kind: string;
    name: string;
    uid: string;
    controller?: boolean;
    blockOwnerDeletion?: boolean;
}
interface ManagedFieldsEntry {
    manager?: string;
    operation?: string;
    apiVersion?: string;
    time?: string;
    fieldsType?: string;
    fieldsV1?: object;
    subresource?: string;
}
interface LabelSelector {
    matchLabels?: {
        [key: string]: string;
    };
    matchExpressions?: LabelSelectorRequirement[];
}
interface LabelSelectorRequirement {
    key: string;
    operator: string;
    values?: string[];
}
interface ListMeta {
    selfLink?: string;
    resourceVersion?: string;
    continue?: string;
    remainingItemCount?: number;
}
interface K8sListResponse<T> {
    apiVersion?: string;
    kind?: string;
    metadata?: ListMeta;
    items: T[];
}
interface LocalObjectReference {
    name?: string;
}
interface ResourceRequirements {
    limits?: {
        [key: string]: string;
    };
    requests?: {
        [key: string]: string;
    };
}
interface EnvVar {
    name: string;
    value?: string;
    valueFrom?: EnvVarSource;
}
interface EnvVarSource {
    fieldRef?: ObjectFieldSelector;
    resourceFieldRef?: ResourceFieldSelector;
    configMapKeyRef?: ConfigMapKeySelector;
    secretKeyRef?: SecretKeySelector;
}
interface ObjectFieldSelector {
    apiVersion?: string;
    fieldPath: string;
}
interface ResourceFieldSelector {
    containerName?: string;
    resource: string;
    divisor?: string;
}
interface ConfigMapKeySelector {
    name?: string;
    key: string;
    optional?: boolean;
}
interface SecretKeySelector {
    name?: string;
    key: string;
    optional?: boolean;
}
interface VolumeMount {
    name: string;
    readOnly?: boolean;
    mountPath: string;
    subPath?: string;
    mountPropagation?: string;
    subPathExpr?: string;
}
interface Volume {
    name: string;
    hostPath?: HostPathVolumeSource;
    emptyDir?: EmptyDirVolumeSource;
    secret?: SecretVolumeSource;
    configMap?: ConfigMapVolumeSource;
    persistentVolumeClaim?: PersistentVolumeClaimVolumeSource;
    projected?: ProjectedVolumeSource;
    downwardAPI?: DownwardAPIVolumeSource;
}
interface HostPathVolumeSource {
    path: string;
    type?: string;
}
interface EmptyDirVolumeSource {
    medium?: string;
    sizeLimit?: string;
}
interface SecretVolumeSource {
    secretName?: string;
    items?: KeyToPath[];
    defaultMode?: number;
    optional?: boolean;
}
interface ConfigMapVolumeSource {
    name?: string;
    items?: KeyToPath[];
    defaultMode?: number;
    optional?: boolean;
}
interface PersistentVolumeClaimVolumeSource {
    claimName: string;
    readOnly?: boolean;
}
interface ProjectedVolumeSource {
    sources?: VolumeProjection[];
    defaultMode?: number;
}
interface VolumeProjection {
    secret?: SecretProjection;
    downwardAPI?: DownwardAPIProjection;
    configMap?: ConfigMapProjection;
    serviceAccountToken?: ServiceAccountTokenProjection;
}
interface SecretProjection {
    name?: string;
    items?: KeyToPath[];
    optional?: boolean;
}
interface ConfigMapProjection {
    name?: string;
    items?: KeyToPath[];
    optional?: boolean;
}
interface DownwardAPIProjection {
    items?: DownwardAPIVolumeFile[];
}
interface ServiceAccountTokenProjection {
    audience?: string;
    expirationSeconds?: number;
    path: string;
}
interface DownwardAPIVolumeSource {
    items?: DownwardAPIVolumeFile[];
    defaultMode?: number;
}
interface DownwardAPIVolumeFile {
    path: string;
    fieldRef?: ObjectFieldSelector;
    resourceFieldRef?: ResourceFieldSelector;
    mode?: number;
}
interface KeyToPath {
    key: string;
    path: string;
    mode?: number;
}
interface ContainerPort {
    name?: string;
    hostPort?: number;
    containerPort: number;
    protocol?: string;
    hostIP?: string;
}
interface Probe {
    exec?: ExecAction;
    httpGet?: HTTPGetAction;
    tcpSocket?: TCPSocketAction;
    grpc?: GRPCAction;
    initialDelaySeconds?: number;
    timeoutSeconds?: number;
    periodSeconds?: number;
    successThreshold?: number;
    failureThreshold?: number;
    terminationGracePeriodSeconds?: number;
}
interface ExecAction {
    command?: string[];
}
interface HTTPGetAction {
    path?: string;
    port: number | string;
    host?: string;
    scheme?: string;
    httpHeaders?: HTTPHeader[];
}
interface HTTPHeader {
    name: string;
    value: string;
}
interface TCPSocketAction {
    port: number | string;
    host?: string;
}
interface GRPCAction {
    port: number;
    service?: string;
}
interface SecurityContext {
    capabilities?: Capabilities;
    privileged?: boolean;
    seLinuxOptions?: SELinuxOptions;
    runAsUser?: number;
    runAsGroup?: number;
    runAsNonRoot?: boolean;
    readOnlyRootFilesystem?: boolean;
    allowPrivilegeEscalation?: boolean;
    procMount?: string;
    seccompProfile?: SeccompProfile;
}
interface Capabilities {
    add?: string[];
    drop?: string[];
}
interface SELinuxOptions {
    user?: string;
    role?: string;
    type?: string;
    level?: string;
}
interface SeccompProfile {
    type: string;
    localhostProfile?: string;
}
interface Container {
    name: string;
    image?: string;
    command?: string[];
    args?: string[];
    workingDir?: string;
    ports?: ContainerPort[];
    env?: EnvVar[];
    envFrom?: EnvFromSource[];
    resources?: ResourceRequirements;
    volumeMounts?: VolumeMount[];
    livenessProbe?: Probe;
    readinessProbe?: Probe;
    startupProbe?: Probe;
    lifecycle?: Lifecycle;
    terminationMessagePath?: string;
    terminationMessagePolicy?: string;
    imagePullPolicy?: string;
    securityContext?: SecurityContext;
    stdin?: boolean;
    stdinOnce?: boolean;
    tty?: boolean;
}
interface EnvFromSource {
    prefix?: string;
    configMapRef?: ConfigMapEnvSource;
    secretRef?: SecretEnvSource;
}
interface ConfigMapEnvSource {
    name?: string;
    optional?: boolean;
}
interface SecretEnvSource {
    name?: string;
    optional?: boolean;
}
interface Lifecycle {
    postStart?: LifecycleHandler;
    preStop?: LifecycleHandler;
}
interface LifecycleHandler {
    exec?: ExecAction;
    httpGet?: HTTPGetAction;
    tcpSocket?: TCPSocketAction;
}
interface PodSecurityContext {
    seLinuxOptions?: SELinuxOptions;
    runAsUser?: number;
    runAsGroup?: number;
    runAsNonRoot?: boolean;
    supplementalGroups?: number[];
    fsGroup?: number;
    sysctls?: Sysctl[];
    fsGroupChangePolicy?: string;
    seccompProfile?: SeccompProfile;
}
interface Sysctl {
    name: string;
    value: string;
}
interface Affinity {
    nodeAffinity?: NodeAffinity;
    podAffinity?: PodAffinity;
    podAntiAffinity?: PodAntiAffinity;
}
interface NodeAffinity {
    requiredDuringSchedulingIgnoredDuringExecution?: NodeSelector;
    preferredDuringSchedulingIgnoredDuringExecution?: PreferredSchedulingTerm[];
}
interface NodeSelector {
    nodeSelectorTerms: NodeSelectorTerm[];
}
interface NodeSelectorTerm {
    matchExpressions?: NodeSelectorRequirement[];
    matchFields?: NodeSelectorRequirement[];
}
interface NodeSelectorRequirement {
    key: string;
    operator: string;
    values?: string[];
}
interface PreferredSchedulingTerm {
    weight: number;
    preference: NodeSelectorTerm;
}
interface PodAffinity {
    requiredDuringSchedulingIgnoredDuringExecution?: PodAffinityTerm[];
    preferredDuringSchedulingIgnoredDuringExecution?: WeightedPodAffinityTerm[];
}
interface PodAntiAffinity {
    requiredDuringSchedulingIgnoredDuringExecution?: PodAffinityTerm[];
    preferredDuringSchedulingIgnoredDuringExecution?: WeightedPodAffinityTerm[];
}
interface PodAffinityTerm {
    labelSelector?: LabelSelector;
    namespaces?: string[];
    topologyKey: string;
    namespaceSelector?: LabelSelector;
}
interface WeightedPodAffinityTerm {
    weight: number;
    podAffinityTerm: PodAffinityTerm;
}
interface Toleration {
    key?: string;
    operator?: string;
    value?: string;
    effect?: string;
    tolerationSeconds?: number;
}
interface TopologySpreadConstraint {
    maxSkew: number;
    topologyKey: string;
    whenUnsatisfiable: string;
    labelSelector?: LabelSelector;
    minDomains?: number;
    nodeAffinityPolicy?: string;
    nodeTaintsPolicy?: string;
    matchLabelKeys?: string[];
}

/**
 * Pod model
 * apiVersion: v1
 * Kind: Pod
 * Plural: pods
 * Scope: Namespaced
 */

interface PodSpec {
    containers: Container[];
    initContainers?: Container[];
    ephemeralContainers?: EphemeralContainer[];
    volumes?: Volume[];
    restartPolicy?: string;
    terminationGracePeriodSeconds?: number;
    activeDeadlineSeconds?: number;
    dnsPolicy?: string;
    nodeSelector?: {
        [key: string]: string;
    };
    serviceAccountName?: string;
    serviceAccount?: string;
    automountServiceAccountToken?: boolean;
    nodeName?: string;
    hostNetwork?: boolean;
    hostPID?: boolean;
    hostIPC?: boolean;
    shareProcessNamespace?: boolean;
    securityContext?: PodSecurityContext;
    imagePullSecrets?: LocalObjectReference[];
    hostname?: string;
    subdomain?: string;
    affinity?: Affinity;
    schedulerName?: string;
    tolerations?: Toleration[];
    hostAliases?: HostAlias[];
    priorityClassName?: string;
    priority?: number;
    dnsConfig?: PodDNSConfig;
    readinessGates?: PodReadinessGate[];
    runtimeClassName?: string;
    enableServiceLinks?: boolean;
    preemptionPolicy?: string;
    overhead?: {
        [key: string]: string;
    };
    topologySpreadConstraints?: TopologySpreadConstraint[];
    setHostnameAsFQDN?: boolean;
    os?: PodOS;
}
interface EphemeralContainer extends Container {
    targetContainerName?: string;
}
interface HostAlias {
    ip?: string;
    hostnames?: string[];
}
interface PodDNSConfig {
    nameservers?: string[];
    searches?: string[];
    options?: PodDNSConfigOption[];
}
interface PodDNSConfigOption {
    name?: string;
    value?: string;
}
interface PodReadinessGate {
    conditionType: string;
}
interface PodOS {
    name: string;
}
interface PodStatus {
    phase?: string;
    conditions?: PodCondition[];
    message?: string;
    reason?: string;
    nominatedNodeName?: string;
    hostIP?: string;
    podIP?: string;
    podIPs?: PodIP[];
    startTime?: string;
    initContainerStatuses?: ContainerStatus[];
    containerStatuses?: ContainerStatus[];
    ephemeralContainerStatuses?: ContainerStatus[];
    qosClass?: string;
}
interface PodCondition {
    type: string;
    status: string;
    lastProbeTime?: string;
    lastTransitionTime?: string;
    reason?: string;
    message?: string;
}
interface PodIP {
    ip?: string;
}
interface ContainerStatus {
    name: string;
    state?: ContainerState;
    lastState?: ContainerState;
    ready: boolean;
    restartCount: number;
    image: string;
    imageID: string;
    containerID?: string;
    started?: boolean;
}
interface ContainerState {
    waiting?: ContainerStateWaiting;
    running?: ContainerStateRunning;
    terminated?: ContainerStateTerminated;
}
interface ContainerStateWaiting {
    reason?: string;
    message?: string;
}
interface ContainerStateRunning {
    startedAt?: string;
}
interface ContainerStateTerminated {
    exitCode: number;
    signal?: number;
    reason?: string;
    message?: string;
    startedAt?: string;
    finishedAt?: string;
    containerID?: string;
}
declare class Pod implements TypeMeta {
    apiVersion?: string;
    kind?: string;
    metadata?: ObjectMeta;
    spec?: PodSpec;
    status?: PodStatus;
    private _ageDisplay?;
    private _ageSortValue;
    private _containersDisplay?;
    private _restartsDisplay?;
    private _controlledByDisplay?;
    private _nodeDisplay?;
    private _qosDisplay?;
    private _statusDisplay?;
    constructor(properties?: Partial<Pod>);
    get name(): string;
    get namespace(): string;
    get containersDisplay(): number;
    get restartsDisplay(): number;
    get controlledByDisplay(): string;
    get nodeDisplay(): string;
    get qosDisplay(): string;
    get ageDisplay(): string;
    get ageSortValue(): number;
    get statusDisplay(): string;
    static API_PARAMS: {
        apiVersion: string;
        plural: string;
        kind: string;
    };
    static readonly podStatusMap: Map<string, string>;
    /** Pods owned by one of `ownerUids` — a Job's pods list the Job in their ownerReferences. */
    static ownedBy(pods: Pod[], ownerUids: string[]): Pod[];
    static getContainersCount(spec: PodSpec): number;
    static getRestarts(status: PodStatus): number;
    static getControlledBy(metadata: ObjectMeta): string;
    static getStatus(metadata: ObjectMeta, status: PodStatus): string;
}
declare class PodLogs {
    podName: string;
    namespace: string;
    provider: string;
    container: null;
    logs: string;
    lineCount: number;
    tailLines: number;
    sinceSeconds: null;
    hasMoreLogs: boolean;
    constructor(properties?: Partial<PodLogs>);
}

interface K8sContext {
    cluster: any;
    namespace: string;
}
/**
 * Interface that defines the contract for Kubernetes resource services.
 * This allows different implementations (regular vs admin) to be injected
 * into shared components via the RESOURCE_K8S_SERVICE token.
 */
interface IResourceK8sService {
    /**
     * Observable that emits when context (cluster or namespace) changes
     */
    activeContext$: Observable<K8sContext>;
    /**
     * Get the current active cluster/scope
     */
    readonly activeCluster: any;
    /**
     * Get the current active namespace
     */
    readonly activeNamespace: string;
    /**
     * Creates a timer that emits context changes along with a boolean indicating
     * whether the context changed since the last emission.
     *
     * @param immediate - If true, emits immediately on subscription
     * @param frequency - Optional refresh interval in milliseconds
     * @returns Observable emitting [context, changed] tuples
     */
    getContextRefreshTimer(immediate?: boolean, frequency?: number): Observable<[K8sContext, boolean]>;
    /**
     * Fetch Kubernetes resources with optional caching
     *
     * @param plural - Resource plural name (e.g., 'deployments', 'pods', 'services')
     * @param apiVersion - API version (e.g., 'apps/v1', 'v1')
     * @param forceFetch - Optional flag to bypass cache and force fresh data fetch
     * @param resourceConstructor - Optional constructor function to instantiate resource objects
     * @returns Observable of resource array
     */
    getK8sResources<T>(plural: string, apiVersion: string, forceFetch?: boolean, resourceConstructor?: new (data: any) => T): Observable<T[]>;
    /**
     * Get pod logs with optional tail lines
     *
     * @param podName - Name of the pod
     * @param tailLines - Number of lines to fetch from the end of the log
     * @returns Observable of pod logs
     */
    getPodLogs(podName: string, tailLines?: number, container?: string): Observable<PodLogs>;
    /**
     * Get K8s JIT access configuration
     *
     * @returns Observable of K8s JIT access configuration
     */
    getK8sJitAccess(): Observable<K8ClusterConfig>;
}
/**
 * Injection token for K8s resource service.
 * Use this token to inject either ResourceK8sService or AdminResourceK8sService
 * depending on the module context.
 */
declare const RESOURCE_K8S_SERVICE: InjectionToken<IResourceK8sService>;

declare class KubPodLogsComponent implements OnInit, AfterViewInit {
    activeModal: NgbActiveModal;
    private resourceK8sService;
    private destroy$;
    private success;
    pod: Pod;
    pods: Pod[];
    isLoading: boolean;
    errorMessage: string;
    noPods: boolean;
    logsScrollDown: boolean;
    isDownloading: boolean;
    containers: string[];
    selectedContainer: string | null;
    /** Override the logs API call. When set, the injected service is not used. */
    podLogsLoader?: (podName: string) => Observable<PodLogs>;
    /** Workload mode: the pods to pick from instead of a single `pod`. The newest one is shown first. */
    podsLoader?: Observable<Pod[]>;
    headerTitle?: string;
    noPodsMessage: string;
    /** Groups the Pod dropdown by the Job owning each pod: one group per CronJob run. */
    groupPodsByJob: boolean;
    readonly jobNameOfPod: (pod: Pod) => string | undefined;
    xtermBlock: XtermBlockComponent;
    private pollInterval;
    private stopPolling$;
    private cancelFetch$;
    private viewReady;
    private pendingLogs?;
    constructor(activeModal: NgbActiveModal, resourceK8sService: IResourceK8sService, destroy$: SubDestroyService, success: SuccessReporter);
    private loadLogs;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    private loadPods;
    onPodChange(podName: string): void;
    private initContainers;
    onContainerChange(container: string): void;
    private reloadLogs;
    onFollowLogsChange(event: Event): void;
    private fetchLogs;
    private startPolling;
    private stopPolling;
    private writeLogs;
    /** So a failed reload after a pod or container switch doesn't leave the previous selection's logs showing. */
    private clearTerminal;
    downloadLog(): void;
    closeModal(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<KubPodLogsComponent, [null, { optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KubPodLogsComponent, "app-kub-pod-logs", never, { "podLogsLoader": { "alias": "podLogsLoader"; "required": false; }; "podsLoader": { "alias": "podsLoader"; "required": false; }; "headerTitle": { "alias": "headerTitle"; "required": false; }; "noPodsMessage": { "alias": "noPodsMessage"; "required": false; }; "groupPodsByJob": { "alias": "groupPodsByJob"; "required": false; }; }, {}, never, never, false, never>;
}

declare class KubPodXtermComponent implements OnInit {
    activeModal: NgbActiveModal;
    private resourceK8sService;
    private destroy$;
    pod: Pod;
    containerName: string;
    isLoading: boolean;
    errorMessage: string;
    queryParams: Record<string, string>;
    terminalName: string;
    /** Override the JIT-access API call. When set, the injected service is not used. */
    jitAccessLoader?: Observable<K8ClusterConfig>;
    /** Override the active namespace used in kubectl context setup. */
    namespace?: string;
    /** Optional command queued automatically once the terminal connects.
     *  Used by callers that want to pre-type e.g. `kubectl logs -f …`. */
    initialCommand?: string;
    xtermSocket: XtermSocketComponent;
    constructor(activeModal: NgbActiveModal, resourceK8sService: IResourceK8sService, destroy$: SubDestroyService);
    ngOnInit(): void;
    private loadKubeConfig;
    /**
     * Builds the socket query params for the xterm connection. The kubeconfig
     * is encoded as YAML+base64 and passed as `queryParams.kubeconfig` for
     * BOTH pod and no-pod flows. {@link XtermSocketComponent} strips it from
     * the actual socket query: with a pod it goes to the server as `k8s-config`,
     * and without one as `env-config`, which the server mounts read-only and
     * points `KUBECONFIG` at. Nothing is typed into the shell, so the token
     * never lands in its history (DUPLO-45021).
     */
    private buildQueryParams;
    onTerminalReady(isConnected: boolean): void;
    closeModal(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<KubPodXtermComponent, [null, { optional: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KubPodXtermComponent, "app-kub-pod-xterm", never, { "jitAccessLoader": { "alias": "jitAccessLoader"; "required": false; }; "namespace": { "alias": "namespace"; "required": false; }; "initialCommand": { "alias": "initialCommand"; "required": false; }; }, {}, never, never, false, never>;
}

declare class K8sPodModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<K8sPodModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<K8sPodModule, [typeof KubPodLogsComponent, typeof KubPodXtermComponent], [typeof i3.CommonModule, typeof i3$1.FormsModule, typeof i5.NgSelectModule, typeof XtermBlockComponent, typeof XtermSocketComponent], [typeof KubPodLogsComponent, typeof KubPodXtermComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<K8sPodModule>;
}

declare class K8sScope {
    constructor(partial: Partial<K8sScope>);
    scopeName: string;
    scopeId: string;
    providerName: string;
    namespaces: string[];
    /** Whether this scope's Kubernetes credential is a static, long-lived token — drives the
     *  kubectl/Download-kubeconfig gating behind AISUITE_SETTING.K8S_ALLOW_STATIC_TOKEN_JIT_ACCESS. */
    isStaticTokenCredential?: boolean;
}

declare class ResourceK8sDataSource {
    private api;
    sessionService: any;
    private apiUrl;
    get workspaceId(): string;
    get baseUrl(): string;
    get scopeBaseUrl(): string;
    constructor(api: HttpClient, sessionService: any);
    getK8sScopes(): Observable<K8sScope[]>;
    /**
     * Fetches a single Kubernetes scope with its namespaces. Prefer this over getK8sScopes()
     * whenever the scope is already known (cluster details page, ticket Kubectl dropdown): the
     * list endpoint makes the server acquire a token and enumerate namespaces for every cluster
     * in the workspace, sequentially, so its cost grows with the number of clusters.
     * Errors when the scope isn't in the workspace or isn't backed by a Kubernetes provider.
     */
    getK8sScope(scopeId: string): Observable<K8sScope>;
    getK8sResourceList<T = any>(scopeId: string, namespace: string, plural: string, apiVersion: string): Observable<K8sListResponse<T>>;
    getPodsLogs(scopeId: string, namespace: string, podId: string, tailLines?: number, container?: string): Observable<PodLogs>;
    /** Trigger a rolling restart on a Deployment / StatefulSet (kubectl rollout restart). */
    restartWorkload(scopeId: string, namespace: string, kind: 'deployments' | 'statefulsets', name: string): Observable<unknown>;
    /** Delete a single pod (kubectl delete pod); the owning controller recreates it. */
    deletePod(scopeId: string, namespace: string, podName: string): Observable<unknown>;
    getK8sJitAccess(scopeId: string, namespace?: string): Observable<K8ClusterConfig>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResourceK8sDataSource, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ResourceK8sDataSource>;
}

declare class MetadataFormFieldComponent implements OnInit {
    label: string;
    required: boolean;
    keyPattern: string;
    keyPlaceholder: string;
    valuePlaceholder: string;
    metaDataChange: EventEmitter<Record<string, string>>;
    pairs: KeyValuePair[];
    rowRequired: boolean[];
    rowOtherKeys: string[][];
    private keyInputs?;
    private lastEmitted;
    set metaData(value: Record<string, string>);
    ngOnInit(): void;
    addRow(): void;
    removeRow(index: number): void;
    emit(): void;
    private recompute;
    private hasContent;
    trackByUid(_: number, row: KeyValuePair): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MetadataFormFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MetadataFormFieldComponent, "app-metadata-form-field", never, { "label": { "alias": "label"; "required": false; }; "required": { "alias": "required"; "required": false; }; "keyPattern": { "alias": "keyPattern"; "required": false; }; "keyPlaceholder": { "alias": "keyPlaceholder"; "required": false; }; "valuePlaceholder": { "alias": "valuePlaceholder"; "required": false; }; "metaData": { "alias": "metaData"; "required": false; }; }, { "metaDataChange": "metaDataChange"; }, never, never, true, never>;
}

declare class MetadataTableComponent implements OnChanges {
    metaData: Record<string, string>;
    readonly: boolean;
    add: EventEmitter<void>;
    edit: EventEmitter<KeyValuePair>;
    delete: EventEmitter<KeyValuePair>;
    rows: KeyValuePair[];
    private all;
    table?: SearchableDatatableComponent;
    ngOnChanges(): void;
    filterUpdate(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MetadataTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MetadataTableComponent, "app-metadata-table", never, { "metaData": { "alias": "metaData"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; }, { "add": "add"; "edit": "edit"; "delete": "delete"; }, never, never, true, never>;
}

/**
 * Bundles the reusable metadata components (inline form-field editor + view
 * table). Import this module wherever metadata add/edit/display is needed.
 * Both components are standalone; this module simply re-exports them.
 */
declare class MetadataComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MetadataComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MetadataComponentsModule, never, [typeof MetadataFormFieldComponent, typeof MetadataTableComponent], [typeof MetadataFormFieldComponent, typeof MetadataTableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MetadataComponentsModule>;
}

declare class KeyValueFormModalComponent {
    activeModal: NgbActiveModal;
    keyValue: KeyValuePair;
    existingKeys: string[];
    isUpdate: boolean;
    submitKeyValue: EventEmitter<KeyValuePair>;
    blockUI?: NgBlockUI;
    formGroupErrors: FormGroupErrorsComponent;
    constructor(activeModal: NgbActiveModal);
    close(state?: KeyValuePair): void;
    submitMetaData(form: NgForm): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<KeyValueFormModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KeyValueFormModalComponent, "app-key-value-form-modal", never, { "keyValue": { "alias": "keyValue"; "required": false; }; "existingKeys": { "alias": "existingKeys"; "required": false; }; }, { "submitKeyValue": "submitKeyValue"; }, never, never, true, never>;
}

/** Credential created inline with a connection's provider. */
declare const DEFAULT_CONNECTION_CREDENTIAL_NAME = "default";
/** Provider type when a request names neither a type nor a type definition; mirrors `OtherProvider.Other`. */
declare const DEFAULT_CONNECTION_TYPE = "other";
/** Mirrors `SCOPE_NAME_PATTERN` in `admin-provider.model.ts`; the agent writes scope names into CLI config. */
declare const CONNECTION_SCOPE_NAME_PATTERN: RegExp;
/** Provider name length bounds; mirror `MinNameLength`/`MaxNameLength` in the backend's `ProviderService.cs`. */
declare const CONNECTION_NAME_MIN_LENGTH = 2;
declare const CONNECTION_NAME_MAX_LENGTH = 70;
declare const CONNECTION_NAME_RULE = "Name must be 2-70 characters: a letter first, then letters, numbers, \"-\" or \"_\" (no spaces).";
/** A connection name is both the provider and the scope name, so it must pass both rules. */
declare function isValidConnectionName(name: string): boolean;
interface ConnectionField {
    key: string;
    label: string;
    htmlType?: 'text' | 'password' | 'url' | 'email' | 'textarea';
    required?: 'always' | 'createOnly' | 'never';
    sensitive?: boolean;
    placeholder?: string;
    helpText?: string;
    minLength?: number;
}
interface ConnectionVariant {
    key: string;
    label: string;
    fields: ConnectionField[];
}
interface ConnectionCredentialSchema {
    fields?: ConnectionField[];
    variants?: ConnectionVariant[];
    variantSelectorLabel?: string;
    defaultVariantKey?: string;
}
interface ConnectionTypeDefinition {
    type: string;
    label: string;
    category: string;
    credentialSchema?: ConnectionCredentialSchema;
    accountIdLabel?: string;
    accountIdHidden?: boolean;
    /** Registry origin (`builtIn`, `adminAuthored`, `autoBackfill`); set on what `ensureType` returns. */
    origin?: string;
}
interface ConnectionResult {
    providerId: string;
    credentialName: string;
    scopeId: string;
}
interface ConnectionOption extends ConnectionResult {
    label: string;
    providerName: string;
    providerType: string;
}
interface ConnectionProvider {
    id: string;
    name: string;
    type: string;
}
interface ConnectionScope {
    id: string;
    name: string;
    providerId: string;
    credentialName: string;
}
interface ConnectRequest {
    category: string;
    type?: string;
    typeDefinition?: ConnectionTypeDefinition;
    name: string;
    values: Record<string, string>;
    resume?: Partial<ConnectionResult>;
}
/** A `connect` step failed; `partial` holds what was already created (never rolled back). */
declare class ConnectionError extends Error {
    step: 'validation' | 'type' | 'provider' | 'scope';
    partial: Partial<ConnectionResult>;
    cause: unknown;
    constructor(step: 'validation' | 'type' | 'provider' | 'scope', message: string, partial?: Partial<ConnectionResult>, cause?: unknown);
}

/**
 * Typed, UI-free access to providers, credentials and scopes over the existing admin APIs.
 * Calls go through the host's `REMOTE_DuploHttpClient`; every method is a cold Observable.
 */
declare class ConnectionsService {
    private readonly http;
    /** Pending `ensureType` runs by lower-cased (category, type); an entry is removed when its run ends. */
    private readonly pendingTypes;
    /** The registry's copy of the (category, type) pair, or a new admin-authored type. Never updates one. */
    ensureType(def: ConnectionTypeDefinition): Observable<ConnectionTypeDefinition>;
    listProviders(q: {
        category: string;
        type?: string;
    }): Observable<ConnectionProvider[]>;
    createProvider(q: {
        category: string;
        type: string;
        name: string;
        credentialName?: string;
        values?: Record<string, string>;
        schema?: ConnectionCredentialSchema;
    }): Observable<ConnectionProvider>;
    listCredentials(providerId: string): Observable<string[]>;
    addCredential(providerId: string, name: string, values: Record<string, string>, schema?: ConnectionCredentialSchema): Observable<string>;
    listScopes(q: {
        providerId: string;
        credentialName?: string;
    }): Observable<ConnectionScope[]>;
    createScope(q: {
        providerId: string;
        credentialName: string;
        name: string;
    }): Observable<ConnectionScope>;
    /** Scopes of the category, labelled with their provider; the scope listing carries no provider name or type.
     *  `alsoTypes` widens the `type` filter; it does nothing without a `type`. */
    listConnections(q: {
        category: string;
        type?: string;
        alsoTypes?: readonly string[];
    }): Observable<ConnectionOption[]>;
    /** Type (if given; its `category` wins) → provider with an inline credential → scope; never deletes, `resume` skips done steps.
     *  Each subscription creates again, so subscribe once; a failed provider step cannot be resumed (retry with another name). */
    connect(req: ConnectRequest): Observable<ConnectionResult>;
    private connectScope;
    private resolveType;
    private findOrCreateType;
    private readRegisteredType;
    private createType;
    /** Another caller may have created the type meanwhile: re-read once, else surface the POST's own error. */
    private recoverCreatedType;
    private fetchProviders;
    /** Defers so a missing client surfaces as an Observable error on subscribe, never a synchronous throw. */
    private withHttp;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConnectionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConnectionsService>;
}

/** A name rule plus the error keys and messages its validator reports. */
interface ConnectionNameRule {
    isValid: (name: string) => boolean;
    formatKey: string;
    formatMessage: string;
    duplicateKey: string;
    duplicateMessage: string;
}

interface CredentialOption {
    /** Null for the "+ New credential" option. */
    name: string | null;
    label: string;
    disabled?: boolean;
}
interface ListState$3 {
    status: 'idle' | 'loading' | 'ready' | 'error';
    names: string[];
    error?: string;
}
interface SchemaState {
    status: 'idle' | 'loading' | 'ready' | 'error';
    schema?: ConnectionCredentialSchema;
    error?: string;
}
/**
 * Picks one of a provider's credentials, or creates one inline.
 * ControlValueAccessor over the credential name; null while a new credential is being entered.
 * Invalid (`credentialNotFound`) once the loaded list lacks the value.
 */
declare class CredentialFormComponent implements ControlValueAccessor, Validator {
    readonly providerId: i0.InputSignal<string>;
    readonly typeDefinition: i0.InputSignal<ConnectionTypeDefinition>;
    private readonly connections;
    private readonly destroyRef;
    private readonly cdr;
    private readonly outerForm;
    protected readonly idPrefix: string;
    protected readonly nameRule: ConnectionNameRule;
    protected readonly disabled: i0.WritableSignal<boolean>;
    protected readonly value: i0.WritableSignal<string>;
    protected readonly newOpen: i0.WritableSignal<boolean>;
    protected readonly newName: i0.WritableSignal<string>;
    protected readonly newValues: i0.WritableSignal<Record<string, string>>;
    protected readonly adding: i0.WritableSignal<boolean>;
    protected readonly addError: i0.WritableSignal<string>;
    protected readonly list: i0.WritableSignal<ListState$3>;
    protected readonly schemaState: i0.WritableSignal<SchemaState>;
    protected readonly hasProvider: i0.Signal<boolean>;
    protected readonly names: i0.Signal<string[]>;
    protected readonly listLoading: i0.Signal<boolean>;
    protected readonly listFailed: i0.Signal<boolean>;
    protected readonly listError: i0.Signal<string>;
    protected readonly pickerDisabled: i0.Signal<boolean>;
    protected readonly placeholder: i0.Signal<"Choose a provider first" | "No credentials yet" | "Choose a credential">;
    /** Only a loaded list can say a value is gone; while loading or failed it is just not known yet. */
    private readonly notFoundOption;
    private readonly valueMissing;
    protected readonly options: i0.Signal<CredentialOption[]>;
    protected readonly selectedOption: i0.Signal<CredentialOption>;
    protected readonly schemaLoading: i0.Signal<boolean>;
    protected readonly schemaFailed: i0.Signal<boolean>;
    protected readonly schemaReady: i0.Signal<boolean>;
    protected readonly schema: i0.Signal<ConnectionCredentialSchema>;
    protected readonly schemaError: i0.Signal<string>;
    /** Inputs are locked while disabled or while the POST is in flight. */
    protected readonly formLocked: i0.Signal<boolean>;
    protected readonly addBlocked: i0.Signal<boolean>;
    private readonly fields;
    private readonly newForm;
    /** Compared by content so a parent rebuilding the same definition does not refetch. */
    private readonly typeDef;
    private readonly listRequest$;
    private readonly schemaRequest$;
    private addSub?;
    private lastProviderId;
    private onChange;
    private onTouched;
    private onValidatorChange;
    constructor();
    /** Any write (including a parent reset) closes and clears the new-credential panel. */
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /** A half-entered credential or a value the loaded list lacks keeps the parent form invalid. */
    validate(_control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    protected sameOption(a: CredentialOption, b: CredentialOption): boolean;
    protected onPick(option: CredentialOption | null): void;
    protected onNameChange(name: string | null): void;
    protected onValuesChange(values: Record<string, string>): void;
    /** Enter in a panel input adds the credential instead of submitting the enclosing form; textareas keep newlines. */
    protected onPanelEnter(event: Event): void;
    protected markTouched(): void;
    protected reloadList(): void;
    protected retrySchema(): void;
    protected addCredential(): void;
    private newFormValid;
    private onAdded;
    private onAddFailed;
    private openNew;
    private onProviderChange;
    private onTypeDefinitionChange;
    /** Emitting from an input change mid-check would change the parent's binding; defer to after it. */
    private clearValueLater;
    private setNewOpen;
    private resetNewForm;
    private setValue;
    private currentProviderId;
    private loadList;
    private loadSchema;
    static ɵfac: i0.ɵɵFactoryDeclaration<CredentialFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CredentialFormComponent, "duplo-credential-form", never, { "providerId": { "alias": "providerId"; "required": true; "isSignal": true; }; "typeDefinition": { "alias": "typeDefinition"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface ProviderOption {
    /** Null for the "+ New provider" option. */
    id: string | null;
    label: string;
    disabled?: boolean;
}
interface ListState$2 {
    status: 'idle' | 'loading' | 'ready' | 'error';
    providers: ConnectionProvider[];
    error?: string;
}
/** What providers are listed and created with; `type` is empty when the picker lists the whole category. */
interface ProviderTarget {
    category: string;
    type: string;
}
/**
 * Picks a provider of a category (narrowed by type), or creates one inline with no credential.
 * ControlValueAccessor over the provider id; null while a new provider is being entered.
 * Invalid (`providerNotFound`) once the loaded list lacks the value.
 */
declare class ProviderPickerComponent implements ControlValueAccessor, Validator {
    readonly category: i0.InputSignal<string>;
    readonly type: i0.InputSignal<string>;
    readonly typeDefinition: i0.InputSignal<ConnectionTypeDefinition>;
    private readonly connections;
    private readonly destroyRef;
    private readonly cdr;
    private readonly outerForm;
    protected readonly idPrefix: string;
    protected readonly nameRule: ConnectionNameRule;
    protected readonly disabled: i0.WritableSignal<boolean>;
    protected readonly value: i0.WritableSignal<string>;
    protected readonly newOpen: i0.WritableSignal<boolean>;
    protected readonly newName: i0.WritableSignal<string>;
    protected readonly adding: i0.WritableSignal<boolean>;
    protected readonly addError: i0.WritableSignal<string>;
    protected readonly list: i0.WritableSignal<ListState$2>;
    /** Resolved per query (after `ensureType` when there is a type definition); null until then. */
    protected readonly target: i0.WritableSignal<ProviderTarget>;
    /** Compared by content so a parent rebuilding the same definition does not refetch. */
    private readonly query;
    protected readonly hasCategory: i0.Signal<boolean>;
    /** Without a type a provider cannot be created, so "+ New provider" is hidden. */
    protected readonly canCreate: i0.Signal<boolean>;
    protected readonly providers: i0.Signal<ConnectionProvider[]>;
    protected readonly names: i0.Signal<string[]>;
    protected readonly listLoading: i0.Signal<boolean>;
    protected readonly listFailed: i0.Signal<boolean>;
    protected readonly listError: i0.Signal<string>;
    protected readonly pickerDisabled: i0.Signal<boolean>;
    protected readonly placeholder: i0.Signal<"No providers yet" | "Choose a provider">;
    private readonly current;
    /** Only a loaded list can say a value is gone; while loading or failed it is just not known yet. */
    private readonly notFoundOption;
    private readonly valueMissing;
    protected readonly options: i0.Signal<ProviderOption[]>;
    protected readonly selectedOption: i0.Signal<ProviderOption>;
    /** Inputs are locked while disabled or while the POST is in flight. */
    protected readonly formLocked: i0.Signal<boolean>;
    protected readonly addBlocked: i0.Signal<boolean>;
    private readonly newForm;
    private readonly listRequest$;
    private addSub?;
    private lastQuery;
    private onChange;
    private onTouched;
    private onValidatorChange;
    constructor();
    /** Any write (including a parent reset) closes and clears the new-provider panel. */
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /** A half-entered provider or a value the loaded list lacks keeps the parent form invalid. */
    validate(_control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    protected sameOption(a: ProviderOption, b: ProviderOption): boolean;
    protected onPick(option: ProviderOption | null): void;
    protected onNameChange(name: string | null): void;
    /** Enter adds the provider instead of submitting the enclosing form. */
    protected onPanelEnter(event: Event): void;
    protected markTouched(): void;
    protected reloadList(): void;
    protected addProvider(): void;
    private onAdded;
    private onAddFailed;
    private openNew;
    private onQueryChange;
    /** Emitting from an input change mid-check would change the parent's binding; defer to after it. */
    private clearValueLater;
    private setNewOpen;
    private resetNewForm;
    private setValue;
    private loadList;
    /** `ensureType` runs once per query; the registry's category and type win over the inputs. */
    private resolveTarget;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProviderPickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProviderPickerComponent, "duplo-provider-picker", never, { "category": { "alias": "category"; "required": true; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "typeDefinition": { "alias": "typeDefinition"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface ScopeOption {
    /** Null for the "+ New scope" option. */
    id: string | null;
    label: string;
    disabled?: boolean;
}
interface ListState$1 {
    status: 'idle' | 'loading' | 'ready' | 'error';
    scopes: ConnectionScope[];
    error?: string;
}
/**
 * Picks one of a provider credential's scopes, or creates one inline.
 * ControlValueAccessor over the scope id; null while a new scope is being entered.
 * Invalid (`scopeNotFound`) once the loaded list lacks the value.
 */
declare class ScopePickerComponent implements ControlValueAccessor, Validator {
    readonly providerId: i0.InputSignal<string>;
    readonly credentialName: i0.InputSignal<string>;
    private readonly connections;
    private readonly destroyRef;
    private readonly cdr;
    private readonly outerForm;
    protected readonly idPrefix: string;
    protected readonly nameRule: ConnectionNameRule;
    protected readonly disabled: i0.WritableSignal<boolean>;
    protected readonly value: i0.WritableSignal<string>;
    protected readonly newOpen: i0.WritableSignal<boolean>;
    protected readonly newName: i0.WritableSignal<string>;
    protected readonly adding: i0.WritableSignal<boolean>;
    protected readonly addError: i0.WritableSignal<string>;
    protected readonly list: i0.WritableSignal<ListState$1>;
    private readonly query;
    protected readonly ready: i0.Signal<boolean>;
    protected readonly scopes: i0.Signal<ConnectionScope[]>;
    protected readonly names: i0.Signal<string[]>;
    protected readonly listLoading: i0.Signal<boolean>;
    protected readonly listFailed: i0.Signal<boolean>;
    protected readonly listError: i0.Signal<string>;
    protected readonly pickerDisabled: i0.Signal<boolean>;
    protected readonly placeholder: i0.Signal<"Choose a provider and credential first" | "No scopes yet" | "Choose a scope">;
    private readonly current;
    /** Only a loaded list can say a value is gone; while loading or failed it is just not known yet. */
    private readonly notFoundOption;
    private readonly valueMissing;
    protected readonly options: i0.Signal<ScopeOption[]>;
    protected readonly selectedOption: i0.Signal<ScopeOption>;
    /** Inputs are locked while disabled or while the POST is in flight. */
    protected readonly formLocked: i0.Signal<boolean>;
    private readonly newForm;
    private readonly listRequest$;
    private addSub?;
    private lastQuery;
    private onChange;
    private onTouched;
    private onValidatorChange;
    constructor();
    /** Any write (including a parent reset) closes and clears the new-scope panel. */
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /** A half-entered scope or a value the loaded list lacks keeps the parent form invalid. */
    validate(_control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    protected sameOption(a: ScopeOption, b: ScopeOption): boolean;
    protected onPick(option: ScopeOption | null): void;
    protected onNameChange(name: string | null): void;
    /** Enter adds the scope instead of submitting the enclosing form. */
    protected onPanelEnter(event: Event): void;
    protected markTouched(): void;
    protected reloadList(): void;
    protected addScope(): void;
    private onAdded;
    private onAddFailed;
    private openNew;
    private onQueryChange;
    /** Emitting from an input change mid-check would change the parent's binding; defer to after it. */
    private clearValueLater;
    private setNewOpen;
    private resetNewForm;
    private setValue;
    private loadList;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScopePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScopePickerComponent, "duplo-scope-picker", never, { "providerId": { "alias": "providerId"; "required": true; "isSignal": true; }; "credentialName": { "alias": "credentialName"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface FieldOption {
    /** Null for the "+ New … connection" option. */
    scopeId: string | null;
    label: string;
    disabled?: boolean;
    connection?: ConnectionOption;
}
interface ListState {
    status: 'idle' | 'loading' | 'ready' | 'error';
    connections: ConnectionOption[];
    error?: string;
}
/** Level-1 drop-in over the scope id: picks a connection of a category (narrowed by type) or creates one in a modal.
 *  `connected` emits on every user-made selection; invalid (`connectionNotFound`) once the loaded list lacks the value. */
declare class ConnectionFieldComponent implements ControlValueAccessor, Validator {
    readonly category: i0.InputSignal<string>;
    readonly type: i0.InputSignal<string>;
    readonly typeDefinition: i0.InputSignal<ConnectionTypeDefinition>;
    readonly label: i0.InputSignal<string>;
    /** Extra provider types to list beside the main one (e.g. connections made by hand as `other`); never used when creating. */
    readonly alsoTypes: i0.InputSignal<readonly string[]>;
    readonly connected: i0.OutputEmitterRef<ConnectionResult>;
    private readonly connections;
    private readonly modal;
    private readonly environmentInjector;
    protected readonly idPrefix: string;
    protected readonly disabled: i0.WritableSignal<boolean>;
    protected readonly value: i0.WritableSignal<string>;
    protected readonly list: i0.WritableSignal<ListState>;
    /** Compared by content so a parent rebuilding the same definition does not refetch. */
    private readonly query;
    protected readonly displayLabel: i0.Signal<string>;
    /** Without a type there is nothing to create, so "+ New … connection" is hidden. */
    private readonly canCreate;
    private readonly listed;
    protected readonly listLoading: i0.Signal<boolean>;
    protected readonly listFailed: i0.Signal<boolean>;
    protected readonly listError: i0.Signal<string>;
    private readonly current;
    /** Only a loaded list can say a value is gone; while loading or failed it is just not known yet. */
    private readonly notFoundOption;
    private readonly valueMissing;
    /** Only a value found in the list; a new connection is listed at once, so the badge holds through the reload. */
    protected readonly isConnected: i0.Signal<boolean>;
    protected readonly placeholder: i0.Signal<"No connections yet" | "Choose a connection">;
    protected readonly options: i0.Signal<FieldOption[]>;
    protected readonly selectedOption: i0.Signal<FieldOption>;
    private readonly select;
    private readonly listRequest$;
    private lastQuery;
    private modalRef;
    /** The inputs changed while the modal was open; its result belongs to the old query. */
    private modalStale;
    private destroyed;
    private onChange;
    private onTouched;
    private onValidatorChange;
    constructor();
    /** A write never emits `connected`. */
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    validate(_control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    protected sameOption(a: FieldOption, b: FieldOption): boolean;
    protected onPick(option: FieldOption | null): void;
    protected markTouched(): void;
    protected reloadList(): void;
    private openNew;
    /** The "+ New" pick must not stay selected in ng-select; deferred so ng-select finishes its own select first. */
    private restoreSelection;
    private onModalClosed;
    private onQueryChange;
    /** Emitting from an input change mid-check would change the parent's binding; defer to after it. */
    private clearValueLater;
    private setValue;
    private loadList;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConnectionFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConnectionFieldComponent, "duplo-connection-field", never, { "category": { "alias": "category"; "required": true; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "typeDefinition": { "alias": "typeDefinition"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "alsoTypes": { "alias": "alsoTypes"; "required": false; "isSignal": true; }; }, { "connected": "connected"; }, never, never, true, never>;
}

export { AIAutomationService, AILabelConfigPipe, AIProviderCategory, AISUITE_SETTING, AISUITE_SETTINGS, AISUITE_SETTINGS_ADMIN, AISUITE_SETTINGS_AGENT_POLICY, AISUITE_SETTINGS_COMMON, AISUITE_SETTINGS_FOR_ADMIN, AISUITE_SETTINGS_FOR_WORKSPACE, AISUITE_SETTINGS_WORKSPACE, AISUITE_SETTING_BY_NAME, AISUITE_SETTING_LABEL, AISUITE_SETTING_LABELS, AISUITE_SETTING_NAME_TO_DISPLAY_NAME, AISettingValueType, AISystemSetting, AISystemSettingRequest, AISystemSettingsDataSource, AISystemSettingsService, AIUIAction, AIUIActionEvent, AIWorkspaceBase, AI_HELPDESK_DEFAULT_ACTION_SELECTION, AI_MENU_ADMIN_ITEM_IDS, AI_MENU_WORKSPACE_ITEM_IDS, AI_SETTING_TYPE_LABELS, AI_SUITE_LABEL_CONFIG, ALERT_PRIOR_AUTOSCALING, ALL_STATUS_BADGES, AUTH_ERROR, AWSAccessToken, AWS_SERVICES_TAG_BASED_OWNERSHIP_ENABLED, AWS_SPECIFIC_TENANT_CONFIG, AadConfig, AccessType, AccountSsoConfig, AddTenantRequest, AdminK8sExplorerDataSource, AdminTenant, AdminTenantAuthInfo, AdminTenantMonitoringConfig, AgentPlatform, AgentPlatformDetails, AgentPlatformUtils, AiCloudProvider, AiDisclosureComponent, AnalyticsConsent, AnalyticsConsentService, AnimationService, AnsiToHtmlPipe, AppType, AssignMultipleUsersToTenantRequest, AsyncNotExistsValidatorDirective, AuthConfig, AuthNZGuard, AwsAccessInfo, AwsScopeData, AwsUnavailableServices, AzureK8sSupportedVersion, AzureNatGateway, AzureResourcePrefix, BASE_JSON_EDITOR_OPTIONS, BaseEntity, BatchAddUserAccessRequest, BatchAddUserTenantAccessRequest, BearerTokenInterceptor, CANVAS_DOC, COMMON_LIB_CONFIG, CONNECTION_NAME_MAX_LENGTH, CONNECTION_NAME_MIN_LENGTH, CONNECTION_NAME_RULE, CONNECTION_SCOPE_NAME_PATTERN, CORE_CUSTOM_CONFIG, CUSTOM_SETTING_HELP, CUSTOM_SETTING_LABELS_HELP, CUSTOM_SETTING_VALUE_HINTS, CacheResponseService, CanvasRendererRegistry, CardGridToolbarComponent, ClipboardService, CloudCredential, CloudCredentialRequest, CloudPlatform$1 as CloudPlatform, CloudPlatformNames, CodeBlockWithCopyComponent, CodeEditorComponent, CodeMirrorThemeService, CommonLibComponentsModule, CommonLibModule, CommonUtils, ConfirmationModalComponent, ConfirmationModalModule, ConfirmationModalRef, ConfirmationModalService, ConnectionError, ConnectionFieldComponent, ConnectionsService, ContainerStatus$1 as ContainerStatus, CopyToClipboardComponent, CoreCommonModule, CoreConfigService, CoreDirectivesModule, CoreMediaService, CoreMenuService, CorePipesModule, CoreTranslationService, CreateVpcEndpointRequest, CredentialFormComponent, CredentialPayload, CronValidatorDirective, CustomData, CustomDataEx, CustomDataKeyToValue, CustomDataUpdate, DARK_CHART_FAINT_LINE, DATE_BOUNDS_DEFAULT_YEARS, DEFAULT_ACTION_SELECTION, DEFAULT_AVATAR_PALETTE, DEFAULT_CARD_GRID_SORT_FIELDS, DEFAULT_COMMON_LIB_CONFIG, DEFAULT_CONNECTION_CREDENTIAL_NAME, DEFAULT_CONNECTION_TYPE, DEFAULT_FILE_BADGE, DEFAULT_INFRA, DEFAULT_K8S_EXPLORER_FEATURES, DEFAULT_K8S_FAN_OUT_CONCURRENCY, DEFAULT_K8S_KIND, DEFAULT_K8S_REFRESH_INTERVAL_MS, DEFAULT_REFRESH_INTERVAL, DELETE_PROTECTION_METADATA_KEY, DESCRIPTION_LIMIT, DISABLE_HELPDESK_NAV_COLLAPSE, DISABLE_PLATFORM, DOCS_LINKS, DUPLOCONST, DUPLO_CI_HTTP_INTERCEPTORS, DUPLO_CUSTOM_EVENTS, DUPLO_DARK_THEME, DUPLO_HTTP_INTERCEPTORS, DUPLO__AUTO_ACTIONS_IFRAME_DONE, DUPLO__AUTO_ACTIONS_IFRAME_READY, DUPLO__AUTO_ACTIONS_IFRAME_START, DUPLO__AUTO_HELPDESK_START_ACTION, DailySchedule, DatatablePageSummaryPipe, DateBoundsDirective, DateUtils, DeleteConfirmationModalComponent, DeleteConfirmationModalRef, DeleteConfirmationModalService, DetailAttachedComponent, DetailCalloutComponent, DetailEmptyComponent, DetailFactComponent, DetailHeaderComponent, DetailKvComponent, DetailLayoutComponent, DetailSectionComponent, DetailSideContentDirective, DetailTimelineComponent, DiffMergeComponent, DiffRenderComponent, DisableForReadonlyUserDirective, DocDiffOpType, DuploApiInterceptor, DuploCiApiInterceptor, DuploCiClientConfig, DuploCiHttpClient, DuploCiTokenInterceptor, DuploHttpClient, DuploToastrService, DuploValidators, DynamicStyleLoaderService, EMPTY_GUID, EMPTY_WORKSPACE, EMPTY_WORKSPACE_ID, ENABLE_AI_SUITE, ENV_RG_PREFIX_DEPTH, ERROR_REPORTER, EXPANDABLE_LIST_TONES, EXPIRE_SECONDS_EARLY, EXT_BADGE_MAP, EchartsThemeService, EmailValidatorDirective, EnableAzureSettings, EntityFileEditorWrapperComponent, EnumUtils, ErrorInterceptor, ErrorSummary, ExpandFormFieldIconComponent, ExpandableFieldDirective, ExpandableListComponent, FILE_BADGE_MAP, FILE_LANG_MAP, FOLDER_COLOR, FeatherIconDirective, FieldRendererComponent, FileDetailsModalComponent, FileEditorService, FileEditorWrapperComponent, FileIconComponent, FileTabsComponent, FileTreeComponent, FileTreeNodeComponent, FilterPillsComponent, FilterPipe, FilterTableUtils, FlatDropdownFilter, FlatDropdownFilterComponent, FlatStatusFilter, FlatStatusFilterComponent, FlattenedGcpNetworkSecurityRule, FlattenedTenantNetworkSecurityRule, FormElementsCollapsableGroupComponent, FormFieldAlert, FormFieldAlertComponent, FormFieldComponent, FormFieldErrorsComponent, FormGroupErrorsComponent, FormKeyValFieldComponent, FormRefDirective, GKE_MIN_PORTS_PER_VM, GcpInfraPeering, GcpLogConfig, GcpNetworkSecurityRule, GcpNetworkSecurityRuleCreateRequest, GcpRegionFeatures, GcpTenantNetworkSecurityRuleCreateRequest, GcpTenantNetworkSecurityRuleType, GenericFormFieldComponent, GenericFormInput, GitRepoConfig, GkeClusterMaintenancePolicy, GkeEnableK8s, GkeMaintenanceExclusion, GkeMaintenanceExclusionScope, GkeMaintenanceRecurringWindow, HELPDESK_DEFAULT_AGENT_NAME, HdUserProfileDataSource, HelpDirective, HelpIconComponent, HelpModule, HelpdeskApiToken, HideForReadonlyUserDirective, INDENT_JSON_EDITOR_OPTIONS, INFRA_AZURE_NAT_GATEWAY, INFRA_CLUSTER_AUTOSCALER, INFRA_CUSTOM_DATA_SPECS, INFRA_DUPLO_CI_CERTIFICATE, INFRA_DUPLO_CI_TENANT, INFRA_EKS_CSI_SNAPSHOT, INFRA_EKS_LOGGING, INFRA_EKS_LOG_TYPES, INFRA_EKS_VISIBILITY, INFRA_EKS_VPN_ACCESS, INFRA_ENABLE_EKS_WINDOWS_WORKLOAD, INFRA_GCP_DYNAMIC_PORT_ALLOCATION, INFRA_GKE_GATEWAY_API, INFRA_GKE_RELEASE_CHANNEL, INFRA_GKE_VISIBILITY, INFRA_HELM_OPERATOR_FLUXV2, INFRA_HELM_OPERATOR_FLUXV2_DISABLED, INFRA_HELM_OPERATOR_FlUXV1, INFRA_HELM_OPERATOR_VERSION, INFRA_K8S_VERSION, INFRA_MAXIMUM_K8S_SESSION_DURATION, INFRA_OKE_VISIBILITY, INI_EDITOR_OPTIONS, IPv4Regex, IPv6Regex, IamRoleHelpComponent, IconModule, IframeConfigs, Infrastructure, InfrastructureASG, InfrastructureAksConfig, InfrastructureECSConfigUpdate, InfrastructureEKSConfigUpdate, IniValidationDirective, InitialsPipe, InputTextTrimDirective, InterceptingHandler, Ipv4Ipv6CIDRRegex, JSONUtils, JSON_EDITOR_OPTIONS, JsonArrayValidatorDirective, JsonKeyStringValueValidatorDirective, JsonObjectValidatorDirective, JwtResponse, K8ClusterAddOns, K8ClusterConfig, K8ClusterUpgradeNodeAction, K8ClusterUpgradeNodeActionType, K8ClusterUpgradeRequest, K8ClusterUpgradeStatus, K8ClusterVersions, K8S_ALL_NAMESPACES, K8S_FAN_OUT_REFRESH_FLOOR_MS, K8S_FAN_OUT_SLOW_THRESHOLD, K8S_KIND_GROUPS, K8S_KIND_LIST, K8S_KIND_REGISTRY, K8S_SECRETS, K8sExplorerComponent, K8sPlatform, K8sPodModule, K8sStatePanelComponent, K8sVendor, KeyStringValue, KeyStringValueUpdateRequest, KeyValConfigFieldComponent, KeyValueConfig, KeyValueConfigPair, KeyValueFormModalComponent, KeyValuePair, KubPodLogsComponent, KubPodXtermComponent, KubeConfigFile, KubeconfigDownloadService, KubernetesScopeData, LBType, LICENSE_REFUSAL_CODE, LabelRefDirective, ListCardComponent, ListCardGridComponent, ListFilterSelectComponent, ListHeaderComponent, ListPageHeaderComponent, ListQueryStateService, ListStatCardComponent, ListStatsComponent, LogAnalyticsWorkSpace, MarkdownEditModalComponent, MarkdownEditModalService, MarkdownEditorComponent, MaskedTextareaComponent, MessageService, MetadataComponentsModule, MetadataFormFieldComponent, MetadataTableComponent, MiniCardComponent, MiniHelpDeskBridge, MixpanelService, NAV_HEADER_ITEM, NameUtils, NavBackService, NgbTimeNativeDateAdapter, NotEqualValidatorDirective, NotExistsCaseValidatorDirective, NotExistsValidatorDirective, NotStartsWithCaseValidatorDirective, NotStartsWithValidatorDirective, OnPremConfig, OnPremEKSConfig, OnPremK8Config, OracleRegionOptions, OrderByPipe, PasswordFieldComponent, Pod, PodLogs, PortRangeValidatorDirective, PrettyJsonPipe, PrettyYamlPipe, ProtoColAndPorts, ProviderCredentialData, ProviderPickerComponent, READ_ONLY_INI_EDITOR_OPTIONS, READ_ONLY_JSON_EDITOR_OPTIONS, READ_ONLY_XML_EDITOR_OPTIONS, REMOTE_AIAutomationService, REMOTE_AuthNZService, REMOTE_CanvasRendererRegistry, REMOTE_CoreConfigService, REMOTE_DuploHttpClient, REMOTE_ENTRY_CACHE_TAG, REMOTE_ExtensionAnalytics, REMOTE_LoadRemoteModule, REMOTE_MiniHelpDesk, REMOTE_SystemFeatures, REMOTE_UserSession, RESOURCE_DETAIL_MODAL, RESOURCE_K8S_SERVICE, RcBaselineResourceViewShellComponent, RcBaselineResourceViewShellModule, RecoveryServicesVault, Reference, RefreshTimerService, RenderFileComponent, RenderFilePreviewModalComponent, ResourceDetailModalComponent, ResourceK8sDataSource, ResourceMode, ResourceStatus, ResourceTemplateViewComponent, ResourceTemplateViewModule, ResourceTicket, ResourceTypePrefix, RestrictElementAccess, RestrictElementAccessModule, RetentionDuration, RetentionPolicy, RevealSecretValueComponent, RippleEffectDirective, RootImportsModule, SGSourceInfos, SILENT_403, STATUS_BADGE_STYLES, SUCCESS_REPORTER, SUPPORTED_FILE_EXTENSIONS, SafePipe, SchedulePolicy, Scope, ScopePickerComponent, ScrollableNavTabComponent, SearchAndPaginationParams$1 as SearchAndPaginationParams, SearchAndPaginationResult, SearchableDatatableComponent, SearchableDatatableExtraAction, SearchableDatatableModule, SecurityGroupRule, SecurityGroupRuleRequest, SelectOption, ServersideDatatableComponent, ServersideDatatableExtraAction, ServersideDatatableModule, ServersideDatatableStatus, ServiceDetail, ServiceProtocolAndPorts, SessionDurationOption, SharedAlertsService, SharedFormsModule, SidecardComponent, Skill, SkillFormatType, SkillType, SourceControlScopeData, SpinnerComponent, StatCardComponent, StatGridComponent, StatusWithStyleComponent, StringUtils, StripHtmlPipe, SubDestroyService, SubStatusDisplayComponent, Subnet, SubscriptionsGuard, SupportedFileType, SystemConfigs, SystemFeatures, SystemSettingGuard, TENANT_AI_STUDIO_ENABLED, TENANT_CONSTS, TENANT_DEFAULT_CONFIGS, TENANT_FEATURE_AUTO_REBOOT_EC2_DISCONNECTED, TENANT_FEATURE_AUTO_REBOOT_EC2_STATUS_CHECK, TENANT_FEATURE_AWS_IOT_THING_PREFIX, TENANT_FEATURE_AWS_IOT_TOPIC_PREFIX, TENANT_FEATURE_AZURE_ALLOW_PUBLIC_NETWORK_DB_AND_CACHE, TENANT_FEATURE_CA_OVERPROVISIONING, TENANT_FEATURE_DENY_OPEN_ACCESS_TO_PUBLIC_LB, TENANT_FEATURE_ENABLE_AWS_IOT, TENANT_FEATURE_HEADER_COLOR, TENANT_FEATURE_MAXIMUM_K8S_SESSION_DURATION, TENANT_FEATURE_MAXIMUM_SESSION_DURATION, TENANT_FEATURE_SET_SNS_TOPIC_ALERTS, TENANT_PLATFORM_SERVICES_CONFIGS, TEXT_EDITOR_OPTIONS, THEME_DEFAULTS_CSS, THEME_DEFAULTS_STYLE_ID, THEME_STORAGE_KEY, TICKET_POLL_TIMEOUT_MS, TabService, TableHelpDirective, TableStatus$1 as TableStatus, TenantAccessGrant, TenantAccessGrantee, TenantAccessPolicy, TenantAccessQuery, TenantAlertConfig, TenantExtConnSgRuleUpdate, TenantFeatures, TenantHeaderColor, TenantMetadataUpdateReq, TenantNetworkSecurityRule, TenantNetworkSecurityRuleProtocol, TenantNetworkSecurityRuleSource, TenantNetworkSecurityRuleSourceType, TenantPlanKmsKeyInfo, TenantTagRequest, TenantTags, TenantUserAccess, ThemeService, TicketExecutionStatus, TicketStatus, TicketStatusBadgeMap, TimeAgoPipe, TokenPaginatedDatatableComponent, TokenPaginatedDatatableModule, UIConfigPipe, UI_CONFIG_DEFAULTS, UnicodeValidatorDirective, UpdateUserAccessRequest, UpdateUserVPNInfo, UseParentFormDirective, UserApiToken, UserAuthConfig, UserConstants, UserCredential, UserDevspace, UserK8sExplorerDataSource, UserPrincipal, UserProvider, UserPublicKey, UserRole, UserRoleInfo, UserRoleSource, UserRoles, UserSession, UserTenant, UserTenantAccess, UserTenantNames, UserTokenResponse, UserUpdateRequest, UserVPNConfig, UsersInfo, ValidationErrorsDirective, ValidationStateDirective, VaultBackupPolicy, VbpProperties, ViewDataModalComponent, ViewDataModalRef, ViewDataModalService, ViewHeaderCardComponent, ViewJsonComponent, ViewJsonModalComponent, ViewJsonModalRef, ViewJsonModalService, ViewWithSidecardsComponent, ViewYamlComponent, VmSize, VpcEndpoint, WARNING_REPORTER, WeeklySchedule, WorkspaceSystemSettingsDataSource, WorkspaceSystemSettingsService, XML_EDITOR_OPTIONS, XTERM_BACKGROUND, XTERM_CLEAR_COMMAND, XTERM_TERMINAL_CONFIG, XmlValidationDirective, XtermBlockComponent, XtermCommand, XtermSocketComponent, XtermSocketService, YAML_EDITOR_OPTIONS, YamlMapValidationDirective, YamlSnippetEditorComponent, YamlUtils, YamlValidationDirective, YamlValueValidationDirective, activeStatusBadges, aiSettingBoolValueStyleMap, aiSettingTypeStyleMap, applyCardGridFilterSort, applyK8sEnrichment, applyLegacyLabels, asBool, asJson, asNumber, asString, brandText, brandTitle, buildLifecycleTimeline, capBadges, closeModalsOnNavigation, cloudToK8sName, codeMirrorTheme, commandBlockTheme, convertKeysToLowerCase, convertUtcToLocalDate, convertUtcToLocalISO, createInsensitivePathGetter, cssColorToHex, docsLink, docsLinkHtml, downloadFileByUrl, downloadJsonAsFile, duploDarkCodeMirror, duploDarkEchartsTheme, duploDarkHighlightStyle, ensureThemeDefaults, expandableListTone, extensionRemoteEntry, extractErrorMessage, formatNumberWithK, formatPodStatus, formatTimelineDate, generateHttpOptions, generateUniqueId, getDiffOps, getExt, getFileLang, getFileRenderKind, getFileType, getK8sKind, getLabelFromSysConfig, getMonacoLanguage, getUiConfig, isAgentPolicySetting, isCustomBrand, isDeprovisionStatus, isInternalEmail, isLicenseRefusal, isNotEmptyValue, isPreviewSupported, isResourceInFlight, isSessionReadOnly, isThemePreference, isValidConnectionName, listCardInitial, listCardInitials, mapEntriesToFileNodes, markedOptionsFactory, monacoTheme, nonEmptyString, openLinkInNewTab, parseSettingValue, podStatusBadgeStyles, pollForTicket, readThemePreference, redirectToParentOnError, removeEmptyProperties, reservedGenericSettingNames, resolveAvatarColor, resolveDarkImage, resolveLabel, resolvePath, resolveRowValue, resolveSingle, resolveSource, resolveThemeMode, resourceHealthCounts, resourceStatusBadge, roundToTwoDecimals, scrollParentToChild, scrollToBottomElement, sendToHelpDesk, serviceEndpointTypes, statusMap, stopMonacoThemeSync, subnetTypes, syncMonacoTheme, toK8sRow, tokenHex, versionMarkedOptionsFactory, westrosDarkEchartsTheme, withCacheTag, withCanUpdateName, withMonacoTheme, workspaceHiddenMenuPrefill, xtermTheme };
export type { AiMenuDeps, AiMenuProviderGroup, AiMenuRemote, AiSuiteSetting, AiSuiteSettingName, AiSuiteSettingOption, AnalyticsConsentState, AnalyticsProps, AnyObject, ApiListResponse, ApiListResponseWithPagination, ApiSingleResponse, ApiTokenCreateResponse, ApiTokenSettings, AppTile, AzureNatGatewayLocation, AzureNatGatewayPublicIPAddress, AzureNatGatewaySubnet, AzureNatGatewayUpdateRequest, AzureResourceId, AzureResourceType, BadgeOverflow, Breadcrumb, BreadcrumbLink, CanvasDoc, CanvasRendererDescriptor, CardGridSortField, CardGridSortOption, CommonLibConfig, ConfirmationModalOptions, ConnectRequest, ConnectionCredentialSchema, ConnectionField, ConnectionOption, ConnectionProvider, ConnectionResult, ConnectionScope, ConnectionTypeDefinition, ConnectionVariant, CoreConfig, CoreConfigLayoutSkin, CoreMenu, CoreMenuItem, CreateApiTokenRequest, CustomDataSpec, DataViewFormat, DeepPartial, DeleteConfirmationModalOptions, DetailBadge, DetailBadgeKind, DetailCallout, DetailCalloutKind, DetailCountRow, DetailKvRow, DetailTimelineEvent, DetailTimelineState, DnsEntry, DnsOptions, DocDiffOp, DocsLinkName, DuploCiClientEndpoint, EditMode, EditableCustomData, EntityFileEntry, EntityFilesContract, EnumMapName, EnumMapOf, EnumMapOfString, EnumSelectOption, ErrorMessage, ErrorReporter, ExpandableListContext, ExpandableListMark, ExpandableListRow, ExpandableListTone, ExtensionAnalytics, ExtensionScope, FieldDetails, FileBadge, FileBinaryLoader, FileContentLoader, FileEditorConfigOpts, FileEditorContentChange, FileEditorSaveEvent, FileLangId, FileNode, FileNodeType, FileRenderKind, FileTreeAction, FileTreeActionEvent, FileTreeActionTheme, FileTreeSourceEntry, FilterChangeEvent, FilterPill, FolderLoader, GenericFormInputType, GkeReleaseChannel, GkeServerConfig, HideWhen, IDocumentEditor, IResourceK8sService, InstantRPDetails, JsonEditorSize, K8sActionId, K8sCellType, K8sCellValue, K8sColumnDef, K8sContext, K8sEnrichDef, K8sExplorerApi, K8sExplorerFeatures, K8sExplorerSelection, K8sExplorerState, K8sFacetDef, K8sKindDef, K8sKindGroup, K8sKindGroupId, K8sLabelSelector, K8sList, K8sObject, K8sObjectMeta, K8sOwnerReference, K8sPodCoverage, K8sPodLogs, K8sPodLogsOptions, K8sResourceRef, K8sRestartableKind, K8sRow, K8sScopeInfo, K8sTone, KeyValueField, KubeConfigCluster, KubeConfigClusterEntry, KubeConfigContext, KubeConfigContextEntry, KubeConfigUser, KubeConfigUserEntry, KvRow, LastError, LifecycleTargetLabels, ListCardAction, ListCardMark, ListFilterOption, ListQueryDefaults, ListQueryState, ListStatTone, LoadPageEvent, Locale, LogAnalyticsConfig, MarkdownEditModalOptions, MarkdownEditorMode, MenuAction, MenuActionEvent, MenuBuilderFn, MiniHelpDeskCommandRules, MiniHelpDeskField, MiniHelpDeskFieldKey, MiniHelpDeskFieldState, MiniHelpDeskFields, MiniHelpDeskHeader, MiniHelpDeskOpenConfig, MiniHelpDeskOrigin, MiniHelpDeskPromptSuggestion, MiniHelpDeskPromptTemplate, MiniHelpDeskTicketRef, MiniHelpDeskUrl, MonacoThemeName, MultiField, NamespacedTracker, NumberSelectOption, PagedData, PrivateDnsDetails, PropertiesSku, RawField, RecoveryVaultConfig, RemoteMenuBuilder, RemoteMenuExtensionNode, RemoteMenuExtensionSetup, RemoteMenuExtensionTree, ResolvedAgent, ResourceHealthCounts, ResourceViewTemplate, RsvProperties, SecurityGroup, SecurityGroupIdentifier, SelectOptions, ServiceTypeDetail, SettingAbout, ShellHeaderTag, ShellSidecard, SingleField, Sku, StatDotKind, StatusBadge, StringSelectOption, SubTemplate, SuccessReporter, TabCloseRequest, TableField, TemplateColumn, TemplateField, TemplateGroup, TenantFeaturesMap, ThemeMode, ThemePreference, ThemedImageKey, TicketStatusResponse, TokenPaginatedPage, UserSettings, ValueObj, ViewDataModalOptions, ViewHeaderAction, ViewJsonModalOptions, Vnet, WarningReporter, WorkspaceSettingOpts, YamlSnippet };
//# sourceMappingURL=duplocloud-internal-ng-common-lib.d.ts.map
