import * as i27 from 'ng-block-ui';
import { NgBlockUI } from 'ng-block-ui';
export * from 'ng-block-ui';
import * as i0 from '@angular/core';
import { InjectionToken, Type, OnDestroy, OnInit, AfterViewInit, OnChanges, EventEmitter, NgZone, ChangeDetectorRef, ElementRef, SimpleChanges, SimpleChange, TemplateRef, ViewContainerRef, QueryList, Renderer2, PipeTransform, AfterContentInit, SecurityContext, ModuleWithProviders, Injector } from '@angular/core';
import * as rxjs from 'rxjs';
import { Observable, Subject, OperatorFunction, BehaviorSubject, Subscription } from 'rxjs';
import * as i4 from '@swimlane/ngx-datatable';
import { DataTableColumnDirective, DatatableRowDetailDirective, DatatableComponent, SortPropDir } from '@swimlane/ngx-datatable';
import { TranslateService, TranslationObject } from '@ngx-translate/core';
import * as i3$1 from '@ng-bootstrap/ng-bootstrap';
import { NgbAlert, NgbNav, NgbTooltip, NgbActiveModal, Placement, NgbModalRef, NgbModal, NgbTimeAdapter, NgbTimeStruct } from '@ng-bootstrap/ng-bootstrap';
import { Clipboard } from '@angular/cdk/clipboard';
import * as i29 from 'ngx-toastr';
import { ToastrService, IndividualConfig } from 'ngx-toastr';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, ActivatedRoute, NavigationExtras } from '@angular/router';
import * as _duplocloud_internal_ng_common_lib from '@duplocloud-internal/ng-common-lib';
import * as i1$2 from '@angular/common';
import { Location } from '@angular/common';
import * as i1$1 from '@angular/material/icon';
import { MatIconRegistry } from '@angular/material/icon';
import * as i1 from 'ngx-monaco-editor-v2';
import * as i2 from 'ngx-markdown';
import * as i2$1 from '@ngbracket/ngx-layout';
import { MediaObserver } from '@ngbracket/ngx-layout';
import * as i3 from '@angular/forms';
import { FormGroupDirective, NgForm, NgControl, ValidationErrors, AbstractControl, AsyncValidator, Validator, ValidatorFn, ControlValueAccessor } from '@angular/forms';
import { DomSanitizer, SafeHtml, SafeStyle, SafeScript, SafeUrl, SafeResourceUrl } from '@angular/platform-browser';
import * as i5 from '@ng-select/ng-select';
import { HttpErrorResponse, HttpClient, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpBackend } from '@angular/common/http';
import * as i28 from 'angularx-flatpickr';
import { Diff2HtmlConfig } from 'diff2html';
import { ITerminalOptions } from '@xterm/xterm';
import { StringKeyOf } from 'ts-enum-util/dist/types/types';
import * as marked from 'marked';

/**
 * Value injected into a canvas renderer component. Renderers read the doc id and its content stream from
 * here instead of an `@Input()` — `ngComponentOutlet` (Angular 15) cannot bind component inputs, so the
 * host hands the renderer its data through a per-canvas injector carrying this token.
 */
interface CanvasDoc {
    docId: string;
    content$: Observable<string>;
}
declare const CANVAS_DOC: InjectionToken<CanvasDoc>;
/**
 * Describes how to render a canvas document (an agent artifact opened in the canvas panel). An extension
 * registers one of these from its ticket wrapper so its own canvas files render its own component, with no
 * host code change. The match predicate decides which artifacts this renderer claims.
 */
interface CanvasRendererDescriptor {
    /** Unique id, e.g. 'tf:extracted-environments'. Re-registering the same id replaces the prior descriptor. */
    id: string;
    /** Canvas tab title. */
    title: string;
    /** Whether the canvas shows the Edit/Save controls. Defaults to false. */
    isEditable?: boolean;
    /** Higher wins on overlapping matches. Defaults to 0; extensions use a positive value (e.g. 10). */
    priority?: number;
    /** Returns true for artifacts this renderer should claim (matched against `artifact.id`). */
    match: (artifact: {
        id?: string;
    }) => boolean;
    /** Component to instantiate for the canvas. */
    component: Type<unknown>;
    /** Optional module that declares/provides `component` — required for components from a Module-Federation
     *  remote so the host can build them with their own module providers. */
    ngModule?: Type<unknown>;
}
/**
 * Runtime registry of canvas renderers, owned by the host app (`providedIn: 'root'` — one instance). An
 * extension reaches that single instance via the `REMOTE_CanvasRendererRegistry` DI token (an extension bundles
 * its own copy of this library, so the string token — not class identity — guarantees both sides see the same
 * object); a renderer it registers is then seen by the host's canvas pipeline.
 *
 * Built-in canvases (stage board, dashboard instance, extracted environments) are NOT registered here; they
 * keep their native hardcoded path. The registry is purely the extension extensibility lane.
 */
declare class CanvasRendererRegistry {
    private readonly byId;
    private order;
    /** Register (or replace by id) a renderer. Idempotent, so re-entering a ticket is safe. */
    register(descriptor: CanvasRendererDescriptor): void;
    unregister(id: string): void;
    get(id: string | undefined): CanvasRendererDescriptor | undefined;
    /** First renderer (by priority desc, then registration order) whose predicate claims the artifact. */
    match(artifact: {
        id?: string;
    }): CanvasRendererDescriptor | undefined;
    private reindex;
    static ɵfac: i0.ɵɵFactoryDeclaration<CanvasRendererRegistry, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CanvasRendererRegistry>;
}

declare class SubDestroyService extends Subject<void> implements OnDestroy {
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubDestroyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubDestroyService>;
}

declare class SearchableDatatableExtraAction {
    name: string;
    label: string;
    icon?: string;
    class?: string;
    isMenu?: boolean;
    helpKey?: string;
    isServiceAction?: boolean;
    restrictAccessForReadonlyUser?: boolean;
    constructor(attrs?: Partial<SearchableDatatableExtraAction>);
}

interface FilterChangeEvent {
    searchTerm: string;
}
declare class SearchableDatatableComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
    private zone;
    private _changeDetector;
    private elRef;
    private i18n;
    /** Whether or not to show the add button. */
    showAdd: boolean;
    addLabel: string;
    _disableAdd: boolean;
    _disableMessage: string;
    set disableAddWithAMessage(message: string);
    /** Whether or not to filter input. */
    showFilter: boolean;
    showCount: boolean;
    showEdit: boolean;
    showNew: boolean;
    showForceRefresh: boolean;
    extraActions: SearchableDatatableExtraAction[];
    loadingIndicator: boolean;
    extraButtonsAvailable: boolean;
    extraActionsButtonCaption: string;
    /** Whether or not to reset the view (pagination, etc.) when the rows change */
    resetOnChange: boolean;
    _rows: any[];
    rowsPerPage: number;
    rowsPerPageOptions: number[];
    columnMode: "force";
    includeHeader: boolean;
    isActionsFixed: boolean;
    footerHeight: number | boolean;
    searchTerm: string;
    set rows(rows: any[]);
    /** Properties for multiselect rows */
    enableCheckboxSelection: boolean;
    displayCheck: () => boolean;
    selected: any[];
    selectionType: any;
    getRowId: (x: any) => any;
    serviceActionFilter: (action: SearchableDatatableExtraAction, selectedServices: unknown[]) => boolean;
    /** To show alert message based on condition */
    showAlert: boolean;
    alertMessage: NgbAlert;
    columnTemplates: i0.Signal<readonly DataTableColumnDirective<any>[]>;
    tableColumns: i0.Signal<i4.TableColumn<any>[]>;
    rowDetailTpl?: DatatableRowDetailDirective;
    ownRowDetail?: DatatableRowDetailDirective;
    private rowDetailBridge?;
    table: DatatableComponent;
    add: EventEmitter<void>;
    action: EventEmitter<string>;
    edit: EventEmitter<void>;
    outputNewItem: EventEmitter<void>;
    forceRefresh: EventEmitter<void>;
    filter: EventEmitter<FilterChangeEvent>;
    select: EventEmitter<void>;
    skipResetOnce: boolean;
    isFixed: boolean;
    externalPaging: boolean;
    externalSorting: boolean;
    totalCount: number;
    pageNumber: number;
    onPage: EventEmitter<{
        pageNumber: number;
        pageSize: number;
        totalCount: number;
    }>;
    onSort: EventEmitter<{
        sortBy: string;
        sortOrder: string;
    }>;
    constructor(zone: NgZone, _changeDetector: ChangeDetectorRef, elRef: ElementRef, i18n: TranslateService);
    /**
     * Handles the 'sidebarToggle' event to recalculate the table layout.
     * This method is triggered when the sidebar is toggled, ensuring
     * the datatable adjusts its dimensions and columns after a delay.
     */
    onSidebarCollapsed(): void;
    addItem(): void;
    editItem(): void;
    emitNewItem(): void;
    emitRefresh(): void;
    getButtons(): SearchableDatatableExtraAction[];
    getMenus(): SearchableDatatableExtraAction[];
    getServiceActions(): SearchableDatatableExtraAction[];
    areAllButtonsRestricted(): void;
    hasMenus(): boolean;
    /** Resets the view (pagination, etc.) */
    reset(): void;
    extraActionClick(action: string): void;
    onLimitChange(limit: any): void;
    /** Refreshes the list by reapplying filters. */
    refresh(skipReset?: boolean): void;
    filterUpdate(value?: string): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    shouldSkipReset(rowChange: SimpleChange): boolean;
    startLoading(): void;
    stopLoading(): void;
    onSelect(selected: any[]): void;
    get showServiceActions(): boolean;
    unSelectAll(): void;
    sortCallback(sorts: any): void;
    pageCallback(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchableDatatableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchableDatatableComponent, "searchable-datatable", never, { "showAdd": { "alias": "showAdd"; "required": false; }; "addLabel": { "alias": "addLabel"; "required": false; }; "disableAddWithAMessage": { "alias": "disableAddWithAMessage"; "required": false; }; "showFilter": { "alias": "showFilter"; "required": false; }; "showCount": { "alias": "showCount"; "required": false; }; "showEdit": { "alias": "showEdit"; "required": false; }; "showNew": { "alias": "showNew"; "required": false; }; "showForceRefresh": { "alias": "showForceRefresh"; "required": false; }; "extraActions": { "alias": "extraActions"; "required": false; }; "extraActionsButtonCaption": { "alias": "extraActionsButtonCaption"; "required": false; }; "resetOnChange": { "alias": "resetOnChange"; "required": false; }; "_rows": { "alias": "_rows"; "required": false; }; "rowsPerPage": { "alias": "rowsPerPage"; "required": false; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; }; "columnMode": { "alias": "columnMode"; "required": false; }; "includeHeader": { "alias": "includeHeader"; "required": false; }; "isActionsFixed": { "alias": "isActionsFixed"; "required": false; }; "footerHeight": { "alias": "footerHeight"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "enableCheckboxSelection": { "alias": "enableCheckboxSelection"; "required": false; }; "displayCheck": { "alias": "displayCheck"; "required": false; }; "getRowId": { "alias": "getRowId"; "required": false; }; "serviceActionFilter": { "alias": "serviceActionFilter"; "required": false; }; "showAlert": { "alias": "showAlert"; "required": false; }; "externalPaging": { "alias": "externalPaging"; "required": false; }; "externalSorting": { "alias": "externalSorting"; "required": false; }; "totalCount": { "alias": "totalCount"; "required": false; }; "pageNumber": { "alias": "pageNumber"; "required": false; }; }, { "add": "add"; "action": "action"; "edit": "edit"; "outputNewItem": "outputNewItem"; "forceRefresh": "forceRefresh"; "filter": "filter"; "select": "select"; "onPage": "onPage"; "onSort": "onSort"; }, ["columnTemplates", "rowDetailTpl", "alertMessage"], ["[datatable-filters]", "ngb-alert", "[datatable-actions]", "*"], false, never>;
}

interface CardGridSortField {
    label: string;
    key: string;
}
interface CardGridSortOption {
    label: string;
    sortBy: string;
    sortOrder: 'asc' | 'desc';
}
/** Default sort fields used by most card-grid lists. Override via the `sortFields` input. */
declare const DEFAULT_CARD_GRID_SORT_FIELDS: CardGridSortField[];
/**
 * Filters by an optional facet `predicate`, then `searchFields`, then sorts.
 * Order matters: filter option counts are built from the unfiltered list.
 */
declare function applyCardGridFilterSort<T>(items: T[], searchFields: string[], searchTerm: string, sortBy: string, sortOrder: 'asc' | 'desc', predicate?: (item: T) => boolean): T[];

declare class CardGridToolbarComponent implements OnInit {
    private destroy$;
    sortFields: CardGridSortField[];
    searchPlaceholder: string;
    showFilter: boolean;
    showSort: boolean;
    /** Initial field key to select. Defaults to the first field. */
    activeSortKey?: string;
    /** Initial sort direction. */
    sortDirection: 'asc' | 'desc';
    /** Seeds the input, so a page can restore a search from queryParams. */
    searchTerm: string;
    searchDebounce: number;
    filter: EventEmitter<FilterChangeEvent>;
    sortChange: EventEmitter<CardGridSortOption>;
    searchActiveChange: EventEmitter<boolean>;
    activeField?: CardGridSortField;
    private readonly search$;
    private lastSearchActive;
    constructor(destroy$: SubDestroyService);
    ngOnInit(): void;
    onSearchInput(term: string): void;
    /** Clears local input state and replaces any pending debounced term with ''. */
    resetSearch(): void;
    /** Emits only on transitions, so typing many characters emits once. */
    private emitSearchActive;
    selectField(field: CardGridSortField): void;
    toggleDirection(): void;
    private emitSort;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardGridToolbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardGridToolbarComponent, "app-card-grid-toolbar", never, { "sortFields": { "alias": "sortFields"; "required": false; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; }; "showFilter": { "alias": "showFilter"; "required": false; }; "showSort": { "alias": "showSort"; "required": false; }; "activeSortKey": { "alias": "activeSortKey"; "required": false; }; "sortDirection": { "alias": "sortDirection"; "required": false; }; "searchTerm": { "alias": "searchTerm"; "required": false; }; "searchDebounce": { "alias": "searchDebounce"; "required": false; }; }, { "filter": "filter"; "sortChange": "sortChange"; "searchActiveChange": "searchActiveChange"; }, never, ["[toolbar-filter]", "[toolbar-summary]"], true, never>;
}

/**
 * Features:
 * - Uses Angular CDK (officially supported)
 * - Synchronous API (no async/await needed)
 * - Automatic success/error toast notifications
 * - Built-in fallback handling by Angular CDK
 * - Works with all Angular versions 16-20+
 *
 * Migration from ngx-clipboard:
 * - Near drop-in replacement
 * - Same API signature: copy(text)
 * - No dependency on third-party libraries
 */
declare class ClipboardService {
    private clipboard;
    constructor(clipboard: Clipboard);
    /**
     * Copy text to clipboard using Angular CDK Clipboard
     *
     * @param text - Text to copy to clipboard
     * @param successMessage - Optional custom success message
     * @returns boolean - true if successful, false otherwise
     */
    copy(text: string, successMessage?: string): boolean;
    /**
     * Copy text to clipboard without showing toast notification
     * Useful when you want to handle the success/error messaging yourself
     *
     * @param text - Text to copy to clipboard
     * @returns boolean - true if successful, false otherwise
     */
    copySilent(text: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClipboardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClipboardService>;
}

declare class DuploToastrService {
    private toaster;
    constructor(toaster: ToastrService);
    shortSuccessMessage(message: string): void;
    longSuccessMessage(message: string): void;
    successMessage(message: string, timeOut?: number): void;
    errorMessage(message: string, timeOut?: number): void;
    shortErrorMessage(message: string): void;
    longErrorMessage(message: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploToastrService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploToastrService>;
}

declare class CodeBlockWithCopyComponent implements OnInit {
    private clipboardService;
    private toastrService;
    code: string;
    displayCode: string;
    successMessage: string;
    language: string;
    copied: boolean;
    constructor(clipboardService: ClipboardService, toastrService: DuploToastrService);
    ngOnInit(): void;
    /**
     * Format language name for better display
     */
    private formatLanguage;
    copyCode(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CodeBlockWithCopyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CodeBlockWithCopyComponent, "app-code-block-with-copy", never, { "code": { "alias": "code"; "required": false; }; "displayCode": { "alias": "displayCode"; "required": false; }; "successMessage": { "alias": "successMessage"; "required": false; }; "language": { "alias": "language"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SidecardComponent implements OnInit {
    private host;
    /** Customize the icon color. */
    iconColor: string;
    /** Pass an icon by name (uses feather icons) */
    icon: string;
    /** Pass a feather icon by name*/
    featherIcon: string;
    /** Pass a material icon (or custom icon) by name */
    matIcon: string;
    /** Pass the help key to show the help onhover */
    helpKey: string;
    /** Pass a custom icon section by a template */
    iconTpl: TemplateRef<any>;
    constructor(host: ViewContainerRef);
    ngOnInit(): void;
    getName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidecardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidecardComponent, "sidecard", never, { "iconColor": { "alias": "iconColor"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "featherIcon": { "alias": "featherIcon"; "required": false; }; "matIcon": { "alias": "matIcon"; "required": false; }; "helpKey": { "alias": "helpKey"; "required": false; }; }, {}, ["iconTpl"], ["*"], false, never>;
}
declare class ViewWithSidecardsComponent implements OnInit {
    private host;
    sideCards: QueryList<SidecardComponent>;
    hostName: any;
    constructor(host: ViewContainerRef);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewWithSidecardsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewWithSidecardsComponent, "view-with-sidecards", never, {}, {}, ["sideCards"], ["*", "sidecard, [side-content]"], false, never>;
}

interface ViewHeaderAction {
    text: string;
    handler: () => void;
}
declare class ViewHeaderCardComponent implements OnInit, AfterViewInit {
    /** Title passed as plain text. */
    title: string;
    /** Title passed as a template. */
    titleTpl: TemplateRef<any>;
    /** Subtitle passed as plain text. */
    subtitle: string;
    /** Subtitle passed as a template. */
    subtitleTpl: TemplateRef<any>;
    /** Whether or not to display the actions dropdown */
    showActions: boolean;
    /** Header actions passed as plain text and handlers. */
    actions: ViewHeaderAction[];
    /** Header actions passed as a template. */
    actionsTpl: TemplateRef<any>;
    /**
     * Optional inline toolbar rendered immediately before the actions button —
     * intended for compact filters (e.g. a Spec/Result `app-flat-status-filter`)
     * that sit next to the three-dot icon.
     */
    headerFilterTpl: TemplateRef<any>;
    /** Dynamic Placement of actions dropdown for grouped layout*/
    dynamicAction: boolean;
    /**
     * When true, the actions trigger is rendered as a three-dot vertical icon
     * button instead of the default "Actions" pill button. Opt-in per-page.
     */
    compactActions: boolean;
    constructor();
    ngAfterViewInit(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewHeaderCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewHeaderCardComponent, "view-header-card", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "showActions": { "alias": "showActions"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; "dynamicAction": { "alias": "dynamicAction"; "required": false; }; "compactActions": { "alias": "compactActions"; "required": false; }; }, {}, ["titleTpl", "subtitleTpl", "actionsTpl", "headerFilterTpl"], ["*"], false, never>;
}

declare class MiniCardComponent implements OnInit {
    /** Customize the icon color. */
    iconColor: string;
    /** Pass an icon by name (uses feather icons) */
    icon: string;
    /** Pass a feather icon by name*/
    featherIcon: string;
    /** Pass a material icon (or custom icon) by name */
    matIcon: string;
    hideHelp: boolean;
    /** Pass a custom icon section by a template */
    iconTpl: TemplateRef<any>;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MiniCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MiniCardComponent, "mini-card", never, { "iconColor": { "alias": "iconColor"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "featherIcon": { "alias": "featherIcon"; "required": false; }; "matIcon": { "alias": "matIcon"; "required": false; }; "hideHelp": { "alias": "hideHelp"; "required": false; }; }, {}, ["iconTpl"], ["*", "[minicard-detail]"], false, never>;
}

declare class ScrollableNavTabComponent implements AfterViewInit, OnDestroy {
    private destroy$;
    navDiv: ElementRef;
    ngbNav: NgbNav;
    startPos: number;
    listWidth: number;
    containerWidth: number;
    firstInViewIndex: number;
    lastInViewIndex: number;
    totalTabs: number;
    private sizeObserver?;
    get showLeftScroll(): boolean;
    get showRightScroll(): boolean;
    get needScroll(): boolean;
    constructor(destroy$: SubDestroyService);
    private navItemElement;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * Measuring once in ngAfterViewInit went stale on a window resize, a rail
     * collapse, a webfont landing, or tabs arriving from async data.
     */
    private observeSize;
    /** The projected tab list. firstChild broke if anything preceded the ul. */
    private tabListElement;
    setTabListWidth(): void;
    setTabInViewIndex(): void;
    scrollToActiveTab(): void;
    onScrollTabs(isPrev?: boolean): void;
    onScrollToPos(startPos: number): void;
    isTabInView(tabEle: HTMLElement): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollableNavTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollableNavTabComponent, "scrollable-nav-tab", never, {}, {}, ["ngbNav"], ["*"], false, never>;
}

/**
 * One page of items. Extracted from ApiListResponseWithPagination so callers whose payload
 * nests a page inside a larger view (rather than at the envelope's root) have a name for it.
 * Structurally identical to what that envelope always declared inline.
 */
interface PagedData<T> {
    items: T[];
    page: number;
    pageSize: number;
    totalCount: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
}
interface ApiListResponseWithPagination<T> {
    success: boolean;
    data: PagedData<T>;
    message: null;
    errors: null;
}
interface ApiListResponse<T> {
    success: boolean;
    data: T[];
    message: null;
    errors: null;
}
interface ApiSingleResponse<T> {
    success: boolean;
    data: T;
    message: null;
    errors: null;
}
/**
 * Base entity class for all MongoDB entities
 */
declare abstract class BaseEntity {
    constructor(properties?: Partial<BaseEntity>);
    /**
     * Unique identifier for the entity
     */
    id?: string;
    /**
     * Name of the entity
     */
    name?: string;
    /**
     * Description of the entity
     */
    description?: string;
    /**
     * Date and time when the entity was created
     */
    createdAt?: string;
    /**
     * Date and time when the entity was last updated
     */
    updatedAt?: string;
    /**
     * Indicates if the entity is active or deleted (soft delete)
     */
    isActive?: boolean;
    /**
     * Version number for optimistic concurrency control
     * Incremented on each update to detect concurrent modifications
     */
    version?: number;
    /**
     * Additional metadata for the entity
     */
    metaData?: Record<string, string>;
}

declare const EMPTY_WORKSPACE_ID = "empty-workspace";
declare class AIWorkspaceBase implements BaseEntity {
    constructor(properties?: Partial<AIWorkspaceBase>);
    id: string;
    name: string;
    shortName?: string;
    description: string;
    personaIds: string[];
    createdAt?: string;
    updatedAt?: string;
    scopeIds?: string[];
    email?: string;
    role?: string;
    team?: string;
    agentIds: string[];
    analyticsId?: string;
    repoIds?: string[];
    knowledgeIds?: string[];
    projectIds?: string[];
    ticketIds?: string[];
    incidentIds?: string[];
    guardrailId?: string;
    quotaId?: string;
}
declare const EMPTY_WORKSPACE: AIWorkspaceBase;

type GenericFormInputType = 'number' | 'text' | 'checkbox' | 'password' | 'hidden' | 'textarea' | 'select' | 'monaco-editor' | 'selectmultiple' | 'json' | 'yaml' | 'password-with-show-option';
type JsonEditorSize = null | 'xlg' | 'lg' | 'md' | 'sm' | 'xsm';
declare class GenericFormInput {
    constructor(properties?: Partial<GenericFormInput>);
    label?: string;
    type?: GenericFormInputType;
    name: string;
    value?: any;
    required?: boolean;
    disabled?: boolean;
    minlen?: number;
    maxlen?: number;
    rows?: number;
    mask?: boolean;
    placeholder?: string;
    selectOptions?: SelectOptions[] | string[] | any[];
    selectBindLabel?: string;
    selectBindValue?: string;
    allowOtherValue?: boolean;
    otherValue?: string;
    pattern?: string;
    jsonEditorOptions?: object;
    jsonEditorSize?: JsonEditorSize;
    notExists?: string[];
    description?: string;
    loading?: boolean;
    groupBy?: string;
    alertIcon?: string;
    alertType?: string;
    alertTitle?: string;
    alertMessage?: string;
    /**
     * Resolves dot-notation selectBindValue / selectBindLabel paths once at load time,
     * adding __resolvedValue and __resolvedLabel flat keys to each option so that
     * ng-select can bind and search without recomputing on every change detection cycle.
     */
    static flattenDeepPaths(options: any[], bindValuePath?: string, bindLabelPath?: string): any[];
}
interface SelectOptions {
    label: string;
    value: string;
    disabled?: boolean;
}

/**
 * generate groups of 4 random characters
 * @example getUniqueId(1) : 607f
 * @example getUniqueId(2) : 95ca-361a
 * @example getUniqueId(4) : 6a22-a5e6-3489-896b
 */
declare function generateUniqueId(parts?: number): string;
declare class TableStatus$1 {
    text: string;
    style: string;
    constructor(text: string, style: string);
}
declare function generateHttpOptions(options?: any): {};
/**
 * Scrolls the parent element to make the child element visible within the parent's viewable area.
 * @param parent - The parent element that contains the child element.
 * @param child - The child element that needs to be made visible within the parent's viewable area.
 * @param topOffset - The additional offset from the top of the child element to scroll the parent element. Default is 0.
 * @param bottomOffset - The additional offset from the bottom of the child element to scroll the parent element. Default is 0.
 */
declare function scrollParentToChild(parent: HTMLElement, child: HTMLElement, topOffset?: number, bottomOffset?: number): void;
/**
 * Downloads a JavaScript object as a JSON file.
 * @param fileName - The name of the JSON file to be downloaded.
 * @param jsObject - The JavaScript object to be converted to JSON and downloaded.
 */
declare function downloadJsonAsFile(fileName: string, jsObject: object): void;
declare function formatNumberWithK(num: number): string | number;
declare function roundToTwoDecimals(num: number): string;
declare function openLinkInNewTab(url: string): void;
declare function scrollToBottomElement(element: HTMLElement): void;
declare function removeEmptyProperties<T extends Record<string, any>>(obj: T): T;
/**
 * Create a case-insensitive path getter with caching.
 * - Converts all enumerable string keys of the source object to lowercase (deeply) once.
 * - Returns a function that accepts a dot-separated path and resolves it case-insensitively.
 */
declare function createInsensitivePathGetter<T extends any>(source: T): (path: string, defaultValue?: any) => any;
declare function isNotEmptyValue(value: any): boolean;
declare function getLabelFromSysConfig(aiSuiteConfigvalue?: string): (label: string) => string;
declare function downloadFileByUrl(url: string, fileName: string): void;
/**
 * Convert UTC date string to local Date object
 * @param utcDateString UTC date string (e.g., "1/16/2026 6:48:03 AM")
 * @returns Date object interpreted as local time
 */
declare function convertUtcToLocalISO(utcDateString: string | Date): string;
/**
 * Convert UTC date string to local Date object
 * @param utcDateString UTC date string (e.g., "1/16/2026 6:48:03 AM")
 * @returns Date object interpreted as local time
 */
declare function convertUtcToLocalDate(utcDateString: string | Date): string;

declare const TENANT_FEATURE_DENY_OPEN_ACCESS_TO_PUBLIC_LB = "deny_open_access_to_public_lb";
declare const TENANT_FEATURE_ENABLE_AWS_IOT = "enable_aws_iot";
declare const TENANT_FEATURE_AWS_IOT_TOPIC_PREFIX = "aws_iot_topic_prefix";
declare const TENANT_FEATURE_AWS_IOT_THING_PREFIX = "aws_iot_thing_prefix";
declare const TENANT_FEATURE_AZURE_ALLOW_PUBLIC_NETWORK_DB_AND_CACHE = "allow_public_network_to_azure_db_and_cache";
declare const TENANT_FEATURE_MAXIMUM_SESSION_DURATION = "maximum_session_duration";
declare const TENANT_FEATURE_MAXIMUM_K8S_SESSION_DURATION = "maximum_k8s_session_duration";
declare const TENANT_FEATURE_HEADER_COLOR = "tenant_header_bg-color";
declare const TENANT_FEATURE_AUTO_REBOOT_EC2_STATUS_CHECK = "auto_reboot_ec2_status_check";
declare const TENANT_FEATURE_AUTO_REBOOT_EC2_DISCONNECTED = "auto_reboot_ec2_disconnected";
declare const TENANT_FEATURE_SET_SNS_TOPIC_ALERTS = "alertssnstopic";
declare const EMPTY_GUID = "00000000-0000-0000-0000-000000000000";
declare const TENANT_FEATURE_CA_OVERPROVISIONING = "enable_ca_overprovisioning";
declare const TENANT_AI_STUDIO_ENABLED = "enabled_ai_studio_tenant";
declare const AI_HELPDESK_DEFAULT_ACTION_SELECTION = "AI_HELPDESK_DEFAULT_ACTION_SELECTION";
declare const AWS_SERVICES_TAG_BASED_OWNERSHIP_ENABLED = "AwsServicesTagBasedOwnershipEnabled";
declare const ENABLE_AI_SUITE = "ENABLE_AI";
declare const DISABLE_PLATFORM = "DISABLE_CORE_PLATFORM";
/**
 *  Aws Unavailable Services tenant feature
 */
declare enum AwsUnavailableServices {
    DATAPIPELINE = "datapipeline",
    MWAA_AIRFLOW = "mwaa_airflow",
    CLOUDFRONT = "cloudfront",
    EMRSERVERLESS = "emrserverless",
    TIMESATREAM = "timestream",
    APPRUNNER = "apprunner"
}
/**
 * Represents an agnostic reference.
 */
declare class Reference {
    static readonly DUPLO_V1_HOST = "duplo:v1/Host";
    QualifiedType: string;
    NativeId: string;
    Name?: string;
    constructor(properties?: Partial<Reference>);
    get IsKubernetes(): boolean;
    get IsDuplo(): boolean;
    get IsDocker(): boolean;
    get IsAws(): boolean;
    get iconName(): string;
}
/**
 * Represents search and pagination parameters.
 */
declare class SearchAndPaginationParams$1 {
    q?: string;
    sf?: string;
    sd?: string;
    max?: number;
    page?: number;
    constructor(properties?: Partial<SearchAndPaginationParams$1>);
    toUriPart(): string;
}
/**
 * Represents search and pagination results.
 */
declare class SearchAndPaginationResult<R> {
    Query?: string;
    SortField?: string;
    SortDescending: boolean;
    MaxItems: number;
    Page: number;
    TotalItems: number;
    TotalPages: number;
    Items: R[];
    constructor(properties?: Partial<SearchAndPaginationResult<R>>);
}
/**
 *  Represents the available features for a given tenant.
 */
declare class TenantFeatures {
    constructor(properties?: Partial<TenantFeatures>);
    Cloud: CloudPlatform$1;
    Region: string;
    IsKubernetesEnabled: boolean;
    KubernetesType: K8sPlatform;
    TenantMetadata?: CustomData[];
    PlanMetadata?: CustomData[];
    InfraMetadata?: CustomData[];
    AwsUnavailableServices?: string[];
    AppConfigs?: CustomDataEx[];
    IsK8sServerless?: boolean;
    /** Retrieves a tenant metadata value. */
    getMetadataValue(key: string): string;
    /** Checks if a tenant feature is enabled. */
    isEnabled(key: string): boolean;
    /** Retrieves a plan metadata value. */
    getPlanMetadataValue(key: string): string;
    /** Checks if a plan feature is enabled. */
    isPlanEnabled(key: string): boolean;
    /** Retrieves a infra metadata value. */
    getInfraMetadataValue(key: string): string;
    /** Checks if a plan feature is enabled. */
    isInfraEnabled(key: string): boolean;
    /** Human-readable name of the current cloud. */
    get CloudName(): string;
    /** Human-readable name of the CSP-managed Kubernetes in the current cloud. */
    get K8sName(): string;
    /** Human-readable name of the VNET in the current cloud.*/
    get VpcName(): "VNET" | "VPC";
    /** What to call a firewall in the current cloud. */
    get FirewallName(): "Firewall" | "Security Group";
    /** What to call a managed SSL certificate ID in the current cloud. */
    get CertificateArnName(): "GCP Certificate Name" | "Certificate ARN";
    /** new dictionary with service => region + partition */
    IsAwsServiceAvailable(serviceName: string): boolean;
    /** Check if Tenant Infra has GKE Standard/Non-Serverless cluster */
    get isGkeStandardCluster(): boolean;
    get runningOnEksAutoModeCluster(): boolean;
    get IsHelmV2Enabled(): boolean;
    get IsHelmOperatorReady(): boolean;
}
interface TenantFeaturesMap {
    [index: string]: TenantFeatures;
}
/**
 *  Represents the available features in the system.
 *
 *  This class is instantiated automatically by Angular's DI system, but data is only populated
 *  by the CommonRepository component.
 */
declare class SystemFeatures {
    IsSignupEnabled: boolean;
    IsComplianceEnabled: boolean;
    IsSiemEnabled: boolean;
    IsBillingEnabled: boolean;
    DisableOobData: boolean;
    IsKatkitEnabled: boolean;
    IsAwsCloudEnabled: boolean;
    IsOnPremEnabled: boolean;
    IsOracleCloudEnabled: boolean;
    AwsRegions: string[];
    DefaultAwsAccount: string;
    DefaultAwsRegion: string;
    DefaultAwsPartition: string;
    EksVersions: K8ClusterVersions;
    AksVersions?: K8ClusterVersions;
    IsAzureCloudEnabled: boolean;
    AzureRegions: string[];
    IsGoogleCloudEnabled: boolean;
    IsOtpNeeded: boolean;
    IsAwsAdminJITEnabled: boolean;
    GoogleRegions: string[];
    IsDuploOpsEnabled: boolean;
    DefaultInfraCloud: string;
    DevopsManagerHostname: string;
    TenantNameMaxLength: number;
    DuploShellFqdn?: string;
    IsTagsBasedResourceMgmtEnabled: boolean;
    EnabledFlags: string[];
    IsAiTenantAvailable: boolean;
    GcpDisableTenantPrefix?: boolean;
    GcpDisableDuploPrefix?: boolean;
    DisableVpcCreation?: boolean;
    AwsServicesTagBasedOwnershipEnabled?: string[];
    DisableRdsBlueGreen?: boolean;
    IsSecurityComplianceEnabled: boolean;
    AuthConfig: AuthConfig;
    AppConfigs?: CustomDataEx[];
    IsLoaded: boolean;
    AzureResourcePrefix?: AzureResourcePrefix;
    get CloudName(): string;
    get IsCommercialAws(): boolean;
    get IsBillingEnabledSetting(): boolean;
    set IsBillingEnabledSetting(value: boolean);
    get IsAWSDefaultInfraCloud(): boolean;
    IsSettingFlagEnabled(flag: string): boolean;
    getAppConfigByName(configName: string): CustomDataEx;
    IsAppConfigFlagEnabled(configName: string): boolean;
    getInfraRgPrefix(config: {
        AzureResourcePrefix: AzureResourcePrefix;
    }): string | undefined;
    private _enabledClouds;
    get EnabledClouds(): CloudPlatform$1[];
    get IsAIEnabled(): boolean;
    get IsPlatformDisabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SystemFeatures, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SystemFeatures>;
}
declare class AzureResourcePrefix {
    IsAzureCustomPrefixesEnabled: boolean;
    InfraRgPrefix: string;
    TenantRgPrefix: string;
    BackupRgPrefix: string;
    ResourceTypePrefix: ResourceTypePrefix[];
}
declare class ResourceTypePrefix {
    Type: string;
    Prefix: string;
}
declare class KeyStringValue {
    Key: string;
    Value: string;
}
declare class KeyStringValueUpdateRequest extends KeyStringValue {
    constructor(properties?: Partial<KeyStringValueUpdateRequest>);
    ComponentId: string;
    State?: string;
}
declare class CustomDataUpdate extends KeyStringValueUpdateRequest {
    constructor(properties?: Partial<CustomDataUpdate>);
}
declare class TenantTagRequest extends KeyStringValueUpdateRequest {
    constructor(properties?: Partial<TenantTagRequest>);
}
declare class CustomData extends KeyStringValue {
}
interface CustomDataSpec {
    Key: string;
    DataType: 'string' | 'boolean' | 'select';
    IsEditable: boolean;
    DisplayName?: string;
    Cloud?: CloudPlatform$1;
    Description?: string;
    Danger?: string;
}
interface EditableCustomData extends CustomData, CustomDataSpec {
}
declare class CustomDataEx extends CustomData {
    constructor(properties?: Object | CustomDataEx);
    Type: string;
    ComponentId?: string;
    State?: string;
}
declare enum AgentPlatform {
    DOCKER_LINUX = 0,
    DOCKER_WINDOWS = 5,
    EKS_LINUX = 7,
    NONE = 4,
    ECS = 8
}
declare class AgentPlatformUtils {
    static getAsString(p: AgentPlatform, cloud?: number): string;
    static getAsMap(isEksEnabled: boolean, cloud?: CloudPlatform$1, isEcsEnabled?: boolean): AgentPlatformDetails[];
}
declare class AgentPlatformDetails {
    name: string;
    display: string;
    value: number;
}
declare enum CloudPlatform$1 {
    AWS = 0,
    Oracle = 1,
    Azure = 2,
    Google = 3,
    BYOH = 4,
    Unknown = 5,
    Digital_Ocean = 6,
    OnPrem = 10
}
declare const CloudPlatformNames: _duplocloud_internal_ng_common_lib.EnumMapOf<string>;
declare enum K8sPlatform {
    EKS = 0,
    AKS = 2,
    GKE = 3,
    OKE = 1
}
declare enum K8sVendor {
    RANCHER = 0,
    GENERIC = 1,
    EKS = 2
}
declare class AuthConfig {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Object | AuthConfig);
    WAFDASHBOARDURL?: string;
    VPNADDRESSINGMETHOD?: string;
    ISVPNAUTHBYLDAP?: boolean;
}
declare class K8ClusterConfig {
    constructor(properties?: Object | K8ClusterConfig);
    Name: string;
    ApiServer: string;
    K8Provider: K8sPlatform;
    K8sVersion: string;
    Cloud?: CloudPlatform$1;
    Token?: string;
    AwsRegion?: string;
    Region?: string;
    CertificateAuthorityDataBase64?: string;
    IsServerless?: boolean;
    DefaultNamespace?: string;
    UpgradeConfig?: K8ClusterUpgradeStatus;
}
declare class K8ClusterUpgradeStatus {
    constructor(properties?: Partial<K8ClusterUpgradeStatus>);
    StartingVersion: string;
    TargetVersion: string;
    Status: string;
    InProgressId?: string;
    InProgressVersion?: string;
    DefaultOldNodeAction?: K8ClusterUpgradeNodeActionType;
    OldNodePrivateIps: CustomData[];
    OldNodeActions: K8ClusterUpgradeNodeAction[];
    ControlPlaneStartTime?: string;
    ControlPlaneEndTime?: string;
    readonly needsResolution: boolean;
    readonly oldNodesByTenant: {
        [tenantName: string]: string[];
    };
}
declare class K8ClusterAddOns {
    Name: string;
    CurrentVersion: string;
    TargetVersion: string;
    CurrentStatus: string;
    AllowUpgrade?: boolean;
    CanUpgrade?: boolean;
    AddOnStatus?: TableStatus$1;
    constructor(properties?: Partial<K8ClusterAddOns>);
    checkCanUpgrade(clusterV: string): boolean;
    get NameUpper(): string;
    get IsDegradedStatus(): boolean;
}
declare class K8ClusterUpgradeRequest {
    constructor(properties?: Partial<K8ClusterUpgradeRequest>);
    DefaultOldNodeAction: K8ClusterUpgradeNodeActionType;
}
declare enum K8ClusterUpgradeNodeActionType {
    None = 0,
    Remove = 1,
    Replace = 2
}
declare class K8ClusterUpgradeNodeAction {
    constructor(properties?: Partial<K8ClusterUpgradeNodeAction>);
    TenantName: string;
    TenantId: string;
    Action: K8ClusterUpgradeNodeActionType;
    OldNodePrivateIp: string;
    OldNodeInstanceId: string;
    OldNodeAsgProfile: string;
    NewNodeInstanceId: string;
}
declare class K8ClusterVersions {
    constructor(properties?: Partial<K8ClusterVersions>);
    DefaultVersion: string;
    SupportedVersions: string[];
    static GetDropdownOptions(versions: string[], defaultVersion: string): SelectOptions[];
}
declare enum LBType {
    Classic = 0,
    Application = 1,
    HealthCheck = 2,
    K8SClusterIP = 3,
    K8SNodePort = 4,
    SharedAlb = 5,
    NLB = 6,
    TargetGroupOnly = 7
}
declare const BASE_JSON_EDITOR_OPTIONS: any;
declare const TEXT_EDITOR_OPTIONS: any;
declare const INDENT_JSON_EDITOR_OPTIONS: any;
declare const READ_ONLY_JSON_EDITOR_OPTIONS: any;
declare const JSON_EDITOR_OPTIONS: any;
declare const YAML_EDITOR_OPTIONS: any;
declare const XML_EDITOR_OPTIONS: any;
declare const READ_ONLY_XML_EDITOR_OPTIONS: any;
declare const INI_EDITOR_OPTIONS: any;
declare const READ_ONLY_INI_EDITOR_OPTIONS: any;
declare class GcpRegionFeatures {
    constructor(properties?: Partial<GcpRegionFeatures>);
    GkeServerConfig: GkeServerConfig;
}
interface GkeServerConfig {
    channels: GkeReleaseChannel[];
    defaultClusterVersion: string;
    defaultImageType: string;
    validImageTypes: string[];
}
interface GkeReleaseChannel {
    channel: string;
    defaultVersion: string;
    validVersions: string[];
}
declare const K8S_SECRETS: ({
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        ARBITRARY_KEY1: string;
        ARBITRARY_KEY2: string;
        ".dockercfg"?: undefined;
        ".dockerconfigjson"?: undefined;
        username?: undefined;
        password?: undefined;
        "ssh-privatekey"?: undefined;
        "tls.key"?: undefined;
        "tls.crt"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
    name?: undefined;
} | {
    name: string;
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        ".dockercfg": string;
        ARBITRARY_KEY1?: undefined;
        ARBITRARY_KEY2?: undefined;
        ".dockerconfigjson"?: undefined;
        username?: undefined;
        password?: undefined;
        "ssh-privatekey"?: undefined;
        "tls.key"?: undefined;
        "tls.crt"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
} | {
    name: string;
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        ".dockerconfigjson": string;
        ARBITRARY_KEY1?: undefined;
        ARBITRARY_KEY2?: undefined;
        ".dockercfg"?: undefined;
        username?: undefined;
        password?: undefined;
        "ssh-privatekey"?: undefined;
        "tls.key"?: undefined;
        "tls.crt"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
} | {
    name: string;
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        username: string;
        password: string;
        ARBITRARY_KEY1?: undefined;
        ARBITRARY_KEY2?: undefined;
        ".dockercfg"?: undefined;
        ".dockerconfigjson"?: undefined;
        "ssh-privatekey"?: undefined;
        "tls.key"?: undefined;
        "tls.crt"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
} | {
    name: string;
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        "ssh-privatekey": string;
        ARBITRARY_KEY1?: undefined;
        ARBITRARY_KEY2?: undefined;
        ".dockercfg"?: undefined;
        ".dockerconfigjson"?: undefined;
        username?: undefined;
        password?: undefined;
        "tls.key"?: undefined;
        "tls.crt"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
} | {
    name: string;
    secretType: string;
    annotationsKeys: {};
    dataKeys: {
        "tls.key": string;
        "tls.crt": string;
        ARBITRARY_KEY1?: undefined;
        ARBITRARY_KEY2?: undefined;
        ".dockercfg"?: undefined;
        ".dockerconfigjson"?: undefined;
        username?: undefined;
        password?: undefined;
        "ssh-privatekey"?: undefined;
    };
    descrption: {
        title: string;
        helpFields: string[];
    };
})[];
declare function cloudToK8sName(cloud: CloudPlatform$1): string;
declare enum ContainerStatus {
    Unknown = 0,
    Running = 1,
    Stopped = 2,
    Pending = 3,
    Waiting = 4,//FixMe
    Delete = 5,
    Deleted = 6,
    Failed = 7,
    SchedulingFailed = 8,
    ImageNotFound = 9,
    Evicted = 10
}
declare function formatPodStatus(val: string): string;
declare const podStatusBadgeStyles: Map<number, string>;
interface KubeConfigCluster {
    'certificate-authority-data'?: string;
    'insecure-skip-tls-verify'?: boolean;
    server: string;
}
interface KubeConfigClusterEntry {
    cluster: KubeConfigCluster;
    name: string;
}
interface KubeConfigContext {
    cluster: string;
    namespace: string;
    user: string;
}
interface KubeConfigContextEntry {
    context: KubeConfigContext;
    name: string;
}
interface KubeConfigUser {
    token?: string;
    exec?: any;
}
interface KubeConfigUserEntry {
    user: KubeConfigUser;
    name: string;
}
declare class KubeConfigFile {
    constructor(properties?: Partial<KubeConfigFile>);
    apiVersion: 'v1';
    clusters: KubeConfigClusterEntry[];
    users: KubeConfigUserEntry[];
    contexts: KubeConfigContextEntry[];
    'current-context'?: string;
    static fromK8ClusterConfig(input: K8ClusterConfig, name?: string, namespace?: string, addUser?: boolean): KubeConfigFile;
    static yamlKubeConfig(planId: string, k8Config: K8ClusterConfig, userConfig: {
        isAdmin: boolean;
        accountName: string;
        existingK8sNamespace: string;
    }): KubeConfigFile;
    static downloadKubeConfig(planId: string, k8Config: K8ClusterConfig, userConfig: {
        isAdmin: boolean;
        accountName: string;
        existingK8sNamespace: string;
    }): KubeConfigFile;
}
declare class SelectOption {
    constructor(properties?: Partial<SelectOption>);
    Label?: string;
    Value?: string | number | boolean;
}
declare class KeyValueConfig {
    constructor(properties?: Partial<KeyValueConfig>);
    Key?: string;
    Value?: string | number | boolean;
}
declare class AWSAccessToken {
    constructor(properties?: Partial<AWSAccessToken>);
    AccessKeyId: string;
    ConsoleUrl: string;
    Region: string;
    SecretAccessKey: string;
    SessionToken: string;
}

declare class AdminTenant {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Object | AdminTenant);
    TenantId: string;
    AccountName: string;
    AgentPools?: any[];
    AsgProfiles?: any[];
    CreationTime?: string;
    Devices?: any[];
    ECacheInstances?: any[];
    EcsServices?: any[];
    Expiry?: Date;
    ExistingK8sNamespace?: string;
    InfraOwner?: string;
    Metadata?: CustomData[];
    Minions?: any[];
    MonitoringCfg?: AdminTenantMonitoringConfig;
    NativeHosts?: any[];
    Networks?: any;
    NwProvider: number;
    OperationalPods?: any[];
    PlanID: string;
    PauseTime?: Date;
    RDSInstances?: any;
    ReplicationControllers?: any[];
    RegistryCredentials?: string;
    StorageAccounts?: any[];
    Tags?: KeyStringValue[];
    Tasks?: any[];
    TenantAccessGrants?: TenantAccessGrant[];
    KmsKeyInfos?: TenantPlanKmsKeyInfo[];
    Features?: TenantFeatures;
    aiWorkspace?: AIWorkspaceBase;
    isAIWorkspace?: boolean;
    isPlatformTenant?: boolean;
    get workspaceName(): string;
    get workspaceId(): string;
    /** Retrieves a User Tenant metadata value. */
    getMetaValueByKey(key: string): string;
}
declare class TenantPlanKmsKeyInfo {
    constructor(properties?: object | TenantPlanKmsKeyInfo);
    KeyName: string;
    KeyArn: string;
    KeyId?: string;
}
declare class AdminTenantMonitoringConfig {
    AlertPublishFrequency?: number;
}
declare class AdminTenantAuthInfo {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties: Object | AdminTenantAuthInfo);
    TenantId: string;
    AccountName: string;
    UserAccess: TenantUserAccess[];
    AccessByUser?: {
        [username: string]: TenantUserAccess;
    };
    ConfigData?: CustomDataEx[];
}
declare enum TenantNetworkSecurityRuleProtocol {
    TCP = "tcp",
    UDP = "udp",
    ICMP = "icmp"
}
declare enum TenantNetworkSecurityRuleSourceType {
    TENANT = 0,
    IP_ADDRESS = 1
}
declare class TenantNetworkSecurityRuleSource {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties: Object | TenantNetworkSecurityRuleSource);
    Description: string;
    Type: TenantNetworkSecurityRuleSourceType;
    Value: string;
}
declare class TenantNetworkSecurityRule {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties: Object | TenantNetworkSecurityRule);
    ServiceProtocol: TenantNetworkSecurityRuleProtocol;
    ServiceType: number;
    FromPort: number;
    ToPort: number;
    SourceInfos: TenantNetworkSecurityRuleSource[];
    getFlattenedSecurityRules(): FlattenedTenantNetworkSecurityRule[];
}
declare class FlattenedTenantNetworkSecurityRule {
    constructor(properties: Object | FlattenedTenantNetworkSecurityRule);
    ServiceProtocol: TenantNetworkSecurityRuleProtocol;
    ServiceType: number;
    FromPort: number;
    ToPort: number;
    Description: string;
    Type: TenantNetworkSecurityRuleSourceType;
    Value: string;
    toTenantExtConnSgRuleUpdate(): TenantExtConnSgRuleUpdate;
}
declare class GcpNetworkSecurityRule {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties: Object | GcpNetworkSecurityRule);
    name: string;
    description: string;
    direction: string;
    disabled: boolean;
    id: number;
    kind: string;
    network: string;
    priority: number;
    selfLink: string;
    sourceRanges: string[];
    sourceTags: string[];
    creationTimestamp: string;
    logConfig: GcpLogConfig;
    allowed: ProtoColAndPorts[];
    denied: ProtoColAndPorts[];
    get action(): string;
    private _protocolAndPorts;
    get protocolAndPorts(): string[];
    private _sourceRanges;
    get sourceRangesString(): string;
    private _sourceTenantName;
    get sourceTenantName(): string;
    private formatProtocolPortValues;
    toFlattenedGcpSecurityRule(): FlattenedGcpNetworkSecurityRule;
}
declare const IPv4Regex: RegExp;
declare const IPv6Regex: RegExp;
declare const Ipv4Ipv6CIDRRegex: RegExp;
declare class GcpNetworkSecurityRuleCreateRequest {
    constructor(properties?: Partial<GcpNetworkSecurityRuleCreateRequest>);
    Name: string;
    Description: string;
    ProtocolAndPorts: ServiceProtocolAndPorts[];
    SourceRanges: string[];
    Type: string;
}
declare class ServiceProtocolAndPorts {
    constructor(properties?: Object | ServiceProtocolAndPorts);
    ServiceProtocol: string;
    Ports: string[];
}
declare class GcpLogConfig {
    constructor(properties?: Object | GcpLogConfig);
    enabled: boolean;
}
declare class ProtoColAndPorts {
    constructor(properties?: Object | ProtoColAndPorts);
    IPProtocol: string;
    ports: string[];
}
declare enum GcpTenantNetworkSecurityRuleType {
    TENANT = "TENANT",
    IPADDRESS = "IPADDRESS"
}
declare class GcpTenantNetworkSecurityRuleCreateRequest extends GcpNetworkSecurityRuleCreateRequest {
    constructor(properties?: Partial<GcpTenantNetworkSecurityRuleCreateRequest>);
    TenantRuleType: GcpTenantNetworkSecurityRuleType;
    SourceSubscriptionId: string;
}
declare class FlattenedGcpNetworkSecurityRule {
    constructor(properties?: Partial<FlattenedGcpNetworkSecurityRule>);
    Name: string;
    Description: string;
    Type: string;
    SourceType: number;
    SourceRanges: string;
    ShowProtocolAndPorts: boolean;
    TcpEnabled: boolean;
    UdpEnabled: boolean;
    SctpEnabled: boolean;
    OtherProtocolEnabled: boolean;
    TcpPorts: string;
    UdpPorts: string;
    SctpPorts: string;
    OtherProtocol: string;
    toGcpNetworkSecurityRuleRequest(): GcpNetworkSecurityRuleCreateRequest;
    getServiceProtocolAndPorts(protocol: string, ports: string): ServiceProtocolAndPorts;
}
declare class AddTenantRequest {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Object | AddTenantRequest);
    AccountName: string;
    PlanID: string;
    TenantBlueprint: 'None';
    ExistingK8sNamespace?: string;
}
declare class TenantUserAccess {
    constructor(properties?: Partial<TenantUserAccess>);
    Username: string;
    Policy?: TenantAccessPolicy;
    user?: UserRoleInfo;
    get isReadOnly(): boolean;
}
declare class TenantAccessPolicy {
    constructor(properties?: Partial<TenantAccessPolicy>);
    IsReadOnly: boolean;
}
declare class UpdateUserAccessRequest extends TenantUserAccess {
    constructor(properties?: Partial<UpdateUserAccessRequest>);
    State?: string;
    TenantId: string;
}
declare class BatchAddUserTenantAccessRequest {
    constructor(properties?: Partial<BatchAddUserTenantAccessRequest>);
    Username: string;
    TenantAccessQueries: TenantAccessQuery;
    initializeTenantAccessQueries(tenantIdList: string[], accessType: boolean): void;
}
declare class TenantAccessQuery {
    constructor(properties?: Partial<TenantAccessQuery>);
    [key: string]: AccessType;
}
declare class AccessType {
    constructor(properties?: Partial<TenantAccessQuery>);
    IsReadOnly: boolean;
}
declare class UserTenantAccess {
    constructor(properties?: Partial<UserTenantAccess>);
    TenantId: string;
    AccountName: string;
    Policy?: TenantAccessPolicy;
    get isReadOnly(): boolean;
}
declare class TenantExtConnSgRuleUpdate {
    constructor(properties?: Object | TenantExtConnSgRuleUpdate);
    ServiceProtocol: string;
    FromPort: number;
    ToPort: number;
    SourceInfos: SGSourceInfos[];
    State?: string;
}
declare class SGSourceInfos {
    constructor(properties?: Object | TenantExtConnSgRuleUpdate);
    Description: string;
    Type: number;
    Value: string;
}
declare class TenantMetadataUpdateReq {
    constructor(properties?: Object | TenantMetadataUpdateReq);
    ComponentId: string;
    Key: string;
    Value: string;
    State?: string;
}
declare class TenantAlertConfig {
    constructor(properties?: Object | TenantAlertConfig);
    Dsn: string;
    RoutingKey: string;
    NrApiKey: string;
    OpsGenieApiKey: string;
    IncidentIoUrl: string;
    AlertPublishFrequency: number;
}
declare class TenantAccessGrant {
    constructor(properties?: Partial<TenantAccessGrant>);
    GrantorTenantId: string;
    GrantedArea: string;
    GrantorTenantName?: string;
    get otherTenantId(): string;
    get otherTenantName(): string;
}
declare class TenantAccessGrantee {
    constructor(properties?: Partial<TenantAccessGrantee>);
    GranteeTenantId: string;
    GrantedArea: string;
    GranteeTenantName?: string;
    get otherTenantId(): string;
    get otherTenantName(): string;
}
declare const TENANT_PLATFORM_SERVICES_CONFIGS: {
    "duplo-infra-svc-node-exporter": string;
    "duplo-infra-svc-node-exporter-k8s-4": string;
    "duplo-infra-svc-cadvisor": string;
    "duplo-infra-svc-cadvisor-k8s": string;
    "duplo-infra-svc-filebeat": string;
    "duplo-infra-svc-filebeat-k8s": string;
};
declare const AWS_SPECIFIC_TENANT_CONFIG: string[];
declare const TENANT_DEFAULT_CONFIGS: ({
    key: string;
    label: string;
    cloud: CloudPlatform$1;
    type?: undefined;
    default?: undefined;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    helpText?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    default: string;
    cloud: CloudPlatform$1;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    helpText?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    cloud?: undefined;
    type?: undefined;
    default?: undefined;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    helpText?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    alertMessage: string;
    alertType: string;
    alertTitle: string;
    alertIcon: string;
    helpText: string;
    cloud: CloudPlatform$1;
    default?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    helpText: string;
    default: string;
    cloud: CloudPlatform$1;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    helpText: string;
    cloud: CloudPlatform$1;
    type?: undefined;
    default?: undefined;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    default: string;
    alertMessage: string;
    alertType: string;
    alertTitle: string;
    alertIcon: string;
    helpText: string;
    cloud: CloudPlatform$1;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    cloud: CloudPlatform$1;
    default?: undefined;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
    helpText?: undefined;
    options?: undefined;
} | {
    key: string;
    label: string;
    type: string;
    default: string;
    options: string[];
    helpText: string;
    cloud: CloudPlatform$1;
    alertMessage?: undefined;
    alertType?: undefined;
    alertTitle?: undefined;
    alertIcon?: undefined;
})[];
declare class SessionDurationOption {
    value: number | 'custom';
    static readonly OPTIONS: SessionDurationOption[];
    label: string;
    constructor(value: number | 'custom');
}
declare class TenantHeaderColor {
    static readonly colorMap: Map<string, string>;
    static getColorByName(name: string): string;
    static getColorOptions(): string[];
}

declare const SystemConfigs: {
    SETTING_ENABLE_VPN: string;
    SETTING_DISABLE_KATKIT: string;
    SETTING_DUPLO_CUSTOM_TAGS: string;
    SETTING_AUTOMATED_RDS_PG_ENABLED_ENGINES: string;
    SETTING_S3_BUCKET_NAME_PREFIX: string;
    SETTING_RDS_AUTOMATED_BACKUP_RETENTION_DAYS: string;
    SETTING_DISABLE_SSH_KEY_DOWNLOAD: string;
    SETTING_ENABLE_STORAGE_ACCOUNT_INFRA_ENCRYPTION: string;
    SETTING_AZURE_DEFAULT_MYSQL_BACKUP_RETENTION_DAYS: string;
    SETTING_AZURE_DEFAULT_POSTGRESQL_FLEXI_BACKUP_RETENTION_DAYS: string;
    SETTING_AZURE_DEFAULT_MYSQL_GEO_REDUNDANT_BACKUP_ENABLED: string;
    SETTING_ADMIN_ONLY_SSH_KEY_DOWNLOAD: string;
    SETTING_ENABLE_ECS_READONLY_PROCESSING: string;
    AWS_APPROVED_RDS_FOR_TENANT_USERS_SETTING: string;
    AWS_RDS_RESTRICT_UPTO_INSTANCE_SIZE: string;
    SETTING_MAXIMUM_SESSION_DURATION: string;
    SETTING_MAXIMUM_K8S_SESSION_DURATION: string;
    SETTING_AD_ONLY_DOMAINS: string;
    SETTING_GSUITE_ONLY_DOMAINS: string;
    SETTING_O365_ONLY_DOMAINS: string;
    SETTING_ALLOW_DEDICATED_HOST_SHARING: string;
    SETTING_DENY_OPEN_ACCESS_TO_PUBLIC_LB: string;
    SETTING_DISABLE_HOST_CREATION_WITH_CUSTOM_AMI: string;
    SETTING_LIST_ALL_LAMBDA_LAYERS: string;
    SETTING_BLOCK_MASTER_VPC_CIDR_ALLOW_IN_EKS_SG: string;
    SETTING_ENABLE_INSTANCE_SCHEDULER: string;
    SETTING_ENABLE_USER_TOKEN_EXPIRATION_NOTIFICATION: string;
    SETTING_ENABLE_NEW_ADMIN_USER_NOTIFICATION: string;
    SETTING_USER_TOKEN_EXPIRATION_NOTIFICATION_EMAILS: string;
    SETTING_ENABLE_INACTIVE_USER_NOTIFICATION: string;
    SETTING_ENABLE_RDS_IAM_AUTH: string;
    SETTING_RDS_IAM_AUTH_DB_USERNAME: string;
    SETTING_ALWAYS_SHOW_VPN_UI: string;
    SETTING_ALLOW_READONLY_K8S_SECRETS: string;
    SETTING_VANTA_ENABLED: string;
    SETTING_INFRA_VPC_IMPORT_ENABLE: string;
    SETTING_ENABLE_AI: string;
    SETTING_DISABLE_MINI_AI_HELP_DESK: string;
    SETTING_DISABLE_PYLON: string;
    SETTING_DISABLE_PYLON_FOR_NON_ADMIN: string;
    SETTING_DUPLO_AUDIT_S3BUCKET: string;
    SETTING_DUPLO_AUDIT_S3BUCKET_REGION: string;
    SETTING_AUTHORIZATION_SESSION_EXPIRATION: string;
    SETTING_ENABLE_ADMIN_AWS_JIT_ACCESS: string;
    SETTING_DISABLE_NON_ADMIN_AWS_JIT: string;
    SETTING_DISABLE_IMAGE_HISTORY_TRACKING: string;
    SETTING_K8S_CONTAINER_EXEC_USE_SSM: string;
    SETTING_AZURE_APP_GATEWAY_SSL_POLICY: string;
    SETTING_ENABLE_USER_PUBLIC_KEY: string;
    SETTING_LOGIN_BANNERTEXT: string;
    SETTING_LOGIN_BUTTONTEXT: string;
    SETTING_ENABLE_BILLING_ALERTS: string;
    AI_URL: string;
    SETTING_KIBANA_BASE_URL: string;
    SETTING_KIBANA_BASE_URLS_PER_TENANT: string;
    SETTING_KIBANA_LOGS_URL_TEMPLATE: string;
    SETTING_KIBANA_LOGS_URL_TEMPLATE_ECS: string;
    SETTING_KIBANA_AUDIT_URL_TEMPLATE: string;
    SETTING_KIBANA_SERVICE_LOGS_URL_TEMPLATE: string;
    SETTING_KIBANA_ADMIN_DASHBOARD_URL_TEMPLATE: string;
    SETTING_CNAME_PREFIXES_TO_IGNORE: string;
    SETTING_NEW_USER_EMAIL_SUBJECT: string;
    SETTING_NEW_USER_EMAIL_BODY: string;
    SETTING_FIPS_ENABLED: string;
    AI_SUITE_LABEL_CONFIG: string;
    ADMIN_INTERFACES_TO_HIDE: string;
    DISABLE_HELPDESK_NAV_COLLAPSE: string;
    REMOVE_VPN_PASSWORD_FROM_EMAIL: string;
    AI_HELPDESK_DEFAULT_ACTION_SELECTION: string;
    SETTING_ENABLE_K8S_PASS_THROUGH: string;
    SETTING_BACKUP_XMLDB_TO_CLOUD: string;
    SETTING_BACKUP_XMLDB_BUCKET_NAME: string;
};
declare class IframeConfigs {
    constructor(properties?: Object | IframeConfigs);
    UIPath: string;
    Links: CustomDataEx[];
}

declare class AccountSsoConfig {
    constructor(properties?: Partial<AccountSsoConfig>);
    DisableGoogle: boolean;
    DisableMicrosoft: boolean;
    MicrosoftClientId: string;
    MicrosoftOauthBaseUrl: string;
    MicrosoftTenantId: string;
    EnableKeycloak: boolean;
    KeycloakHost: string;
    KeycloakRealm: string;
    KeycloakClientId: string;
    KeycloakState: string;
    KeycloakNonce: string;
    EnableAzureAd: boolean;
    AzureAdClientId: string;
    AzureAdIssuer: string;
    EnableAzureAdUserSource: boolean;
    EnableOktaLogin: boolean;
    OktaClientId: string;
    OktaDomain: string;
    EnableOktaUserSource: boolean;
    OktaSamlUrl: string;
    LoginBannerText: string;
    LoginButtonText: string;
    /** Local-dev username/password login — enabled by the backend only when an admin password env var is set. */
    EnablePasswordLogin: boolean;
    get hasNonDuploUserSources(): boolean;
}
declare const EXPIRE_SECONDS_EARLY: number;
declare class JwtResponse {
    constructor(properties?: Partial<JwtResponse>);
    Token: string;
    IsAdmin: boolean;
    TenantId: string;
    ExpiresAt: Date;
    isValid(): boolean;
    get isExpired(): boolean;
}
interface DuploCiClientEndpoint {
    argoTenantId: string;
    apiUrl: string;
}
declare class DuploCiClientConfig extends JwtResponse {
    constructor(properties?: Partial<DuploCiClientConfig>);
    argoTenantId: string;
    apiUrl: string;
    duploToken: string;
}
declare class UserTenant {
    constructor(properties?: Partial<UserTenant>);
    TenantId: string;
    AccountName: string;
    PlanID?: string;
    Metadata?: CustomData[];
    InfraOwner?: string;
    ExistingK8sNamespace?: string;
    Tags?: TenantTags[];
    Features?: TenantFeatures;
    aiWorkspace?: AIWorkspaceBase;
    isAIWorkspace?: boolean;
    isPlatformTenant?: boolean;
    get workspaceName(): string;
    get workspaceId(): string;
    /** Retrieves a User Tenant metadata value. */
    getMetaValueByKey(key: string): string;
}
declare class TenantTags {
    constructor(properties?: Partial<TenantTags>);
    Key: string;
    Value: string;
}
declare class UserPublicKey {
    constructor(properties?: Partial<UserPublicKey>);
    PublicKey: string;
}
declare class UserApiToken {
    constructor(properties?: Partial<UserApiToken>);
    Name: string;
    Token: string;
    ExpirationDate: string;
}
declare class UserDevspace {
    constructor(properties?: Partial<UserDevspace>);
    IsAdmin: boolean;
    IsEnabled: boolean;
    Size: string;
    Username?: string;
}
declare enum UserRoleSource {
    Duplo = "Duplo",
    AzureAD = "AzureAd",
    Okta = "Okta"
}
interface UserSettings {
    /** null = never asked → prompt once. false = declined → don't re-prompt. */
    AnalyticsConsent?: boolean | null;
}
declare class UserRoleInfo {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Partial<UserRoleInfo>);
    ApiTokens?: UserApiToken[];
    Devspaces?: UserDevspace[];
    CurrentSessionToken?: string;
    IsConfirmationEmailSent?: boolean;
    IsReadOnly?: boolean;
    IsVpnConfigCreated?: boolean;
    Role?: string;
    Roles: UserRole[];
    Settings?: UserSettings;
    TenantAccess?: Record<string, TenantAccessPolicy>;
    UserSource?: UserRoleSource | '';
    Username: string;
    VpnPassword?: string;
    VpnServerUrl?: string;
    VpnStaticIp?: string;
    PublicKey?: string;
    get isDuploUser(): boolean;
    get isAdmin(): boolean;
    get isAiStudioAdmin(): boolean;
    isReadOnly(tenantId: string): boolean;
}
declare class UserAuthConfig {
    ISVPNAUTHBYLDAP: boolean;
    VPNADDRESSINGMETHOD: string;
    WAFDASHBOARDURL: string;
    VPNSERVERIP: string;
}
declare enum UserProvider {
    Google = "google",
    Microsoft = "microsoft",
    AzureAD = "azure-ad",
    Okta = "okta",
    Keycloak = "keycloak",
    Local = "local"
}
/** Error codes rendered by LoginComponent through the `/app/auth/:error` route. */
declare const AUTH_ERROR: {
    readonly NO_ROLE: "no-role";
    readonly NO_SUBSCRIPTION: "no-subscription";
    readonly NO_TENANT_ACCESS: "no-tenant-access";
    readonly TIMEOUT: "timeout";
};
declare enum UserRole {
    User = "User",
    Admin = "Administrator",
    Signup = "SignupUser",
    Security = "SecurityAdmin",
    AiStudioAdmin = "AIStudioAdmin"
}
declare const UserRoles: {
    LoggedIn: UserRole[];
    Security: UserRole[];
    Signup: UserRole[];
    User: UserRole[];
    Admin: UserRole[];
    AIStudioAdmin: UserRole[];
};
declare class UserPrincipal {
    id: string;
    provider: UserProvider;
    username?: string;
    email: string;
    roles?: Array<UserRole>;
    token?: string;
    isReadOnly?: boolean;
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Partial<UserPrincipal>);
    /** Try to find the best way to identify a user. */
    get fuzzyPrincipal(): string;
    isAdmin(): boolean;
    isAiStudioAdmin(): boolean;
    /**
     * Checks if the user has any one of the given roles (or the user is an administrator).
     *
     * @param access  A list of roles or role names to check
     * @returns true if the user passes any of the roles given.
     */
    hasAnyRole(access: Array<string | UserRole>): boolean;
}
/**
 *  Represents the currently logged-in user's session.
 *
 *  This class is instantiated automatically by Angular's DI system, but data is only populated
 *  by the AuthNZService.
 *
 *  - Manages applicable session state in the browser's localStorage  for:
 *    - userPrincipal
 *    - this._tenant
 *    - userProvider
 *  - Provides Observable(s) for:
 *    - currentUser
 *    - currentTenant
 *    - currentAccessibleTenants
 *  - Does not require any DI dependencies, so there are no circular references.
 */
declare class UserSession {
    private router;
    private _iframeConfigs;
    currentIframeCinfigs: Observable<Map<string, IframeConfigs[]>>;
    private _user;
    private _userRoleInfo;
    private _tenant;
    private _duploCi;
    private _accessibleTenants;
    readonly currentUser: Observable<UserPrincipal>;
    readonly currentTenant: Observable<UserTenant>;
    readonly currentDuploCi: Observable<DuploCiClientConfig>;
    readonly currentAccessibleTenants: Observable<UserTenant[]>;
    readonly currentUserRoleInfo: Observable<UserRoleInfo>;
    userAuthConfig: UserAuthConfig;
    private _defaultTenant;
    constructor(router: Router);
    clear(): void;
    get listRefreshFrequency(): number;
    getRefreshTimer(immediate?: boolean, frequency?: number): Observable<number>;
    getTenantRefreshTimer(immediate?: boolean, frequency?: number): Observable<[UserTenant, boolean]>;
    getDuploCiRefreshTimer(immediate?: boolean, frequency?: number): Observable<[UserTenant, boolean]>;
    get user(): UserPrincipal;
    get tenant(): UserTenant;
    get duploCi(): DuploCiClientConfig;
    get iframeConfigs(): Map<string, IframeConfigs[]>;
    get defaultTenant(): UserTenant;
    get accessibleTenants(): UserTenant[];
    get bearerToken(): string;
    get provider(): string;
    get userRoleInfo(): UserRoleInfo;
    set user(user: UserPrincipal);
    set tenant(tenant: UserTenant);
    set duploCi(duploCi: DuploCiClientConfig);
    set iframeConfigs(iframeConfigs: Map<string, IframeConfigs[]>);
    set accessibleTenants(accessibleTenants: UserTenant[]);
    set defaultTenant(tenant: UserTenant);
    set userRoleInfo(userRoleInfo: UserRoleInfo);
    set appConfigs(appConfigs: CustomDataEx[]);
    get appConfigs(): CustomDataEx[] | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserSession, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserSession>;
}

declare class RestrictElementAccess {
    protected session: UserSession;
    protected router: Router;
    constructor(session: UserSession, router: Router);
    isUserReadonly(): boolean;
}
declare class DisableForReadonlyUserDirective extends RestrictElementAccess implements OnInit, OnDestroy {
    private _el;
    private renderer;
    protected session: UserSession;
    protected router: Router;
    private _disableForReadonlyUser;
    set disableForReadonlyUser(value: boolean | string);
    private _unsubscribeAll;
    /**
     * Whether this directive is the one that currently has the element disabled.
     *
     * doReadonly() runs on every tenant-refresh tick, so both branches have to be idempotent.
     * Without this flag the non-readonly branch stripped the `disabled` attribute on every tick,
     * including from elements it never disabled — which silently cleared what a `[disabled]`
     * binding had set, and Angular does not rewrite a property binding whose value has not changed,
     * so the element stayed enabled until that expression next changed. The readonly branch had the
     * mirror problem: it wrapped the element in a fresh title span each tick, nesting spans for as
     * long as the page stayed open.
     */
    private _readonlyApplied;
    constructor(_el: ElementRef, renderer: Renderer2, session: UserSession, router: Router);
    ngOnInit(): void;
    doReadonly(): void;
    private wrapReadonlyTitleElement;
    private unwrapReadonlyTitleElement;
    private onClick;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DisableForReadonlyUserDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DisableForReadonlyUserDirective, "[disableForReadonlyUser]", never, { "disableForReadonlyUser": { "alias": "disableForReadonlyUser"; "required": false; }; }, {}, never, never, false, never>;
}
declare class HideForReadonlyUserDirective extends RestrictElementAccess implements OnInit, OnDestroy {
    private _el;
    protected session: UserSession;
    protected router: Router;
    private _hideForReadonlyUser;
    set hideForReadonlyUser(value: boolean | string);
    private _unsubscribeAll;
    constructor(_el: ElementRef, session: UserSession, router: Router);
    ngOnInit(): void;
    ngOnDestroy(): void;
    doReadonly(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HideForReadonlyUserDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HideForReadonlyUserDirective, "[hideForReadonlyUser]", never, { "hideForReadonlyUser": { "alias": "hideForReadonlyUser"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ViewJsonComponent extends RestrictElementAccess implements OnInit, OnChanges {
    private clipboardService;
    private toastr;
    protected session: UserSession;
    protected router: Router;
    messageObject: any;
    downloadFileName: string;
    enableEdit: boolean;
    heightToReduce: number;
    isEditMode: boolean;
    delaySizeChange: boolean;
    editedMessage: EventEmitter<string>;
    messageText: string;
    messageTextEdited: string;
    jsonEditorOptions: any;
    jsonEditorOptionsReadOnly: any;
    tooltipEdit: NgbTooltip;
    tooltipEditText: string;
    tooltipEditIcon: string;
    screenHeight: number;
    screenWidth: number;
    divHeight: string;
    constructor(clipboardService: ClipboardService, toastr: DuploToastrService, session: UserSession, router: Router);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewChecked(): void;
    getScreenSize(event?: any): void;
    getMessageAsText(): string;
    downloadJson(): void;
    copyTextToClipboard(): void;
    editJson(): void;
    updateMessage(): void;
    cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewJsonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewJsonComponent, "app-view-json-comp", never, { "messageObject": { "alias": "messageObject"; "required": false; }; "downloadFileName": { "alias": "downloadFileName"; "required": false; }; "enableEdit": { "alias": "enableEdit"; "required": false; }; "heightToReduce": { "alias": "heightToReduce"; "required": false; }; "isEditMode": { "alias": "isEditMode"; "required": false; }; "delaySizeChange": { "alias": "delaySizeChange"; "required": false; }; }, { "editedMessage": "editedMessage"; }, never, never, false, never>;
}

declare class ViewJsonModalComponent extends RestrictElementAccess {
    activeModal: NgbActiveModal;
    private clipboardService;
    private toastr;
    protected session: UserSession;
    protected router: Router;
    /** Allow supplying a plain-text title for the header. */
    headerText: string;
    /** Allow supplying a plain-text message or  object for the body. */
    messageText: string;
    showDownload: false;
    downloadFileName: string;
    enableEdit: boolean;
    isEditMode: boolean;
    fullScreen: boolean;
    editedMessage: EventEmitter<string>;
    messageTextEdited: string;
    jsonEditorOptions: any;
    jsonEditorOptionsReadOnly: any;
    tooltipEditText: string;
    tooltipEditIcon: string;
    tooltipEdit: NgbTooltip;
    constructor(activeModal: NgbActiveModal, clipboardService: ClipboardService, toastr: DuploToastrService, session: UserSession, router: Router);
    getHeaderAsText(): string;
    getMessageAsText(): string;
    downloadJson(): void;
    copyTextToClipboard(): void;
    editJson(): void;
    updateMessage(): void;
    cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewJsonModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewJsonModalComponent, "app-view-json", never, { "headerText": { "alias": "headerText"; "required": false; }; "messageText": { "alias": "messageText"; "required": false; }; "showDownload": { "alias": "showDownload"; "required": false; }; "downloadFileName": { "alias": "downloadFileName"; "required": false; }; "enableEdit": { "alias": "enableEdit"; "required": false; }; "isEditMode": { "alias": "isEditMode"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; }, { "editedMessage": "editedMessage"; }, never, never, false, never>;
}

declare class ViewYamlComponent extends RestrictElementAccess implements OnInit, OnChanges {
    private clipboardService;
    private toastr;
    protected session: UserSession;
    protected router: Router;
    messageObject: any;
    downloadFileName: string;
    heightToReduce: number;
    editedMessage: EventEmitter<string>;
    canEditYml: boolean;
    isEditMode: boolean;
    messageText: string;
    messageTextEdited: string;
    yamlEditorOptions: any;
    yamlEditorOptionsReadOnly: any;
    tooltipEditText: string;
    tooltipEditIcon: string;
    screenHeight: number;
    screenWidth: number;
    divHeight: string;
    tooltipEdit: NgbTooltip;
    constructor(clipboardService: ClipboardService, toastr: DuploToastrService, session: UserSession, router: Router);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    getScreenSize(event?: any): void;
    getMessageAsText(): string;
    downloadYAML(): void;
    copyTextToClipboard(): void;
    editYAML(): void;
    updateMessage(): void;
    cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewYamlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewYamlComponent, "app-view-yaml-comp", never, { "messageObject": { "alias": "messageObject"; "required": false; }; "downloadFileName": { "alias": "downloadFileName"; "required": false; }; "heightToReduce": { "alias": "heightToReduce"; "required": false; }; "canEditYml": { "alias": "canEditYml"; "required": false; }; "isEditMode": { "alias": "isEditMode"; "required": false; }; }, { "editedMessage": "editedMessage"; }, never, never, false, never>;
}

declare class RootImportsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RootImportsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RootImportsModule, never, [typeof i1.MonacoEditorModule, typeof i2.MarkdownModule], [typeof i1.MonacoEditorModule, typeof i2.MarkdownModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RootImportsModule>;
}

declare class RippleEffectDirective {
    private _elementRef;
    private _nativeElement;
    wave: string;
    /**
     * Constructor
     *
     * @param {ElementRef} _elementRef
     */
    constructor(_elementRef: ElementRef);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RippleEffectDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RippleEffectDirective, "[rippleEffect]", never, { "wave": { "alias": "wave"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FeatherIconDirective implements OnChanges {
    private _elementRef;
    private _changeDetector;
    name: string;
    class: string;
    size: string;
    constructor(_elementRef: ElementRef, _changeDetector: ChangeDetectorRef);
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FeatherIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FeatherIconDirective, "[data-feather]", never, { "name": { "alias": "data-feather"; "required": false; }; "class": { "alias": "class"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CoreDirectivesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreDirectivesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CoreDirectivesModule, [typeof RippleEffectDirective, typeof FeatherIconDirective], never, [typeof RippleEffectDirective, typeof FeatherIconDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CoreDirectivesModule>;
}

declare class InitialsPipe implements PipeTransform {
    transform(fullName: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitialsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<InitialsPipe, "initials", false>;
}

declare class FilterPipe implements PipeTransform {
    /**
     * Transform
     *
     * @param {any[]} items
     * @param {string} searchText
     * @param {string} key
     *
     * @returns {any}
     */
    transform(items: any[], searchText: string, key: string): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FilterPipe, "filter", false>;
}

declare class StripHtmlPipe implements PipeTransform {
    transform(value: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<StripHtmlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<StripHtmlPipe, "striphtml", false>;
}

/**
 * Sanitize HTML
 */
declare class SafePipe implements PipeTransform {
    protected _sanitizer: DomSanitizer;
    /**
     * Pipe Constructor
     *
     * @param _sanitizer: DomSanitezer
     */
    constructor(_sanitizer: DomSanitizer);
    /**
     * Transform
     *
     * @param value: string
     * @param type: string
     */
    transform(value: string, type: string): SafeHtml | SafeStyle | SafeScript | SafeUrl | SafeResourceUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<SafePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SafePipe, "safe", false>;
}

declare class OrderByPipe implements PipeTransform {
    transform(array: any[], field: string, order?: 'asc' | 'desc'): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderByPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OrderByPipe, "orderby", false>;
}

declare class UIConfigPipe implements PipeTransform {
    constructor();
    transform(key: string): string | boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UIConfigPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<UIConfigPipe, "uiConfig", false>;
}

declare class PrettyJsonPipe implements PipeTransform {
    transform(val: string): string;
    private syntaxHighlight;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrettyJsonPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<PrettyJsonPipe, "prettyJson", true>;
}

declare class PrettyYamlPipe implements PipeTransform {
    transform(val: string | object): string;
    private syntaxHighlight;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrettyYamlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<PrettyYamlPipe, "prettyYaml", true>;
}

declare class CorePipesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CorePipesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CorePipesModule, [typeof InitialsPipe, typeof FilterPipe, typeof StripHtmlPipe, typeof SafePipe, typeof OrderByPipe, typeof UIConfigPipe], [typeof PrettyJsonPipe, typeof PrettyYamlPipe], [typeof InitialsPipe, typeof FilterPipe, typeof StripHtmlPipe, typeof SafePipe, typeof OrderByPipe, typeof UIConfigPipe, typeof PrettyJsonPipe, typeof PrettyYamlPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CorePipesModule>;
}

declare class IconModule {
    constructor(matIconRegistry: MatIconRegistry, domSanitizer: DomSanitizer);
    static ɵfac: i0.ɵɵFactoryDeclaration<IconModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IconModule, never, [typeof i1$1.MatIconModule], [typeof i1$1.MatIconModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IconModule>;
}

declare class CoreCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CoreCommonModule, never, [typeof i1$2.CommonModule, typeof i2$1.FlexLayoutModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof CoreDirectivesModule, typeof CorePipesModule, typeof i1$1.MatIconModule, typeof IconModule], [typeof i1$2.CommonModule, typeof i2$1.FlexLayoutModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof CoreDirectivesModule, typeof CorePipesModule, typeof i1$1.MatIconModule, typeof IconModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CoreCommonModule>;
}

declare class RestrictElementAccessModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RestrictElementAccessModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RestrictElementAccessModule, [typeof DisableForReadonlyUserDirective, typeof HideForReadonlyUserDirective], [typeof i1$2.CommonModule, typeof CoreCommonModule, typeof i3$1.NgbTooltipModule, typeof i3$1.NgbPopoverModule, typeof i2.MarkdownModule], [typeof DisableForReadonlyUserDirective, typeof HideForReadonlyUserDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RestrictElementAccessModule>;
}

declare class CopyToClipboardComponent {
    private clipboardService;
    source: string | ElementRef<HTMLElement>;
    includeCopyText: boolean;
    manual: boolean;
    placement?: Placement;
    onclick: EventEmitter<void>;
    tooltip: NgbTooltip;
    constructor(clipboardService: ClipboardService);
    click($event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CopyToClipboardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CopyToClipboardComponent, "copy-to-clipboard", never, { "source": { "alias": "source"; "required": false; }; "includeCopyText": { "alias": "includeCopyText"; "required": false; }; "manual": { "alias": "manual"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; }, { "onclick": "click"; }, never, never, true, never>;
}

declare class HelpIconComponent implements OnInit {
    private readonly translateService;
    private readonly clipboard;
    private _key;
    help: string;
    header: string;
    placement: string;
    maxSize: string;
    set key(key: string);
    constructor(translateService: TranslateService, clipboard: ClipboardService);
    ngOnInit(): void;
    init(): void;
    copy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HelpIconComponent, "help-icon, [help-icon]", never, { "help": { "alias": "help"; "required": false; }; "header": { "alias": "header"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "key": { "alias": "key"; "required": false; }; }, {}, never, never, false, never>;
}

declare class HelpDirective implements AfterViewInit {
    private i18n;
    private host;
    naveItems: QueryList<ViewContainerRef>;
    hostName: any;
    constructor(i18n: TranslateService, host: ViewContainerRef);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HelpDirective, "[navHelp]", never, {}, {}, ["naveItems"], never, false, never>;
}

declare class HelpModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HelpModule, [typeof HelpIconComponent, typeof HelpDirective], [typeof i1$2.CommonModule, typeof CoreCommonModule, typeof i3$1.NgbTooltipModule, typeof i3$1.NgbPopoverModule, typeof i2.MarkdownModule], [typeof HelpIconComponent, typeof HelpDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HelpModule>;
}

declare class FlatStatusFilter {
    constructor(properties?: Partial<FlatStatusFilter>);
    name: string;
    label: string;
    count: number;
    hideWhenZero?: boolean;
    badgeClass?: string;
    group?: string;
}
declare class FlatStatusFilterComponent implements OnChanges {
    filters: FlatStatusFilter[];
    activeStatus: string;
    statusChanged: EventEmitter<string>;
    showAll: boolean;
    defaultAll: boolean;
    showCount: boolean;
    computedFilters: FlatStatusFilter[];
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    setStatusFilter(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FlatStatusFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlatStatusFilterComponent, "app-flat-status-filter", never, { "filters": { "alias": "filters"; "required": false; }; "activeStatus": { "alias": "activeStatus"; "required": false; }; "showAll": { "alias": "showAll"; "required": false; }; "defaultAll": { "alias": "defaultAll"; "required": false; }; "showCount": { "alias": "showCount"; "required": false; }; }, { "statusChanged": "changed"; }, never, never, true, never>;
}

interface FilterPill {
    value: string;
    label: string;
}
/**
 * A single-select facet, sized to sit beside a datatable's search box (project it
 * into `[datatable-filters]`). Unlike app-flat-status-filter it carries no counts;
 * past a handful of values, app-flat-dropdown-filter reads better in a toolbar.
 */
declare class FilterPillsComponent {
    readonly options: i0.InputSignal<FilterPill[]>;
    /** '' is the All pill. */
    readonly value: i0.InputSignal<string>;
    readonly allLabel: i0.InputSignal<string>;
    readonly showAll: i0.InputSignal<boolean>;
    /** Names the row for screen readers, which otherwise hear loose buttons. */
    readonly ariaLabel: i0.InputSignal<string>;
    readonly valueChange: i0.OutputEmitterRef<string>;
    /** Resolved here, not in a binding, so it runs once per input change. */
    readonly pills: i0.Signal<FilterPill[]>;
    select(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterPillsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterPillsComponent, "app-filter-pills", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "allLabel": { "alias": "allLabel"; "required": false; "isSignal": true; }; "showAll": { "alias": "showAll"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SearchableDatatableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchableDatatableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SearchableDatatableModule, [typeof SearchableDatatableComponent], [typeof CoreCommonModule, typeof i3$1.NgbModule, typeof i4.NgxDatatableModule, typeof i5.NgSelectModule, typeof HelpModule, typeof RestrictElementAccessModule], [typeof CoreCommonModule, typeof i3$1.NgbModule, typeof i4.NgxDatatableModule, typeof SearchableDatatableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SearchableDatatableModule>;
}

/**
 * A convenience type representing all types that we know how to extract error messages from.
 */
type ErrorMessage = string | HttpErrorResponse | ErrorEvent;
/**
 * An interface for a class that knows how to report errors to the user.
 */
interface ErrorReporter {
    reportError: (error: ErrorMessage, title?: string) => void;
}
/**
 * Resolves to {@link SharedAlertsService} (toastr) unless the app provides its own.
 *
 * The root factory matters for components created outside a module's injector —
 * anything opened through NgbModal, for instance, is instantiated against the root
 * injector, so module-level `providers` are invisible to it. Without a default,
 * importing a common-lib module lazily (feature module, Module Federation remote)
 * left the token unresolvable and threw
 * `NullInjectorError: No provider for InjectionToken Duplo ErrorReporter`.
 * An explicit provider in the consuming app still wins over this default.
 */
declare const ERROR_REPORTER: InjectionToken<ErrorReporter>;
/**
 * An interface for a class that knows how to report success to the user.
 */
interface SuccessReporter {
    reportSuccess: (message: string, title?: string) => void;
}
/** Success counterpart of {@link ERROR_REPORTER}; same root-factory rationale. */
declare const SUCCESS_REPORTER: InjectionToken<SuccessReporter>;
/**
 * Extracts an error message.
 */
declare function extractErrorMessage(err: ErrorMessage): string;
declare class SharedAlertsService implements ErrorReporter, SuccessReporter {
    private toastr;
    constructor(toastr: ToastrService);
    reportSuccess(message: string, title?: string): void;
    reportError(error: ErrorMessage, title?: string): void;
    systemDown(message: ErrorMessage): void;
    /** RxJS operator for system down detection. */
    catchAndReportSystemDown<T>(): OperatorFunction<T, T>;
    catchAndReportSystemDownToConsole<T>(): OperatorFunction<T, T>;
    /** RxJS operator for error handling. */
    catchAndReportError<T>(): OperatorFunction<T, T>;
    configureToast(override?: Partial<IndividualConfig>): Partial<IndividualConfig>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SharedAlertsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SharedAlertsService>;
}

declare class ConfirmationModalComponent {
    activeModal: NgbActiveModal;
    errorReporter: ErrorReporter;
    successReporter: SuccessReporter;
    /** Allow supplying a plain-text title for the header. */
    headerText: string;
    /** Allow supplying a template for the header. */
    headerTemplate: TemplateRef<void>;
    /** Allow supplying a plain-text message for the body. */
    messageText: string;
    /** Allow supplying a template for the header. */
    messageTemplate: TemplateRef<void>;
    data: any;
    showToggleSwitch: boolean;
    toggleText: string;
    tooltipText: string;
    toggleValue: boolean;
    constructor(activeModal: NgbActiveModal, errorReporter: ErrorReporter, successReporter: SuccessReporter);
    /** Convenience method used by ConfirmationModalRef.confirmThenAct() */
    getHeaderAsText(): string;
    /** Convenience method used by ConfirmationModalRef.confirmThenAct() */
    getMessageAsText(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmationModalComponent, "confirmation-modal", never, { "headerText": { "alias": "headerText"; "required": false; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; }; "messageText": { "alias": "messageText"; "required": false; }; "messageTemplate": { "alias": "messageTemplate"; "required": false; }; "data": { "alias": "data"; "required": false; }; "showToggleSwitch": { "alias": "showToggleSwitch"; "required": false; }; "toggleText": { "alias": "toggleText"; "required": false; }; "tooltipText": { "alias": "tooltipText"; "required": false; }; }, {}, never, never, false, never>;
}

declare class DeleteConfirmationModalComponent {
    activeModal: NgbActiveModal;
    errorReporter: ErrorReporter;
    successReporter: SuccessReporter;
    /** Allow supplying a plain-text title for the header. */
    headerText: string;
    /** Allow supplying a template for the header. */
    headerTemplate: TemplateRef<void>;
    /** Allow supplying a plain-text message for the body. */
    messageText: string;
    /** Allow supplying a template for the header. */
    messageTemplate: TemplateRef<void>;
    data: any;
    showToggleSwitch: boolean;
    toggleText: string;
    tooltipText: string;
    toggleValue: boolean;
    entityType: string;
    private _confirmationText;
    set confirmationText(value: string);
    get confirmationText(): string;
    confirmationInputValue: string;
    constructor(activeModal: NgbActiveModal, errorReporter: ErrorReporter, successReporter: SuccessReporter);
    /** Convenience method used by ConfirmationModalRef.confirmThenAct() */
    getHeaderAsText(): string;
    /** Convenience method used by ConfirmationModalRef.confirmThenAct() */
    getMessageAsText(): string;
    get isConfirmationTextMatched(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteConfirmationModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeleteConfirmationModalComponent, "delete-confirmation-modal", never, { "headerText": { "alias": "headerText"; "required": false; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; }; "messageText": { "alias": "messageText"; "required": false; }; "messageTemplate": { "alias": "messageTemplate"; "required": false; }; "data": { "alias": "data"; "required": false; }; "showToggleSwitch": { "alias": "showToggleSwitch"; "required": false; }; "toggleText": { "alias": "toggleText"; "required": false; }; "tooltipText": { "alias": "tooltipText"; "required": false; }; "entityType": { "alias": "entityType"; "required": false; }; "confirmationText": { "alias": "confirmationText"; "required": false; }; }, {}, never, never, false, never>;
}

/** A marker directive to make form information injectable into children. */
declare class FormRefDirective implements AfterViewInit {
    readonly elementRef: ElementRef<HTMLFormElement>;
    readonly formGroupDirective: FormGroupDirective;
    readonly ngForm: NgForm;
    readonly name: string | undefined;
    readonly form: NgForm | FormGroupDirective;
    constructor(elementRef: ElementRef<HTMLFormElement>, formGroupDirective: FormGroupDirective, ngForm: NgForm);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormRefDirective, [null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormRefDirective, "form", never, { "name": { "alias": "name"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * A simple utility directive to provide the parent form to a child component.
 *
 * - If you are using template-driven forms, the simplest approach is to add the `use-parent-form` attribute
 *   to some top-level container element in your child component.
 * - If you are using reactive forms, you should pass the formGroup to the child as an input instead.
 */
declare class UseParentFormDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<UseParentFormDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UseParentFormDirective, "[use-parent-form]", never, {}, {}, never, never, false, never>;
}

declare class FormFieldComponent implements OnInit, AfterContentInit {
    private _changeDetector;
    private _element;
    readonly formRef: FormRefDirective;
    private i18n;
    viewContainerRef: ViewContainerRef;
    private renderer2;
    private _control;
    private _modelElement;
    private _label;
    helpIcon: HelpIconComponent;
    private _labelViewContainerRef;
    constructor(_changeDetector: ChangeDetectorRef, _element: ElementRef<HTMLElement>, formRef: FormRefDirective, i18n: TranslateService, viewContainerRef: ViewContainerRef, renderer2: Renderer2);
    /** Allow passing the control as an input. */
    set control(control: NgControl);
    /** Allow discovering the control from the content. */
    set contentControl(control: NgControl);
    /** Allow discovering the control's host element from the content. */
    set modelElement(ref: ElementRef<HTMLElement>);
    /** Allow discovering the control's host element from the content. */
    set labelViewContainerRef(ref: ViewContainerRef);
    get control(): NgControl;
    get name(): string;
    get label(): HTMLLabelElement;
    get labelText(): string;
    ngAfterContentInit(): void;
    ngOnInit(): void;
    /**
     * Internal method to set up the ID (and possibley name) HTML attributes for the control.
     *
     * @returns the ID attribute for the control's host element
     */
    private setupControlIdentification;
    /**
     * Internal method to set up the label for the control.
     */
    private setupControlLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormFieldComponent, "form-field", never, { "control": { "alias": "control"; "required": false; }; }, {}, ["contentControl", "modelElement", "labelViewContainerRef"], ["*"], false, never>;
}

/**
 * Simple service for translating formatted messages with support for fallback keys.
 */
declare class MessageService {
    private i18n;
    constructor(i18n: TranslateService);
    /**
     *  Instantly translates a key.  Supports a list of keys to be used as fallback translations.
     *
     *  Unlike the TranslateService.instant function, this function will return `null` if no translation was found.
     *
     *  @param key      a single key, or a list of keys to look up in order
     *  @param params   message formatting parameters
     */
    instant(key: string | string[], params?: object): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MessageService>;
}

/**
 * Represents a summary of errors in the form.  Does not include individual field errors.
 */
declare class ErrorSummary {
    header?: ErrorMessage;
    messages?: ErrorMessage[];
    constructor(header?: ErrorMessage, messages?: ErrorMessage[]);
    hasErrors(): boolean;
}
declare class FormGroupErrorsComponent implements ErrorReporter {
    private messages;
    host: ElementRef;
    private cdr;
    showSummaryWhen: 'always' | 'submitted' | 'dirty' | 'touched' | 'never';
    showDetailsWhen: 'always' | 'submitted' | 'dirty' | 'touched' | 'never';
    form: NgForm | FormGroupDirective;
    summary: ErrorSummary;
    title: string;
    fields: {
        [name: string]: FormFieldErrorsComponent;
    };
    /** Convenience setter to set a single summary header message. */
    set summaryHeader(header: ErrorMessage);
    /** Convenience setter to set a single summary error message. */
    set summaryMessage(message: ErrorMessage);
    msgContainers: QueryList<ElementRef>;
    checkMsgDebounce: any;
    /** Allow this component to act as an ErrorReporter. */
    reportError(error: ErrorMessage): void;
    constructor(messages: MessageService, formGropuDirective: FormGroupDirective, ngForm: NgForm, host: ElementRef, cdr: ChangeDetectorRef);
    /** Internal method, called by a FormFieldErrorsComponent, to add itself to the list. */
    add(field: FormFieldErrorsComponent): string;
    /** Internal method, called by a FormFieldErrorsComponent, to remove itself from the list. */
    remove(field: FormFieldErrorsComponent): string;
    /** Internal getter to return a formatted error summary header. */
    get summaryHeaderMessage(): string;
    /** Internal getter to return a list of formatted error summary messages. */
    get summaryMessages(): string[];
    /** Internal getter to return a list of formatted error detail messages. */
    get detailMessages(): string[];
    /**
     *  Whether or not any error messages (or the title!) need to be displayed.
     */
    get showErrors(): boolean;
    /**
     *  Whether or not summary errors should be displayed.
     */
    get showSummary(): boolean;
    /**
     *  Whether or not detailed errors should be displayed.
     */
    get showDetails(): boolean;
    /**
    * Check if any message content overflows its container and add the 'has-overflow' class accordingly
    */
    checkMessageOverflow(): void;
    toggleMsgView(container: HTMLElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormGroupErrorsComponent, [null, { optional: true; }, { optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormGroupErrorsComponent, "[form-group-errors], form-group-errors", never, { "showSummaryWhen": { "alias": "showSummaryWhen"; "required": false; }; "showDetailsWhen": { "alias": "showDetailsWhen"; "required": false; }; "form": { "alias": "form"; "required": false; }; "summary": { "alias": "summary"; "required": false; }; "title": { "alias": "title"; "required": false; }; "summaryHeader": { "alias": "summaryHeader"; "required": false; }; "summaryMessage": { "alias": "summaryMessage"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class FormFieldErrorsComponent implements AfterViewInit, OnDestroy {
    private messages;
    private elementRef;
    private formField;
    private formGroupErrors;
    control: NgControl;
    name: string | null;
    label: string | null;
    showWhen: 'always' | 'submitted' | 'dirty' | 'touched' | 'never';
    customErrorMessage: string;
    form: NgForm | FormGroupDirective;
    constructor(messages: MessageService, elementRef: ElementRef, formGroupDirective: FormGroupDirective, ngForm: NgForm, formField: FormFieldComponent, formGroupErrors: FormGroupErrorsComponent);
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    /**
     *  Whether or not errors should be displayed.
     */
    get showErrors(): boolean;
    /**
     *  Returns the field label, to be used for error messages.
     */
    get fieldLabel(): string;
    /**
     *  Returns the field name, to be used for i18n keys.
     */
    get fieldName(): string;
    /**
     *  Returns the form name, to be used for i18n keys.
     */
    get formName(): string;
    /**
     *  Returns a map of formatted errors.
     */
    get errors(): ValidationErrors;
    private getMessage;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldErrorsComponent, [null, null, { optional: true; }, { optional: true; }, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormFieldErrorsComponent, "form-field-errors, [form-field-errors]", never, { "control": { "alias": "control"; "required": false; }; "name": { "alias": "name"; "required": false; }; "label": { "alias": "label"; "required": false; }; "showWhen": { "alias": "showWhen"; "required": false; }; "customErrorMessage": { "alias": "customErrorMessage"; "required": false; }; "form": { "alias": "form"; "required": false; }; }, {}, never, never, false, never>;
}

declare class PasswordFieldComponent {
    input: GenericFormInput;
    change: EventEmitter<any>;
    onValueChange(event: any): void;
    /**
     * Closest enclosing form, resolved with `@Host()` so it matches the `ControlContainer`
     * the inner `NgModel` binds to via `[use-parent-form]` on this component's top-level
     * `<div>` (see password-field.component.html) — without `@Host()` this could resolve to
     * an unrelated ancestor form in templates with multiple sibling `<form>`s (e.g. accordion
     * panels). Used to pass `<form-field-errors>` a "submitted" signal, and to let error text
     * show the field's `label` — `<form-field>`'s own DOM-based label auto-discovery can't see
     * a control buried in this component's own template.
     */
    formDirective: NgForm | null;
    constructor(ngForm: NgForm);
    /**
     * Emits on every value change (ngModelChange), not just the native `change`/blur event.
     * Lets consumers propagate the value immediately — e.g. so a secret typed and submitted
     * via Enter (without blurring) is still captured. Additive; existing `(change)` users are unaffected.
     */
    valueChange: EventEmitter<any>;
    onModelChange(value: any): void;
    showPassword: boolean;
    togglePasswordVisibility(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordFieldComponent, [{ optional: true; host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PasswordFieldComponent, "password-field", never, { "input": { "alias": "input"; "required": false; }; }, { "change": "change"; "valueChange": "valueChange"; }, never, never, false, never>;
}

declare class ValidationErrorsDirective implements OnInit {
    private _container;
    private _control;
    showWhen: 'always' | 'submitted' | 'dirty' | 'touched' | 'never';
    customErrorMessage: string;
    form: NgForm | FormGroupDirective;
    component: FormFieldErrorsComponent;
    constructor(_container: ViewContainerRef, _control: NgControl, formGropuDirective: FormGroupDirective, ngForm: NgForm);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidationErrorsDirective, [null, null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ValidationErrorsDirective, "[validation-errors]", never, { "showWhen": { "alias": "validation-errors"; "required": false; }; "customErrorMessage": { "alias": "customErrorMessage"; "required": false; }; "form": { "alias": "form"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ValidationStateDirective {
    private control;
    showWhen: 'always' | 'invalid' | 'submitted' | 'dirty' | 'touched' | 'never';
    private form;
    constructor(control: NgControl, formGropuDirective: FormGroupDirective, ngForm: NgForm);
    get isValid(): boolean;
    get isInvalid(): boolean;
    /**
     *  Whether or not validation state should be displayed.
     */
    get showState(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidationStateDirective, [{ self: true; }, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ValidationStateDirective, "[validation-state]", never, { "showWhen": { "alias": "validation-state"; "required": false; }; }, {}, never, never, false, never>;
}

declare class YamlValidationDirective {
    private _control;
    form: NgForm | FormGroupDirective;
    onSuccessfulYamlValidation?: (ctl: AbstractControl, parsedYaml: Record<string, string> | string) => void;
    constructor(_control: NgControl, formGropuDirective: FormGroupDirective, ngForm: NgForm);
    onKeyUp(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<YamlValidationDirective, [null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<YamlValidationDirective, "[yaml-validation]", never, { "form": { "alias": "form"; "required": false; }; "onSuccessfulYamlValidation": { "alias": "onSuccessfulYamlValidation"; "required": false; }; }, {}, never, never, false, never>;
}

declare class YamlMapValidationDirective {
    private _control;
    form: NgForm | FormGroupDirective;
    constructor(_control: NgControl, formGropuDirective: FormGroupDirective, ngForm: NgForm);
    onValidate(event: KeyboardEvent): void;
    private containsUnquotedNumbersOrBooleans;
    hasInvalidPairs(checkObject: {
        [keyName: string]: string;
    }): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<YamlMapValidationDirective, [null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<YamlMapValidationDirective, "[yaml-map-validation]", never, { "form": { "alias": "form"; "required": false; }; }, {}, never, never, false, never>;
}

declare class XmlValidationDirective {
    private readonly _control;
    form: NgForm | FormGroupDirective;
    constructor(_control: NgControl, formGroupDirective: FormGroupDirective, ngForm: NgForm);
    onKeyUp(event: KeyboardEvent): any;
    private setError;
    static ɵfac: i0.ɵɵFactoryDeclaration<XmlValidationDirective, [null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<XmlValidationDirective, "[xml-validation]", never, { "form": { "alias": "form"; "required": false; }; }, {}, never, never, false, never>;
}

declare class IniValidationDirective {
    private readonly _control;
    form: NgForm | FormGroupDirective;
    constructor(_control: NgControl, formGroupDirective: FormGroupDirective, ngForm: NgForm);
    onKeyUp(event: KeyboardEvent): any;
    private setError;
    static ɵfac: i0.ɵɵFactoryDeclaration<IniValidationDirective, [null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IniValidationDirective, "[ini-validation]", never, { "form": { "alias": "form"; "required": false; }; }, {}, never, never, false, never>;
}

declare class DuploValidators {
    /**
     * Validate a JSON object or JSON array of objects.
     *
     * @param type one of 'object' or 'array'
     * @returns an instance of ValidatorFn
     */
    static json(type?: 'object' | 'array'): ValidatorFn;
    static jsonObject: ValidatorFn;
    static jsonArray: ValidatorFn;
    /**
     * Validate a JSON object or JSON array of objects.
     *
     * @param type one of 'object' or 'array'
     * @returns an instance of ValidatorFn
     */
    static jsonKeyStringValue(): ValidatorFn;
    /**
     * Validates that a value does not appear in a list.
     *
     * @param list  list of any object
     * @param checkCase   whether or not to consider string case
     * @returns an instance of ValidatorFn
     */
    static notExists(list: any[], checkCase?: boolean): ValidatorFn;
    /**
     * Validates that:
     *  - the value does not appear in the list
     *  - the value does not start with item from the list
     *  - no item from the list starts with the value
     *
     * @param list  list of strings
     * @param checkCase   whether or not to consider string case
     * @returns an instance of ValidatorFn
     */
    static notStartsWith(list: string[], checkCase?: boolean): ValidatorFn;
    static cron(control: AbstractControl): ValidationErrors | null;
    static EMAIL_REGEX: RegExp;
    static email(control: AbstractControl): ValidationErrors | null;
    static equalityValidator(otherControlName: string, fieldOneLabel: string, fieldTwoLabel: string): ValidatorFn;
    static NON_UNICODE_REGEX: RegExp;
    /**
     * Validates the control value only contains unicode characters.
     * Angular's pattern validator does not support unicode with regular expressions.
     * Please refer to: https://github.com/angular/angular/issues/51000
     *
     * @returns {ValidatorFn} an instance of ValidatorFn
     */
    static unicode(): ValidatorFn;
    static PORT_RANGE_REGEX: RegExp;
    static readonly KMS_KEY_ID_PATTERN = "^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}|mrk-[0-9a-f]{32})$";
    static readonly KMS_KEY_ARN_PATTERN = "^arn:aws(-us-gov)?:kms:[a-z][a-z0-9\\-]+:[0-9]{12}:key\\/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}|mrk-[0-9a-f]{32})$";
    /**
     * Validates that:
     *  - the value should between the given min and max value
     *  - the value can be port range with hyphen separated
     *  - the value can be individual port
     *  - the value can be port range and individual port with comma separated
     *
     * @param minPort minimum number
     * @param maxPort maximum number
     * @returns an instance of ValidatorFn
     */
    static portRange(minPort: number, maxPort: number): ValidatorFn;
}
declare class NotExistsValidatorDirective implements Validator {
    list: any[];
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotExistsValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotExistsValidatorDirective, "[notExists]", never, { "list": { "alias": "notExists"; "required": false; }; }, {}, never, never, false, never>;
}
/**
 * Async sibling of [notExists] for cases where the "existing values" list is too large
 * to load upfront — checks uniqueness via a server call instead of a static in-memory list.
 * Debounces internally (400ms) so it's safe to bind directly to a fast-typing input.
 */
declare class AsyncNotExistsValidatorDirective implements AsyncValidator {
    checkFn: (value: string) => Observable<boolean>;
    validate(control: AbstractControl): Observable<ValidationErrors | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsyncNotExistsValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AsyncNotExistsValidatorDirective, "[asyncNotExists]", never, { "checkFn": { "alias": "asyncNotExists"; "required": false; }; }, {}, never, never, false, never>;
}
declare class NotExistsCaseValidatorDirective implements Validator {
    list: any[];
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotExistsCaseValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotExistsCaseValidatorDirective, "[notExistsCase]", never, { "list": { "alias": "notExistsCase"; "required": false; }; }, {}, never, never, false, never>;
}
declare class NotStartsWithValidatorDirective implements Validator {
    list: string[];
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotStartsWithValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotStartsWithValidatorDirective, "[notStartsWith]", never, { "list": { "alias": "notStartsWith"; "required": false; }; }, {}, never, never, false, never>;
}
declare class NotStartsWithCaseValidatorDirective implements Validator {
    list: string[];
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotStartsWithCaseValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotStartsWithCaseValidatorDirective, "[notStartsWithCase]", never, { "list": { "alias": "notStartsWithCase"; "required": false; }; }, {}, never, never, false, never>;
}
declare class JsonObjectValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonObjectValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<JsonObjectValidatorDirective, "[jsonObject]", never, {}, {}, never, never, false, never>;
}
declare class JsonArrayValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonArrayValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<JsonArrayValidatorDirective, "[jsonArray]", never, {}, {}, never, never, false, never>;
}
declare class JsonKeyStringValueValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonKeyStringValueValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<JsonKeyStringValueValidatorDirective, "[jsonKeyStringValue]", never, {}, {}, never, never, false, never>;
}
declare class CronValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<CronValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CronValidatorDirective, "[validCron]", never, {}, {}, never, never, false, never>;
}
declare class EmailValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<EmailValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EmailValidatorDirective, "[validEmail], [type=\"email\"]", never, {}, {}, never, never, false, never>;
}
declare class NotEqualValidatorDirective implements Validator {
    validateAgainst: string;
    fieldOneLabel: string;
    fieldTwoLabel: string;
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotEqualValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotEqualValidatorDirective, "[notEqualValidator]", never, { "validateAgainst": { "alias": "notEqualValidator"; "required": false; }; "fieldOneLabel": { "alias": "fieldOneLabel"; "required": false; }; "fieldTwoLabel": { "alias": "fieldTwoLabel"; "required": false; }; }, {}, never, never, false, never>;
}
declare class UnicodeValidatorDirective implements Validator {
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnicodeValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UnicodeValidatorDirective, "[unicode]", never, {}, {}, never, never, false, never>;
}
declare class PortRangeValidatorDirective implements Validator {
    minPort: number;
    maxPort: number;
    validate(control: AbstractControl): ValidationErrors | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<PortRangeValidatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PortRangeValidatorDirective, "[portRangeValidator]", never, { "minPort": { "alias": "minPort"; "required": false; }; "maxPort": { "alias": "maxPort"; "required": false; }; }, {}, never, never, false, never>;
}

/** A marker directive to make label information injectable into children. */
declare class LabelRefDirective implements AfterViewInit {
    constructor();
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LabelRefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LabelRefDirective, "label", never, {}, {}, never, never, false, never>;
}

declare class InputTextTrimDirective implements OnInit {
    private ngControl;
    private readonly elementRef;
    private readonly ngForm;
    private destroy$;
    constructor(ngControl: NgControl, elementRef: ElementRef<HTMLInputElement>, ngForm: NgForm, valueAccessors: ControlValueAccessor[], destroy$: SubDestroyService);
    ngOnInit(): void;
    /**
     * Modifies the registerOnChange function of a value accessor to trim whitespace
     * from string inputs before passing them to the original change handler.
     * @param valueAccessor - The ControlValueAccessor bound to this input.
     */
    trimValueAccessor(valueAccessor: ControlValueAccessor): void;
    /**
     * Update the input element value to match the form control's value on form submission.
     */
    updateInputValueOnSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputTextTrimDirective, [null, null, { optional: true; }, { optional: true; self: true; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InputTextTrimDirective, "input[type=\"text\"][name]", never, {}, {}, never, never, false, never>;
}

declare class GenericFormFieldComponent implements OnInit, AfterViewInit {
    input: GenericFormInput;
    form: NgForm | FormGroupDirective;
    change: EventEmitter<any>;
    onValueChange(event: any): void;
    jsonEditorOptions: object;
    jsonEditorSize: JsonEditorSize;
    yamlEditorOptions: any;
    editorContainerEl: ElementRef<HTMLElement>;
    editorEl: ElementRef<HTMLElement>;
    constructor(formGroupDirective: FormGroupDirective, ngForm: NgForm);
    get jsonEditorContainerClass(): string;
    onJsonEditorInit(editor: any): void;
    getOptionLabel(option: any): string;
    get resolvedBindLabel(): string | null;
    get resolvedBindValue(): string | null;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    private updateHeight;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericFormFieldComponent, [{ optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GenericFormFieldComponent, "generic-form-field", never, { "input": { "alias": "input"; "required": false; }; "form": { "alias": "form"; "required": false; }; }, { "change": "change"; }, never, never, false, never>;
}

declare class FormFieldAlert {
    constructor(properties?: Partial<FormFieldAlert>);
    alertIcon?: string;
    alertType?: string;
    alertTitle?: string;
    alertMessage?: string;
}

declare class FormFieldAlertComponent implements OnInit {
    input: FormFieldAlert;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldAlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormFieldAlertComponent, "form-field-alert", never, { "input": { "alias": "input"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FormElementsCollapsableGroupComponent {
    label: string;
    isCollapsed: boolean;
    isCollapsedChanged: EventEmitter<boolean>;
    toggle(state?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormElementsCollapsableGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormElementsCollapsableGroupComponent, "app-form-elements-collapsable-group", never, { "label": { "alias": "label"; "required": false; }; "isCollapsed": { "alias": "isCollapsed"; "required": false; }; }, { "isCollapsedChanged": "isCollapsedChanged"; }, never, ["*"], false, never>;
}

declare class ExpandFormFieldIconComponent {
    isExpanded: boolean;
    expandToggle: EventEmitter<boolean>;
    toggleExpand(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpandFormFieldIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpandFormFieldIconComponent, "expand-form-field-icon", never, { "isExpanded": { "alias": "isExpanded"; "required": false; }; }, { "expandToggle": "expandToggle"; }, never, never, false, never>;
}

declare class ExpandableFieldDirective implements AfterViewInit {
    private el;
    private renderer;
    private viewContainerRef;
    private destroy$;
    expandableModalField: boolean;
    isExpanded: boolean;
    private expandIconRef;
    private hasMonacoEditor;
    private monacoEditorNormalHeight;
    get expandedClass(): boolean;
    constructor(el: ElementRef, renderer: Renderer2, viewContainerRef: ViewContainerRef, destroy$: SubDestroyService);
    ngAfterViewInit(): void;
    private addExpandIcon;
    private onExpandFieldModal;
    /**
     * Minimizes the expanded field modal by:
     * 1. Removing inline height and width styles from the host element
     * 2. Removing the modal backdrop element if it exists
     */
    private onMinimizeFieldModal;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpandableFieldDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ExpandableFieldDirective, "form-field[expandableModalField]", never, { "expandableModalField": { "alias": "expandableModalField"; "required": false; }; "isExpanded": { "alias": "isExpanded"; "required": false; }; }, {}, never, never, false, never>;
}

declare class KeyValuePair {
    Key: string;
    Value: string;
    uid?: string;
    constructor(properties?: Partial<KeyValuePair>);
    static getKeyValArrayToObject(vals: KeyValuePair[]): Object;
    static getObjectToKeyValArray(objMap: Object): KeyValuePair[];
}
declare class KeyValueConfigPair extends KeyValuePair {
    isMandatory: boolean;
    constructor(properties?: Partial<KeyValueConfigPair>);
    private _statusBadge;
    get statusBadge(): TableStatus;
}
declare const statusMap: Map<boolean, string>;
declare class TableStatus {
    text: string;
    style: string;
    constructor(text: string, style: string);
}

declare class FormKeyValFieldComponent {
    list: KeyValuePair[];
    listChange: EventEmitter<KeyValuePair[]>;
    keyId: string;
    valId: string;
    canAdd: boolean;
    keyLabel: string;
    maxCount: number;
    fieldTracker: (field: any) => any;
    addKeyValuePair(): void;
    removeKeyValuePair(index: number): void;
    get showAddBtn(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormKeyValFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormKeyValFieldComponent, "app-form-key-val-field", never, { "list": { "alias": "list"; "required": false; }; "keyId": { "alias": "keyId"; "required": false; }; "valId": { "alias": "valId"; "required": false; }; "canAdd": { "alias": "canAdd"; "required": false; }; "keyLabel": { "alias": "keyLabel"; "required": false; }; "maxCount": { "alias": "maxCount"; "required": false; }; }, { "listChange": "listChange"; }, never, never, false, never>;
}

declare class KeyValConfigFieldComponent {
    list: KeyValueConfigPair[];
    listChange: EventEmitter<KeyValueConfigPair[]>;
    readonly: boolean;
    keyId: string;
    valId: string;
    isMandatoryId: string;
    canAdd: boolean;
    keyLabel: string;
    maxCount: number;
    fieldTracker: (field: any) => any;
    addKeyValuePair(): void;
    removeKeyValuePair(index: number): void;
    get showAddBtn(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<KeyValConfigFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KeyValConfigFieldComponent, "app-key-val-config-field", never, { "list": { "alias": "list"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "keyId": { "alias": "keyId"; "required": false; }; "valId": { "alias": "valId"; "required": false; }; "isMandatoryId": { "alias": "isMandatoryId"; "required": false; }; "canAdd": { "alias": "canAdd"; "required": false; }; "keyLabel": { "alias": "keyLabel"; "required": false; }; "maxCount": { "alias": "maxCount"; "required": false; }; }, { "listChange": "listChange"; }, never, never, false, never>;
}

declare class SharedFormsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SharedFormsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SharedFormsModule, [typeof FormRefDirective, typeof UseParentFormDirective, typeof FormFieldComponent, typeof FormFieldErrorsComponent, typeof FormGroupErrorsComponent, typeof PasswordFieldComponent, typeof ValidationErrorsDirective, typeof ValidationStateDirective, typeof YamlValidationDirective, typeof YamlMapValidationDirective, typeof XmlValidationDirective, typeof IniValidationDirective, typeof NotExistsValidatorDirective, typeof NotExistsCaseValidatorDirective, typeof AsyncNotExistsValidatorDirective, typeof NotEqualValidatorDirective, typeof NotStartsWithValidatorDirective, typeof NotStartsWithCaseValidatorDirective, typeof JsonObjectValidatorDirective, typeof JsonArrayValidatorDirective, typeof JsonKeyStringValueValidatorDirective, typeof CronValidatorDirective, typeof EmailValidatorDirective, typeof UnicodeValidatorDirective, typeof PortRangeValidatorDirective, typeof LabelRefDirective, typeof InputTextTrimDirective, typeof GenericFormFieldComponent, typeof FormFieldAlertComponent, typeof FormElementsCollapsableGroupComponent, typeof ExpandFormFieldIconComponent, typeof ExpandableFieldDirective, typeof FormKeyValFieldComponent, typeof KeyValConfigFieldComponent], [typeof i1$2.CommonModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof i3$1.NgbModule, typeof i5.NgSelectModule, typeof i27.BlockUIModule, typeof i28.FlatpickrModule, typeof i29.ToastrModule, typeof i1.MonacoEditorModule, typeof CorePipesModule, typeof CoreCommonModule, typeof HelpModule], [typeof i1$2.CommonModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof i1.MonacoEditorModule, typeof i3$1.NgbModule, typeof i5.NgSelectModule, typeof i27.BlockUIModule, typeof i28.FlatpickrModule, typeof i29.ToastrModule, typeof CoreCommonModule, typeof FormRefDirective, typeof UseParentFormDirective, typeof FormFieldComponent, typeof FormFieldErrorsComponent, typeof FormGroupErrorsComponent, typeof PasswordFieldComponent, typeof ValidationErrorsDirective, typeof ValidationStateDirective, typeof YamlValidationDirective, typeof YamlMapValidationDirective, typeof XmlValidationDirective, typeof IniValidationDirective, typeof NotExistsValidatorDirective, typeof NotExistsCaseValidatorDirective, typeof AsyncNotExistsValidatorDirective, typeof NotEqualValidatorDirective, typeof NotStartsWithValidatorDirective, typeof NotStartsWithCaseValidatorDirective, typeof JsonObjectValidatorDirective, typeof JsonArrayValidatorDirective, typeof JsonKeyStringValueValidatorDirective, typeof CronValidatorDirective, typeof EmailValidatorDirective, typeof UnicodeValidatorDirective, typeof PortRangeValidatorDirective, typeof LabelRefDirective, typeof InputTextTrimDirective, typeof GenericFormFieldComponent, typeof FormFieldAlertComponent, typeof FormElementsCollapsableGroupComponent, typeof ExpandFormFieldIconComponent, typeof ExpandableFieldDirective, typeof FormKeyValFieldComponent, typeof KeyValConfigFieldComponent, typeof HelpModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SharedFormsModule>;
}

declare class ConfirmationModalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationModalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfirmationModalModule, [typeof ConfirmationModalComponent, typeof DeleteConfirmationModalComponent], [typeof i1$2.CommonModule, typeof SharedFormsModule, typeof i3$1.NgbModule], [typeof ConfirmationModalComponent, typeof DeleteConfirmationModalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfirmationModalModule>;
}

/** Shared types for the detail-view components, and the one badge builder they all share. */
type DetailBadgeKind = 'ok' | 'info' | 'warn' | 'bad' | 'mute' | 'brand';
/** A status or flag chip beside the record name. */
interface DetailBadge {
    label: string;
    kind?: DetailBadgeKind;
}
/** One row of a label/value block in `main`. */
interface DetailKvRow {
    label: string;
    value: string;
    href?: string;
}
/** One row of the side's counts panel. */
interface DetailCountRow {
    label: string;
    value: string | number;
}
type DetailTimelineState = 'done' | 'now' | 'todo';
/** One step of a lifecycle in the side's timeline panel. */
interface DetailTimelineEvent {
    label: string;
    sub?: string;
    state: DetailTimelineState;
}
type DetailCalloutKind = 'warn' | 'danger' | 'info';
/** Severity of a spec value, drawn as a dot after the value in `app-stat-card`. */
type StatDotKind = 'ok' | 'warn' | 'bad' | 'mute';
/**
 * The record's active state, for `app-detail-header`'s [status] — the one badge
 * every detail page shows the same way, so it is built here rather than per page.
 * `isActive` is optional on most payloads: undefined means the resource has no
 * such state, and inventing an "Active" chip for it would be a claim, so the
 * header stays bare.
 */
declare function activeStatusBadges(isActive?: boolean): DetailBadge[];

/**
 * The detail page header: a 3-column grid of optional slots. Row 1 is
 * icon | identity | actions; row 2 of the identity column is the description.
 */
declare class DetailHeaderComponent {
    readonly title: i0.InputSignal<string>;
    readonly subtitle: i0.InputSignal<string>;
    /** Plain text. The component owns the clamp and the more/less toggle. */
    readonly description: i0.InputSignal<string>;
    /** Glyph for the identity mark; falls back to the title's initial. */
    readonly mark: i0.InputSignal<string>;
    readonly status: i0.InputSignal<DetailBadge[]>;
    readonly showActions: i0.InputSignal<boolean>;
    readonly actions: i0.InputSignal<ViewHeaderAction[]>;
    readonly compactActions: i0.InputSignal<boolean>;
    readonly dynamicAction: i0.InputSignal<boolean>;
    /**
     * ngbDropdown's autoClose. 'outside' is what a projected cascade sub-menu needs:
     * the default dismisses the menu the moment the cascade's own trigger is clicked.
     */
    readonly autoClose: i0.InputSignal<boolean | "outside" | "inside">;
    /** 'body' teleports the menu out, for a header inside a clipping or scrolling ancestor. */
    readonly container: i0.InputSignal<"body">;
    /** Fires when the actions menu opens or closes, for pages holding their own sub-menu state. */
    readonly actionsOpenChange: i0.OutputEmitterRef<boolean>;
    /**
     * Extra class on the actions menu. [container] can teleport the menu out of
     * the consumer's DOM, so a page that wants to style its own menu items needs
     * a hook it can name; this component takes no view on what that style is.
     */
    readonly menuClass: i0.InputSignal<string>;
    readonly titleTpl: i0.Signal<TemplateRef<unknown>>;
    readonly subtitleTpl: i0.Signal<TemplateRef<unknown>>;
    readonly actionsTpl: i0.Signal<TemplateRef<unknown>>;
    readonly headerFilterTpl: i0.Signal<TemplateRef<unknown>>;
    readonly markGlyph: i0.Signal<string>;
    /** Unique per instance, so two headers on one page cannot share a checkbox. */
    readonly descId: string;
    /** Unique per instance, so two headers on one page cannot share an id. */
    readonly actionsId: string;
    /**
     * Whether one line was not enough. The only measured value here — CSS has
     * no way to detect truncation.
     */
    readonly clamped: i0.WritableSignal<boolean>;
    private static nextId;
    private readonly descText;
    private readonly descToggle;
    private readonly actionsDropdown;
    /**
     * Closes the actions menu. Needed because a projected item that is not an
     * ngbDropdownItem — a cascade's choice, say — does not close it by itself,
     * and autoClose="outside" deliberately ignores clicks inside the menu.
     */
    closeActions(): void;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailHeaderComponent, "app-detail-header", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "mark": { "alias": "mark"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "showActions": { "alias": "showActions"; "required": false; "isSignal": true; }; "actions": { "alias": "actions"; "required": false; "isSignal": true; }; "compactActions": { "alias": "compactActions"; "required": false; "isSignal": true; }; "dynamicAction": { "alias": "dynamicAction"; "required": false; "isSignal": true; }; "autoClose": { "alias": "autoClose"; "required": false; "isSignal": true; }; "container": { "alias": "container"; "required": false; "isSignal": true; }; "menuClass": { "alias": "menuClass"; "required": false; "isSignal": true; }; }, { "actionsOpenChange": "actionsOpenChange"; }, ["titleTpl", "subtitleTpl", "actionsTpl", "headerFilterTpl"], ["*"], true, never>;
}

/**
 * One fact in the side column. Renders a row, not a card: `app-detail-layout`
 * owns the panel frame, which is what makes 1 fact and 16 the same rule.
 */
declare class DetailFactComponent {
    /** Feather icon name. */
    readonly icon: i0.InputSignal<string>;
    /** Feather icon name; kept for parity with sidecard. */
    readonly featherIcon: i0.InputSignal<string>;
    /** Material or custom icon name. */
    readonly matIcon: i0.InputSignal<string>;
    /**
     * A model rather than an input: `app-detail-layout` derives the key and
     * writes it from the parent, which a read-only input would forbid.
     */
    readonly helpKey: i0.ModelSignal<string>;
    /** Custom icon markup, projected as `<ng-template #icon>`. */
    readonly iconTpl: i0.Signal<TemplateRef<unknown>>;
    private readonly host;
    /**
     * The fact's name for the help key: an explicit `name` attribute, else the
     * projected `.card-subtitle` text. Same contract as sidecard.getName().
     */
    getName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailFactComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailFactComponent, "app-detail-fact", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "featherIcon": { "alias": "featherIcon"; "required": false; "isSignal": true; }; "matIcon": { "alias": "matIcon"; "required": false; "isSignal": true; }; "helpKey": { "alias": "helpKey"; "required": false; "isSignal": true; }; }, { "helpKey": "helpKeyChange"; }, ["iconTpl"], ["*"], true, never>;
}

/** A counts panel for the side column. */
declare class DetailAttachedComponent {
    readonly title: i0.InputSignal<string>;
    readonly rows: i0.InputSignal<DetailCountRow[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailAttachedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailAttachedComponent, "app-detail-attached", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** A tinted plate for a condition the reader has to act on. */
declare class DetailCalloutComponent {
    readonly kind: i0.InputSignal<DetailCalloutKind>;
    readonly heading: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailCalloutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailCalloutComponent, "app-detail-callout", never, { "kind": { "alias": "kind"; "required": false; "isSignal": true; }; "heading": { "alias": "heading"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** A lifecycle panel. Omitted entirely by pages whose record has no lifecycle. */
declare class DetailTimelineComponent {
    readonly title: i0.InputSignal<string>;
    readonly events: i0.InputSignal<DetailTimelineEvent[]>;
    readonly actionLabel: i0.InputSignal<string>;
    readonly action: i0.OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailTimelineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailTimelineComponent, "app-detail-timeline", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "events": { "alias": "events"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; }, { "action": "action"; }, never, never, true, never>;
}

/** Marker only, no behaviour: lets app-detail-layout query side content reactively. */
declare class DetailSideContentDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailSideContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DetailSideContentDirective, "app-detail-attached, app-detail-timeline, app-detail-callout, [side-content]", never, {}, {}, never, never, true, never>;
}

/**
 * One layout for every detail page: main and side are both section lists.
 * "Layout 1" and "Layout 2" are side compositions, not separate layouts.
 */
declare class DetailLayoutComponent {
    /** Optional heading for the side panel. Unset invents no label. */
    readonly sidePanelTitle: i0.InputSignal<string>;
    readonly headerWidth: i0.InputSignal<"main" | "full">;
    readonly facts: i0.Signal<readonly DetailFactComponent[]>;
    readonly attached: i0.Signal<readonly DetailAttachedComponent[]>;
    readonly timeline: i0.Signal<readonly DetailTimelineComponent[]>;
    readonly callout: i0.Signal<readonly DetailCalloutComponent[]>;
    readonly sideContent: i0.Signal<readonly DetailSideContentDirective[]>;
    /**
     * A record with nothing for the side must not reserve its column. Both
     * queries are signals, so this stays correct as projected content changes.
     */
    readonly hasSide: i0.Signal<boolean>;
    private readonly host;
    constructor();
    /**
     * `SIDECARD.<Name>.<Label>`, from the host's Name attribute and each fact's
     * label. Drives contextual help and fails silently, so it is tested.
     */
    private assignHelpKeys;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailLayoutComponent, "app-detail-layout", never, { "sidePanelTitle": { "alias": "sidePanelTitle"; "required": false; "isSignal": true; }; "headerWidth": { "alias": "headerWidth"; "required": false; "isSignal": true; }; }, {}, ["facts", "attached", "timeline", "callout", "sideContent"], ["app-detail-header", "scrollable-nav-tab", "*", "app-detail-fact", "app-detail-attached, app-detail-timeline, app-detail-callout, [side-content]"], true, never>;
}

/**
 * A labelled block in the main column. Unframed on purpose: projected content
 * carries its own frame, and nesting the two reads as a card inside a card.
 */
declare class DetailSectionComponent {
    /** Unset renders no heading, so a section can be spacing alone. */
    readonly title: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailSectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailSectionComponent, "app-detail-section", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * One cell of `app-stat-grid`. Twin of mini-card, without the frame: the grid
 * owns it. The .minicard-* size classes are accepted but inert inside a grid.
 */
declare class StatCardComponent {
    readonly iconColor: i0.InputSignal<string>;
    readonly icon: i0.InputSignal<string>;
    readonly featherIcon: i0.InputSignal<string>;
    readonly matIcon: i0.InputSignal<string>;
    readonly hideHelp: i0.InputSignal<boolean>;
    /** Severity dot drawn after the value; null draws nothing. */
    readonly dot: i0.InputSignal<StatDotKind>;
    readonly iconTpl: i0.Signal<TemplateRef<unknown>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatCardComponent, "app-stat-card", never, { "iconColor": { "alias": "iconColor"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "featherIcon": { "alias": "featherIcon"; "required": false; "isSignal": true; }; "matIcon": { "alias": "matIcon"; "required": false; "isSignal": true; }; "hideHelp": { "alias": "hideHelp"; "required": false; "isSignal": true; }; "dot": { "alias": "dot"; "required": false; "isSignal": true; }; }, {}, ["iconTpl"], ["*", "[minicard-detail]"], true, never>;
}

/** The Overview panel. One grid rule, in one place. */
declare class StatGridComponent {
    readonly title: i0.InputSignal<string>;
    /**
     * Theme token filling each card, without the `--`. 'white' reads as the page's own
     * card; 'bg-color' as an inset panel inside a framed one. Any contract token works.
     */
    readonly cardBackground: i0.InputSignal<string>;
    /**
     * Fixed column count, 1-4. Unset (the default) sizes the grid to the number of
     * cards, which is what every page wants until the values are long enough that
     * four across reads worse than two rows of two.
     */
    readonly columnCount: i0.InputSignal<number>;
    readonly cards: i0.Signal<readonly StatCardComponent[]>;
    /** The fallback keeps a card painted if a page names a token that does not exist. */
    readonly cardBackgroundValue: i0.Signal<string>;
    /** A class, not an inline grid-template-columns, which would beat the responsive step-downs. */
    readonly columns: i0.Signal<number>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatGridComponent, "app-stat-grid", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "cardBackground": { "alias": "cardBackground"; "required": false; "isSignal": true; }; "columnCount": { "alias": "columnCount"; "required": false; "isSignal": true; }; }, {}, ["cards"], ["*"], true, never>;
}

/**
 * The page header for a list view: what this collection is, on the left, and
 * whatever the page lets you do with it, on the right.
 *
 * Deliberately not app-detail-header — that one identifies a single record (mark,
 * status badges, a record's Actions menu). A list page names a collection and hangs
 * its own controls off the right, so it gets its own, smaller component.
 */
declare class ListHeaderComponent {
    readonly title: i0.InputSignal<string>;
    /** One line on what the collection is for. Omitted leaves no gap. */
    readonly description: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListHeaderComponent, "app-list-header", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, ["[actions]"], true, never>;
}

/** The row of summary cards above a list. One grid rule, in one place. */
declare class ListStatsComponent {
    /**
     * Theme token filling each card, without the `--`. 'white' is the default and
     * reads as a card on the page ground; 'bg-color' tints them. Same contract as
     * app-stat-grid's input of the same name.
     */
    readonly cardBackground: i0.InputSignal<string>;
    /** The fallback keeps a card painted if a page names a token that does not exist. */
    readonly cardBackgroundValue: i0.Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListStatsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListStatsComponent, "app-list-stats", never, { "cardBackground": { "alias": "cardBackground"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** Severity of a list summary value; colours the number it labels. */
type ListStatTone = 'default' | 'ok' | 'warn' | 'bad';
/**
 * One summary card above a list: a label, the number it counts, and an optional
 * hint spelling that number out. Framed in its own right, unlike the detail page's
 * app-stat-card, which is a cell of a divided panel.
 */
declare class ListStatCardComponent {
    readonly label: i0.InputSignal<string>;
    /** Left unset for a card whose value is projected markup — a badge, say. */
    readonly value: i0.InputSignal<string | number>;
    /** Secondary line under the value: `6 created · 2 imported`. */
    readonly hint: i0.InputSignal<string>;
    readonly tone: i0.InputSignal<ListStatTone>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListStatCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListStatCardComponent, "app-list-stat-card", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** A label/value block for `main`. */
declare class DetailKvComponent {
    readonly title: i0.InputSignal<string>;
    readonly rows: i0.InputSignal<DetailKvRow[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailKvComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailKvComponent, "app-detail-kv", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** An empty section, with exactly one exit. */
declare class DetailEmptyComponent {
    readonly heading: i0.InputSignal<string>;
    readonly message: i0.InputSignal<string>;
    readonly actionLabel: i0.InputSignal<string>;
    readonly action: i0.OutputEmitterRef<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailEmptyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailEmptyComponent, "app-detail-empty", never, { "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; }, { "action": "action"; }, never, never, true, never>;
}

declare class CommonLibComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonLibComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonLibComponentsModule, [typeof SidecardComponent, typeof ViewWithSidecardsComponent, typeof ViewHeaderCardComponent, typeof MiniCardComponent, typeof ScrollableNavTabComponent, typeof ViewJsonComponent, typeof ViewJsonModalComponent, typeof ViewYamlComponent], [typeof i1$2.CommonModule, typeof i1$1.MatIconModule, typeof i3$1.NgbModule, typeof i27.BlockUIModule, typeof RootImportsModule, typeof RestrictElementAccessModule, typeof CodeBlockWithCopyComponent, typeof CopyToClipboardComponent, typeof CoreCommonModule, typeof HelpModule, typeof i3.FormsModule, typeof FlatStatusFilterComponent, typeof FilterPillsComponent, typeof SearchableDatatableModule, typeof ConfirmationModalModule, typeof DetailHeaderComponent, typeof DetailLayoutComponent, typeof DetailSectionComponent, typeof DetailFactComponent, typeof StatGridComponent, typeof StatCardComponent, typeof ListHeaderComponent, typeof ListStatsComponent, typeof ListStatCardComponent, typeof DetailKvComponent, typeof DetailEmptyComponent, typeof DetailAttachedComponent, typeof DetailTimelineComponent, typeof DetailCalloutComponent, typeof DetailSideContentDirective], [typeof i1$2.CommonModule, typeof CoreCommonModule, typeof i1$1.MatIconModule, typeof i3$1.NgbModule, typeof SidecardComponent, typeof ViewWithSidecardsComponent, typeof ViewHeaderCardComponent, typeof MiniCardComponent, typeof CopyToClipboardComponent, typeof ScrollableNavTabComponent, typeof RestrictElementAccessModule, typeof CodeBlockWithCopyComponent, typeof HelpModule, typeof ViewJsonComponent, typeof ViewJsonModalComponent, typeof ViewYamlComponent, typeof FlatStatusFilterComponent, typeof FilterPillsComponent, typeof SearchableDatatableModule, typeof ConfirmationModalModule, typeof i27.BlockUIModule, typeof RootImportsModule, typeof DetailHeaderComponent, typeof DetailLayoutComponent, typeof DetailSectionComponent, typeof DetailFactComponent, typeof StatGridComponent, typeof StatCardComponent, typeof ListHeaderComponent, typeof ListStatsComponent, typeof ListStatCardComponent, typeof DetailKvComponent, typeof DetailEmptyComponent, typeof DetailAttachedComponent, typeof DetailTimelineComponent, typeof DetailCalloutComponent, typeof DetailSideContentDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonLibComponentsModule>;
}

/** Options for a confirmation modal. */
interface ConfirmationModalOptions<T> {
    header: string | TemplateRef<void>;
    message: string | TemplateRef<void>;
    successMessage?: string;
    data?: T;
    showToggleSwitch?: boolean;
    toggleText?: string;
    tooltipText?: string;
    defaultToggleValue?: boolean;
}
/** A reference to a confirmation modal. */
declare class ConfirmationModalRef<T> {
    modal: NgbModalRef;
    component: ConfirmationModalComponent;
    successMessage: string;
    /**
     * Convenience method for handling a common workflow:
     *
     * - create an outer promise for the entire operation
     * - wait for the user to confirm
     * - run an action on confirmation
     *   - if it fails, report an error, and reject the promise
     *   - if it succeeds, report the success, and
     *
     * @param onconfirm   a confirmation handler that returns an "inner" promise to perform some action
     * @param fail        optional: the ErrorReporter to use for reporting an error
     * @param succeed     optional: the SuccessReporter to use for reporting success
     * @returns a promise that can be used to perform follow-up actions, on failure or success.
     */
    actIfConfirmed(onconfirm: (data: T, toggleValue: boolean) => Promise<any>, fail?: ErrorReporter, succeed?: SuccessReporter, blockUI?: NgBlockUI, blockMessage?: string, customSuccessMessage?: string, customErrorMessage?: string): Promise<T>;
}
declare class ConfirmationModalService {
    private _modals;
    constructor(_modals: NgbModal);
    open<T>(options: ConfirmationModalOptions<T>): ConfirmationModalRef<T>;
    openGeneric<T>(action: string, entityType: string, entityIdentifier: any, onconfirm: (data: T) => Promise<any>, blockUI?: NgBlockUI, customSuccessMessage?: string, customErrorMessage?: string): Promise<any>;
    openWithMessage<T>(header: string, message: string, successMessage: any, onconfirm: (data: T) => Promise<any>, blockUI?: NgBlockUI): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfirmationModalService>;
}

/** Options for a confirmation modal. */
interface DeleteConfirmationModalOptions<T> {
    header: string | TemplateRef<void>;
    message: string | TemplateRef<void>;
    entityType?: string;
    successMessage?: string;
    data?: T;
    showToggleSwitch?: boolean;
    toggleText?: string;
    tooltipText?: string;
    defaultToggleValue?: boolean;
    confirmationText?: string;
}
/** A reference to a confirmation modal. */
declare class DeleteConfirmationModalRef<T> {
    modal: NgbModalRef;
    component: DeleteConfirmationModalComponent;
    successMessage: string;
    /**
     * Convenience method for handling a common workflow:
     *
     * - create an outer promise for the entire operation
     * - wait for the user to confirm
     * - run an action on confirmation
     *   - if it fails, report an error, and reject the promise
     *   - if it succeeds, report the success, and
     *
     * @param onconfirm   a confirmation handler that returns an "inner" promise to perform some action
     * @param fail        optional: the ErrorReporter to use for reporting an error
     * @param succeed     optional: the SuccessReporter to use for reporting success
     * @returns a promise that can be used to perform follow-up actions, on failure or success.
     */
    actIfConfirmed(onconfirm: (data: T, toggleValue: boolean) => Promise<any>, fail?: ErrorReporter, succeed?: SuccessReporter, blockUI?: NgBlockUI, blockMessage?: string, customSuccessMessage?: string, customErrorMessage?: string): Promise<T>;
}
declare class DeleteConfirmationModalService {
    private _modals;
    constructor(_modals: NgbModal);
    open<T>(options: DeleteConfirmationModalOptions<T>): DeleteConfirmationModalRef<T>;
    openGeneric<T>(entityType: string, entityIdentifier: string, onconfirm: (data: T) => Promise<any>, blockUI?: NgBlockUI, action?: string, customSuccessMessage?: string, customErrorMessage?: string): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteConfirmationModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DeleteConfirmationModalService>;
}

declare class DiffMergeComponent implements OnChanges, OnDestroy {
    private zone;
    currentContent: string;
    incomingContent: string;
    currentFileName: string;
    incomingFileName: string;
    language: string;
    title: string;
    resolved: EventEmitter<string>;
    editorContainer: ElementRef;
    totalConflicts: number;
    resolvedConflicts: number;
    get noChanges(): boolean;
    private editor;
    private conflicts;
    private conflictMap;
    private decorationIds;
    private viewZoneIds;
    private resizeObserver;
    private rafId;
    private originalTotalConflicts;
    private monacoSub;
    constructor(zone: NgZone);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private initEditor;
    private updateEditorContent;
    private createEditor;
    private buildConflictMarkedContent;
    private wrapConflict;
    private scanConflicts;
    private applyDecorations;
    private applyViewZones;
    private createActionBar;
    resolveConflict(conflictId: number, resolution: 'current' | 'incoming' | 'both'): void;
    applyResult(): void;
    copyResult(): void;
    acceptAllCurrent(): void;
    acceptAllIncoming(): void;
    private resolveAllConflicts;
    private setupResizeObserver;
    static ɵfac: i0.ɵɵFactoryDeclaration<DiffMergeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DiffMergeComponent, "app-diff-merge", never, { "currentContent": { "alias": "currentContent"; "required": false; }; "incomingContent": { "alias": "incomingContent"; "required": false; }; "currentFileName": { "alias": "currentFileName"; "required": false; }; "incomingFileName": { "alias": "incomingFileName"; "required": false; }; "language": { "alias": "language"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, { "resolved": "resolved"; }, never, never, true, never>;
}

/**
 * Service to dynamically load CSS stylesheets on demand.
 * This enables lazy loading of third-party CSS (like xterm, diff2html)
 * only when the components that need them are actually used.
 */
declare class DynamicStyleLoaderService {
    private loadedStyles;
    /**
     * Loads a CSS file dynamically by injecting a <link> element into the <head>.
     * If the stylesheet is already loaded, it will not be loaded again.
     *
     * @param href - The URL or path to the CSS file
     * @returns Promise that resolves when the stylesheet is loaded
     */
    loadStyle(href: string): Promise<void>;
    /**
     * Checks if a stylesheet has already been loaded
     */
    isLoaded(href: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicStyleLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DynamicStyleLoaderService>;
}

declare class DiffRenderComponent implements OnInit, OnChanges {
    private styleLoader;
    title: string;
    oldString: string;
    newString: string;
    containerClass: string;
    currentFileName: string;
    incomingFileName: string;
    diffConfig: Diff2HtmlConfig;
    showFull: boolean;
    diffHtml: string;
    constructor(styleLoader: DynamicStyleLoaderService);
    ngOnInit(): void;
    ngOnChanges(): void;
    generateDiff(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DiffRenderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DiffRenderComponent, "app-diff-render", never, { "title": { "alias": "title"; "required": false; }; "oldString": { "alias": "oldString"; "required": false; }; "newString": { "alias": "newString"; "required": false; }; "containerClass": { "alias": "containerClass"; "required": false; }; "currentFileName": { "alias": "currentFileName"; "required": false; }; "incomingFileName": { "alias": "incomingFileName"; "required": false; }; "diffConfig": { "alias": "diffConfig"; "required": false; }; "showFull": { "alias": "showFull"; "required": false; }; }, {}, never, never, true, never>;
}

/** How a card renders its 2.25rem mark. Exactly one field should be set. */
interface ListCardMark {
    initial?: string;
    svgIcon?: string;
    feather?: string;
}
/** One entry in a card's overflow menu. */
interface ListCardAction {
    label: string;
    icon: string;
    handler: () => void;
    disabled?: boolean;
    hidden?: boolean;
}
/** First usable character of a name, for a card's letter tile. */
declare function listCardInitial(name: string): string;
/** Up to `max` word initials, for the avatar stack in a card footer. */
declare function listCardInitials(name: string, max?: number): string;
interface BadgeOverflow<T> {
    shown: T[];
    overflow: number;
}
/**
 * Caps a projected badge row to a character budget, so a record with nine
 * badges is the same card height as one with two. Always keeps one badge.
 */
declare function capBadges<T>(items: T[], label: (item: T) => string, budget?: number): BadgeOverflow<T>;

/**
 * How a row renders its mark. Extends ListCardMark — the same initial/svgIcon/
 * feather contract common-lib already defines — with the tone this list picks
 * per record.
 */
interface ExpandableListMark extends ListCardMark {
    /**
     * Which themed colour the tile takes. Omit to let the list pick one
     * deterministically from the title, so a given record keeps its colour
     * across reloads without anyone storing it.
     */
    tone?: ExpandableListTone;
}
/**
 * The tile palette. Every entry maps to a theme var, so a deployment on the
 * blue or red bundle recolours with everything else — which a stored hex
 * per record could not.
 */
type ExpandableListTone = 'primary' | 'info' | 'success' | 'warning' | 'secondary' | 'danger';
declare const EXPANDABLE_LIST_TONES: ExpandableListTone[];
/**
 * A stable tone for a title. Not crypto — it only has to be well spread and
 * repeatable, so the same record keeps its colour between visits.
 */
declare function expandableListTone(name: string): ExpandableListTone;
/** Context handed to every row, mark, detail and actions template. */
interface ExpandableListContext<T = any> {
    $implicit: T;
    item: T;
    expanded: boolean;
    index: number;
}
/** One rendered row. Every display value is resolved here, never in a binding. */
interface ExpandableListRow<T = any> {
    id: string;
    item: T;
    title: string;
    description: string;
    mark: ExpandableListMark;
    /** Resolved here so the template binds a class, never a method call. */
    markClass: string;
    expanded: boolean;
    /** Target of the head button's aria-controls. */
    detailId: string;
    context: ExpandableListContext<T>;
}

/**
 * A searchable list whose rows expand in place.
 *
 * The component owns the chrome — the search bar, the rows, the chevron, the
 * expand/collapse state and the empty state. Everything inside a row is the
 * caller's, supplied as templates:
 *
 *   #elRow      the collapsed row's main content   (falls back to mark/title/description)
 *   #elMark     the tile at the left of a row      (falls back to a toned initial)
 *   #elDetail   what the row reveals when expanded
 *   #elActions  the controls at the right of a row
 *   #elToolbar  the controls at the right of the search bar
 *
 * Every template gets `{ $implicit: item, item, expanded, index }`.
 *
 *   <app-expandable-list [items]="rows" [searchFields]="['name', 'description']"
 *                        searchPlaceholder="Search personas">
 *     <ng-template #elToolbar><button …>Add persona</button></ng-template>
 *     <ng-template #elDetail let-item>…</ng-template>
 *   </app-expandable-list>
 *
 * Search is caller-declared rather than "every field": a persona's skillIds and
 * metaData would otherwise match on ids nobody can see, which reads as the box
 * being broken.
 */
declare class ExpandableListComponent<T extends Record<string, any> = any> {
    /** Distinguishes this list's generated element ids from another on the same page. */
    private static instances;
    private readonly uid;
    readonly items: i0.InputSignal<T[]>;
    /** Dot paths are supported, so 'spec.region' works as well as 'name'. */
    readonly searchFields: i0.InputSignal<string[]>;
    readonly searchPlaceholder: i0.InputSignal<string>;
    readonly showSearch: i0.InputSignal<boolean>;
    /** Identity for expand state and @for tracking. */
    readonly idKey: i0.InputSignal<string>;
    /** Default-row rendering, used only when no #elRow template is projected. */
    readonly titleKey: i0.InputSignal<string>;
    readonly descriptionKey: i0.InputSignal<string>;
    readonly emptyMessage: i0.InputSignal<string>;
    readonly noMatchMessage: i0.InputSignal<string>;
    readonly loading: i0.InputSignal<boolean>;
    /** Off by default: one open row at a time keeps the list scannable. */
    readonly multiExpand: i0.InputSignal<boolean>;
    readonly expandedChange: i0.OutputEmitterRef<string[]>;
    readonly searchChange: i0.OutputEmitterRef<string>;
    readonly rowTemplate: i0.Signal<TemplateRef<ExpandableListContext<T>>>;
    readonly detailTemplate: i0.Signal<TemplateRef<ExpandableListContext<T>>>;
    readonly actionsTemplate: i0.Signal<TemplateRef<ExpandableListContext<T>>>;
    readonly markTemplate: i0.Signal<TemplateRef<ExpandableListContext<T>>>;
    readonly toolbarTemplate: i0.Signal<TemplateRef<void>>;
    readonly term: i0.WritableSignal<string>;
    private readonly expandedIds;
    /**
     * The rendered rows, with every display value already resolved. Bindings
     * read plain fields off these — the repo forbids calling a method from a
     * template, and a context object rebuilt per pass would also make
     * ngTemplateOutlet re-apply it on every check.
     */
    readonly rows: i0.Signal<ExpandableListRow<T>[]>;
    readonly isFiltered: i0.Signal<boolean>;
    /**
     * Ids resolved over the full list, once. Items whose idKey is absent fall
     * back to their position — @for throws NG0955 the moment two rows track to
     * the same key, and every item resolving to '' is the easy way to get there.
     */
    private readonly keyed;
    /** Split from rows() so typing does not rebuild the view models of unmatched items. */
    private readonly matches;
    onSearch(value: string): void;
    /**
     * The whole row is a click target for convenience. Anything interactive
     * between the click and the row owns its own click instead — the chevron,
     * and whatever the caller projects into a slot.
     *
     * The ancestry comes from composedPath(), which the browser captures when
     * the event is dispatched, rather than from event.target. A handler earlier
     * in the bubble can detach the clicked node before this one runs: the
     * feather directive replaces the chevron's <svg> wholesale on the change
     * detection that follows the chevron's own click. closest() on the detached
     * node then walks an orphaned tree, misses the button, and toggles the row a
     * second time — which read as the arrow not working at all.
     */
    onRowClick(event: MouseEvent, id: string): void;
    toggle(id: string): void;
    private idOf;
    /** The mark a row shows when the caller projects no #elMark template. */
    private markOf;
    private textAt;
    /** Reads 'a.b.c' as well as 'a'. */
    private read;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpandableListComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpandableListComponent<any>, "app-expandable-list", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "searchFields": { "alias": "searchFields"; "required": false; "isSignal": true; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; "isSignal": true; }; "showSearch": { "alias": "showSearch"; "required": false; "isSignal": true; }; "idKey": { "alias": "idKey"; "required": false; "isSignal": true; }; "titleKey": { "alias": "titleKey"; "required": false; "isSignal": true; }; "descriptionKey": { "alias": "descriptionKey"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "noMatchMessage": { "alias": "noMatchMessage"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "multiExpand": { "alias": "multiExpand"; "required": false; "isSignal": true; }; }, { "expandedChange": "expandedChange"; "searchChange": "searchChange"; }, ["rowTemplate", "detailTemplate", "actionsTemplate", "markTemplate", "toolbarTemplate"], never, true, never>;
}

type FileNodeType = 'file' | 'directory';
interface FileNode {
    name: string;
    path: string;
    type: FileNodeType;
    content?: string;
    children?: FileNode[];
    loaded?: boolean;
    loading?: boolean;
    loadError?: boolean;
    isExpanded?: boolean;
    size?: number;
    lastModified?: string;
    readOnly?: boolean;
}
type FileTreeActionTheme = 'primary' | 'secondary' | 'success' | 'info' | 'warning' | 'danger' | 'dark';
interface FileTreeAction {
    /** Stable identifier the parent matches on in the event handler. */
    type: string;
    /** Human-readable label shown in the menu. */
    title: string;
    /** Feather icon name. */
    icon: string;
    /** Visual theme. Maps to Bootstrap `text-{theme}`. Defaults to 'secondary'. */
    theme?: FileTreeActionTheme;
    /** Optional predicate — return false to hide for this node. */
    when?: (node: FileNode) => boolean;
    /** Optional predicate — return true to disable the item. */
    disabled?: (node: FileNode) => boolean;
    /** Tooltip shown when `disabled` returns true. */
    disabledTooltip?: string;
    /** Render a divider above this item. */
    divider?: boolean;
}
interface FileTreeActionEvent {
    actionType: string;
    node: FileNode;
}
interface FileEditorContentChange {
    path: string;
    content: string;
}
interface FileEditorSaveEvent {
    path: string;
    content: string;
}
type FileContentLoader = (node: FileNode) => Observable<string>;
type FileBinaryLoader = (node: FileNode) => Observable<Blob>;
type FolderLoader = (node: FileNode) => Observable<FileNode[]>;
type FileRenderKind = 'text' | 'image' | 'pdf' | 'office' | 'unsupported';
declare function getFileRenderKind(name: string): FileRenderKind;
type FileLangId = 'typescript' | 'javascript' | 'json' | 'yaml' | 'markdown' | 'python' | 'hcl' | 'html' | 'css' | 'plaintext';
declare const FILE_LANG_MAP: Record<string, FileLangId>;
interface FileBadge {
    label: string;
    bg: string;
    darkText?: boolean;
}
declare const FILE_BADGE_MAP: Record<FileLangId, FileBadge>;
declare const DEFAULT_FILE_BADGE: FileBadge;
declare const FOLDER_COLOR = "var(--warning)";
declare const EXT_BADGE_MAP: Record<string, FileBadge>;
declare function getExt(name: string): string;
declare function getFileLang(name: string): FileLangId;

/** Minimal editor surface the animator drives. Implemented by CodeEditorComponent. */
interface IDocumentEditor {
    getContent(): string;
    setContent(content: string): void;
    insertTextAt(offset: number, text: string): void;
    deleteTextRange(from: number, to: number): void;
}
declare enum DocDiffOpType {
    Equal = "equal",
    Insert = "insert",
    Delete = "delete"
}
interface DocDiffOp {
    type: DocDiffOpType;
    text: string;
}
declare function getDiffOps(oldContent: string, newContent: string): DocDiffOp[];
declare class AnimationService {
    private animating;
    private abortController;
    private animationPromise;
    get isAnimating(): boolean;
    cancelAnimation(): void;
    applyContent(editor: IDocumentEditor, newContent: string): Promise<void>;
    private animateOps;
    private splitIntoLines;
    private countChangedLines;
    private getAdaptiveDelay;
    private sleep;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnimationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnimationService>;
}

declare class CodeEditorComponent implements AfterViewInit, OnChanges, OnDestroy, IDocumentEditor {
    private animation;
    editorHost: ElementRef<HTMLDivElement>;
    content: string;
    language: FileLangId;
    readOnly: boolean;
    theme: 'light' | 'dark';
    lineWrap: boolean;
    contentChange: EventEmitter<FileEditorContentChange>;
    saveRequest: EventEmitter<void>;
    private view;
    private langCompartment;
    private editableCompartment;
    private themeCompartment;
    private suppressEmit;
    private currentLangExt;
    private currentPath;
    constructor(animation: AnimationService);
    ngAfterViewInit(): void;
    private _buildState;
    ngOnChanges(changes: SimpleChanges): void;
    getContent(): string;
    setContent(content: string): void;
    /** Animated content replacement (diff-driven typing). Suppresses change events. */
    applyContent(content: string): Promise<void>;
    insertTextAt(offset: number, text: string): void;
    deleteTextRange(from: number, to: number): void;
    focus(): void;
    /** Called by wrapper so emitted events carry the active file path. */
    setPath(path: string): void;
    ngOnDestroy(): void;
    private _applyLang;
    static ɵfac: i0.ɵɵFactoryDeclaration<CodeEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CodeEditorComponent, "app-code-editor", never, { "content": { "alias": "content"; "required": false; }; "language": { "alias": "language"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "lineWrap": { "alias": "lineWrap"; "required": false; }; }, { "contentChange": "contentChange"; "saveRequest": "saveRequest"; }, never, never, true, never>;
}

interface FileEditorConfigOpts {
    tree: FileNode[];
    contentLoader?: FileContentLoader;
    binaryLoader?: FileBinaryLoader;
    folderLoader?: FolderLoader;
    readOnly?: boolean;
    initialPath?: string | null;
    autoOpenFirst?: boolean;
    /**
     * When set, file-row clicks delegate to this handler instead of pushing to
     * openPaths$. Lets a host (e.g. the manage-ticket tree tab) route opens into
     * its own canvas-block flow instead of the in-place tab strip.
     */
    openFileHandler?: (path: string) => void;
}
declare class FileEditorService implements OnDestroy {
    readonly tree$: BehaviorSubject<FileNode[]>;
    readonly openPaths$: BehaviorSubject<string[]>;
    readonly activePath$: BehaviorSubject<string>;
    readonly dirtyPaths$: BehaviorSubject<Set<string>>;
    readonly treeCollapsed$: BehaviorSubject<boolean>;
    readonly loadingPath$: BehaviorSubject<string>;
    readonly savingPath$: BehaviorSubject<string>;
    readonly save$: Subject<FileEditorSaveEvent>;
    readonly contentChange$: Subject<FileEditorContentChange>;
    private originalByPath;
    private currentByPath;
    private nodeByPath;
    private binaryUrlByPath;
    private recentStack;
    private readOnly;
    private contentLoader?;
    private binaryLoader?;
    private folderLoader?;
    private openFileHandler?;
    readonly binaryUrlsTick$: BehaviorSubject<number>;
    configure(opts: FileEditorConfigOpts): void;
    openFile(path: string): void;
    selectTab(path: string): void;
    setActive(path: string): void;
    closeTab(path: string): void;
    toggleTree(): void;
    updateContent(path: string, content: string): void;
    save(path: string): void;
    markSaving(path: string): void;
    clearSaving(): void;
    isSaving(path: string | null): boolean;
    cancel(path: string): void;
    expandFolder(path: string): void;
    getContent(path: string): string;
    isDirty(path: string): boolean;
    getNode(path: string): FileNode | undefined;
    getRenderKind(path: string | null): FileRenderKind;
    getBinaryUrl(path: string | null): string | null;
    ngOnDestroy(): void;
    reset(): void;
    private _revokeAllBinaryUrls;
    private _revokeBinaryUrl;
    /** Selects the next active tab after `closedPath` is removed from `open`. */
    _pickNextActive(closedPath: string, open: string[]): string | null;
    /**
     * Drops the cached content for `path` and re-triggers the content loader.
     * Clears any dirty state. Used by the Refresh toolbar action.
     */
    refreshContent(path: string): void;
    private _ensureContent;
    private _seedContent;
    private _indexTree;
    private _firstFile;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileEditorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileEditorService>;
}

interface TabCloseRequest {
    path: string;
    isDirty: boolean;
}
declare class FileTabsComponent {
    closeRequest: EventEmitter<TabCloseRequest>;
    readonly service: FileEditorService;
    readonly vm$: rxjs.Observable<{
        openPaths: string[];
        activePath: string;
        dirtyPaths: Set<string>;
    }>;
    basename(path: string): string;
    onTabClick(path: string): void;
    onCloseClick(event: MouseEvent, path: string, isDirty: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileTabsComponent, "app-file-tabs", never, {}, { "closeRequest": "closeRequest"; }, never, never, true, never>;
}

interface EntityFileEntry {
    name: string;
    relativePath: string;
    isDirectory: boolean;
    lastModified?: string;
    size?: number;
}
/** Structural contract for entity file services — no ai-studio compile-time dependency. */
interface EntityFilesContract {
    listFiles(entityId: string, relativePath?: string): Observable<EntityFileEntry[]>;
    downloadFile(entityId: string, filePath: string): Observable<Blob>;
    uploadFile(entityId: string, filePath: string, file: File): Observable<void>;
    createFolder(entityId: string, folderPath: string): Observable<void>;
    deleteFile(entityId: string, filePath: string): Observable<void>;
}

declare class EntityFileEditorWrapperComponent implements OnChanges, OnInit, OnDestroy {
    private successReporter;
    private errorReporter;
    service: EntityFilesContract;
    entityId: string;
    entityName: string;
    basePath: string;
    readOnly: boolean;
    theme: 'light' | 'dark';
    treeMinWidth: number;
    treeMaxWidth: number;
    fileActions: FileTreeAction[];
    folderActions: FileTreeAction[];
    save: EventEmitter<FileEditorSaveEvent>;
    contentChange: EventEmitter<FileEditorContentChange>;
    fileAction: EventEmitter<FileTreeActionEvent>;
    folderAction: EventEmitter<FileTreeActionEvent>;
    private editor?;
    blockUI: NgBlockUI;
    readonly editorService: FileEditorService;
    private readonly destroy$;
    private readonly confirmSvc;
    private readonly clipboard;
    private readonly hostEl;
    private readonly sanitizer;
    copySuccess: boolean;
    downloadSuccess: boolean;
    private copyResetTimer?;
    private downloadResetTimer?;
    treeWidth: number;
    isResizingTree: boolean;
    private lastTreeX;
    constructor(successReporter: SuccessReporter | null, errorReporter: ErrorReporter | null);
    isRootLoading: boolean;
    rootError: string | null;
    readonly activePath$: rxjs.BehaviorSubject<string>;
    readonly treeCollapsed$: rxjs.BehaviorSubject<boolean>;
    readonly savingPath$: rxjs.BehaviorSubject<string>;
    readonly vm$: rxjs.Observable<{
        activePath: string;
        kind: FileRenderKind;
        isDirty: boolean;
        isSaving: boolean;
        content: string;
        lang: FileLangId;
        imageUrl: string;
        pdfUrl: SafeResourceUrl;
    }>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    startTreeResize(event: MouseEvent): void;
    onMouseMove(event: MouseEvent): void;
    stopResize(): void;
    ngOnChanges(changes: SimpleChanges): void;
    loadRoot(): void;
    onCloseRequest({ path, isDirty }: TabCloseRequest): void;
    onSaveActive(): void;
    onCancelActive(): void;
    onCloseActive(): void;
    onCopyContent(): void;
    onDownloadActive(): void;
    onRefreshActive(): void;
    onEditorContentChange(event: FileEditorContentChange): void;
    private _langFor;
    isDirty(path: string | null): boolean;
    _mapEntriesToFileNodes(entries: EntityFileEntry[], parentQueryPath: string): FileNode[];
    refreshTree(): void;
    refreshFolder(path: string): void;
    private _buildFolderLoader;
    private _buildContentLoader;
    private _buildBinaryLoader;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntityFileEditorWrapperComponent, [{ optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntityFileEditorWrapperComponent, "app-entity-file-editor-wrapper", never, { "service": { "alias": "service"; "required": false; }; "entityId": { "alias": "entityId"; "required": false; }; "entityName": { "alias": "entityName"; "required": false; }; "basePath": { "alias": "basePath"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "treeMinWidth": { "alias": "treeMinWidth"; "required": false; }; "treeMaxWidth": { "alias": "treeMaxWidth"; "required": false; }; "fileActions": { "alias": "fileActions"; "required": false; }; "folderActions": { "alias": "folderActions"; "required": false; }; }, { "save": "save"; "contentChange": "contentChange"; "fileAction": "fileAction"; "folderAction": "folderAction"; }, never, never, true, never>;
}

declare class FileDetailsModalComponent {
    activeModal: NgbActiveModal;
    node: FileNode;
    isReport: boolean;
    reportCategory: string;
    formatSize?: (n?: number) => string;
    constructor(activeModal: NgbActiveModal);
    get isFile(): boolean;
    get typeLabel(): string;
    get sizeText(): string;
    private _defaultFormatSize;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileDetailsModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileDetailsModalComponent, "app-file-details-modal", never, { "node": { "alias": "node"; "required": false; }; "isReport": { "alias": "isReport"; "required": false; }; "reportCategory": { "alias": "reportCategory"; "required": false; }; "formatSize": { "alias": "formatSize"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FileEditorWrapperComponent implements OnChanges, OnInit, OnDestroy {
    tree: FileNode[];
    contentLoader?: FileContentLoader;
    readOnly: boolean;
    theme: 'light' | 'dark';
    initialPath?: string | null;
    treeMinWidth: number;
    treeMaxWidth: number;
    fileActions: FileTreeAction[];
    folderActions: FileTreeAction[];
    save: EventEmitter<FileEditorSaveEvent>;
    contentChange: EventEmitter<FileEditorContentChange>;
    fileAction: EventEmitter<FileTreeActionEvent>;
    folderAction: EventEmitter<FileTreeActionEvent>;
    private editor?;
    readonly service: FileEditorService;
    private readonly destroy$;
    private readonly confirmSvc;
    private readonly hostEl;
    treeWidth: number;
    isResizingTree: boolean;
    private lastTreeX;
    readonly activePath$: rxjs.BehaviorSubject<string>;
    readonly treeCollapsed$: rxjs.BehaviorSubject<boolean>;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    startTreeResize(event: MouseEvent): void;
    onMouseMove(event: MouseEvent): void;
    stopResize(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onCloseRequest({ path, isDirty }: TabCloseRequest): void;
    onSaveActive(): void;
    onCancelActive(): void;
    onCloseActive(): void;
    onEditorContentChange(event: FileEditorContentChange): void;
    langFor(path: string | null): FileLangId;
    contentFor(path: string | null): string;
    isDirty(path: string | null): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileEditorWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileEditorWrapperComponent, "app-file-editor-wrapper", never, { "tree": { "alias": "tree"; "required": false; }; "contentLoader": { "alias": "contentLoader"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "initialPath": { "alias": "initialPath"; "required": false; }; "treeMinWidth": { "alias": "treeMinWidth"; "required": false; }; "treeMaxWidth": { "alias": "treeMaxWidth"; "required": false; }; "fileActions": { "alias": "fileActions"; "required": false; }; "folderActions": { "alias": "folderActions"; "required": false; }; }, { "save": "save"; "contentChange": "contentChange"; "fileAction": "fileAction"; "folderAction": "folderAction"; }, never, never, true, never>;
}

declare class FileIconComponent implements OnChanges {
    name: string;
    type: FileNodeType;
    expanded: boolean;
    badge: FileBadge;
    darkText: boolean;
    ngOnChanges(): void;
    private _needsDarkText;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileIconComponent, "app-file-icon", never, { "name": { "alias": "name"; "required": false; }; "type": { "alias": "type"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FileTreeNodeComponent implements OnChanges {
    node: FileNode;
    depth: number;
    activePath: string | null;
    dirtyPaths: Set<string>;
    service: FileEditorService;
    fileActions: FileTreeAction[];
    folderActions: FileTreeAction[];
    fileAction: EventEmitter<FileTreeActionEvent>;
    folderAction: EventEmitter<FileTreeActionEvent>;
    /** Whether the node exposes any action — drives the kebab *ngIf. Recomputed on input change. */
    hasActions: boolean;
    /** Action view-model rendered in the open menu. Recomputed only when the dropdown opens,
     *  so dynamic predicates (e.g. add/remove-report) stay correct without per-CD work. */
    menuItems: {
        action: FileTreeAction;
        disabled: boolean;
        tooltip: string | null;
    }[];
    ngOnChanges(changes: SimpleChanges): void;
    onNodeClick(): void;
    onMenuOpen(open: boolean): void;
    private _actionsFor;
    emitAction(type: string, node: FileNode): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileTreeNodeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileTreeNodeComponent, "app-file-tree-node", never, { "node": { "alias": "node"; "required": false; }; "depth": { "alias": "depth"; "required": false; }; "activePath": { "alias": "activePath"; "required": false; }; "dirtyPaths": { "alias": "dirtyPaths"; "required": false; }; "service": { "alias": "service"; "required": false; }; "fileActions": { "alias": "fileActions"; "required": false; }; "folderActions": { "alias": "folderActions"; "required": false; }; }, { "fileAction": "fileAction"; "folderAction": "folderAction"; }, never, never, true, never>;
}

declare class FileTreeComponent implements OnInit, OnChanges {
    readonly service: FileEditorService;
    basePath: string;
    fileActions: FileTreeAction[];
    folderActions: FileTreeAction[];
    fileAction: EventEmitter<FileTreeActionEvent>;
    folderAction: EventEmitter<FileTreeActionEvent>;
    /** Emitted by the header "Hide" button. Hosts may use it to collapse their pane. */
    collapse: EventEmitter<void>;
    rootNode: FileNode;
    /** Whether the root row shows any action — drives the root-row *ngIf. Root actions are static. */
    hasRootActions: boolean;
    /** Root action view-model. Computed once (root node is static), refreshed if inputs change. */
    rootMenuItems: {
        action: FileTreeAction;
        disabled: boolean;
    }[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private _computeRootActions;
    readonly vm$: rxjs.Observable<{
        tree: FileNode[];
        activePath: string;
        dirtyPaths: Set<string>;
    }>;
    emitRootAction(type: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileTreeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileTreeComponent, "app-file-tree", never, { "basePath": { "alias": "basePath"; "required": false; }; "fileActions": { "alias": "fileActions"; "required": false; }; "folderActions": { "alias": "folderActions"; "required": false; }; }, { "fileAction": "fileAction"; "folderAction": "folderAction"; "collapse": "collapse"; }, never, never, true, never>;
}

declare class FlatDropdownFilter {
    constructor(properties?: Partial<FlatDropdownFilter>);
    name: string;
    label: string;
    count?: number;
    hideWhenZero?: boolean;
    badgeClass?: string;
    group?: string;
    disabled?: boolean;
}
declare class FlatDropdownFilterComponent implements OnChanges {
    activeOption: string;
    options: FlatDropdownFilter[];
    showIfNoOptions?: boolean;
    placeholder?: string;
    showCount?: boolean;
    showGroup?: boolean;
    hideAll?: boolean;
    showAllOption?: boolean;
    activeOptionChange: EventEmitter<any>;
    activeGroupChange: EventEmitter<any>;
    ngOnChanges(changes: SimpleChanges): void;
    optionSelectionHandler(name?: string, grpName?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FlatDropdownFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlatDropdownFilterComponent, "app-flat-dropdown-filter", never, { "activeOption": { "alias": "activeOption"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showIfNoOptions": { "alias": "showIfNoOptions"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "showCount": { "alias": "showCount"; "required": false; }; "showGroup": { "alias": "showGroup"; "required": false; }; "hideAll": { "alias": "hideAll"; "required": false; }; "showAllOption": { "alias": "showAllOption"; "required": false; }; }, { "activeOptionChange": "activeOptionChange"; "activeGroupChange": "activeGroupChange"; }, never, never, true, never>;
}

declare class NgbTimeNativeDateAdapter extends NgbTimeAdapter<Date> {
    fromModel(value: Date | null): NgbTimeStruct | null;
    toModel(time: NgbTimeStruct | null): Date | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgbTimeNativeDateAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NgbTimeNativeDateAdapter>;
}

/**
 * Validates that a control's value is valid YAML that parses to the expected top-level kind
 * (`'array'` or `'object'`), allowing ANY element/property types. YAML is a superset of JSON,
 * so JSON flow syntax (`[1,2,3]`, `{"a":1}`) is accepted too.
 *
 * Attaches an inline error message so it renders without an i18n entry.
 *
 * Usage: `<ngx-monaco-editor yamlValue="array" ...>` or `yamlValue="object"`.
 */
declare class YamlValueValidationDirective implements Validator {
    /** `'array'` = list only, `'object'` = map only, `'json'` = either (any structured value). */
    kind: 'array' | 'object' | 'json';
    validate(control: AbstractControl): ValidationErrors | null;
    private error;
    static ɵfac: i0.ɵɵFactoryDeclaration<YamlValueValidationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<YamlValueValidationDirective, "[yamlValue]", never, { "kind": { "alias": "yamlValue"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TableHelpDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<TableHelpDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TableHelpDirective, "[appTableHelp]", never, {}, {}, never, never, false, never>;
}

/**
 * The card grid for AI Admin list pages. One auto-fill rule serves every
 * breakpoint, so pages carry no grid CSS of their own.
 */
declare class ListCardGridComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ListCardGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListCardGridComponent, "app-list-card-grid", never, {}, {}, never, ["*"], true, never>;
}

/**
 * One card in an AI Admin list. The frame is fixed; each page projects its own
 * metadata into the [card-badges] and [card-footer] slots.
 */
declare class ListCardComponent {
    private readonly router;
    private readonly route;
    mark: i0.InputSignal<ListCardMark>;
    title: i0.InputSignal<string>;
    description: i0.InputSignal<string>;
    emptyDescription: i0.InputSignal<string>;
    link: i0.InputSignal<string | any[]>;
    actions: i0.InputSignal<ListCardAction[]>;
    /** computed() caches and only recomputes when actions() changes — the modern answer to the old filtering setter. */
    visibleActions: i0.Signal<ListCardAction[]>;
    /**
     * The whole card is the click target. The title is also a real anchor, which
     * is what makes it keyboard-reachable — routerLink on a host is not.
     */
    onCardClick(event?: MouseEvent): void;
    runAction(action: ListCardAction, event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListCardComponent, "app-list-card", never, { "mark": { "alias": "mark"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "emptyDescription": { "alias": "emptyDescription"; "required": false; "isSignal": true; }; "link": { "alias": "link"; "required": false; "isSignal": true; }; "actions": { "alias": "actions"; "required": false; "isSignal": true; }; }, {}, never, ["[card-badges]", "[card-footer]"], true, never>;
}

/**
 * Record count and primary action for an AI Admin list page. Deliberately has no
 * heading: the shell header's current breadcrumb crumb is the page title.
 */
declare class ListPageHeaderComponent {
    /** Plural noun for the records, e.g. 'workspaces'. */
    noun: i0.InputSignal<string>;
    total: i0.InputSignal<number>;
    shown: i0.InputSignal<number>;
    filtering: i0.InputSignal<boolean>;
    clearAll: i0.OutputEmitterRef<void>;
    count: i0.Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListPageHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListPageHeaderComponent, "app-list-page-header", never, { "noun": { "alias": "noun"; "required": false; "isSignal": true; }; "total": { "alias": "total"; "required": false; "isSignal": true; }; "shown": { "alias": "shown"; "required": false; "isSignal": true; }; "filtering": { "alias": "filtering"; "required": false; "isSignal": true; }; }, { "clearAll": "clearAll"; }, never, ["[header-actions]"], true, never>;
}

type EditMode = 'edit' | 'preview';
declare class MarkdownEditModalComponent implements AfterViewInit, OnDestroy {
    activeModal: NgbActiveModal;
    editorContainer: ElementRef;
    title: string;
    content: string;
    isEditable: boolean;
    fullScreen: boolean;
    saved: EventEmitter<string>;
    activeMode: EditMode;
    previewContent: string;
    private view;
    constructor(activeModal: NgbActiveModal);
    ngAfterViewInit(): void;
    setMode(mode: EditMode): void;
    save(): void;
    close(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarkdownEditModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MarkdownEditModalComponent, "app-markdown-edit-modal", never, { "title": { "alias": "title"; "required": false; }; "content": { "alias": "content"; "required": false; }; "isEditable": { "alias": "isEditable"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; }, { "saved": "saved"; }, never, never, true, never>;
}

interface MarkdownEditModalOptions {
    title?: string;
    content?: string;
    isEditable?: boolean;
    fullScreen?: boolean;
    size?: 'sm' | 'lg' | 'xl';
}
declare class MarkdownEditModalService {
    private modalService;
    constructor(modalService: NgbModal);
    open(options: MarkdownEditModalOptions): NgbModalRef;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarkdownEditModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MarkdownEditModalService>;
}

type MarkdownEditorMode = 'edit' | 'preview';
/**
 * Inline markdown editor with an Edit/Preview toggle — the embeddable counterpart of
 * MarkdownEditModalComponent, sharing its CodeMirror setup and preview rendering.
 *
 * Implements ControlValueAccessor, so it drops into template-driven forms like any input:
 *   <markdown-editor name="notes" [(ngModel)]="notes" required minlength="10"
 *                    validation-state validation-errors></markdown-editor>
 *
 * With [readOnly] it doubles as a viewer for markdown a page already holds:
 *   <markdown-editor [ngModel]="persona.promptMd" [readOnly]="true"></markdown-editor>
 * Consumers need MarkdownModule.forRoot() provided at their root (both apps already do).
 */
declare class MarkdownEditorComponent implements OnInit, AfterViewInit, OnDestroy, ControlValueAccessor {
    private editorContainer;
    /**
     * Height of the editing/preview area (any CSS length). Defaults to filling the host, which
     * in an auto-height container means sizing to the document — pass a length to cap it.
     */
    height: string;
    /** Caps the editing/preview area; longer content scrolls inside it. */
    maxHeight?: string;
    /**
     * Display-only: the document cannot be typed into, the toggle reads Code rather than Edit,
     * and the component opens on the rendered view instead of the source.
     */
    readOnly: boolean;
    /** Mode toggle labels. The source tab shows `codeLabel` when read-only, `editLabel` otherwise. */
    editLabel: string;
    codeLabel: string;
    previewLabel: string;
    activeMode: MarkdownEditorMode;
    previewContent: string;
    private view?;
    private pendingValue;
    private disabled;
    private readonly editableCompartment;
    private onChange;
    /**
     * Set only while writeValue() is pushing a programmatic value into the editor. CodeMirror reports
     * that dispatch as a normal document change, and Angular's ControlValueAccessor contract forbids
     * writeValue from invoking the registered onChange — doing so marks the NgModel dirty on a form
     * reset / resolver patch / tenant switch, firing unsaved-changes guards and submitted-state errors.
     */
    private writingValue;
    private onTouched;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    setMode(mode: MarkdownEditorMode): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarkdownEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MarkdownEditorComponent, "markdown-editor", never, { "height": { "alias": "height"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "editLabel": { "alias": "editLabel"; "required": false; }; "codeLabel": { "alias": "codeLabel"; "required": false; }; "previewLabel": { "alias": "previewLabel"; "required": false; }; }, {}, never, never, true, never>;
}

declare class RenderFilePreviewModalComponent {
    activeModal: NgbActiveModal;
    private clipboard;
    private success;
    content: string | Blob;
    fileName: string;
    title: string;
    copyLink: string;
    canDownload: boolean;
    constructor(activeModal: NgbActiveModal, clipboard: ClipboardService, success: SuccessReporter);
    copyLinkToClipboard(): void;
    downloadFile(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RenderFilePreviewModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RenderFilePreviewModalComponent, "app-render-file-preview-modal", never, { "content": { "alias": "content"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "title": { "alias": "title"; "required": false; }; "copyLink": { "alias": "copyLink"; "required": false; }; "canDownload": { "alias": "canDownload"; "required": false; }; }, {}, never, never, true, never>;
}

declare enum SupportedFileType {
    Markdown = "markdown",
    Html = "html",
    Code = "code",
    Image = "image",
    Pdf = "pdf",
    Docx = "docx",
    Pptx = "pptx",
    Unsupported = "unsupported"
}
/** All file extensions that can be rendered as code in Monaco */
declare const SUPPORTED_FILE_EXTENSIONS: string[];
declare function getFileType(fileName: string): SupportedFileType;
declare function getMonacoLanguage(fileName: string): string;
declare function isPreviewSupported(fileName: string): boolean;

declare class RenderFileComponent implements OnChanges, OnDestroy {
    private sanitizer;
    private zone;
    content: string | Blob;
    fileName: string;
    readonly SupportedFileType: typeof SupportedFileType;
    readonly SecurityContext: typeof SecurityContext;
    readonly MAX_PREVIEW_BYTES: number;
    readonly MAX_OFFICE_BYTES: number;
    private static readonly LEGACY_OFFICE_EXTS;
    fileType: SupportedFileType;
    textContent: string;
    safeHtmlContent: SafeHtml;
    imageUrl: string;
    pdfUrl: SafeResourceUrl;
    officeBlob: Blob | null;
    monacoLanguage: string;
    isLoading: boolean;
    isTooLarge: boolean;
    unsupportedTitle: string;
    editorOptions: any;
    private objectUrl;
    constructor(sanitizer: DomSanitizer, zone: NgZone);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private reset;
    private prepare;
    private prepareFromString;
    private prepareFromBlob;
    private revokeObjectUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<RenderFileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RenderFileComponent, "app-render-file", never, { "content": { "alias": "content"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ServersideDatatableExtraAction {
    name: string;
    label: string;
    icon?: string;
    class?: string;
    isMenu?: boolean;
    helpKey?: string;
    restrictAccessForReadonlyUser?: boolean;
    constructor(attrs?: Partial<ServersideDatatableExtraAction>);
}
declare class ServersideDatatableStatus {
    itemsPerPage: number;
    page: number;
    totalPages: number;
    totalItems: number;
    constructor(attrs?: Partial<ServersideDatatableStatus>);
}
declare class SearchAndPaginationParams {
    q?: string;
    sf?: string;
    sd?: string;
    max?: number;
    page?: number;
    constructor(properties?: Partial<SearchAndPaginationParams>);
    toUriPart(): string;
}

declare class ServersideDatatableComponent implements AfterViewInit, OnChanges, OnDestroy {
    private _changeDetector;
    private elRef;
    private i18n;
    private destroy$;
    /** Minimum time between server updates, in milliseconds. */
    minUpdateFrequency: number;
    /** Quiet period (ms) to wait after the last search keystroke before querying. */
    searchDebounce: number;
    /** Minimum search-term length before a server query fires; 0 (default) disables the gate. Clearing the box always re-queries regardless of this. */
    minSearchLength: number;
    /** Whether or not to show the add button. */
    showAdd: boolean;
    /** Whether or not to filter input. */
    showFilter: boolean;
    showEdit: boolean;
    extraActions: ServersideDatatableExtraAction[];
    loadingIndicator: boolean;
    /** Whether or not to reset the view (pagination, etc.) when the rows change */
    resetOnChange: boolean;
    _rows: any[];
    page: SearchAndPaginationParams;
    itemsPerPageOptions: number[];
    status: ServersideDatatableStatus;
    columnMode: "force";
    includeHeader: boolean;
    /** Pins the toolbar under the app header while the page scrolls. */
    isActionsFixed: boolean;
    searchTerm: string;
    set rows(rows: any[]);
    columnTemplates: i0.Signal<readonly DataTableColumnDirective<any>[]>;
    tableColumns: i0.Signal<i4.TableColumn<any>[]>;
    rowDetailTpl?: DatatableRowDetailDirective;
    ownRowDetail?: DatatableRowDetailDirective;
    private rowDetailBridge?;
    table: DatatableComponent;
    add: EventEmitter<void>;
    action: EventEmitter<string>;
    edit: EventEmitter<void>;
    update: EventEmitter<SearchAndPaginationParams>;
    serverUpdater: Subject<SearchAndPaginationParams>;
    searchUpdater: Subject<void>;
    skipResetOnce: boolean;
    constructor(_changeDetector: ChangeDetectorRef, elRef: ElementRef, i18n: TranslateService, destroy$: SubDestroyService);
    addItem(): void;
    editItem(): void;
    getButtons(): ServersideDatatableExtraAction[];
    getMenus(): ServersideDatatableExtraAction[];
    hasMenus(): boolean;
    /** Resets the view (pagination, sort, etc.) */
    reset(): void;
    extraActionClick(action: string): void;
    onItemsPerPageChange(limit: any): void;
    onSearchChange(text: string | undefined): void;
    onSortChange(sorts: SortPropDir[]): void;
    onPageChange(nr: any): void;
    /** Refreshes the list by reapplying filters. */
    refresh(skipReset?: boolean): void;
    serverRefresh(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    get shouldSkipReset(): boolean;
    startLoading(): void;
    stopLoading(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServersideDatatableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ServersideDatatableComponent, "serverside-datatable", never, { "minUpdateFrequency": { "alias": "minUpdateFrequency"; "required": false; }; "searchDebounce": { "alias": "searchDebounce"; "required": false; }; "minSearchLength": { "alias": "minSearchLength"; "required": false; }; "showAdd": { "alias": "showAdd"; "required": false; }; "showFilter": { "alias": "showFilter"; "required": false; }; "showEdit": { "alias": "showEdit"; "required": false; }; "extraActions": { "alias": "extraActions"; "required": false; }; "resetOnChange": { "alias": "resetOnChange"; "required": false; }; "_rows": { "alias": "_rows"; "required": false; }; "page": { "alias": "page"; "required": false; }; "itemsPerPageOptions": { "alias": "itemsPerPageOptions"; "required": false; }; "columnMode": { "alias": "columnMode"; "required": false; }; "includeHeader": { "alias": "includeHeader"; "required": false; }; "isActionsFixed": { "alias": "isActionsFixed"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; }, { "add": "add"; "action": "action"; "edit": "edit"; "update": "update"; }, ["columnTemplates", "rowDetailTpl"], ["[datatable-filters]", "*"], false, never>;
}

declare class ServersideDatatableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ServersideDatatableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ServersideDatatableModule, [typeof ServersideDatatableComponent], [typeof CoreCommonModule, typeof i3$1.NgbModule, typeof i4.NgxDatatableModule, typeof i5.NgSelectModule, typeof HelpModule, typeof RestrictElementAccessModule], [typeof CoreCommonModule, typeof i3$1.NgbModule, typeof i4.NgxDatatableModule, typeof ServersideDatatableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ServersideDatatableModule>;
}

declare class SpinnerComponent {
    size: number;
    spinnerClass?: string;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SpinnerComponent, "app-spinner", never, { "size": { "alias": "size"; "required": false; }; "spinnerClass": { "alias": "spinnerClass"; "required": false; }; }, {}, never, never, true, never>;
}

declare class StatusWithStyleComponent {
    status?: string;
    statusBadgeStyles: Map<string, string> | ReadonlyMap<string, string>;
    statusStyle: string;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatusWithStyleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatusWithStyleComponent, "status-with-style", never, { "status": { "alias": "status"; "required": false; }; "statusBadgeStyles": { "alias": "statusBadgeStyles"; "required": false; }; }, {}, never, never, true, never>;
}

interface TokenPaginatedPage<T = any> {
    rows: T[];
    nextToken?: string;
}
interface LoadPageEvent {
    pageIndex: number;
    token?: string;
    pageSize?: number;
}

declare class TokenPaginatedDatatableComponent implements AfterViewInit, OnDestroy {
    private _changeDetector;
    showForceRefresh: boolean;
    columnMode: "force";
    includeHeader: boolean;
    isActionsFixed: boolean;
    footerHeight: number | boolean;
    pageSizeOptions: number[];
    loadingIndicator: boolean;
    columnTemplates: i0.Signal<readonly DataTableColumnDirective<any>[]>;
    tableColumns: i0.Signal<i4.TableColumn<any>[]>;
    rowDetailTpl?: DatatableRowDetailDirective;
    ownRowDetail?: DatatableRowDetailDirective;
    private rowDetailBridge?;
    table: DatatableComponent;
    loadPage: EventEmitter<LoadPageEvent>;
    forceRefresh: EventEmitter<void>;
    pageSizeChange: EventEmitter<number>;
    private pageCache;
    currentPageIndex: number;
    currentRows: any[];
    private currentNextToken;
    pageSize: number;
    constructor(_changeDetector: ChangeDetectorRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    onSidebarCollapsed(): void;
    setPageData(pageIndex: number, rows: any[], nextToken?: string): void;
    clearCache(): void;
    get hasPreviousPage(): boolean;
    get hasNextPage(): boolean;
    goToPreviousPage(): void;
    goToNextPage(): void;
    emitRefresh(): void;
    onPageSizeChange(value: number): void;
    startLoading(): void;
    stopLoading(): void;
    get displayPageNumber(): number;
    getTokenForPage(pageIndex: number): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<TokenPaginatedDatatableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TokenPaginatedDatatableComponent, "token-paginated-datatable", never, { "showForceRefresh": { "alias": "showForceRefresh"; "required": false; }; "columnMode": { "alias": "columnMode"; "required": false; }; "includeHeader": { "alias": "includeHeader"; "required": false; }; "isActionsFixed": { "alias": "isActionsFixed"; "required": false; }; "footerHeight": { "alias": "footerHeight"; "required": false; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; }; }, { "loadPage": "loadPage"; "forceRefresh": "forceRefresh"; "pageSizeChange": "pageSizeChange"; }, ["columnTemplates", "rowDetailTpl"], ["*"], false, never>;
}

declare class TokenPaginatedDatatableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TokenPaginatedDatatableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TokenPaginatedDatatableModule, [typeof TokenPaginatedDatatableComponent], [typeof CoreCommonModule, typeof i3$1.NgbModule, typeof i4.NgxDatatableModule, typeof i5.NgSelectModule], [typeof CoreCommonModule, typeof i3$1.NgbModule, typeof i4.NgxDatatableModule, typeof TokenPaginatedDatatableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TokenPaginatedDatatableModule>;
}

type DataViewFormat = 'json' | 'yaml';
declare class ViewDataModalComponent {
    activeModal: NgbActiveModal;
    private clipboardService;
    headerText: string;
    showDownload: boolean;
    downloadFileName: string;
    fullScreen: boolean;
    private _dataObject;
    activeFormat: DataViewFormat;
    formattedContent: string;
    copySuccess: boolean;
    downloadSuccess: boolean;
    jsonEditorOptionsReadOnly: any;
    yamlEditorOptionsReadOnly: any;
    constructor(activeModal: NgbActiveModal, clipboardService: ClipboardService);
    set dataObject(value: any);
    get dataObject(): any;
    get editorOptions(): any;
    setFormat(format: DataViewFormat): void;
    private updateFormattedContent;
    getHeaderAsText(): string;
    downloadData(event?: Event): void;
    private showDownloadSuccess;
    copyToClipboard(event?: Event): void;
    private showCopySuccess;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewDataModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewDataModalComponent, "app-view-data-modal", never, { "headerText": { "alias": "headerText"; "required": false; }; "showDownload": { "alias": "showDownload"; "required": false; }; "downloadFileName": { "alias": "downloadFileName"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "dataObject": { "alias": "dataObject"; "required": false; }; }, {}, never, never, true, never>;
}

interface ViewDataModalOptions {
    headerText: string;
    dataObject: any;
    downloadFileName?: string;
    showDownload?: boolean;
    fullScreen?: boolean;
    size?: 'sm' | 'lg' | 'xl';
    defaultFormat?: DataViewFormat;
}
declare class ViewDataModalRef {
    modal: NgbModalRef;
    component: ViewDataModalComponent;
}
declare class ViewDataModalService {
    private modalService;
    constructor(modalService: NgbModal);
    open(options: ViewDataModalOptions): ViewDataModalRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewDataModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ViewDataModalService>;
}

/** Options for a ViewJson modal. */
interface ViewJsonModalOptions<T> {
    downloadFileName?: string;
    showDownload?: boolean;
    headerText: string;
    messageText?: string;
    messageObject: object;
    size?: "xs:" | "sm" | "lg" | "xl";
    enableEdit?: boolean;
    isEditMode?: boolean;
    fullScreen?: boolean;
}
/** A reference to a ViewJson modal. */
declare class ViewJsonModalRef<T> {
    modal: NgbModalRef;
    component: ViewJsonModalComponent;
}
declare class ViewJsonModalService {
    private _modals;
    constructor(_modals: NgbModal);
    open<T>(options: ViewJsonModalOptions<T>): ViewJsonModalRef<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewJsonModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ViewJsonModalService>;
}

declare class XtermBlockComponent implements OnInit, OnDestroy {
    private styleLoader;
    cmdText: string;
    cmdTextChange: EventEmitter<string>;
    cmdOutput: string;
    rows: number;
    isEditable: boolean;
    canResize: boolean;
    terminalOptions: ITerminalOptions;
    containerClass: string;
    scrollBottom: boolean;
    terminalContainer: ElementRef;
    private terminal;
    private fitAddon;
    private commandBuffer;
    private resizeObserver;
    private resizeHandler;
    constructor(styleLoader: DynamicStyleLoaderService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    writeOutput(output: string, autoScroll?: boolean, appendCmdText?: boolean): void;
    ngOnDestroy(): void;
    private getTerminalOptions;
    /** Fits the terminal to its container size */
    private fitTerminal;
    /** Writes the shell prompt */
    writePrompt(): void;
    handleInput(data: string): void;
    private formatTerminalOutput;
    writeCommandOutput(output: string): void;
    scrollToBottom(): void;
    scrollToLine(line: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<XtermBlockComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<XtermBlockComponent, "app-xterm-block", never, { "cmdText": { "alias": "cmdText"; "required": false; }; "cmdOutput": { "alias": "cmdOutput"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "isEditable": { "alias": "isEditable"; "required": false; }; "canResize": { "alias": "canResize"; "required": false; }; "terminalOptions": { "alias": "terminalOptions"; "required": false; }; "containerClass": { "alias": "containerClass"; "required": false; }; "scrollBottom": { "alias": "scrollBottom"; "required": false; }; }, { "cmdTextChange": "cmdTextChange"; }, never, never, true, never>;
}

declare const XTERM_CLEAR_COMMAND = "echo '-----------------------' ; clear";
declare const XTERM_TERMINAL_CONFIG: {
    minCols: number;
    minRows: number;
    widthReduction: number;
    charWidth: number;
    charHeight: number;
};
declare class XtermCommand {
    cmdText: string;
    cmdId: string;
    output: string;
    constructor(properties?: Partial<XtermCommand>);
}

declare class XtermSocketService {
    private api;
    private _xtermUrl;
    constructor(api: HttpClient);
    getXtermUrl(): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<XtermSocketService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<XtermSocketService>;
}

declare class XtermSocketComponent implements OnInit, OnDestroy {
    private destroy$;
    private cdr;
    private xtermSocketService;
    session: any;
    private error;
    private styleLoader;
    rows: number;
    queryParams: Record<string, string>;
    serverUrl: string;
    canResize: boolean;
    terminalOptions: ITerminalOptions;
    containerClass: string;
    terminalReady: EventEmitter<boolean>;
    commandComplete: EventEmitter<XtermCommand>;
    terminalContainer: ElementRef;
    blockUI: NgBlockUI;
    connected: boolean;
    canSendOutput: boolean;
    private terminal;
    private socket;
    private resizeObserver;
    private resizeHandler;
    private cmdQ;
    constructor(destroy$: SubDestroyService, cdr: ChangeDetectorRef, xtermSocketService: XtermSocketService, session: any, error: ErrorReporter, styleLoader: DynamicStyleLoaderService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private getTerminalUrl;
    private initSocketConnection;
    private initTerminal;
    /** Fits the terminal to its container size */
    private fitTerminal;
    checkIfXtermOpen(): void;
    private disconnect;
    runCommand(command: string): void;
    runStringCommand(cmdStr: string): void;
    addToRunningQueue(cmdQueue: string[]): void;
    clear(): void;
    loadCommandHistory(history: XtermCommand[]): void;
    private updateTerminalDimensions;
    private getTerminalOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<XtermSocketComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<XtermSocketComponent, "app-xterm-socket", never, { "rows": { "alias": "rows"; "required": false; }; "queryParams": { "alias": "queryParams"; "required": false; }; "serverUrl": { "alias": "serverUrl"; "required": false; }; "canResize": { "alias": "canResize"; "required": false; }; "terminalOptions": { "alias": "terminalOptions"; "required": false; }; "containerClass": { "alias": "containerClass"; "required": false; }; }, { "terminalReady": "terminalReady"; "commandComplete": "commandComplete"; }, never, never, true, never>;
}

interface YamlSnippet {
    label: string;
    /** Content to insert. When `parent` is set, this is the value under the parent key (no wrapper). */
    yaml: string;
    group?: string;
    /**
     * Top-level YAML key to merge under. When set, the snippet yaml is treated as the value:
     *   - array value → appended to any existing array under `parent`
     *   - object/scalar value → replaces the existing value under `parent`
     * When absent, all top-level keys in the snippet are merged into the document (always replacing).
     */
    parent?: string;
}
interface SnippetGroup {
    group: string | null;
    items: YamlSnippet[];
}
declare class YamlSnippetEditorComponent implements ControlValueAccessor, OnDestroy {
    snippets: YamlSnippet[];
    placeholder: string;
    minHeight: string;
    private monacoComp?;
    value: string;
    disabled: boolean;
    flashingLabel: string | null;
    readonly editorOptions: {
        language: string;
        theme: string;
        minimap: {
            enabled: boolean;
        };
        scrollBeyondLastLine: boolean;
        wordWrap: "on";
        fontSize: number;
        lineNumbers: "on";
        folding: boolean;
        glyphMargin: boolean;
        lineDecorationsWidth: number;
        lineNumbersMinChars: number;
        automaticLayout: boolean;
    };
    private _flashTimer?;
    private onChange;
    private onTouched;
    private get rawEditor();
    get groupedSnippets(): SnippetGroup[];
    onEditorChange(v: string): void;
    insertSnippet(snippet: YamlSnippet, event: MouseEvent): void;
    /**
     * Merge snippet keys into the current YAML document (always replacing — handles
     * multi-key snippets like command+args and flat annotation dicts).
     * Falls back to concat when either side isn't a plain object.
     */
    private smartMerge;
    /**
     * Merge a snippet value under a specific parent key.
     *   - snippet value is array  → append items to existing array (or create one)
     *   - snippet value is object → replace existing value
     */
    private mergeIntoParent;
    private isPlainObject;
    private concatYaml;
    writeValue(v: string): void;
    registerOnChange(fn: (v: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<YamlSnippetEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<YamlSnippetEditorComponent, "app-yaml-snippet-editor", never, { "snippets": { "alias": "snippets"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Mirrors the server-side `SettingValueType` enum (string-serialised).
 * Case-sensitive — send exactly as shown.
 */
declare enum AISettingValueType {
    String = "String",
    Number = "Number",
    Bool = "Bool",
    Json = "Json"
}
/**
 * Friendly, user-facing label for each type. Single source of truth — the Add form's
 * type dropdown, the list badge text (`displayType`), and the badge-style map all derive from this.
 */
declare const AI_SETTING_TYPE_LABELS: Map<AISettingValueType, string>;
/**
 * Badge-style map keyed by the friendly label (`displayType`) — used by the list table.
 * Defined at module level (not inside a class) per project conventions.
 */
declare const aiSettingTypeStyleMap: Map<string, string>;
/**
 * Badge-style map for Bool-typed values (keyed lowercase — `displayValue` for a Bool setting is
 * `String(value)`, i.e. `'true'` / `'false'`). Defined at module level per project conventions.
 */
declare const aiSettingBoolValueStyleMap: Map<string, string>;
/**
 * Parse a raw form value into the typed value the API expects. Throws on invalid input
 * (non-numeric Number, YAML that doesn't parse to a structured value) so callers fail loud
 * instead of silently sending a type-mismatched value. Bool is handled by the toggle, not this
 * function. Json values are authored as YAML (a superset of JSON) and must be a list or a map.
 */
declare function parseSettingValue(raw: string | number, type: AISettingValueType): unknown;
/**
 * Represents a system-wide key-value setting as returned by every read endpoint.
 * Domain identity is `name` (immutable), but admin CRUD writes (create/update/delete) address
 * records by `id`.
 */
declare class AISystemSetting {
    id?: string;
    name: string;
    type: AISettingValueType;
    value: any;
    labels: string[];
    description?: string;
    createdAt?: string;
    updatedAt?: string;
    isActive?: boolean;
    version?: number;
    /** Display-safe string for the value cell — derived once in the constructor. */
    displayValue: string;
    /** Display-safe string for type badge — derived once in the constructor. */
    displayType: string;
    /**
     * Friendly name shown in the list. Set by the list component from the AI Suite catalog
     * (display-label when the name matches a predefined setting, else the raw name). Kept a plain
     * field — not derived in the constructor — so the model does not import the catalog (which
     * imports AISettingValueType from here; a constructor lookup would create a circular import).
     */
    displayName?: string;
    /**
     * Display-safe "Last Modified" string. Set by the list component in refreshAll (formatted via
     * DateUtils) so the column is both rendered and searchable without a template date pipe.
     */
    displayUpdatedAt?: string;
    constructor(props?: Partial<AISystemSetting>);
    private _toDisplayType;
    private _toDisplayValue;
}
/**
 * Request body for Create (POST) and Update (PUT).
 * `name` is ignored by the server on Update — the URL segment is authoritative.
 */
declare class AISystemSettingRequest {
    name: string;
    type: AISettingValueType;
    value: any;
    labels?: string[];
    description?: string;
    constructor(props?: Partial<AISystemSettingRequest>);
}

/**
 * Canonical AI Suite ai-system-setting names — never use a magic string.
 * Keep this file import-free: the './Menu' federation chunk takes a name from here, and the
 * catalog in `aisuite-settings.ts` would drag `yaml` into that chunk.
 */
declare const AISUITE_SETTING: {
    readonly COLLAPSE_ADVANCED_OPTIONS: "add-hd-ticket-collapse-advanced";
    readonly LANGFUSE_URL: "langfuse-url";
    readonly MENU_HIDDEN_ITEMS: "ai-menu-hidden-items";
    readonly K8S_ALLOW_STATIC_TOKEN_JIT_ACCESS: "k8s-allow-static-token-jit-access";
    readonly NAV_HEADER_HIDDEN_ITEMS: "ai-nav-header-hidden-items";
    readonly HIDE_SINGLE_WORKSPACE_SELECTOR: "ai-hide-single-workspace-selector";
    readonly ENABLE_PRODUCT_ANALYTICS: "ai-enable-product-analytics";
    readonly WORKSPACE_MEMORY_DEFAULT: "ai-workspace-memory-default";
};
/**
 * Ids accepted by `ai-nav-header-hidden-items` — the right-hand navbar icons. The `-non-admin`
 * suffix is load-bearing: that flag hides the icon from User-role users only, never from admins.
 */
declare const NAV_HEADER_ITEM: {
    readonly FAULTS_NOTIFICATION_NON_ADMIN: "faults-notification-non-admin";
    readonly TRUST_CENTER: "trust-center";
    readonly HELP: "help";
};
type AiSuiteSettingName = typeof AISUITE_SETTING[keyof typeof AISUITE_SETTING];

/** A selectable option for a predefined setting. `value` must match the owning setting's type. */
interface AiSuiteSettingOption {
    label: string;
    value: string | number | boolean;
}
/**
 * A predefined system setting — a template that fixes the name/type and, optionally, a set of
 * selectable options. When `options` is present the value renders as a single-select dropdown;
 * otherwise it renders as the type's normal input.
 */
interface AiSuiteSetting {
    /** Setting identity (immutable). Use an `AISUITE_SETTING.*` value. */
    name: string;
    /** Data type. Json entries never carry options (they use the YAML editor). */
    type: AISettingValueType;
    /** UI display name — distinct from the setting's grouping `labels`. */
    displayName: string;
    /** Optional default description / help text. */
    description?: string;
    /** Optional placeholder for the plain typed field. */
    placeholder?: string;
    /**
     * Optional value prefilled into the Add form. Must match `type` — Json takes a list or map
     * (not a YAML string), and an `options` entry must match one option's `value`.
     */
    defaultValue?: string | number | boolean | unknown[] | Record<string, any>;
    /** Optional single-select options (scalar types only). Present → dropdown; absent → typed field. */
    options?: AiSuiteSettingOption[];
}
/**
 * Predefined settings selectable from both the admin AI System Settings form and the
 * per-workspace Settings form.
 */
declare const AISUITE_SETTINGS_COMMON: AiSuiteSetting[];
/**
 * Predefined settings selectable only from the admin AI System Settings form — never offered
 * as a predefined choice in the per-workspace Settings form.
 */
declare const AISUITE_SETTINGS_ADMIN: AiSuiteSetting[];
/**
 * Predefined settings selectable only from the per-workspace Settings form — never offered
 * as a predefined choice in the admin AI System Settings form.
 */
declare const AISUITE_SETTINGS_WORKSPACE: AiSuiteSetting[];
/** Predefined choices selectable from the admin AI System Settings form. */
declare const AISUITE_SETTINGS_FOR_ADMIN: AiSuiteSetting[];
/** Predefined choices selectable from the per-workspace Settings form. */
declare const AISUITE_SETTINGS_FOR_WORKSPACE: AiSuiteSetting[];
/**
 * The full predefined catalog, regardless of scope. Each entry's `name` must be an
 * `AISUITE_SETTING.*` value; option values must match the entry `type`. Used for name→entry
 * lookups (`AISUITE_SETTING_BY_NAME`, `AISUITE_SETTING_NAME_TO_DISPLAY_NAME`) that don't care
 * which form the setting was created from.
 */
declare const AISUITE_SETTINGS: AiSuiteSetting[];
/** Predefined setting by name. */
declare const AISUITE_SETTING_BY_NAME: ReadonlyMap<string, AiSuiteSetting>;
/** Setting name → display label (for the list's Name column). */
declare const AISUITE_SETTING_NAME_TO_DISPLAY_NAME: ReadonlyMap<string, string>;

interface BreadcrumbLink {
    name: string;
    isLink: boolean;
    link?: string;
}
interface Breadcrumb {
    type?: string;
    alignment?: string;
    links?: BreadcrumbLink[];
}
interface CoreConfig {
    app: {
        appName: string;
        appTitle: string;
        appLogoImage: string;
    };
    layout: {
        skin: CoreConfigLayoutSkin;
        type: 'vertical' | 'horizontal';
        menu: {
            hidden: boolean;
            collapsed: boolean;
        };
        header?: {
            hidden?: boolean;
            title?: string;
            breadcrumbs?: Breadcrumb;
            extraBreadcrumbs?: BreadcrumbLink[];
            noTenantSwitchImpact?: boolean;
        };
        navbar: {
            hidden: boolean;
            type: 'navbar-static-top' | 'fixed-top' | 'floating-nav' | 'd-none';
            background: 'navbar-dark' | 'navbar-light';
            customBackgroundColor: boolean;
            backgroundColor: string;
        };
        footer: {
            hidden: boolean;
            type: 'footer-static' | 'footer-sticky' | 'd-none';
            background: 'footer-dark' | 'footer-light';
            customBackgroundColor: boolean;
            backgroundColor: string;
        };
        enableLocalStorage: boolean;
        customizer: boolean;
        scrollTop: boolean;
    };
}
type CoreConfigLayoutSkin = 'default' | 'bordered' | 'dark' | 'semi-dark';

interface CoreMenuItem {
    id: string;
    title: string;
    shortMenu?: string;
    shortTitle?: string;
    url?: string;
    type: 'section' | 'collapsible-section' | 'collapsible' | 'item' | 'dummy';
    role?: Array<string>;
    translate?: string;
    icon?: string;
    matIcon?: string;
    featherIcon?: string;
    disabled?: boolean;
    hidden?: boolean;
    classes?: string;
    exactMatch?: boolean;
    externalUrl?: boolean;
    openInNewTab?: boolean;
    badge?: {
        title?: string;
        translate?: string;
        classes?: string;
    };
    children?: CoreMenuItem[];
    hideSearch?: boolean;
}
interface CoreMenu extends CoreMenuItem {
    children?: CoreMenuItem[];
}

/**
 * Read-only, globally-shared access to system settings (any authenticated user).
 * Write operations (create/update/delete) live in the admin-only
 * `AdminAISystemSettingsDataSource` under the ai-studio admin module.
 */
declare class AISystemSettingsDataSource {
    private api;
    private readonly baseUrl;
    constructor(api: HttpClient);
    /**
     * GET /v1/aiservicedesk/user/data/systemsettings?type={type}&label={label}
     * Both query params are optional. Returns active settings only.
     */
    listSettings(options?: {
        type?: AISettingValueType;
        label?: string;
    }): Observable<AISystemSetting[]>;
    /**
     * GET /v1/aiservicedesk/user/data/systemsettings/{id}
     */
    getById(id: string): Observable<AISystemSetting>;
    /**
     * GET /v1/aiservicedesk/user/data/systemsettings/by-name/{name}?suppressNotFound=true
     * A missing setting is a real 404 by default; suppressNotFound=true opts into a 200 with
     * `data: null` instead (duplo-ai-helpdesk PR #449) — same envelope the workspace endpoint uses.
     */
    getByName(name: string): Observable<AISystemSetting | null>;
    /**
     * GET /v1/aiservicedesk/user/data/systemsettings/by-label/{label}
     * Returns every active setting carrying the label. No suppressNotFound here — this endpoint
     * never 404s on its own (a missing label is just an empty array) and the server does not
     * accept the parameter.
     */
    getByLabel(label: string): Observable<AISystemSetting[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AISystemSettingsDataSource, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AISystemSettingsDataSource>;
}

/**
 * Central, cached, read-oriented access to global AI system settings — the AI-suite analogue of
 * SystemFeatures. Injectable anywhere; caches per name for the session (explicit invalidate()).
 * For workspace-scoped settings use WorkspaceSystemSettingsService.
 */
declare class AISystemSettingsService {
    private ds;
    private features?;
    private readonly cache;
    private readonly inFlight;
    private readonly labelCache;
    private readonly labelInFlight;
    constructor(ds: AISystemSettingsDataSource, features?: {
        IsAIEnabled?: boolean;
    });
    /**
     * The endpoint lives behind /v1/aiservicedesk, so reads are pointless when the AI suite is off.
     * Fails open when the token is absent (bare TestBed) — unknown is treated as enabled.
     */
    private get aiDisabled();
    getString(name: string, defaultValue?: string | null): Observable<string | null>;
    getNumber(name: string, defaultValue?: number | null): Observable<number | null>;
    getBool(name: string, defaultValue?: boolean | null): Observable<boolean | null>;
    getJson<T = unknown>(name: string, defaultValue?: T | null): Observable<T | null>;
    /** { [settingName]: value } for every active setting carrying the label. */
    getByLabel(label: string): Observable<Record<string, unknown>>;
    /** Drop cached entries so the next read refetches. name → that entry; no arg → clear all. */
    invalidate(name?: string): void;
    private resolve;
    static ɵfac: i0.ɵɵFactoryDeclaration<AISystemSettingsService, [null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AISystemSettingsService>;
}

/**
 * Read-only, workspace-scoped access to system settings for cross-module consumers. The server
 * resolves scope: by-name falls back workspace→global; by-label merges the two (workspace wins on
 * a name collision). Pass `excludeGlobal=true` to restrict to the workspace. Responses are wrapped
 * in `ApiResponse<T>` — this unwraps `.data`. Writes live in the ai-studio settings feature.
 */
declare class WorkspaceSystemSettingsDataSource {
    private api;
    private readonly baseUrl;
    constructor(api: HttpClient);
    private settingsUrl;
    /**
     * GET .../workspaces/{workspaceId}/systemsettings/by-name/{name}?excludeGlobal={bool}&suppressNotFound=true
     * Workspace-first with a global fallback. Like the system-level by-name endpoint, a missing
     * setting is a real 404 by default and suppressNotFound=true opts into a 200 with `data: null`
     * instead — this endpoint is not graceful on its own.
     */
    getByName(workspaceId: string, name: string, excludeGlobal?: boolean): Observable<AISystemSetting | null>;
    /**
     * GET .../workspaces/{workspaceId}/systemsettings/by-label/{label}?excludeGlobal={bool}
     * Merged across workspace and global scopes (workspace wins on a name collision) unless
     * `excludeGlobal` is true. No suppressNotFound here — this endpoint never 404s on its own (a
     * missing label is just an empty array) and the server does not accept the parameter.
     */
    getByLabel(workspaceId: string, label: string, excludeGlobal?: boolean): Observable<AISystemSetting[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkspaceSystemSettingsDataSource, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WorkspaceSystemSettingsDataSource>;
}

/**
 * Options for the workspace-scoped reads. `workspaceId` defaults to the session's current
 * workspace when omitted; `excludeGlobal` (default false) restricts the read to the workspace,
 * disabling the server-side global fallback/merge.
 */
interface WorkspaceSettingOpts {
    workspaceId?: string;
    excludeGlobal?: boolean;
}
/**
 * Central, cached, read-oriented access to workspace-scoped AI system settings. The server resolves
 * scope (by-name falls back workspace→global; by-label merges the two, workspace winning) unless
 * `excludeGlobal` is set. Cache entries are keyed by (workspaceId, excludeGlobal, name/label) so
 * they stay isolated per workspace and are retained across workspace switches; call `invalidate`
 * after a write. For global-only settings use AISystemSettingsService.
 */
declare class WorkspaceSystemSettingsService {
    private ds;
    private session?;
    private features?;
    private readonly cache;
    private readonly inFlight;
    private readonly labelCache;
    private readonly labelInFlight;
    constructor(ds: WorkspaceSystemSettingsDataSource, session?: {
        tenant?: {
            aiWorkspace?: {
                id?: string;
            };
        };
    }, features?: {
        IsAIEnabled?: boolean;
    });
    /**
     * The endpoint lives behind /v1/aiservicedesk, so reads are pointless when the AI suite is off.
     * Fails open when the token is absent (bare TestBed) — unknown is treated as enabled.
     */
    private get aiDisabled();
    getString(name: string, defaultValue?: string | null, opts?: WorkspaceSettingOpts): Observable<string | null>;
    getNumber(name: string, defaultValue?: number | null, opts?: WorkspaceSettingOpts): Observable<number | null>;
    getBool(name: string, defaultValue?: boolean | null, opts?: WorkspaceSettingOpts): Observable<boolean | null>;
    getJson<T = unknown>(name: string, defaultValue?: T | null, opts?: WorkspaceSettingOpts): Observable<T | null>;
    /** { [settingName]: value } for every setting carrying the label in the resolved workspace scope. */
    getByLabel(label: string, opts?: WorkspaceSettingOpts): Observable<Record<string, unknown>>;
    /**
     * Invalidate cache after a write. `name` drops that setting (both merge-modes) plus the
     * workspace's label caches (a changed setting may appear in any label set); no `name` drops all
     * of the workspace's entries. `workspaceId` defaults to the session workspace.
     */
    invalidate(name?: string, workspaceId?: string): void;
    /** Clears `name` for every cached workspace after a global write — `invalidate()` alone
     *  only clears the current one. Pass `labels` (the setting's labels before ∪ after the write)
     *  to scope the label-cache clearing to just those — an empty array means the setting has no
     *  labels, so nothing to clear; omitted (unknown) falls back to a full clear. Same-bundle
     *  only — ai-studio and portal hold separate instances. */
    invalidateAcrossWorkspaces(name: string, labels?: string[]): void;
    private deleteByWorkspace;
    /** Deletes every cache entry for `name`, regardless of which workspace or merge-mode it's under. */
    private deleteByName;
    private resolveWorkspaceId;
    private key;
    private resolve;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkspaceSystemSettingsService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WorkspaceSystemSettingsService>;
}

declare enum AppType {
    Platform = "Platform",
    AISuite = "AI DevOps",
    Admin = "AI Admin"
}
/**
 * A runtime-loaded extension's menu tree, passed from the host into the remote menu builder.
 * The host owns the loaded-extension snapshot (its app initializer fetches `…/extensions/ui-manifest`);
 * `@common-lib` is NOT a federation singleton, so the data is passed by value across the './Menu' call
 * boundary rather than read from a shared module. Structurally matches the host's `ExtensionMenuNode`.
 */
interface RemoteMenuExtensionNode {
    id: string;
    title: string;
    type?: 'section' | 'collapsible-section' | 'collapsible' | 'item' | 'dummy';
    matIcon?: string;
    icon?: string;
    order?: number;
    relativeUrl?: string;
    role?: string[];
    children?: RemoteMenuExtensionNode[];
}
interface RemoteMenuExtensionTree {
    node: RemoteMenuExtensionNode;
    /** Legacy single-menu path: merge into a top-level group whose id matches. New menus[] omit this. */
    legacyParentGroupId?: string;
}
/**
 * Contract for a remote module's './Menu' federation expose.
 * Pure function: must not touch Angular DI, components, or globals.
 * Every remote that contributes sidebar nav exports `buildMenu` matching this type.
 * `extensionMenus` (optional) carries runtime-loaded extensions' menu trees for the builder to
 * find-or-create by title; omitted by callers that don't surface extensions.
 */
type RemoteMenuBuilder = (features: SystemFeatures, session: UserSession, appType: AppType, extensionMenus?: RemoteMenuExtensionTree[]) => CoreMenu[];
/**
 * Everything the host hands a remote so it can load its own menu config. Build it per call:
 * `appType` changes at runtime and the scope derives from it plus the session's workspace.
 * Services are passed as instances, not resolved on the remote side — `@common-lib` is not shared
 * across the federation boundary, so class identity differs; method dispatch is duck-typed.
 */
interface AiMenuDeps {
    features: SystemFeatures;
    session: UserSession;
    appType: AppType;
    /** Global / admin scope. */
    aiSettings: AISystemSettingsService;
    /** Workspace scope; the server falls back to the global value. */
    workspaceSettings: WorkspaceSystemSettingsService;
}
/** The subset of the './Menu' federation expose that the host calls. */
interface AiMenuRemote {
    buildMenu: RemoteMenuBuilder;
    ensureMenuConfig?: (deps: AiMenuDeps) => Promise<boolean>;
}

type DeepPartial<T> = {
    [P in keyof T]?: T[P] extends Record<string, unknown> ? DeepPartial<T[P]> : T[P];
};

declare class ProviderCredentialData {
    constructor(properties?: Partial<ProviderCredentialData>);
    key: string;
    value: string;
    type?: string;
    isSensitive?: boolean;
}
interface ApiTokenSettings {
    defaultExpiryDays: number;
}
interface CreateApiTokenRequest {
    name: string;
    expiresAt?: string | null;
}
interface ApiTokenCreateResponse {
    token: HelpdeskApiToken;
    plainToken: string;
}
declare class HelpdeskApiToken implements BaseEntity {
    id: string;
    name: string;
    userId: string;
    tokenHint: string;
    createdAt: string;
    lastUsedAt?: string;
    expiresAt?: string;
    isActive: boolean;
    private _isExpired;
    private _statusLabel;
    constructor(properties?: Partial<HelpdeskApiToken>);
    get isExpired(): boolean;
    get statusLabel(): string;
}
declare class CredentialPayload {
    constructor(properties?: Partial<CredentialPayload>);
    name?: string;
    dataEx?: ProviderCredentialData[];
    metaData?: Record<string, any>;
}
declare class UserCredential implements BaseEntity {
    constructor(properties?: Partial<UserCredential>);
    id?: string;
    name?: string;
    description?: string;
    ownerEmail?: string;
    scopeId?: string;
    isEnabled: boolean;
    credential?: CredentialPayload;
    createdAt?: string;
    updatedAt?: string;
    isActive?: boolean;
    version?: number;
    metaData?: Record<string, any>;
}

declare class HdUserProfileDataSource {
    private api;
    private baseUrl;
    constructor(api: HttpClient);
    getSettings(): Observable<ApiTokenSettings>;
    listTokens(): Observable<HelpdeskApiToken[]>;
    createToken(request: CreateApiTokenRequest): Observable<ApiTokenCreateResponse>;
    revokeToken(id: string): Observable<void>;
    deleteToken(id: string): Observable<void>;
    getAllowedWorkspaces(): Observable<AIWorkspaceBase[]>;
    private credUrl;
    getUserCredential(scopeId: string): Observable<UserCredential | null>;
    upsertUserCredential(scopeId: string, credential: Partial<UserCredential>): Observable<UserCredential>;
    deleteUserCredential(scopeId: string): Observable<void>;
    toggleUserCredential(scopeId: string, isEnabled: boolean): Observable<UserCredential>;
    getCredentialTemplate(scopeId: string): Observable<ProviderCredentialData[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HdUserProfileDataSource, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HdUserProfileDataSource>;
}

declare const DEFAULT_INFRA: {
    Name: string;
    Accountid: string;
    Cloud: number;
    ProvisioningStatus: string;
    Vnet: {
        Subnets: any[];
        SecurityGroups: any[];
    };
};
declare const INFRA_K8S_VERSION = "K8sVersion";
declare const INFRA_EKS_VISIBILITY = "EksEndpointVisibility";
declare const INFRA_EKS_LOGGING = "EksControlplaneLogs";
declare const INFRA_EKS_VPN_ACCESS = "EnableVpnAccessToEks";
declare const INFRA_EKS_CSI_SNAPSHOT = "EksEbsCsiSnapshotController";
declare const INFRA_DUPLO_CI_TENANT = "DuploCiTenant";
declare const INFRA_DUPLO_CI_CERTIFICATE = "DuploCiCertificate";
declare const INFRA_CLUSTER_AUTOSCALER = "EnableClusterAutoscaler";
declare const ALERT_PRIOR_AUTOSCALING = "AlertPriorAutoscaling";
declare const INFRA_EKS_LOG_TYPES: string[];
declare const INFRA_GKE_VISIBILITY = "GkeEndpointVisibility";
declare const INFRA_OKE_VISIBILITY = "OkeEndpointVisibility";
declare const INFRA_MAXIMUM_K8S_SESSION_DURATION = "MaximumK8sSessionDuration";
declare const GKE_MIN_PORTS_PER_VM = "GkeMinPortsPerVm";
declare const INFRA_HELM_OPERATOR_FLUXV2 = "EnableHelmOperatorFluxV2";
declare const INFRA_HELM_OPERATOR_FLUXV2_DISABLED = "DisableHelmOperatorFluxV2";
declare const INFRA_GCP_DYNAMIC_PORT_ALLOCATION = "DynamicPortAllocation";
declare const INFRA_HELM_OPERATOR_VERSION = "K8sHelmOperator";
declare const INFRA_HELM_OPERATOR_FlUXV1 = "RemoveHelmOperatorFluxV1";
declare const INFRA_GKE_RELEASE_CHANNEL = "GkeChannel";
declare const INFRA_ENABLE_EKS_WINDOWS_WORKLOAD = "EnableK8sWindowsWorkload";
declare const INFRA_GKE_GATEWAY_API = "GkeGatewayAPI";
declare const INFRA_AZURE_NAT_GATEWAY = "EnableNATGateway";
declare enum CloudPlatform {
    AWS = 0,
    Oracle = 1,
    Azure = 2,
    Google = 3,
    BYOH = 4,
    Unknown = 5,
    Digital_Ocean = 6,
    OnPrem = 10
}
declare const INFRA_CUSTOM_DATA_SPECS: CustomDataSpec[];
declare class InfrastructureECSConfigUpdate {
    constructor(properties?: Object | InfrastructureECSConfigUpdate);
    EnableECSCluster: boolean;
    EnableContainerInsights: boolean;
}
declare class InfrastructureEKSConfigUpdate {
    constructor(properties?: Object | InfrastructureEKSConfigUpdate);
    EnableK8Cluster: boolean;
    K8sVersion: string;
}
declare class Infrastructure {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Object | Infrastructure);
    Name: string;
    Accountid?: string;
    Cloud: CloudPlatform;
    Vnet: Vnet;
    Region: string;
    AzCount: number;
    EnableK8Cluster: boolean;
    ClusterIpv4Cidr: string;
    CustomData: CustomData[];
    ProvisioningStatus?: string;
    AksConfig: InfrastructureAksConfig;
    VpcPeers: Array<string>;
    VpcPeerSubnets: Array<any>;
    EnableECSCluster: boolean;
    EnableContainerInsights: boolean;
    OnPremConfig?: OnPremConfig;
    IsServerlessKubernetes?: boolean;
    selected?: boolean;
    toggled?: boolean;
    ImportVpcConfig?: {
        VpcId?: string;
        EnableMasterVpcPeering?: boolean;
    };
    HubName: string;
    Type: number;
    LogAnalyticsConfig: LogAnalyticsConfig;
    RecoveryVaultConfig: RecoveryVaultConfig;
    private _statusColor;
    get StatusColor(): string;
    private _status;
    get Status(): string;
    get IsInfraFailed(): boolean;
    /** Human-readable name of the current cloud. */
    get CloudName(): string;
    /** Human-readable name of the CSP-managed Kubernetes in the current cloud. */
    get K8sName(): string;
    get isGKE(): boolean;
    /** Human-readable name of the VNET in the current cloud.*/
    get VpcName(): "VNET" | "VPC";
    /** What to call a firewall in the currently selected cloud. */
    get FirewallName(): "Firewall" | "Security Group";
    get isAWS(): boolean;
    get isAzure(): boolean;
    get isOracle(): boolean;
    /** Whether or not Kubernetes is available for the currently selected cloud. */
    get isK8sAvailable(): boolean;
    get K8sVersion(): string;
    set K8sVersion(value: string);
    get EksVisibility(): string;
    set EksVisibility(value: string);
    get GkeReleaseChannel(): string;
    set GkeReleaseChannel(value: string);
    get isNatGatewayEnabled(): boolean;
    getCustomDataValue(key: string): string;
    deleteCustomData(key: string): void;
    putCustomData(key: string, value: string): void;
}
interface Vnet {
    AddressPrefix: string;
    SubnetCidr: number;
    Subnets: Subnet[];
    SecurityGroups: SecurityGroup[];
    P2SRootCerts: any[];
    Id: string;
    Name: string;
    CustomPublicSubnetCidrs: string[];
    CustomPrivateSubnetCidrs: string[];
}
declare class OnPremConfig {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Partial<OnPremConfig>);
    Datacenter: string;
    OnPremK8Config: OnPremK8Config;
}
declare class OnPremK8Config {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Partial<OnPremK8Config>);
    Name: string;
    ClusterEndpoint: string;
    ApiToken: string;
    CertificateAuthorityDataBase64: string;
    Vendor: K8sVendor;
    OnPremEKSConfig: OnPremEKSConfig;
}
declare class OnPremEKSConfig {
    /** Convenience constructor for deserialization or cloning.  */
    constructor(properties?: Partial<OnPremEKSConfig>);
    PrivateSubnets: string[];
    PublicSubnets: string[];
    VpcId: string;
    IngressSecurityGroupIds: string[];
    get PrivateSubnetString(): string;
    get PublicSubnetString(): string;
    get IngressSecurityGroupIdString(): string;
}
interface SecurityGroup {
    Name: string;
    SystemId?: string;
    Rules: SecurityGroupRule[];
    ReadOnly?: boolean;
    SgType?: string;
    SubnetName?: string;
}
declare class SecurityGroupRule {
    constructor(properties?: Object | SecurityGroupRule);
    Name: string;
    SrcRuleType: number;
    SrcAddressPrefix?: string;
    DstRuleType: number;
    SourcePortRange?: string;
    Protocol: string;
    Direction: string;
    RuleAction: string;
    Priority: number;
    DstAddressPrefix?: string;
    DestinationPortRange?: string;
}
declare class Subnet {
    constructor(properties?: Object | Subnet);
    AddressPrefix: string;
    InfrastructureName?: string;
    NameEx: string;
    Id: string;
    SubnetType?: string;
    ServiceEndpoints?: any[];
    IsolatedNetwork?: boolean;
    [index: string]: any;
    toggled?: boolean;
}
declare class CloudCredential {
    Platform: CloudPlatform;
    username: string;
    password: string;
    email: string;
    AccountId: string;
    MetaData?: CustomData[];
    /** Only set by the UI. */
    constructor(properties?: any | CloudCredential);
    /** Human-readable name of the current cloud. */
    get CloudName(): string;
    get DisplayName(): string;
    set DisplayName(value: string);
    get Fingerprint(): string;
    set Fingerprint(value: string);
    get ObjectId(): string;
    set ObjectId(value: string);
    get TenantId(): string;
    set TenantId(value: string);
    get canUpdate(): boolean;
    get canDelete(): boolean;
    getMetadataValue(key: string): string;
    deleteMetadata(key: string): void;
    putMetadata(key: string, value: string): void;
}
declare class CloudCredentialRequest extends CloudCredential {
    State: 'delete' | null;
    constructor(properties?: Partial<CloudCredentialRequest>);
}
interface LogAnalyticsConfig {
    Name: string;
    SharedKey: string;
    CustomerId: string;
}
interface RecoveryVaultConfig {
    Name: string;
    ResourceGroup: string;
}
declare class InfrastructureASG {
    constructor(properties?: Object | InfrastructureASG);
    "properties.provisioningState": string;
    etag: string;
    id: string;
    name: string;
    type: string;
    location: string;
}
declare class SecurityGroupRuleRequest {
    constructor(properties?: Object | SecurityGroupRuleRequest);
    Name: string;
    SgName: string;
    RulesToAdd: SecurityGroupRule[];
    [index: string]: any;
}
declare class EnableAzureSettings {
    constructor(properties?: Object | EnableAzureSettings);
    name: string;
    resourceGroup: string;
}
declare const subnetTypes: {
    value: string;
    label: string;
}[];
declare const serviceEndpointTypes: {
    label: string;
    value: number;
}[];
declare class LogAnalyticsWorkSpace {
    constructor(properties?: Object | LogAnalyticsWorkSpace);
    "properties.provisioningState": string;
    "properties.customerId": string;
    "properties.sku": PropertiesSku;
    "properties.retentionInDays": number;
    "properties.publicNetworkAccessForIngestion": string;
    "properties.publicNetworkAccessForQuery": string;
    location: string;
    id: string;
    name: string;
    type: string;
}
interface PropertiesSku {
    name: string;
}
declare class RecoveryServicesVault {
    constructor(properties?: Object | RecoveryServicesVault);
    properties: RsvProperties;
    sku: Sku;
    location: string;
    id: string;
    name: string;
    type: string;
    eTag: string;
}
interface RsvProperties {
    provisioningState: string;
    privateEndpointStateForBackup: string;
    privateEndpointStateForSiteRecovery: string;
}
interface Sku {
    name: string;
}
declare class AzureK8sSupportedVersion {
    constructor(properties?: Partial<AzureK8sSupportedVersion>);
    Version: string;
    PatchVersions: string[];
}
declare class VmSize {
    constructor(properties?: Partial<VmSize>);
    Name: string;
    NumberOfCores: number;
    MemoryInMB: number;
}
declare class VaultBackupPolicy {
    constructor(properties?: Partial<VaultBackupPolicy>);
    properties: VbpProperties;
    id: string;
    name: string;
    type: string;
    get scheduledTime(): string;
}
declare class VbpProperties {
    constructor(properties?: Partial<VbpProperties>);
    instantRPDetails: InstantRPDetails;
    schedulePolicy: SchedulePolicy;
    retentionPolicy: RetentionPolicy;
    instantRpRetentionRangeInDays: number;
    timeZone: string;
    protectedItemsCount: number;
    backupManagementType: string;
}
interface InstantRPDetails {
}
declare class RetentionPolicy {
    constructor(properties?: Partial<RetentionPolicy>);
    dailySchedule: DailySchedule;
    retentionPolicyType: string;
    weeklySchedule: WeeklySchedule;
}
declare class DailySchedule {
    constructor(properties?: Partial<DailySchedule>);
    retentionTimes: string[];
    retentionDuration: RetentionDuration;
}
declare class WeeklySchedule {
    constructor(properties?: Partial<WeeklySchedule>);
    daysOfTheWeek: string[];
    retentionTimes: string[];
    retentionDuration: RetentionDuration;
}
declare class RetentionDuration {
    constructor(properties?: Object | RetentionDuration);
    count: number;
    durationType: string;
}
declare class SchedulePolicy {
    constructor(properties?: Object | SchedulePolicy);
    scheduleRunFrequency: string;
    scheduleRunTimes: string[];
    scheduleRunDays: string[];
    schedulePolicyType: string;
}
declare class AadConfig {
    constructor(properties?: Partial<AadConfig>);
    IsManagedAadEnabled?: boolean;
    IsAzureRbacEnabled?: boolean;
    TenantId?: string;
    AdminGroupObjectIds?: string[];
}
declare class InfrastructureAksConfig {
    constructor(properties?: Object | InfrastructureAksConfig);
    Name: string;
    VmSize: string;
    CreateAndManage: boolean;
    State: string;
    K8sVersion?: string;
    PrivateCluster?: boolean;
    NetworkPlugin?: string;
    NodeResourceGroup?: string;
    OutboundType?: string;
    EnableAutoScaling?: boolean;
    NodeCount?: number;
    MaxCount?: number;
    MinCount?: number;
    MaxPods?: number;
    PricingTier: string;
    ImageCleanerIntervalInDays?: number;
    EnableImageCleaner?: boolean;
    DisableRunCommand?: boolean;
    EnableBlobCsiDriver?: boolean;
    EnableWorkloadIdentity?: boolean;
    SystemAgentPoolTaints?: string[];
    AddCriticalTaintToSystemAgentPool?: boolean;
    AadConfig: AadConfig;
    LinuxAdminUsername?: string;
    LinuxSshPublicKey?: string;
    get NetworkPluginString(): string;
    get OutboundTypeString(): string;
}
declare class VpcEndpoint {
    constructor(properties?: Object | Partial<VpcEndpoint>);
    VpcEndpointId: string;
    Tags: KeyStringValue[];
    SubnetIds: string[];
    State: ValueObj;
    ServiceName: string;
    RouteTableIds: string[];
    RequesterManaged: boolean;
    PrivateDnsEnabled: boolean;
    PolicyDocument: string;
    OwnerId: string;
    NetworkInterfaceIds: string[];
    LastError: LastError;
    IpAddressType: string;
    Groups: SecurityGroupIdentifier[];
    DnsOptions: DnsOptions;
    DnsEntries: DnsEntry[];
    CreationTimestamp: string;
    VpcEndpointType: ValueObj;
    VpcId: string;
    get PrivateDnsStatus(): string;
}
interface LastError {
    Code: string;
    Message: string;
}
interface SecurityGroupIdentifier {
    GroupId: string;
    GroupName: string;
}
interface DnsOptions {
    DnsRecordIpType: string;
}
interface DnsEntry {
    DnsName: string;
    HostedZoneId: string;
}
interface ValueObj {
    Value: string;
}
declare class CreateVpcEndpointRequest {
    constructor(properties?: Object | Partial<CreateVpcEndpointRequest>);
    VpcEndpointType: ValueObj;
    ServiceName: string;
}
declare class ServiceDetail {
    constructor(properties?: Object | Partial<ServiceDetail>);
    AcceptanceRequired: boolean;
    AvailabilityZones: string[];
    BaseEndpointDnsNames: string[];
    ManagesVpcEndpoints: boolean;
    owner: string;
    PayerResponsibility: ValueObj;
    PrivateDnsName: string;
    PrivateDnsNames: PrivateDnsDetails[];
    PrivateDnsNameVerificationState: ValueObj;
    ServiceId: string;
    ServiceName: string;
    ServiceType: ServiceTypeDetail[];
    SupportedIpAddressTypes: string[];
    Tags: KeyStringValue[];
    VpcEndpointPolicySupported: boolean;
}
interface PrivateDnsDetails {
    PrivateDnsName: string;
}
interface ServiceTypeDetail {
    ServiceType: ValueObj;
}
declare class GcpInfraPeering {
    constructor(properties?: Partial<GcpInfraPeering>);
    PeeringName: string;
    SourceVpc: string;
    DestinationVpc: string;
    ExportCustomRoutes: boolean;
    ImportCustomRoutes: boolean;
    ImportSubnetRoutesWithPublicIp: boolean;
    ExportSubnetRoutesWithPublicIp: boolean;
    Status?: string;
    get sourceInfra(): string;
    get destinationInfra(): string;
    get statusBadge(): TableStatus$1;
    static InfraPeeringStatusMap: Map<string, string>;
    get showDelete(): boolean;
}
declare class GkeEnableK8s {
    constructor(properties?: Partial<GkeEnableK8s>);
    EnableK8Cluster: boolean;
    IsServerlessKubernetes: boolean;
    K8sVersion: string;
    GkeEndpointVisibility: string;
    GkeChannel: string;
    ClusterIpv4Cidr: string;
    static readonly K8sServerlessOption: {
        value: boolean;
        label: string;
    }[];
    static readonly ChannelOptions: SelectOption[];
    static readonly VisibilityOptions: {
        value: string;
        label: string;
    }[];
}
declare class GkeClusterMaintenancePolicy {
    constructor(properties?: Partial<GkeClusterMaintenancePolicy>);
    Exclusions: GkeMaintenanceExclusion[];
    DailyMaintenanceStartTime?: Date;
    RecurringWindow: GkeMaintenanceRecurringWindow;
}
declare class GkeMaintenanceRecurringWindow {
    constructor(properties?: Partial<GkeMaintenanceRecurringWindow>);
    StartTime: string;
    EndTime: string;
    Recurrence: string;
    StartTimeError: string;
    EndTimeError: string;
}
declare class GkeMaintenanceExclusion {
    constructor(properties?: Partial<GkeMaintenanceExclusion>);
    StartTime: string;
    EndTime: string;
    Scope: string;
    StartTimeError: string;
    EndTimeError: string;
}
declare enum GkeMaintenanceExclusionScope {
    NO_UPGRADES = "No upgrades",
    NO_MINOR_UPGRADES = "No minor upgrades",
    NO_MINOR_OR_NODE_UPGRADES = "No minor or node upgrades"
}
declare const OracleRegionOptions: string[];
interface AzureResourceType {
    Namespace: string;
    Type: string;
}
interface AzureResourceId {
    ResourceType: AzureResourceType;
    Name: string;
    Parent?: AzureResourceId;
    SubscriptionId?: string;
    ResourceGroupName?: string;
}
interface AzureNatGatewayPublicIPAddress {
    Id: AzureResourceId;
}
interface AzureNatGatewaySubnet {
    Id: AzureResourceId;
}
interface AzureNatGatewayLocation {
    Name: string;
    DisplayName: string;
}
interface AzureNatGatewayUpdateRequest {
    NatGatewayName: string;
    VirtualNetworkName: string;
    SubnetsToBeAttached: string[];
}
declare class AzureNatGateway {
    SkuName: any;
    Zones: string[];
    ETag: any;
    IdleTimeoutInMinutes: number;
    PublicIPAddresses: AzureNatGatewayPublicIPAddress[];
    PublicIPAddressesV6: any[];
    PublicIPPrefixes: any[];
    PublicIPPrefixesV6: any[];
    Subnets: AzureNatGatewaySubnet[];
    ResourceGuid: string;
    ProvisioningState: any;
    Id: AzureResourceId;
    Name: string;
    ResourceType: AzureResourceType;
    Location: AzureNatGatewayLocation;
    Tags: {
        [key: string]: string;
    };
    constructor(properties?: Partial<AzureNatGateway>);
}

declare class UsersInfo {
    constructor(properties?: Object | UsersInfo);
    Username: string;
    Roles: UserRole[];
    Role: UserRole;
    UserSource?: UserRoleSource | '';
    VpnPassword: string;
    VpnStaticIp?: string;
    ApiTokens: UserApiToken[];
    IsReadOnly: boolean;
    IsVpnConfigCreated: boolean;
    IsConfirmationEmailSent: boolean;
    Devspaces: UserDevspace;
    VpnServerUrl?: string;
    LastLoggedIn?: string;
    get isDuploUser(): boolean;
    get isOktaUser(): boolean;
    get isAdmin(): boolean;
}
declare class UserTenantNames {
    constructor(name?: string);
    name: string;
}
declare class UserVPNConfig {
    constructor(properties?: Partial<UserVPNConfig>);
    "access_from.0": string;
    "access_to.0": string;
    conn_ip: string;
    pvt_password_digest: string;
    type: string;
}
declare class UserUpdateRequest extends UsersInfo {
    constructor(properties?: object | UserUpdateRequest);
    ReallocateVpnAddress: boolean;
    RegenerateVpnPassword: boolean;
    ResetVpnConfig: boolean;
    State: string;
    Permissions?: string[];
    PermissionGroups?: string[];
}
declare class UserTokenResponse {
    constructor(properties?: object | UserTokenResponse);
    Name: string;
    Token: string;
}
declare class UpdateUserVPNInfo {
    constructor(properties?: object | UpdateUserVPNInfo);
    Username: string;
    State: string;
    ReallocateVpnAddress: string;
    RegenerateVpnPassword: string;
    IsReadOnly: boolean;
    ResetVpnConfig: true;
}
declare class BatchAddUserAccessRequest {
    constructor(properties?: Partial<BatchAddUserAccessRequest>);
    Username: string;
    TenantAccessQueries: TenantAccessQuery;
    AddToAllTenants: boolean;
    AddToAllExceptDefault: boolean;
}
declare class AssignMultipleUsersToTenantRequest {
    constructor(properties?: Partial<AssignMultipleUsersToTenantRequest>);
    Users: string[];
    TenantAccessQueries: TenantAccessQuery;
}
declare class UserConstants {
    static readonly roleBadgeStyles: Map<UserRole, string>;
}

/**
 * Runtime configuration consumed by common-lib services. Supplied by each host app
 * (portal, ai-studio, …) via `CommonLibModule.forRoot(...)` so the library owns no
 * consumer-specific environment values and stays publishable.
 */
interface CommonLibConfig {
    /** API base URL. `DuploApiInterceptor` prepends this to root-relative requests. */
    apiUrl: string;
    /** Mixpanel project token. Empty/undefined disables analytics. */
    mixpanelToken?: string;
}
/**
 * Defaults used when a consumer does not call `forRoot` (or omits fields).
 *  - `apiUrl: '/'` keeps root-relative requests same-origin: `'/v1/x'` → `'/' + 'v1/x'`.
 *  - `mixpanelToken: ''` leaves analytics disabled.
 */
declare const DEFAULT_COMMON_LIB_CONFIG: CommonLibConfig;
/**
 * Tree-shakable root-provided token. Resolves to the defaults above when no provider
 * is registered, so services never fail injection. `CommonLibModule.forRoot(...)`
 * overrides it at the app's root injector.
 */
declare const COMMON_LIB_CONFIG: InjectionToken<CommonLibConfig>;

/**
 * Root configuration module for common-lib. Import once per app via
 * `CommonLibModule.forRoot({ apiUrl, mixpanelToken })`. Any omitted field falls back
 * to {@link DEFAULT_COMMON_LIB_CONFIG}. Apps that skip `forRoot` entirely still work,
 * resolving the defaults through the {@link COMMON_LIB_CONFIG} token's root factory.
 */
declare class CommonLibModule {
    static forRoot(config?: Partial<CommonLibConfig>): ModuleWithProviders<CommonLibModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonLibModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonLibModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonLibModule>;
}

/**
 * Convert raw text containing ANSI escape sequences into colored, XSS-safe HTML.
 *
 * `ansi-to-html` (with `escapeXML: true`) escapes &lt;/&gt;/&amp; in the source text BEFORE
 * inserting its own `<span style="color:...">` tags — so the post-conversion string
 * is safe to mark trusted. We only bypass sanitization on the converted output.
 *
 * SECURITY INVARIANT: `escapeXML: true` is the XSS control here — the input is
 * attacker-influenceable customer CLI output (terraform/git logs). It MUST stay true.
 * Do not switch to `DomSanitizer.sanitize(SecurityContext.HTML, …)`: that strips the
 * inline-style color spans the converter emits, defeating the purpose.
 *
 * Use inside a `<pre>` so newlines + monospace render correctly.
 */
declare class AnsiToHtmlPipe implements PipeTransform {
    private readonly converter;
    private readonly sanitizer;
    transform(text: string | null | undefined): SafeHtml;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnsiToHtmlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<AnsiToHtmlPipe, "ansiToHtml", true>;
}

declare class CustomDataKeyToValue implements PipeTransform {
    transform(dataArray: Array<{
        Key: string;
        Value: any;
    }>, key: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomDataKeyToValue, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CustomDataKeyToValue, "customDataKeyToValue", false>;
}

declare class TimeAgoPipe implements PipeTransform {
    transform(value: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimeAgoPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TimeAgoPipe, "timeAgo", true>;
}

/**
 * Pure value-coercion helpers shared by the settings services. Each returns the typed value when
 * the setting matches the expected type — coercing (with a console.warn) for String/Number, and
 * falling back to the caller default for Bool/Json mismatches and for a missing setting (null).
 * `context` is used only in the warning message (e.g. the calling service name).
 */
declare function asString(s: AISystemSetting | null, name: string, def: string | null, context?: string): string | null;
declare function asNumber(s: AISystemSetting | null, name: string, def: number | null, context?: string): number | null;
declare function asBool(s: AISystemSetting | null, name: string, def: boolean | null, context?: string): boolean | null;
declare function asJson<T>(s: AISystemSetting | null, name: string, def: T | null, context?: string): T | null;

declare class AIAutomationService {
    isInIframe: boolean;
    activeActionId: string;
    private _event$;
    get events$(): Observable<{
        eventName: string;
        actionId: string;
        [key: string]: any;
    }>;
    constructor();
    initMessageListener(): Promise<void>;
    removeMessageListener(): void;
    private _handleParentMessages;
    /**
     * Emits an event either to the parent window via postMessage or through the internal subject
     * @param eventName - Name of the event to emit
     * @param actionId - Optional identifier for the action (default: undefined)
     * @param additionalData - Optional additional data to include with the event (default: null)
     */
    private _emitEvent;
    /**
     * Simulates a sequence of user interactions based on provided actions
     * @param actions - Array of AIUIAction objects defining the user interactions to perform
     * @param actionId - Unique identifier for this sequence of actions
     * @returns Promise that resolves when all actions have been completed
     */
    private _simulateUserFlow;
    private _wait;
    private _simulateHover;
    private _simulateInput;
    /**
     * Attempts to find an HTML element using the provided selector with multiple retries
     * @param selector - CSS selector string to find the element
     * @param maxRetries - Maximum number of retry attempts (default: 3)
     * @param retryDelay - Delay in milliseconds between retry attempts (default: 2000)
     * @returns Promise resolving to the found HTMLElement or null if not found
     */
    private _findElementWithRetry;
    /**
     * Simulates a sequence of user interactions based on provided actions
     * @param actions - Array of AIUIAction objects defining the user interactions to perform
     * @param actionId - Unique identifier for this sequence of actions
     * @returns Promise that resolves when all actions have been completed
     */
    private _highlightElement;
    /**
     * Cleans up highlight effects and disconnects observer
     * @param element - The highlighted element
     * @param chevIcon - The chevron icon element
     * @param observer - The mutation observer
     */
    private _cleanupHighlight;
    static ɵfac: i0.ɵɵFactoryDeclaration<AIAutomationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AIAutomationService>;
}

declare class AIUIAction {
    constructor(properties?: Partial<AIUIAction>);
    action: string;
    selector?: string;
    action_type?: string;
    value?: string;
    waitBefore?: number;
    waitAfter?: number;
    uid?: string;
    href?: string;
}
declare class AIUIActionEvent {
    eventName: string;
    actions?: AIUIAction[];
    actionId?: string;
    [key: string]: any;
    constructor(properties?: Partial<AIUIActionEvent>);
}
declare function sendToHelpDesk(eventName: string, data?: {
    [key: string]: any;
}): void;
declare const DUPLO__AUTO_HELPDESK_START_ACTION = "DUPLO__AUTO_HELPDESK_START_ACTION";
declare const DUPLO__AUTO_ACTIONS_IFRAME_READY = "DUPLO__AUTO_ACTIONS_IFRAME_READY";
declare const DUPLO__AUTO_ACTIONS_IFRAME_START = "DUPLO__AUTO_ACTIONS_IFRAME_START";
declare const DUPLO__AUTO_ACTIONS_IFRAME_DONE = "DUPLO__AUTO_ACTIONS_IFRAME_DONE";

/**
 * Builds the application's main menu. Supplied by the consuming app (portal, ai-studio, …)
 * via `CoreMenuService.registerMenuBuilder` so this generic service holds no app-specific
 * menu definition and no dependency on the host's source tree. See `setMainMenu`.
 */
type MenuBuilderFn = (features: SystemFeatures, session: UserSession, appType?: AppType) => CoreMenu[];
interface AppTile {
    name: string;
    icon: string;
    route: string;
    disabled?: boolean;
    type: AppType;
}
declare class CoreMenuService {
    private session;
    private location;
    private features;
    currentUser: UserPrincipal;
    readonly onItemCollapsed: Subject<any>;
    readonly onItemCollapseToggled: Subject<any>;
    readonly onSectionCollapsed: Subject<any>;
    readonly onSectionCollapseToggled: Subject<any>;
    readonly onMenuScrolled: Subject<void>;
    private _onMenuRegistered;
    private _onMenuUnregistered;
    private _onMenuChanged;
    private _currentMenuKey;
    private _registry;
    private _currentAppType$;
    private _menuBuilder;
    /**
     * Constructor
     *
     * @param {Router} _router
     * @param {AuthNZService} _authnz
     */
    constructor(session: UserSession, location: Location, features: SystemFeatures);
    get onMenuRegistered(): Observable<any>;
    get onMenuUnregistered(): Observable<any>;
    get onMenuChanged(): Observable<any>;
    get currentAppType(): AppType;
    get currentAppType$(): Observable<AppType>;
    replace(key: any, menu: any): void;
    /**
     * Register the provided menu with the provided key
     *
     * @param key
     * @param menu
     */
    register(key: any, menu: any): void;
    /**
     * Unregister the menu from the registry
     *
     * @param key
     */
    unregister(key: any): void;
    /**
     * Get menu from registry by key
     *
     * @param key
     * @returns {any}
     */
    getMenu(key: any): any;
    /**
     * Get current menu
     *
     * @returns {any}
     */
    getCurrentMenu(): any;
    /**
     * Set menu with the key as the current menu
     *
     * @param key
     */
    setCurrentMenu(key: any): void;
    getUrlByTitle(children: any[], fullPath: string): string | null;
    setUrlBasedAppType(routeUrl?: string): CoreMenu[];
    /**
     * Registers the host application's menu builder. Call once during app bootstrap
     * (before anything triggers `setMainMenu`) — the portal does this in
     * `AppComponent`'s constructor. Keeps the menu definition in the host so this
     * library stays free of any dependency on the consuming app's source tree.
     */
    registerMenuBuilder(build: MenuBuilderFn): void;
    setMainMenu(appType?: AppType): CoreMenu[];
    getAvailableApps(): AppTile[];
    getDefaultAppType(): AppType;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreMenuService>;
}

declare class AuthNZGuard {
    private _router;
    private _session;
    private static readonly BROWSER_IGNORE_PATHS;
    constructor(_router: Router, _session: UserSession);
    /**
     * Checks if a given browser URL is ignored for auth guards.
     *
     * @param routerUrl a browser URL as formatted by the Angular router (which omits the origin)
     * @returns true, if this browser URL is ignored for auth guards, false otherwise
     */
    static isUrlIgnored(routerUrl: string): boolean;
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree>;
    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthNZGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthNZGuard>;
}
/**
 * NOTE:  This must run *AFTER* the AuthNZGuard.
 */
declare class SubscriptionsGuard {
    private _router;
    private _session;
    private _error;
    constructor(_router: Router, _session: UserSession, _error: ErrorReporter);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean | UrlTree>;
    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean | UrlTree>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionsGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionsGuard>;
}
declare class SystemSettingGuard {
    private _coreMenuService;
    private _features;
    private _router;
    constructor(_coreMenuService: CoreMenuService, _features: SystemFeatures, _router: Router);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean | UrlTree>;
    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean | UrlTree>;
    private checkAccess;
    static ɵfac: i0.ɵɵFactoryDeclaration<SystemSettingGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SystemSettingGuard>;
}

/**
 * Simple middleware to inject the user's bearer token into a Duplo API call.
 */
declare class BearerTokenInterceptor implements HttpInterceptor {
    private session;
    constructor(session: UserSession);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BearerTokenInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BearerTokenInterceptor>;
}
/**
 * Simple middleware to inject the Duplo CI JWT token into a Duplo CI API call.
 */
declare class DuploCiTokenInterceptor implements HttpInterceptor {
    private session;
    constructor(session: UserSession);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploCiTokenInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploCiTokenInterceptor>;
}
declare class DuploCiApiInterceptor implements HttpInterceptor {
    private session;
    constructor(session: UserSession);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploCiApiInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploCiApiInterceptor>;
}
/**
 * Simple middleware to handle authnz failures by redirecting to a login or error page.
 */
declare class ErrorInterceptor implements HttpInterceptor {
    private session;
    private router;
    private injector;
    constructor(session: UserSession, router: Router, injector: Injector);
    intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>>;
    private getLocationPath;
    private get toastrService();
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorInterceptor>;
}

interface CacheEntry<T> {
    data: T;
    timestamp: number;
    key: string;
}
/**
 * Base class providing generic caching functionality for HTTP responses.
 * Services can extend this class to get caching capabilities.
 */
declare abstract class CacheResponseService {
    protected cache: Map<string, CacheEntry<any>>;
    protected readonly CACHE_TTL: number;
    /**
     * Check if a cached entry is still valid based on TTL
     */
    protected isCacheValid(key: string): boolean;
    /**
     * Get data from cache or fetch from source if cache is invalid/missing
     * @param key - Cache key
     * @param fetchFn - Function that returns Observable to fetch fresh data
     * @returns Observable of cached or fetched data
     */
    protected getCacheOrFetch<T>(key: string, fetchFn: () => Observable<T>): Observable<T>;
    /**
     * Invalidate cache entries by exact key or pattern matching
     * @param keyOrPattern - Exact key to delete, or undefined to clear all
     * @param additionalPattern - Additional pattern to match (for multi-part keys)
     */
    protected invalidateCache(keyOrPattern?: string, additionalPattern?: string): void;
    /**
     * Delete a specific cache entry by exact key
     */
    protected deleteCache(key: string): void;
    /**
     * Clear all cache entries
     */
    protected clearCache(): void;
}

declare const CORE_CUSTOM_CONFIG: InjectionToken<unknown>;
declare class CoreConfigService {
    private _router;
    private _config;
    localConfig: CoreConfig;
    private readonly _defaultConfig;
    private _configSubject;
    /**
     * Constructor
     *
     * @param _config
     * @param {Router} _router
     */
    constructor(_router: Router, _config: any);
    set config(data: DeepPartial<CoreConfig>);
    get config$(): Observable<CoreConfig>;
    /**
     * Get default config
     *
     * @returns {CoreConfig}
     */
    get defaultConfig(): CoreConfig;
    /**
     * Initialize
     *
     * @private
     */
    private _initConfig;
    /**
     * Saves the configuration to the local storage if the `enableLocalStorage` flag is set in the configuration.
     * It creates a clone of the configuration object, removes the `enableLocalStorage` property, and then saves the
     * configuration to the local storage.
     *
     * @param {CoreConfig} config - The configuration object to be saved.
     */
    private _saveInLocalStorage;
    /**
     * Set config
     *
     * @param data
     * @param {{emitEvent: boolean}} param
     */
    setConfig(data: DeepPartial<CoreConfig>, param?: {
        emitEvent: boolean;
    }): void;
    /**
     * Get config
     *
     * @returns {Observable<CoreConfig>}
     */
    getConfig(): Observable<CoreConfig>;
    /**
     * Get config Subject current value
     *
     * @returns {CoreConfig}
     */
    getConfigValue(): CoreConfig;
    /**
     * Reset to the default config
     */
    resetConfig(): void;
    setLastExtraBreadcrumbs(label: string): void;
    setExtraBreadcrumbs(o: BreadcrumbLink[]): void;
    removeLastBreadcrumb(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreConfigService>;
}

/**
 *  The DuploHttpClient programming API is exactly the same as angular's HttpClient, but all headers
 *  have been added for you.
 *
 *  An alternative pattern to the UI v1 app.service.ts
 *
 *   - Retains all type-safety of HttpClient methods (no more wrapping with "any")
 *   - Does not need to "reimplement" or "expose" HttpClient methods.
 *
 *  See:
 *   - https://indepth.dev/posts/1455/how-to-split-http-interceptors-between-multiple-backends
 */

declare const DUPLO_HTTP_INTERCEPTORS: InjectionToken<HttpInterceptor[]>;
declare const DUPLO_CI_HTTP_INTERCEPTORS: InjectionToken<HttpInterceptor[]>;
declare class InterceptingHandler implements HttpHandler {
    private backend;
    private interceptors;
    private chain;
    constructor(backend: HttpBackend, interceptors: HttpInterceptor[]);
    handle(req: HttpRequest<any>): Observable<HttpEvent<any>>;
    private buildChain;
}
declare class DuploApiInterceptor implements HttpInterceptor {
    private config;
    constructor(config: CommonLibConfig);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploApiInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploApiInterceptor>;
}
declare class DuploHttpClient extends HttpClient {
    constructor(backend: HttpBackend, standardInterceptors: HttpInterceptor[], duploInterceptors: HttpInterceptor[]);
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploHttpClient, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploHttpClient>;
}
declare class DuploCiHttpClient extends HttpClient {
    private zone;
    private session;
    constructor(backend: HttpBackend, zone: NgZone, session: UserSession, standardInterceptors: HttpInterceptor[], duploInterceptors: HttpInterceptor[]);
    loadEventSource<E>(url: string): Observable<MessageEvent<E>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DuploCiHttpClient, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DuploCiHttpClient>;
}

/**
 * Builds a kubeconfig YAML from a {@link K8ClusterConfig} and triggers a
 * browser download. Pure presentation/file-IO concern — JIT access loading
 * stays at the call site since the data source varies (cluster-baselines vs.
 * scopes vs. plans), so callers fetch their own config and hand it to
 * {@link download}.
 *
 * Used by:
 *   - Cluster Baseline view's "Download Kubeconfig" menu item
 *     ({@link ViewClusterBaselineComponent}).
 *
 * Add new callers by injecting this service and calling {@link download} with
 * the loaded K8ClusterConfig + a cluster name. No module wiring required —
 * `providedIn: 'root'`.
 *
 * Note: the YAML carries the JIT token verbatim, which is short-lived (TTL
 * minutes-to-hours depending on backend config). Callers wanting a long-lived
 * `duplo-jit`-backed kubeconfig should use the portal-side
 * `KubeconfigDownloadComponent` instead — it bakes in the exec credential
 * plugin + portal session context.
 */
declare class KubeconfigDownloadService {
    /**
     * Builds the kubeconfig YAML and triggers a browser download. Returns the
     * filename used.
     *
     * @throws Error when {@link K8ClusterConfig.ApiServer} or
     *   {@link K8ClusterConfig.Token} is missing — these mean the cluster isn't
     *   provisioned yet or the JIT response was incomplete.
     */
    download(k8Config: K8ClusterConfig, clusterName: string, namespace?: string): string;
    /**
     * Loads JIT access from `loader$` and downloads the resulting kubeconfig, reporting success
     * and build/download errors via `reporters` — the shared shape every call site (Admin/Workspace
     * scope lists, K8s Resources pages, Namespace list/detail) otherwise repeats verbatim.
     * `loader$` errors (the JIT request itself failing) are NOT reported here — the caller still
     * owns subscribing (with its own `takeUntil`/cleanup) and its own `error` handler for those.
     */
    downloadFrom(loader$: Observable<K8ClusterConfig>, clusterName: string, fallbackNamespace: string, reporters: {
        error: ErrorReporter;
        success: SuccessReporter;
    }): Observable<void>;
    /**
     * Builds + downloads using the modern Blob + temporary anchor approach.
     * No `file-saver` dependency — every browser we target supports this.
     */
    private triggerBrowserDownload;
    static ɵfac: i0.ɵɵFactoryDeclaration<KubeconfigDownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KubeconfigDownloadService>;
}

interface ListQueryState {
    q: string;
    sortBy: string;
    sortOrder: 'asc' | 'desc';
    /** One entry per facet key; null means unfiltered. */
    facets: Record<string, string | null>;
}
interface ListQueryDefaults {
    sortBy: string;
    sortOrder: 'asc' | 'desc';
}
/**
 * Puts a card list's search, facets and sort in the URL, so the view survives a
 * refresh and can be shared. Sort is omitted at its default to keep URLs clean.
 */
declare class ListQueryStateService {
    private readonly location;
    read(route: ActivatedRoute, facetKeys: string[], defaults: ListQueryDefaults): ListQueryState;
    write(state: ListQueryState, defaults: ListQueryDefaults): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListQueryStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ListQueryStateService>;
}

declare class CoreMediaService {
    private _mediaObserver;
    currentMediaQuery: string;
    onMediaUpdate: BehaviorSubject<string>;
    /**
     * Constructor
     *
     * @param {MediaObserver} _mediaObserver
     */
    constructor(_mediaObserver: MediaObserver);
    /**
     * Initialize
     *
     * @private
     */
    private _init;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreMediaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreMediaService>;
}

declare class MixpanelService {
    private config;
    isInitialized: boolean;
    isEnabled: boolean;
    constructor(config: CommonLibConfig);
    /** No project token means init() no-ops, so nothing can ever be tracked. */
    get isConfigured(): boolean;
    initMixpanel(): void;
    grantConsent(): void;
    revokeConsent(): void;
    setDistinctId(id?: string): void;
    identifyUser(user: UserPrincipal): Promise<void>;
    disableMixpanel(): Promise<void>;
    track(eventName: string, properties?: Record<string, any>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MixpanelService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MixpanelService>;
}

/** Internal representation only — the wire format is a tri-state boolean on UserSettings. */
declare enum AnalyticsConsent {
    Granted = "granted",
    Declined = "declined",
    Unset = "unset"
}
interface AnalyticsConsentState {
    globalEnabled: boolean;
    consent: AnalyticsConsent;
}
declare class AnalyticsConsentService {
    private features;
    private aiSettings;
    private session;
    private api;
    private tracker;
    private _state;
    readonly state$: Observable<AnalyticsConsentState>;
    private principal;
    constructor(features: SystemFeatures, aiSettings: AISystemSettingsService, session: UserSession, api: DuploHttpClient, tracker: MixpanelService);
    get isGloballyEnabled(): boolean;
    get consent(): AnalyticsConsent;
    get isTrackingAllowed(): boolean;
    get shouldPrompt(): boolean;
    resolve(user: UserPrincipal): Observable<AnalyticsConsentState>;
    record(value: boolean | null): Observable<void>;
    private gateOnTracker;
    private readConsent;
    private toConsent;
    reset(): void;
    private publish;
    private applyToTracker;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnalyticsConsentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnalyticsConsentService>;
}

declare class NavBackService {
    private router;
    private location;
    private previousRoute;
    private currentRoute;
    constructor(router: Router, location: Location);
    /**
       * Tracks and stores the previous and current routes during navigation.
       *
       * Listens to router navigation events and updates the previousRoute and currentRoute
       * properties whenever a navigation is completed, allowing tracking of route history.
       */
    storeLast(): void;
    /**
       * Retrieves the deepest activated route in the current router state.
       *
       * @returns The most specific ActivatedRoute in the current navigation hierarchy.
       */
    private getCurrentActivatedRoute;
    /**
     * Generates a serialized URL for a relative path based on a given route context.
     *
     * @param relativePath The relative path to convert to a full URL.
     * @param route Optional ActivatedRoute to use as the base context. Defaults to the current route.
     * @returns A fully serialized URL string.
     */
    private getRelativePath;
    /**
     * Navigates back to a route relative to the current route context.
     *
     * @param relativePath A relative path to navigate back to within the current module (e.g., '../' or '../../').
     */
    relativeGoBack(relativePath: string, navExtra?: NavigationExtras): void;
    /**
     * Navigates back to a relevant route within the specified module.
     * If the previous route was within the module, it navigates back.
     * Otherwise, it navigates to the module's base route.
     *
     * @param moduleBasePath The base path of the current module (e.g., '/app/service').
     * @param defaultBackRoute (Optional) A specific route within the module to navigate to if no relevant history is found. Defaults to the moduleBasePath.
     */
    navigateBackToModule(moduleBasePath: string, defaultBackRoute?: string, navExtra?: NavigationExtras): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavBackService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NavBackService>;
}

declare const DEFAULT_REFRESH_INTERVAL: number;
declare class RefreshTimerService {
    /**
     * Creates a refresh timer observable that emits on a fixed interval.
     * @param immediate - If true, emits immediately (delay = 0); otherwise waits one full interval.
     * @param frequency - Interval in ms (default 30 000).
     */
    getTimer(immediate?: boolean, frequency?: number): Observable<number>;
    /**
     * Combines a context observable with a periodic timer and emits `[context, changed]` tuples.
     *
     * Works standalone (pass any `BehaviorSubject.asObservable()`) or inside a
     * domain service such as `ResourceK8sService` / `ResourceAWSService`.
     *
     * @param context$    - Observable that emits the current context value.
     * @param idExtractor - Pure function that pulls a comparable identity from the context
     *                      (e.g. `ctx => ctx.cluster?.scopeId`). Return `null`/`undefined`
     *                      for "no context".
     * @param immediate   - When `true` the very first emission is delivered; when `false`
     *                      the first tick is suppressed (useful when the caller already has
     *                      data and only wants refreshes).
     * @param frequency   - Interval in ms (default 30 000).
     * @param currentId   - Optional starting identity so the first emission can correctly
     *                      report `changed`. When `immediate` is `true` this defaults to
     *                      `null` so the first emission always shows `changed = true`.
     */
    getContextRefreshTimer<T>(context$: Observable<T>, idExtractor: (ctx: T) => string | null | undefined, immediate?: boolean, frequency?: number, currentId?: string | null): Observable<[T, boolean]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RefreshTimerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RefreshTimerService>;
}

declare class TabService {
    constructor();
    activateTabHook(router: Router, destroy$: SubDestroyService, action: (url: string, load: boolean) => void): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TabService>;
}

interface Locale {
    lang: string;
    data: TranslationObject;
}
declare class CoreTranslationService {
    private _translateService;
    private httpClient;
    /**
     * Constructor
     *
     * @param {TranslateService} _translateService
     */
    constructor(_translateService: TranslateService, httpClient: HttpClient);
    /**
     * Translate
     *
     * @param {Locale} args
     */
    translate(...args: Locale[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreTranslationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CoreTranslationService>;
}

/**
 * Returns a deterministic avatar color for a display name using a palette-level WeakMap cache.
 */
declare const DEFAULT_AVATAR_PALETTE: readonly ["var(--blue)", "var(--purple)", "var(--pink)", "var(--red)", "var(--orange)", "var(--green)", "var(--teal)", "var(--cyan)", "var(--info)", "var(--danger)"];
declare function resolveAvatarColor(displayText: string, palette?: readonly string[]): string;

declare class CommonUtils {
    static formatDate(date: Date): string;
    /** Tooltip shown on a disabled Deprovision/Delete action; null when not protected. */
    static deprovisionBlockedReason(resourceType: string, name: string, isDeleteProtected: boolean): string | null;
    /** True when a metadata map has `key` set to 'true' (case- and whitespace-insensitive). */
    static isMetadataFlagTrue(metaData: Record<string, string> | undefined, key: string): boolean;
    static isNullOrEmpty(value: any): boolean;
    static formatFileSize(bytes: number): string;
}

declare const REMOTE_UserSession: InjectionToken<unknown>;
declare const REMOTE_DuploHttpClient: InjectionToken<HttpClient>;
declare const REMOTE_SystemFeatures = "REMOTE_SystemFeatures";
declare const REMOTE_CoreConfigService = "REMOTE_CoreConfigService";
declare const REMOTE_AIAutomationService = "REMOTE_AIAutomationService";
declare const REMOTE_AuthNZService = "REMOTE_AuthNZService";
declare const AI_SUITE_LABEL_CONFIG = "AI_SUITE_LABEL_CONFIG";
declare const DISABLE_HELPDESK_NAV_COLLAPSE = "DISABLE_HELPDESK_NAV_COLLAPSE";
declare const DEFAULT_ACTION_SELECTION = "DEFAULT_ACTION_SELECTION";
declare const HELPDESK_DEFAULT_AGENT_NAME = "helpdesk-default-agent-name";
declare const REMOTE_CanvasRendererRegistry = "REMOTE_CanvasRendererRegistry";

interface AnyObject {
    [key: string]: any;
}
declare function convertKeysToLowerCase(obj: AnyObject): AnyObject;

declare class DateUtils {
    static parseOrEmpty(text: string): Date;
    static nowPlusSeconds(offset: number): Date;
    static duration(from: Date, to: Date): number;
    static durationOrEmpty(from: Date, to: Date): number;
    static durationText(duration: number): string;
    static durationTextOrEmpty(duration: number): string;
    static getDurationBetweenTimestamps(startTime: string, endTime: string): string;
    static getTimeFromDate(date: Date, needSecond?: boolean): string;
    static getDateFromTime(timeStr: string, needSecond?: boolean): Date;
    /**
     * Wraps Angular's `formatDate` — accepts the same format strings as the `date` pipe.
     * Returns an empty string if the input is invalid instead of throwing.
     *
     * @example
     *   DateUtils.formatDate('2026-03-27T10:30:00Z', 'mediumDate')    // 'Mar 27, 2026'
     *   DateUtils.formatDate('2026-03-27T10:30:00Z', 'short')         // '3/27/26, 10:30 AM'
     *   DateUtils.formatDate('2026-03-27T10:30:00Z', 'MMM d, h:mm a') // 'Mar 27, 10:30 AM'
     */
    static formatDate(dateStr: string, format?: string, locale?: string): string;
    private static readonly _mediumFormatter;
    private static getTzAbbr;
    static formatWithTzAbbr(value: string | Date | number, formatter?: Intl.DateTimeFormat): string;
    /**
     * `<input type="date">` yields a bare "yyyy-MM-dd" with no offset. Only the frontend knows
     * the viewer's real offset, so these resolve the ambiguity here and send precise instants:
     * `new Date(\`${d}T00:00:00\`)` parses as browser-local midnight and `.toISOString()` carries
     * that instant's UTC offset through to the wire.
     *
     * Shared by every keyset-paged search filter bar (Audit Trail, Langfuse Sessions) — the
     * backend's ComputeDateBounds trusts these as instants rather than re-deriving a calendar day.
     */
    static toDateFromBound(date?: string): string | undefined;
    /** Local midnight at the START of the day AFTER `date` — the exclusive upper bound the
     * backend needs, since an inclusive "<=" on the selected day's own midnight would exclude
     * virtually the whole day. */
    static toDateToBound(date?: string): string | undefined;
}

declare const DUPLOCONST: {
    sso_url_suffix: string;
    ossec_agent_type: string;
    cloud_resource_prefix: string;
};
declare const TENANT_CONSTS: {
    default_tenant_name: string;
};
declare const DUPLO_CUSTOM_EVENTS: {
    sidebarToggle: string;
};

interface EnumMapOfString<V> {
    [index: string]: V;
}
interface EnumMapOf<V> {
    [index: number]: V;
}
interface EnumMapName<V> {
    [index: string]: V;
}
interface EnumSelectOption<E> {
    value: E;
    label: string;
}
interface NumberSelectOption {
    label: string;
    value: number;
}
interface StringSelectOption {
    label: string;
    value: string;
    subLabel?: string;
}
declare class EnumUtils {
    static SKIP_ENTRY: symbol;
    /**
     * Maps enum entries to a new map, keyed by enum key.
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static mapByKey<T extends Record<StringKeyOf<T>, number>, R>(enumObj: T, mapper: (key: StringKeyOf<T>, value?: number) => R): EnumMapName<R>;
    /**
     * Maps enum entries to a new map, keyed by string key.
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static mapByStringKey<T extends Record<StringKeyOf<T>, string>, R>(enumObj: T, mapper: (key: StringKeyOf<T>, value?: string) => R): EnumMapOfString<R>;
    /**
     * Maps enum entries to a new map, keyed by numeric value.
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static mapByValue<T extends Record<StringKeyOf<T>, number>, R>(enumObj: T, mapper: (key: StringKeyOf<T>, value?: number) => R): EnumMapOf<R>;
    /**
     * Maps enum entries to a new map, keyed by string value.
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static mapByStringValue<T extends Record<StringKeyOf<T>, string>, R>(enumObj: T, mapper: (key: StringKeyOf<T>, value?: string) => R): EnumMapOfString<R>;
    static enumToSelectOptions(enumObj: object): NumberSelectOption[];
    /**
     * Maps an enum value map to select options
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static byValueToSelectOptions<E, V>(valueMap: EnumMapOf<V>): EnumSelectOption<E>[];
    /**
     * Maps an enum value map to select options
     *
     * @param enumObj a typescript enum type
     * @param mapper  a function that maps the enum entries to a new string
     * @returns
     */
    static byStringValueToSelectOptions<E, V>(valueMap: EnumMapOfString<V>): EnumSelectOption<E>[];
    static convertToSelectOptions(s: object): object[];
}

declare class FilterTableUtils {
    static searchByFields: (item: any, keys: string[], searchTerm: any) => boolean;
    static searchInAllFields: (item: any, searchTerm: any) => boolean;
    static getObjectValuesAsStringArray: (obj: any, accu: string[]) => void;
}

declare class JSONUtils {
    static clone(d: any): any;
    static fullClone<T>(d: T): T;
    static isEmptyObject(o: any): boolean;
    static isNotEmptyObject(o: any): boolean;
    static moveAttributeIfExists(source: object, dest: object, attr: string): void;
    static deleteIfExists(o: object, key: any): any;
    static merge(source: object, toBeMerged: object): {};
    static getAndDeletePropertyIfExists(o: any, key: string): string;
    static stringifyPretty(s: any): any;
    static stringifyCompact(s: any): any;
    static isValidJSON(s: string): boolean;
    static parse(s: string): any;
    /**
     * Like parse() but does NOT strip non-ASCII characters (e.g. emoji).
     * Use when the input may contain Unicode beyond printable ASCII.
     */
    static parseSafe(s: string): any;
    static setObjectIfNotEmpty(mainObject: any, key: string, toBeMerged: any): void;
    static setIfNotEmpty(mainObject: any, key: string, toBeMerged: any): any;
    static removeEmptyKeys(obj: any): {};
    static omitPrivate(obj: any): any;
    static isMatchingClass<T>(json: string | any, ClassType: new () => T, options?: {
        checkTypes?: boolean;
        strict?: boolean;
        partial?: boolean;
    }): boolean;
    /**
     * Recursively compares two objects.
     */
    static deepCompare(parsed: any, instance: any, options?: {
        checkTypes?: boolean;
        strict?: boolean;
        partial?: boolean;
    }): boolean;
}

/**
 * Builds the `MARKED_OPTIONS` value for `MarkdownModule.forRoot()`, with one
 * renderer override: links open in a new tab, focusable, with
 * `nofollow noopener noreferrer`.
 *
 * Provide it at the app root only, e.g.
 *   MarkdownModule.forRoot({
 *     markedOptions: { provide: MARKED_OPTIONS, useFactory: markedOptionsFactory }
 *   })
 */
declare function markedOptionsFactory(): {
    renderer: marked.Renderer<string, string>;
    gfm: boolean;
    breaks: boolean;
    pedantic: boolean;
};

/**
 * Subscribes to NavigationStart events on the given Router and dismisses all
 * open modals managed by the given NgbModal instance.
 *
 * ### Why this function exists (Module Federation context)
 * When `@ng-bootstrap/ng-bootstrap` is NOT declared as a shared singleton in
 * webpack-shared-lib.js, each Module Federation bundle (host + remotes) gets
 * its own independent NgbModal instance. A single `providedIn: 'root'` service
 * cannot cover both — it can only hold one NgbModal reference.
 *
 * The solution is for each bundle to call this function with its own NgbModal,
 * while sharing the same Router singleton (which IS shared via webpack-shared-lib).
 *
 * ### Usage
 * Call once on application/module init and unsubscribe on destroy:
 *
 * ```typescript
 * // In AppComponent or a root NgModule constructor:
 * this._navSub = closeModalsOnNavigation(this._router, this._modalService);
 *
 * // In ngOnDestroy / module cleanup:
 * this._navSub.unsubscribe();
 * ```
 *
 * @param router       The Angular Router (shared singleton across MF bundles).
 * @param modalService The NgbModal instance local to the current bundle.
 * @returns A Subscription — unsubscribe it when the calling context is destroyed.
 */
declare function closeModalsOnNavigation(router: Router, modalService: NgbModal): Subscription;

declare class NameUtils {
    static resourceLengthConstraint: {
        s3BucketName: {
            allowedLength: number;
            prefixLength: number;
        };
        lambdaFunctionName: {
            allowedLength: number;
            prefixLength: number;
        };
        elasticSearchDomainName: {
            allowedLength: number;
            prefixLength: number;
        };
        loadBalancerName: {
            allowedLength: number;
            prefixLength: number;
        };
        bigtableInstanceId: {
            allowedLength: number;
            prefixLength: number;
        };
        bigtableClusterId: {
            allowedLength: number;
            prefixLength: number;
        };
    };
    /** Convenience method for feeding a notExists validation.
     *
     *  Returns a list of names *BOTH* with the prefix remove and the prefix present.
     */
    static withAndWithout(prefix: string, list: string[]): string[];
    /** Convenience method for feeding a notExists validation.
     *
     *  Returns a list of names that also includes name versions that have the prefix removed.
     */
    static withAndWithoutDuploServices(tenant: string | UserTenant, list: string[]): string[];
    static fieldAllowedLength(fieldName: string, tenantName: string, allowed?: number, noPrefix?: boolean): number;
}

declare const REMOTE_ENTRY_CACHE_TAG: string;
declare function withCacheTag(url: string): string;

/** Segment depth of the shared `view/:envId/rg/:rgId` prefix every flat full-page
 * resource route is declared under — used as `route.url.length - ENV_RG_PREFIX_DEPTH`
 * to strip a matched flat route back to that prefix before appending the real list path. */
declare const ENV_RG_PREFIX_DEPTH = 4;
/**
 * Navigates up out of the route that failed to resolve — typically back to
 * a resource's list page — instead of leaving the router parked on a broken
 * `view/:id` (or similar) url with no way back. Call this from a resolver's
 * `catchError` alongside `return EMPTY`.
 *
 * `segments` is the number of trailing URL segments to strip, at raw segment
 * granularity — Angular's `../` resolution only escalates to the parent
 * route once `segments` exceeds the current route's own segment count, so a
 * single flat multi-segment route (e.g. `view/:envId/rg/:rgId/app-services/:asId/edit`
 * declared as ONE `Route`) can be partially unwound to land mid-route (back
 * to `.../app-services`) by passing `route.url.length - ENV_RG_PREFIX_DEPTH`.
 *
 * Defaults to `route.url.length`, which strips this route's own segments in
 * full and lands on its immediate parent — correct whenever the resolver's
 * route is a genuine sibling of the page to land on (`view/:id`, `edit/:id`,
 * `:id/ticket/:ticketId`, ...).
 *
 * `appendPath`, when the real list page isn't a sibling at all — e.g. a
 * flat full-page route declared under a different segment name than its
 * embedded counterpart (`.../node-groups/:ngId/edit` vs. the real list at
 * `.../kubernetes-resources/nodes`). Pass the shared-prefix segment count to
 * strip plus the literal path to land on instead.
 */
declare function redirectToParentOnError(router: Router, route: ActivatedRouteSnapshot, segments?: number, appendPath?: string): void;

declare class StringUtils {
    static isEmpty(s: string): boolean;
    static isNotEmpty(s: string): boolean;
    static safetrim(s: string): string;
    static awsUrlEncode(s: string): string;
    static doubleEncode(s: string): string;
    static urlSafeBase64Encode(s: string): string;
    static toFirstLetterUpperCase(s: string): string;
    static removeSpacesInString(srcString: string): string;
    /**
     * The first `limit` characters plus an ellipsis, cut at a word boundary when one
     * falls in the last fifth of the allowance so the tail is not a broken word.
     * Text that already fits comes back untouched, which is how a cell decides
     * whether it needs to offer the full value on hover.
     */
    static truncate(text?: string, limit?: number): string;
    /**
     * Up to `cap` values spelled out, the rest as `+N`, so a summary hint cannot run
     * away. A narrow cell (four cards across a modal) passes a lower cap.
     */
    static truncatedList(values: string[], cap?: number): string;
    /**
     * `6 created · 2 imported`, dropping the parts that are zero — a bucket with
     * nothing in it is noise, not information.
     */
    static summaryLine(parts: [number, string][]): string;
    /** The `n` most frequent values as summaryLine parts; ties break alphabetically. */
    static topCounts(values: string[], n?: number): [number, string][];
    static splitByCapitalLetter(s: string): string;
}

declare class YamlUtils {
    /**
     * Returns the yaml string for the specified json string
     * @param s JSON in string format
     * @returns
     */
    static jsonStringToYaml(s: any): any;
    /**
     *
     * @param y Parse the yaml string into javascript object
     * @returns
     */
    static parse(y: string): any;
    /**
     *  Converts and returns specified javascript object into the yaml string
     * @param o
     * @returns
     */
    static stringify(o: any): string;
    /**
     * Converts yaml string into json string
     *
     * @param y
     * @returns
     */
    static yamlToJsonString(y: string): string;
    /**
     * Parse the yaml string into javascript object after safe trim.
     * Similar to parse with *StringUtils.safetrim* added.
     *
     * @param y
     * @returns
     */
    static parseSafeTrim(y: string): any;
}

export { AIAutomationService, AISUITE_SETTING, AISUITE_SETTINGS, AISUITE_SETTINGS_ADMIN, AISUITE_SETTINGS_COMMON, AISUITE_SETTINGS_FOR_ADMIN, AISUITE_SETTINGS_FOR_WORKSPACE, AISUITE_SETTINGS_WORKSPACE, AISUITE_SETTING_BY_NAME, AISUITE_SETTING_NAME_TO_DISPLAY_NAME, AISettingValueType, AISystemSetting, AISystemSettingRequest, AISystemSettingsDataSource, AISystemSettingsService, AIUIAction, AIUIActionEvent, AIWorkspaceBase, AI_HELPDESK_DEFAULT_ACTION_SELECTION, AI_SETTING_TYPE_LABELS, AI_SUITE_LABEL_CONFIG, ALERT_PRIOR_AUTOSCALING, AUTH_ERROR, AWSAccessToken, AWS_SERVICES_TAG_BASED_OWNERSHIP_ENABLED, AWS_SPECIFIC_TENANT_CONFIG, AadConfig, AccessType, AccountSsoConfig, AddTenantRequest, AdminTenant, AdminTenantAuthInfo, AdminTenantMonitoringConfig, AgentPlatform, AgentPlatformDetails, AgentPlatformUtils, AnalyticsConsent, AnalyticsConsentService, AnimationService, AnsiToHtmlPipe, AppType, AssignMultipleUsersToTenantRequest, AsyncNotExistsValidatorDirective, AuthConfig, AuthNZGuard, AwsUnavailableServices, AzureK8sSupportedVersion, AzureNatGateway, AzureResourcePrefix, BASE_JSON_EDITOR_OPTIONS, BaseEntity, BatchAddUserAccessRequest, BatchAddUserTenantAccessRequest, BearerTokenInterceptor, CANVAS_DOC, COMMON_LIB_CONFIG, CORE_CUSTOM_CONFIG, CacheResponseService, CanvasRendererRegistry, CardGridToolbarComponent, ClipboardService, CloudCredential, CloudCredentialRequest, CloudPlatform$1 as CloudPlatform, CloudPlatformNames, CodeBlockWithCopyComponent, CodeEditorComponent, CommonLibComponentsModule, CommonLibModule, CommonUtils, ConfirmationModalComponent, ConfirmationModalModule, ConfirmationModalRef, ConfirmationModalService, ContainerStatus, CopyToClipboardComponent, CoreCommonModule, CoreConfigService, CoreDirectivesModule, CoreMediaService, CoreMenuService, CorePipesModule, CoreTranslationService, CreateVpcEndpointRequest, CredentialPayload, CronValidatorDirective, CustomData, CustomDataEx, CustomDataKeyToValue, CustomDataUpdate, DEFAULT_ACTION_SELECTION, DEFAULT_AVATAR_PALETTE, DEFAULT_CARD_GRID_SORT_FIELDS, DEFAULT_COMMON_LIB_CONFIG, DEFAULT_FILE_BADGE, DEFAULT_INFRA, DEFAULT_REFRESH_INTERVAL, DISABLE_HELPDESK_NAV_COLLAPSE, DISABLE_PLATFORM, DUPLOCONST, DUPLO_CI_HTTP_INTERCEPTORS, DUPLO_CUSTOM_EVENTS, DUPLO_HTTP_INTERCEPTORS, DUPLO__AUTO_ACTIONS_IFRAME_DONE, DUPLO__AUTO_ACTIONS_IFRAME_READY, DUPLO__AUTO_ACTIONS_IFRAME_START, DUPLO__AUTO_HELPDESK_START_ACTION, DailySchedule, DateUtils, DeleteConfirmationModalComponent, DeleteConfirmationModalRef, DeleteConfirmationModalService, DetailAttachedComponent, DetailCalloutComponent, DetailEmptyComponent, DetailFactComponent, DetailHeaderComponent, DetailKvComponent, DetailLayoutComponent, DetailSectionComponent, DetailSideContentDirective, DetailTimelineComponent, DiffMergeComponent, DiffRenderComponent, DisableForReadonlyUserDirective, DocDiffOpType, DuploApiInterceptor, DuploCiApiInterceptor, DuploCiClientConfig, DuploCiHttpClient, DuploCiTokenInterceptor, DuploHttpClient, DuploToastrService, DuploValidators, DynamicStyleLoaderService, EMPTY_GUID, EMPTY_WORKSPACE, EMPTY_WORKSPACE_ID, ENABLE_AI_SUITE, ENV_RG_PREFIX_DEPTH, ERROR_REPORTER, EXPANDABLE_LIST_TONES, EXPIRE_SECONDS_EARLY, EXT_BADGE_MAP, EmailValidatorDirective, EnableAzureSettings, EntityFileEditorWrapperComponent, EnumUtils, ErrorInterceptor, ErrorSummary, ExpandFormFieldIconComponent, ExpandableFieldDirective, ExpandableListComponent, FILE_BADGE_MAP, FILE_LANG_MAP, FOLDER_COLOR, FeatherIconDirective, FileDetailsModalComponent, FileEditorService, FileEditorWrapperComponent, FileIconComponent, FileTabsComponent, FileTreeComponent, FileTreeNodeComponent, FilterPillsComponent, FilterPipe, FilterTableUtils, FlatDropdownFilter, FlatDropdownFilterComponent, FlatStatusFilter, FlatStatusFilterComponent, FlattenedGcpNetworkSecurityRule, FlattenedTenantNetworkSecurityRule, FormElementsCollapsableGroupComponent, FormFieldAlert, FormFieldAlertComponent, FormFieldComponent, FormFieldErrorsComponent, FormGroupErrorsComponent, FormKeyValFieldComponent, FormRefDirective, GKE_MIN_PORTS_PER_VM, GcpInfraPeering, GcpLogConfig, GcpNetworkSecurityRule, GcpNetworkSecurityRuleCreateRequest, GcpRegionFeatures, GcpTenantNetworkSecurityRuleCreateRequest, GcpTenantNetworkSecurityRuleType, GenericFormFieldComponent, GenericFormInput, GkeClusterMaintenancePolicy, GkeEnableK8s, GkeMaintenanceExclusion, GkeMaintenanceExclusionScope, GkeMaintenanceRecurringWindow, HELPDESK_DEFAULT_AGENT_NAME, HdUserProfileDataSource, HelpDirective, HelpIconComponent, HelpModule, HelpdeskApiToken, HideForReadonlyUserDirective, INDENT_JSON_EDITOR_OPTIONS, INFRA_AZURE_NAT_GATEWAY, INFRA_CLUSTER_AUTOSCALER, INFRA_CUSTOM_DATA_SPECS, INFRA_DUPLO_CI_CERTIFICATE, INFRA_DUPLO_CI_TENANT, INFRA_EKS_CSI_SNAPSHOT, INFRA_EKS_LOGGING, INFRA_EKS_LOG_TYPES, INFRA_EKS_VISIBILITY, INFRA_EKS_VPN_ACCESS, INFRA_ENABLE_EKS_WINDOWS_WORKLOAD, INFRA_GCP_DYNAMIC_PORT_ALLOCATION, INFRA_GKE_GATEWAY_API, INFRA_GKE_RELEASE_CHANNEL, INFRA_GKE_VISIBILITY, INFRA_HELM_OPERATOR_FLUXV2, INFRA_HELM_OPERATOR_FLUXV2_DISABLED, INFRA_HELM_OPERATOR_FlUXV1, INFRA_HELM_OPERATOR_VERSION, INFRA_K8S_VERSION, INFRA_MAXIMUM_K8S_SESSION_DURATION, INFRA_OKE_VISIBILITY, INI_EDITOR_OPTIONS, IPv4Regex, IPv6Regex, IconModule, IframeConfigs, Infrastructure, InfrastructureASG, InfrastructureAksConfig, InfrastructureECSConfigUpdate, InfrastructureEKSConfigUpdate, IniValidationDirective, InitialsPipe, InputTextTrimDirective, InterceptingHandler, Ipv4Ipv6CIDRRegex, JSONUtils, JSON_EDITOR_OPTIONS, JsonArrayValidatorDirective, JsonKeyStringValueValidatorDirective, JsonObjectValidatorDirective, JwtResponse, K8ClusterAddOns, K8ClusterConfig, K8ClusterUpgradeNodeAction, K8ClusterUpgradeNodeActionType, K8ClusterUpgradeRequest, K8ClusterUpgradeStatus, K8ClusterVersions, K8S_SECRETS, K8sPlatform, K8sVendor, KeyStringValue, KeyStringValueUpdateRequest, KeyValConfigFieldComponent, KeyValueConfig, KeyValueConfigPair, KeyValuePair, KubeConfigFile, KubeconfigDownloadService, LBType, LabelRefDirective, ListCardComponent, ListCardGridComponent, ListHeaderComponent, ListPageHeaderComponent, ListQueryStateService, ListStatCardComponent, ListStatsComponent, LogAnalyticsWorkSpace, MarkdownEditModalComponent, MarkdownEditModalService, MarkdownEditorComponent, MessageService, MiniCardComponent, MixpanelService, NAV_HEADER_ITEM, NameUtils, NavBackService, NgbTimeNativeDateAdapter, NotEqualValidatorDirective, NotExistsCaseValidatorDirective, NotExistsValidatorDirective, NotStartsWithCaseValidatorDirective, NotStartsWithValidatorDirective, OnPremConfig, OnPremEKSConfig, OnPremK8Config, OracleRegionOptions, OrderByPipe, PasswordFieldComponent, PortRangeValidatorDirective, PrettyJsonPipe, PrettyYamlPipe, ProtoColAndPorts, ProviderCredentialData, READ_ONLY_INI_EDITOR_OPTIONS, READ_ONLY_JSON_EDITOR_OPTIONS, READ_ONLY_XML_EDITOR_OPTIONS, REMOTE_AIAutomationService, REMOTE_AuthNZService, REMOTE_CanvasRendererRegistry, REMOTE_CoreConfigService, REMOTE_DuploHttpClient, REMOTE_ENTRY_CACHE_TAG, REMOTE_SystemFeatures, REMOTE_UserSession, RecoveryServicesVault, Reference, RefreshTimerService, RenderFileComponent, RenderFilePreviewModalComponent, ResourceTypePrefix, RestrictElementAccess, RestrictElementAccessModule, RetentionDuration, RetentionPolicy, RippleEffectDirective, RootImportsModule, SGSourceInfos, SUCCESS_REPORTER, SUPPORTED_FILE_EXTENSIONS, SafePipe, SchedulePolicy, ScrollableNavTabComponent, SearchAndPaginationParams$1 as SearchAndPaginationParams, SearchAndPaginationResult, SearchableDatatableComponent, SearchableDatatableExtraAction, SearchableDatatableModule, SecurityGroupRule, SecurityGroupRuleRequest, SelectOption, ServersideDatatableComponent, ServersideDatatableExtraAction, ServersideDatatableModule, ServersideDatatableStatus, ServiceDetail, ServiceProtocolAndPorts, SessionDurationOption, SharedAlertsService, SharedFormsModule, SidecardComponent, SpinnerComponent, StatCardComponent, StatGridComponent, StatusWithStyleComponent, StringUtils, StripHtmlPipe, SubDestroyService, Subnet, SubscriptionsGuard, SupportedFileType, SystemConfigs, SystemFeatures, SystemSettingGuard, TENANT_AI_STUDIO_ENABLED, TENANT_CONSTS, TENANT_DEFAULT_CONFIGS, TENANT_FEATURE_AUTO_REBOOT_EC2_DISCONNECTED, TENANT_FEATURE_AUTO_REBOOT_EC2_STATUS_CHECK, TENANT_FEATURE_AWS_IOT_THING_PREFIX, TENANT_FEATURE_AWS_IOT_TOPIC_PREFIX, TENANT_FEATURE_AZURE_ALLOW_PUBLIC_NETWORK_DB_AND_CACHE, TENANT_FEATURE_CA_OVERPROVISIONING, TENANT_FEATURE_DENY_OPEN_ACCESS_TO_PUBLIC_LB, TENANT_FEATURE_ENABLE_AWS_IOT, TENANT_FEATURE_HEADER_COLOR, TENANT_FEATURE_MAXIMUM_K8S_SESSION_DURATION, TENANT_FEATURE_MAXIMUM_SESSION_DURATION, TENANT_FEATURE_SET_SNS_TOPIC_ALERTS, TENANT_PLATFORM_SERVICES_CONFIGS, TEXT_EDITOR_OPTIONS, TabService, TableHelpDirective, TableStatus$1 as TableStatus, TenantAccessGrant, TenantAccessGrantee, TenantAccessPolicy, TenantAccessQuery, TenantAlertConfig, TenantExtConnSgRuleUpdate, TenantFeatures, TenantHeaderColor, TenantMetadataUpdateReq, TenantNetworkSecurityRule, TenantNetworkSecurityRuleProtocol, TenantNetworkSecurityRuleSource, TenantNetworkSecurityRuleSourceType, TenantPlanKmsKeyInfo, TenantTagRequest, TenantTags, TenantUserAccess, TimeAgoPipe, TokenPaginatedDatatableComponent, TokenPaginatedDatatableModule, UIConfigPipe, UnicodeValidatorDirective, UpdateUserAccessRequest, UpdateUserVPNInfo, UseParentFormDirective, UserApiToken, UserAuthConfig, UserConstants, UserCredential, UserDevspace, UserPrincipal, UserProvider, UserPublicKey, UserRole, UserRoleInfo, UserRoleSource, UserRoles, UserSession, UserTenant, UserTenantAccess, UserTenantNames, UserTokenResponse, UserUpdateRequest, UserVPNConfig, UsersInfo, ValidationErrorsDirective, ValidationStateDirective, VaultBackupPolicy, VbpProperties, ViewDataModalComponent, ViewDataModalRef, ViewDataModalService, ViewHeaderCardComponent, ViewJsonComponent, ViewJsonModalComponent, ViewJsonModalRef, ViewJsonModalService, ViewWithSidecardsComponent, ViewYamlComponent, VmSize, VpcEndpoint, WeeklySchedule, WorkspaceSystemSettingsDataSource, WorkspaceSystemSettingsService, XML_EDITOR_OPTIONS, XTERM_CLEAR_COMMAND, XTERM_TERMINAL_CONFIG, XmlValidationDirective, XtermBlockComponent, XtermCommand, XtermSocketComponent, XtermSocketService, YAML_EDITOR_OPTIONS, YamlMapValidationDirective, YamlSnippetEditorComponent, YamlUtils, YamlValidationDirective, YamlValueValidationDirective, activeStatusBadges, aiSettingBoolValueStyleMap, aiSettingTypeStyleMap, applyCardGridFilterSort, asBool, asJson, asNumber, asString, capBadges, closeModalsOnNavigation, cloudToK8sName, convertKeysToLowerCase, convertUtcToLocalDate, convertUtcToLocalISO, createInsensitivePathGetter, downloadFileByUrl, downloadJsonAsFile, expandableListTone, extractErrorMessage, formatNumberWithK, formatPodStatus, generateHttpOptions, generateUniqueId, getDiffOps, getExt, getFileLang, getFileRenderKind, getFileType, getLabelFromSysConfig, getMonacoLanguage, isNotEmptyValue, isPreviewSupported, listCardInitial, listCardInitials, markedOptionsFactory, openLinkInNewTab, parseSettingValue, podStatusBadgeStyles, redirectToParentOnError, removeEmptyProperties, resolveAvatarColor, roundToTwoDecimals, scrollParentToChild, scrollToBottomElement, sendToHelpDesk, serviceEndpointTypes, statusMap, subnetTypes, withCacheTag };
export type { AiMenuDeps, AiMenuRemote, AiSuiteSetting, AiSuiteSettingName, AiSuiteSettingOption, AnalyticsConsentState, AnyObject, ApiListResponse, ApiListResponseWithPagination, ApiSingleResponse, ApiTokenCreateResponse, ApiTokenSettings, AppTile, AzureNatGatewayLocation, AzureNatGatewayPublicIPAddress, AzureNatGatewaySubnet, AzureNatGatewayUpdateRequest, AzureResourceId, AzureResourceType, BadgeOverflow, Breadcrumb, BreadcrumbLink, CanvasDoc, CanvasRendererDescriptor, CardGridSortField, CardGridSortOption, CommonLibConfig, ConfirmationModalOptions, CoreConfig, CoreConfigLayoutSkin, CoreMenu, CoreMenuItem, CreateApiTokenRequest, CustomDataSpec, DataViewFormat, DeepPartial, DeleteConfirmationModalOptions, DetailBadge, DetailBadgeKind, DetailCalloutKind, DetailCountRow, DetailKvRow, DetailTimelineEvent, DetailTimelineState, DnsEntry, DnsOptions, DocDiffOp, DuploCiClientEndpoint, EditMode, EditableCustomData, EntityFileEntry, EntityFilesContract, EnumMapName, EnumMapOf, EnumMapOfString, EnumSelectOption, ErrorMessage, ErrorReporter, ExpandableListContext, ExpandableListMark, ExpandableListRow, ExpandableListTone, FileBadge, FileBinaryLoader, FileContentLoader, FileEditorConfigOpts, FileEditorContentChange, FileEditorSaveEvent, FileLangId, FileNode, FileNodeType, FileRenderKind, FileTreeAction, FileTreeActionEvent, FileTreeActionTheme, FilterChangeEvent, FilterPill, FolderLoader, GenericFormInputType, GkeReleaseChannel, GkeServerConfig, IDocumentEditor, InstantRPDetails, JsonEditorSize, KubeConfigCluster, KubeConfigClusterEntry, KubeConfigContext, KubeConfigContextEntry, KubeConfigUser, KubeConfigUserEntry, LastError, ListCardAction, ListCardMark, ListQueryDefaults, ListQueryState, ListStatTone, LoadPageEvent, Locale, LogAnalyticsConfig, MarkdownEditModalOptions, MarkdownEditorMode, MenuBuilderFn, NumberSelectOption, PagedData, PrivateDnsDetails, PropertiesSku, RecoveryVaultConfig, RemoteMenuBuilder, RemoteMenuExtensionNode, RemoteMenuExtensionTree, RsvProperties, SecurityGroup, SecurityGroupIdentifier, SelectOptions, ServiceTypeDetail, Sku, StatDotKind, StringSelectOption, SuccessReporter, TabCloseRequest, TenantFeaturesMap, TokenPaginatedPage, UserSettings, ValueObj, ViewDataModalOptions, ViewHeaderAction, ViewJsonModalOptions, Vnet, WorkspaceSettingOpts, YamlSnippet };
//# sourceMappingURL=duplocloud-internal-ng-common-lib.d.ts.map
